<?php

namespace PEBKAC404\Backup;

const PILOT_DROPBOX_FOLDER = '/PEBKAC Backup Pilot';

function valid_backup_dropbox_folder(string $folder): bool {
    return preg_match('~^/[^/]+(?:/[^/]+)*$~uD', $folder) === 1
        && !preg_match('~[\x00-\x1f\x7f\\\\]~', $folder)
        && !array_intersect(explode('/', $folder), ['.', '..']);
}

/** Resolve the saved destination inside the app folder. An empty setting uses the pilot default. */
function backup_dropbox_folder(array $plan): string {
    $folder = $plan['folder'] ?? '';
    if ($folder === '') {
        return PILOT_DROPBOX_FOLDER;
    }
    if (!is_string($folder) || !valid_backup_dropbox_folder($folder)) {
        throw new \RuntimeException('The saved Dropbox folder is invalid.');
    }
    return $folder;
}

/** Only the two approved pilot sites have a Dropbox filename prefix. */
function pilot_site_slug(string $site): string {
    return [
        'https://securitylab.subdiv.net' => 'securitylab',
        'https://pebkac404.com' => 'pebkac404',
    ][$site] ?? '';
}

function pilot_backup_path_prefix(string $site, ?string $component = null, string $folder = PILOT_DROPBOX_FOLDER): ?string {
    $slug = pilot_site_slug($site);
    if ($slug === '' || !valid_backup_dropbox_folder($folder) || ($component !== null && !isset(SNAPSHOT_COMPONENT_DIRECTORIES[$component]))) {
        return null;
    }
    return $folder . '/' . $slug . '-' . ($component === null ? '' : $component . '-');
}

function pilot_backup_base(string $site, string $job_id, ?string $component = null, string $folder = PILOT_DROPBOX_FOLDER): string {
    $prefix = pilot_backup_path_prefix($site, $component, $folder);
    if ($prefix === null || !preg_match('/^[a-f0-9]{32}$/D', $job_id)) {
        throw new \RuntimeException('The pilot site or backup identifier is invalid.');
    }
    return $prefix . $job_id;
}

function pilot_backup_object_path(string $site, string $path, ?string $component = null, string $folder = PILOT_DROPBOX_FOLDER): bool {
    $prefix = pilot_backup_path_prefix($site, $component, $folder);
    return $prefix !== null && strpos($path, $prefix) === 0
        && preg_match('/^[a-f0-9]{32}\.(?:zip|manifest\.json)$/D', substr($path, strlen($prefix))) === 1;
}

function pilot_recovery_pair(string $site, string $archive, string $manifest, ?string $component = null, string $folder = PILOT_DROPBOX_FOLDER): bool {
    return substr($archive, -4) === '.zip' && pilot_backup_object_path($site, $archive, $component, $folder)
        && $manifest === substr($archive, 0, -4) . '.manifest.json';
}
