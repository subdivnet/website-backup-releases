<?php

namespace PEBKAC404\Backup;

if (!defined('ABSPATH')) {
    exit;
}

const HOST_CHECK_OPTION = 'pebkac_backup_host_check';

/** Use PHP's temporary volume only if it is outside the public site trees. */
function backup_temp_parent(): string {
    $temp = realpath(sys_get_temp_dir());
    $root = realpath(ABSPATH);
    $document_root = (string) ($_SERVER['DOCUMENT_ROOT'] ?? '');
    $document = $document_root === '' ? false : realpath($document_root);
    if ($temp === false || $root === false || ($document_root !== '' && $document === false)
        || !is_dir($temp) || !is_writable($temp)) {
        return '';
    }
    $normalize = static function (string $path): string { return rtrim(str_replace('\\', '/', $path), '/') . '/'; };
    foreach (array_filter([$root, $document]) as $public_root) {
        if (stripos($normalize($temp), $normalize($public_root)) === 0) {
            return '';
        }
    }
    return $temp;
}

function backup_host_limits(): array {
    $temp = backup_temp_parent();
    $free = $temp === '' ? false : @disk_free_space($temp);
    return [
        'staging_free' => $free === false ? null : $free,
        'memory' => ini_get('memory_limit'),
        'execution' => ini_get('max_execution_time'),
        'zip' => class_exists(\ZipArchive::class),
    ];
}

/** Count candidate files without reading them, with both a time and an entry cap. */
function count_backup_files(array $roots, int $limit = 20000, float $seconds = 1.5): array {
    $deadline = microtime(true) + $seconds;
    $files = 0;
    $entries = 0;
    $complete = true;
    foreach ($roots as $root) {
        if (is_link($root)) {
            $complete = false;
            continue;
        }
        if (!is_dir($root)) {
            continue;
        }
        try {
            $tree = new \RecursiveIteratorIterator(new \RecursiveDirectoryIterator($root, \FilesystemIterator::SKIP_DOTS), \RecursiveIteratorIterator::SELF_FIRST);
            foreach ($tree as $entry) {
                if (++$entries > $limit || microtime(true) >= $deadline) {
                    return ['files' => $files, 'complete' => false];
                }
                if ($entry->isLink()) {
                    $complete = false;
                } elseif ($entry->isFile()) {
                    ++$files;
                }
            }
        } catch (\UnexpectedValueException $error) {
            $complete = false;
        }
    }
    return ['files' => $files, 'complete' => $complete];
}

add_action('admin_post_pebkac_backup_host_check', static function () {
    if (($_SERVER['REQUEST_METHOD'] ?? '') !== 'POST' || !current_user_can('manage_options')) {
        wp_die('An administrator must run the host check.', '', ['response' => 403]);
    }
    check_admin_referer('pebkac_backup_host_check');
    $roots = [ABSPATH . 'wp-admin', ABSPATH . 'wp-includes'];
    foreach (['plugins', 'mu-plugins', 'themes', 'uploads', 'languages'] as $component) {
        $roots[] = WP_CONTENT_DIR . '/' . $component;
    }
    $result = count_backup_files($roots);
    $result['checked_at'] = time();
    update_option(HOST_CHECK_OPTION, $result, false);
    wp_safe_redirect(admin_url('admin.php?page=pebkac-backup'), 303);
    exit;
});

function render_host_check(): void {
    $limits = backup_host_limits();
    $count = get_option(HOST_CHECK_OPTION, []);
    ?>
    <section class="notice inline <?php echo $limits['zip'] && $limits['staging_free'] !== null ? 'notice-info' : 'notice-warning'; ?>">
        <h2>Host readiness</h2>
        <details><summary>Show details</summary>
            <p>Temporary backup space: <?php echo esc_html($limits['staging_free'] === null ? 'Unavailable' : size_format($limits['staging_free'], 1)); ?>.</p>
            <p>PHP memory limit: <?php echo esc_html((string) $limits['memory']); ?>. Time limit: <?php echo esc_html($limits['execution'] === '0' ? 'No PHP limit' : $limits['execution'] . ' seconds'); ?>. ZIP support: <?php echo $limits['zip'] ? 'Available' : 'Unavailable'; ?>.</p>
            <?php if (isset($count['files'], $count['checked_at'])) : ?>
                <p><?php echo esc_html(($count['complete'] ? '' : 'At least ') . number_format_i18n($count['files']) . ' files checked in standard WordPress folders on ' . wp_date('M j, Y H:i T', $count['checked_at'])); ?>.</p>
            <?php else : ?><p>File count has not been checked yet.</p><?php endif; ?>
            <form action="<?php echo esc_url(admin_url('admin-post.php')); ?>" method="post">
                <input type="hidden" name="action" value="pebkac_backup_host_check">
                <?php wp_nonce_field('pebkac_backup_host_check'); ?>
                <button type="submit" class="button">Check file count</button>
            </form>
        </details>
    </section>
    <?php
}
