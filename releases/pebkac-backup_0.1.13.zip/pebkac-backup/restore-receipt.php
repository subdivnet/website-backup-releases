<?php

namespace PEBKAC404\Backup;

if (!defined('ABSPATH')) {
    exit;
}

/** Bind a completed local test to the current off-site copy. Caller holds the backup lock. */
function accept_restore_receipt($receipt, array $backup, int $now): array {
    $checked = $receipt['verified_at'] ?? null;
    if (!is_array($receipt) || !isset($backup['manifest_sha256'])
        || ($receipt['method'] ?? null) !== 'isolated_wordpress'
        || (array_key_exists('site', $receipt) && $receipt['site'] !== ($backup['site'] ?? null))
        || ($receipt['archive_sha256'] ?? null) !== $backup['archive_sha256']
        || ($receipt['manifest_sha256'] ?? null) !== $backup['manifest_sha256']
        || !is_int($checked) || $checked < $backup['offsite_verified_at'] || $checked > $now
        || $checked < ($backup['restore']['verified_at'] ?? 0)
        || ($receipt['wordpress_booted'] ?? null) !== true
        || ($receipt['home_page_rendered'] ?? null) !== true) {
        throw new \RuntimeException('This receipt does not match a completed test of the current Dropbox backup.');
    }

    $backup['restore'] = [
        'archive_sha256' => $backup['archive_sha256'],
        'method' => 'isolated_wordpress',
        'verified_at' => $checked,
    ];
    return $backup;
}

const COMPONENT_RESTORE_OPTION = 'pebkac_backup_component_restore';

function component_restore_chain_fingerprints(array $chain): array {
    return array_map(static function (array $record): array {
        return ['archive_sha256' => $record['archive_sha256'], 'manifest_sha256' => $record['manifest_sha256']];
    }, $chain);
}

/** Summarize the last recorded file check against the currently verified component chain. */
function component_restore_check_label(string $site, array $chain, $saved, int $now): string {
    $waiting = 'Waiting for a restore check.';
    $checked = $saved['verified_at'] ?? null;
    $digest = $saved['chain_sha256'] ?? null;
    if ($chain === [] || ($saved['site'] ?? null) !== $site || ($saved['method'] ?? null) !== 'isolated_component_staging'
        || !is_int($checked) || $checked < 1 || $checked > $now || !is_string($digest) || !preg_match('/^[a-f0-9]{64}$/D', $digest)) {
        return $waiting;
    }
    $current = hash('sha256', json_encode(component_restore_chain_fingerprints($chain), JSON_THROW_ON_ERROR));
    $date = wp_date('M j, Y H:i T', $checked);
    if (hash_equals($current, $digest)) {
        return $checked >= $chain[count($chain) - 1]['offsite_verified_at'] ? 'Isolated file check passed on ' . $date . '.' : $waiting;
    }
    return 'Latest backup is waiting for a check. Earlier file check passed on ' . $date . '.';
}

/** Store a component staging result separately from the immutable off-site backup chain. Caller holds the backup lock. */
function record_component_restore_receipt(array $receipt, string $site, int $now): void {
    $component = $receipt['component'] ?? null;
    $checked = $receipt['verified_at'] ?? null;
    $count = $receipt['file_count'] ?? null;
    if (($receipt['kind'] ?? null) !== 'component_restore' || ($receipt['method'] ?? null) !== 'isolated_component_staging'
        || ($receipt['site'] ?? null) !== $site || !is_string($component) || !isset(COMPONENTS[$component])
        || !is_int($checked) || $checked > $now || !is_int($count) || $count < 0 || $count > SNAPSHOT_MAX_FILES
        || ($component === 'database' && $count !== 1)) {
        throw new \RuntimeException('This receipt does not match a completed component restore check.');
    }
    $history = get_option(COMPONENT_RECOVERY_STATE_OPTION, []);
    $chain = is_array($history) ? component_recovery_chain($site, $component, $history, $now) : [];
    $fingerprints = component_restore_chain_fingerprints($chain);
    if ($chain === [] || ($receipt['chain'] ?? null) !== $fingerprints || $checked < $chain[count($chain) - 1]['offsite_verified_at']) {
        throw new \RuntimeException('This receipt does not match the current verified component backup chain.');
    }
    $saved = get_option(COMPONENT_RESTORE_OPTION, []);
    if (!is_array($saved) || $checked < ($saved[$component]['verified_at'] ?? 0)) {
        throw new \RuntimeException('This receipt would replace a newer component restore check.');
    }
    $result = [
        'site' => $site, 'method' => 'isolated_component_staging', 'verified_at' => $checked, 'file_count' => $count,
        'archive_path' => $chain[count($chain) - 1]['archive_path'],
        'chain_sha256' => hash('sha256', json_encode($fingerprints, JSON_THROW_ON_ERROR)),
    ];
    if (($saved[$component] ?? null) !== $result) {
        $saved[$component] = $result;
        if (!update_option(COMPONENT_RESTORE_OPTION, $saved, false)) {
            throw new \RuntimeException('Could not save the component restore check.');
        }
    }
}

add_action('admin_post_pebkac_backup_restore_receipt', __NAMESPACE__ . '\\save_restore_receipt');

function save_restore_receipt(): void {
    if (!current_user_can('manage_options') || !is_ssl() || ($_SERVER['REQUEST_METHOD'] ?? '') !== 'POST') {
        wp_die('Administrator access over HTTPS is required.', '', ['response' => 403]);
    }
    check_admin_referer('pebkac_backup_restore_receipt');
    $bytes = $_POST['restore_receipt'] ?? null;
    if (!is_string($bytes) || strlen($bytes) > 4096) {
        wp_die('Enter a valid restore test receipt.', '', ['response' => 400]);
    }
    $receipt = json_decode(wp_unslash($bytes), true, 8);
    try {
        with_backup_job_lock(backup_job_root(true), static function () use ($receipt): void {
            $now = time();
            if (($receipt['kind'] ?? null) === 'component_restore') {
                record_component_restore_receipt($receipt, home_url(), $now);
                return;
            }
            $backup = verified_evidence(get_option(EVIDENCE_OPTION, []), home_url(), $now);
            $updated = accept_restore_receipt($receipt, $backup, $now);
            remember_verified_backups([$updated], home_url(), $now);
            if ($updated !== $backup && !update_option(EVIDENCE_OPTION, $updated, false)) {
                throw new \RuntimeException('Could not save the restore test result.');
            }
        });
    } catch (\RuntimeException $error) {
        wp_die(esc_html($error->getMessage()), '', ['response' => 409, 'back_link' => true]);
    }
    wp_safe_redirect(admin_url('admin.php?page=pebkac-backup&tab=overview'));
    exit;
}

function render_restore_receipt(): void {
    if (!is_ssl()) {
        return;
    }
    $site = home_url();
    $now = time();
    $available = isset(verified_evidence(get_option(EVIDENCE_OPTION, []), $site, $now)['manifest_sha256']);
    if (!$available) {
        $history = get_option(COMPONENT_RECOVERY_STATE_OPTION, []);
        foreach (is_array($history) ? array_keys(COMPONENTS) : [] as $component) {
            try {
                if (component_recovery_chain($site, $component, $history, $now) !== []) {
                    $available = true;
                    break;
                }
            } catch (\RuntimeException $error) {
                continue;
            }
        }
    }
    if (!$available) {
        return;
    }
    ?>
    <details>
        <summary>Record an isolated restore test</summary>
        <form method="post" action="<?php echo esc_url(admin_url('admin-post.php')); ?>">
            <input type="hidden" name="action" value="pebkac_backup_restore_receipt">
            <?php wp_nonce_field('pebkac_backup_restore_receipt'); ?>
            <p><label for="pebkac-backup-receipt">Paste the receipt from a completed site restore test or component restore check.</label></p>
            <textarea id="pebkac-backup-receipt" name="restore_receipt" rows="4" class="large-text code" maxlength="4096" required></textarea>
            <?php submit_button('Save restore test result'); ?>
        </form>
    </details>
    <?php
}
