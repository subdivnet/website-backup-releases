<?php

namespace PEBKAC404\Backup;

if (!defined('ABSPATH')) {
    exit;
}

require_once __DIR__ . '/snapshot-archive.php';
require_once __DIR__ . '/backup-incremental.php';

/** A site-bound path under a non-public PHP temporary directory. */
function wordpress_capture_directory(string $parent, string $site, string $id): string {
    if ($parent === '' || !preg_match('/^[0-9a-f]{32}$/D', $id)) {
        throw new \RuntimeException('Private backup staging is unavailable.');
    }
    return $parent . DIRECTORY_SEPARATOR . 'website-backup-' . substr(hash('sha256', $site), 0, 12) . '-' . $id;
}

function start_wordpress_capture(string $directory, $wpdb, float $seconds): void {
    $free = @disk_free_space(dirname($directory));
    if ($free === false || $free < 32 * 1024 * 1024 || !@mkdir($directory, 0700)) {
        throw new \RuntimeException('Could not reserve private temporary backup space.');
    }
    $path = $directory . '/database.sql';
    $stream = @fopen($path, 'xb');
    if ($stream === false) {
        throw new \RuntimeException('Could not reserve the database export.');
    }
    try {
        export_wordpress_database($wpdb, $stream, $seconds);
        if (!fflush($stream)) {
            throw new \RuntimeException('Could not flush the database export.');
        }
    } catch (\Throwable $error) {
        fclose($stream);
        @unlink($path);
        throw $error;
    }
    fclose($stream);
}

function require_wordpress_capture_directory(string $directory, string $root, string $content): void {
    if (!is_dir($directory) || is_link($directory) || (DIRECTORY_SEPARATOR === '/' && (fileperms($directory) & 0077) !== 0)
        || realpath($content) === false || realpath($content) !== realpath(rtrim($root, '/\\') . '/wp-content')) {
        throw new \RuntimeException('The pilot requires a private staging directory and standard WordPress content folders.');
    }
}

function finish_wordpress_capture(string $directory, string $root, string $content, float $deadline, ?string $component = null): array {
    require_wordpress_capture_directory($directory, $root, $content);
    $database = $directory . '/database.sql';
    $manifest = capture_snapshot($root, $database, $directory . '/backup.zip', $deadline, $component);
    $json = json_encode($manifest, JSON_UNESCAPED_SLASHES);
    if ($json === false || file_put_contents($directory . '/manifest.json', $json, LOCK_EX) !== strlen($json)) {
        throw new \RuntimeException('Could not save the capture manifest.');
    }
    if (($component === null || $component === 'database') && !@unlink($database)) {
        throw new \RuntimeException('Could not clear the temporary database export.');
    }
    return $manifest;
}


/** Stage a delta from a verified file inventory without building a second full ZIP. */
function finish_wordpress_incremental_capture(string $directory, string $root, string $content, array $baseline, float $deadline): array {
    require_wordpress_capture_directory($directory, $root, $content);
    $archive = $directory . '/backup.zip';
    $sidecar = $directory . '/manifest.json';
    if (file_exists($sidecar) || is_link($sidecar) || !is_string($baseline['component'] ?? null)) {
        throw new \RuntimeException('Choose a fresh staging directory and a verified file component.');
    }
    $current = scan_incremental_file_inventory($root, $baseline['component'], $deadline);
    $delta = plan_incremental_file_backup($baseline, $current);
    $changed_bytes = array_sum(array_column($delta['changed'], 'size'));
    $free = @disk_free_space($directory);
    if ($free === false || $free < 2 * $changed_bytes + 16 * 1024 * 1024) {
        throw new \RuntimeException('Insufficient private staging space for the incremental backup.');
    }
    $manifest = package_incremental_file_backup($root, $baseline, $delta, $archive, $deadline);
    $stream = false;
    try {
        snapshot_deadline($deadline);
        $bytes = json_encode($manifest, JSON_THROW_ON_ERROR | JSON_UNESCAPED_SLASHES);
        if (strlen($bytes) > SNAPSHOT_MAX_MANIFEST_BYTES || ($stream = @fopen($sidecar, 'xb')) === false
            || fwrite($stream, $bytes) !== strlen($bytes) || !fflush($stream)) {
            throw new \RuntimeException('Could not save the incremental backup manifest.');
        }
        fclose($stream);
    } catch (\Throwable $error) {
        if (is_resource($stream)) {
            fclose($stream);
            @unlink($sidecar);
        }
        @unlink($archive);
        throw $error;
    }
    return $manifest;
}
