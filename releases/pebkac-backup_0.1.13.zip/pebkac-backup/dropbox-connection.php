<?php

namespace PEBKAC404\Backup;

if (!defined('ABSPATH')) {
    exit;
}

const DROPBOX_SCOPES = 'files.metadata.read files.content.read files.content.write';
const DROPBOX_CREDENTIAL_OPTION = 'pebkac_backup_dropbox_connection';

const DROPBOX_PEBKAC404_CALLBACK_REGISTERED = false;

function dropbox_pilot_callback(string $site): ?string {
    if (!in_array($site, ['https://securitylab.subdiv.net', 'https://pebkac404.com'], true)) {
        return null;
    }
    return $site . '/wp-admin/admin-post.php?action=pebkac_backup_dropbox_callback';
}

function dropbox_pilot_callback_ready(string $site, string $callback, bool $second_registered = DROPBOX_PEBKAC404_CALLBACK_REGISTERED): bool {
    return $callback === dropbox_pilot_callback($site)
        && ($site === 'https://securitylab.subdiv.net' || ($site === 'https://pebkac404.com' && $second_registered));
}

function dropbox_app_key(): string {
    // Keep the second callback disabled until its exact URI has been registered and read back.
    return dropbox_pilot_callback_ready(home_url(), dropbox_callback_url()) ? 'cnsewl5o3156prm' : '';
}

function dropbox_can_encrypt(): bool {
    return defined('AUTH_KEY') && defined('AUTH_SALT') && is_string(AUTH_KEY) && is_string(AUTH_SALT)
        && strlen(AUTH_KEY) >= 32 && strlen(AUTH_SALT) >= 32 && AUTH_KEY !== AUTH_SALT
        && function_exists('openssl_encrypt') && function_exists('openssl_decrypt')
        && in_array('aes-256-gcm', openssl_get_cipher_methods(), true);
}

function dropbox_encryption_key(): string {
    return hash_hmac('sha256', 'website-backup/dropbox/v1', AUTH_KEY . "\0" . AUTH_SALT, true);
}

function dropbox_saved_refresh_token(string $app): string {
    if ($app === '' || !dropbox_can_encrypt()) {
        return '';
    }
    $record = get_option(DROPBOX_CREDENTIAL_OPTION, '');
    $sealed = is_string($record) && strlen($record) <= 16384 ? base64_decode($record, true) : false;
    if ($sealed === false || strlen($sealed) < 29) {
        return '';
    }
    $token = openssl_decrypt(substr($sealed, 28), 'aes-256-gcm', dropbox_encryption_key(), OPENSSL_RAW_DATA,
        substr($sealed, 0, 12), substr($sealed, 12, 16), $app . '|' . dropbox_callback_url());
    return dropbox_valid_token($token) ? $token : '';
}

function dropbox_valid_token($token): bool {
    return is_string($token) && strlen($token) >= 16 && strlen($token) <= 8192 && !preg_match('/[\x00-\x20\x7f]/', $token);
}

function dropbox_callback_url(): string {
    return admin_url('admin-post.php?action=pebkac_backup_dropbox_callback', 'https');
}

function dropbox_authorize_url(string $app, string $callback, string $state, string $verifier): string {
    $challenge = rtrim(strtr(base64_encode(hash('sha256', $verifier, true)), '+/', '-_'), '=');
    return 'https://www.dropbox.com/oauth2/authorize?' . http_build_query([
        'client_id' => $app, 'redirect_uri' => $callback, 'response_type' => 'code',
        'token_access_type' => 'offline', 'scope' => DROPBOX_SCOPES,
        'state' => $state, 'code_challenge_method' => 'S256', 'code_challenge' => $challenge,
    ], '', '&', PHP_QUERY_RFC3986);
}

function dropbox_token_request(array $body): array {
    $response = wp_remote_post('https://api.dropboxapi.com/oauth2/token', [
        'body' => $body, 'redirection' => 0, 'sslverify' => true, 'timeout' => 20, 'limit_response_size' => 16384,
    ]);
    if (is_wp_error($response) || wp_remote_retrieve_response_code($response) !== 200) {
        throw new \RuntimeException('Dropbox did not authorize the backup connection.');
    }
    $payload = json_decode(wp_remote_retrieve_body($response), true);
    if (!is_array($payload) || !dropbox_valid_token($payload['access_token'] ?? null)) {
        throw new \RuntimeException('Dropbox returned an incomplete authorization.');
    }
    return $payload;
}

/** The backup worker refreshes access without persisting the short-lived token. */
function dropbox_connected_access_token(): string {
    $app = dropbox_app_key();
    $refresh = dropbox_saved_refresh_token($app);
    if ($refresh === '') {
        throw new \RuntimeException('Connect the Dropbox app folder in Website Backup first.');
    }
    return dropbox_token_request(['grant_type' => 'refresh_token', 'refresh_token' => $refresh, 'client_id' => $app])['access_token'];
}

function save_dropbox_connection(string $app, string $token): void {
    if ($app === '' || !dropbox_can_encrypt() || !dropbox_valid_token($token)) {
        throw new \RuntimeException('Dropbox authorization could not be protected.');
    }
    $nonce = random_bytes(12);
    $ciphertext = openssl_encrypt($token, 'aes-256-gcm', dropbox_encryption_key(), OPENSSL_RAW_DATA,
        $nonce, $tag, $app . '|' . dropbox_callback_url(), 16);
    if ($ciphertext === false || !add_option(DROPBOX_CREDENTIAL_OPTION, base64_encode($nonce . $tag . $ciphertext), '', false)) {
        throw new \RuntimeException('The private Dropbox connection could not be saved.');
    }
}

function dropbox_admin_redirect(string $status): void {
    wp_safe_redirect(admin_url('admin.php?page=pebkac-backup&tab=setup&dropbox=' . $status), 303);
    exit;
}

function dropbox_require_admin(): void {
    if (!is_ssl() || !current_user_can('manage_options') || is_multisite()) {
        wp_die('Dropbox setup requires a signed-in administrator over HTTPS.', '', ['response' => 403]);
    }
    nocache_headers();
    header('Referrer-Policy: no-referrer');
}

add_action('admin_post_pebkac_backup_dropbox_connect', static function () {
    dropbox_require_admin();
    if (($_SERVER['REQUEST_METHOD'] ?? '') !== 'POST') {
        wp_die('Use the Connect Dropbox button.', '', ['response' => 405]);
    }
    check_admin_referer('pebkac_backup_dropbox_connect');
    $app = dropbox_app_key();
    if ($app === '' || !dropbox_can_encrypt() || get_option(DROPBOX_CREDENTIAL_OPTION, false) !== false) {
        dropbox_admin_redirect('unavailable');
    }
    $state = bin2hex(random_bytes(32));
    $verifier = bin2hex(random_bytes(32));
    $callback = dropbox_callback_url();
    $pending = ['user' => get_current_user_id(), 'app' => $app, 'site' => home_url(), 'verifier' => $verifier];
    if (!set_transient('pebkac_dbx_' . hash('sha256', $state), $pending, 600)) {
        dropbox_admin_redirect('failed');
    }
    wp_redirect(dropbox_authorize_url($app, $callback, $state, $verifier), 303);
    exit;
});

add_action('admin_post_pebkac_backup_dropbox_callback', static function () {
    dropbox_require_admin();
    $state = $_GET['state'] ?? '';
    if (!is_string($state) || !preg_match('/^[a-f0-9]{64}$/D', $state)) {
        dropbox_admin_redirect('failed');
    }
    $name = 'pebkac_dbx_' . hash('sha256', $state);
    $pending = get_transient($name);
    $app = dropbox_app_key();
    if (!is_array($pending) || ($pending['user'] ?? null) !== get_current_user_id()
        || ($pending['site'] ?? null) !== home_url() || ($pending['app'] ?? null) !== $app
        || !delete_transient($name) || $app === '' || !dropbox_can_encrypt() || get_option(DROPBOX_CREDENTIAL_OPTION, false) !== false) {
        dropbox_admin_redirect('failed');
    }
    $code = $_GET['code'] ?? '';
    if (!is_string($code) || !dropbox_valid_token($code)) {
        dropbox_admin_redirect('failed');
    }
    try {
        $tokens = dropbox_token_request([
            'code' => $code, 'grant_type' => 'authorization_code', 'client_id' => $app,
            'redirect_uri' => dropbox_callback_url(), 'code_verifier' => $pending['verifier'],
        ]);
        if (!dropbox_valid_token($tokens['refresh_token'] ?? null)) {
            throw new \RuntimeException('Dropbox did not grant background access.');
        }
        save_dropbox_connection($app, $tokens['refresh_token']);
    } catch (\RuntimeException $error) {
        dropbox_admin_redirect('failed');
    }
    dropbox_admin_redirect('connected');
});
