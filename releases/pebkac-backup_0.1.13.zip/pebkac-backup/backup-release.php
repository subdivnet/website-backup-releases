<?php

namespace PEBKAC404\Backup;

const BACKUP_RELEASE_SLUG = 'pebkac-backup';
const BACKUP_PUBLIC_RELEASE_ORIGIN = 'https://raw.githubusercontent.com/subdivnet/website-backup-releases/refs/heads/main';
const BACKUP_RELEASE_MAX_BYTES = 10 * 1024 * 1024;

function valid_backup_release_origin(string $origin): bool {
    return $origin === BACKUP_PUBLIC_RELEASE_ORIGIN || preg_match('~^https://[a-z0-9.-]+$~D', $origin) === 1;
}

/** Verify a bounded, signed release using an independently configured public key and HTTPS origin. */
function verify_backup_release(string $payload, string $signature, string $public_key, string $origin, string $installed, int $now): ?array {
    if (strlen($payload) > 4096 || strlen($signature) > 1024 || !function_exists('openssl_verify')
        || !valid_backup_release_origin($origin)) {
        return null;
    }
    $decoded = base64_decode($signature, true);
    if ($decoded === false || @openssl_verify($payload, $decoded, $public_key, OPENSSL_ALGO_SHA256) !== 1) {
        return null;
    }
    $release = json_decode($payload, true, 3);
    if (!is_array($release) || array_keys($release) !== ['slug', 'version', 'download_url', 'bytes', 'sha256', 'issued_at', 'expires_at']
        || json_encode($release, JSON_UNESCAPED_SLASHES) !== $payload || $release['slug'] !== BACKUP_RELEASE_SLUG
        || !is_string($release['version']) || !preg_match('/^(?:0|[1-9][0-9]{0,8})(?:\.(?:0|[1-9][0-9]{0,8})){2}$/D', $release['version'])
        || !version_compare($release['version'], $installed, '>')
        || $release['download_url'] !== $origin . '/releases/' . BACKUP_RELEASE_SLUG . '_' . $release['version'] . '.zip'
        || !is_int($release['bytes']) || $release['bytes'] < 1 || $release['bytes'] > BACKUP_RELEASE_MAX_BYTES
        || !is_string($release['sha256']) || !preg_match('/^[a-f0-9]{64}$/D', $release['sha256'])
        || !is_int($release['issued_at']) || $release['issued_at'] < 1 || $release['issued_at'] > $now
        || !is_int($release['expires_at']) || $release['expires_at'] <= $now
        || $release['expires_at'] - $release['issued_at'] > 30 * 86400) {
        return null;
    }
    return $release;
}

/** Verify the exact bytes of a local package before it can be passed to WordPress. */
function backup_release_package_matches($stream, array $release): bool {
    $size = $release['bytes'] ?? null;
    $digest = $release['sha256'] ?? null;
    if (!is_resource($stream) || get_resource_type($stream) !== 'stream' || ftell($stream) !== 0
        || !is_int($size) || $size < 1 || $size > BACKUP_RELEASE_MAX_BYTES
        || !is_string($digest) || !preg_match('/^[a-f0-9]{64}$/D', $digest)) {
        return false;
    }
    $hash = hash_init('sha256');
    $read = hash_update_stream($hash, $stream, $size + 1);
    return $read === $size && feof($stream) && hash_equals($digest, hash_final($hash));
}

const BACKUP_UPDATE_URI = 'https://pebkac404.com/wordpress/pebkac-backup/';
const BACKUP_PLUGIN_FILE = 'pebkac-backup/pebkac-backup.php';

/** Fetch only the fixed manifest for a configured release origin. An empty configuration disables checks. */
function fetch_verified_backup_release(array $configuration, string $installed, int $now): ?array {
    $origin = $configuration['origin'] ?? null;
    $key = $configuration['public_key'] ?? null;
    if (!is_string($origin) || !valid_backup_release_origin($origin)
        || !is_string($key) || $key === '' || strlen($key) > 4096) {
        return null;
    }
    $response = wp_safe_remote_get($origin . '/releases/' . BACKUP_RELEASE_SLUG . '.json', [
        'timeout' => 8, 'redirection' => 0, 'sslverify' => true, 'limit_response_size' => 8193,
    ]);
    if (is_wp_error($response) || wp_remote_retrieve_response_code($response) !== 200) {
        return null;
    }
    $body = wp_remote_retrieve_body($response);
    if (!is_string($body) || strlen($body) > 8192) {
        return null;
    }
    $envelope = json_decode($body, true, 3);
    if (!is_array($envelope) || !is_string($envelope['payload'] ?? null) || !is_string($envelope['signature'] ?? null)) {
        return null;
    }
    return verify_backup_release($envelope['payload'], $envelope['signature'], $key, $origin, $installed, $now);
}

/** Offer the update to WordPress after verifying the release manifest. */
function check_backup_wordpress_update(array $configuration, array $plugin, string $plugin_file, int $now, bool $installer_ready = false): ?array {
    if ($plugin_file !== BACKUP_PLUGIN_FILE || ($plugin['UpdateURI'] ?? null) !== BACKUP_UPDATE_URI
        || !is_string($plugin['Version'] ?? null)) {
        return null;
    }
    $release = fetch_verified_backup_release($configuration, $plugin['Version'], $now);
    if ($release === null) {
        return null;
    }
    $offer = ['id' => BACKUP_UPDATE_URI, 'slug' => BACKUP_RELEASE_SLUG, 'version' => $release['version'], 'new_version' => $release['version']];
    if ($installer_ready) {
        $offer['package'] = $release['download_url'];
    }
    return $offer;
}

/** Fetch and verify a fresh signed release before returning a local ZIP to the installer. */
function download_verified_backup_release(array $configuration, string $installed, string $package_url, int $now, string $directory): string {
    $release = fetch_verified_backup_release($configuration, $installed, $now);
    if ($release === null || $release['download_url'] !== $package_url) {
        throw new \RuntimeException('The requested update no longer matches a signed Website Backup release.');
    }
    $root = realpath($directory);
    if ($root === false || !is_dir($root) || is_link($directory)
        || (DIRECTORY_SEPARATOR === '/' && (fileperms($root) & 0077) !== 0)) {
        throw new \RuntimeException('Private update staging is unavailable.');
    }
    $file = @tempnam($root, 'website-backup-update-');
    if ($file === false || realpath(dirname($file)) !== $root) {
        if ($file !== false) {
            @unlink($file);
        }
        throw new \RuntimeException('Could not reserve a private update file.');
    }
    try {
        $response = wp_safe_remote_get($release['download_url'], [
            'timeout' => 20, 'redirection' => 0, 'sslverify' => true, 'decompress' => false,
            'stream' => true, 'filename' => $file, 'limit_response_size' => $release['bytes'] + 1,
        ]);
        if (is_wp_error($response) || wp_remote_retrieve_response_code($response) !== 200) {
            throw new \RuntimeException('Could not download the signed Website Backup update.');
        }
        $stream = @fopen($file, 'rb');
        if ($stream === false) {
            throw new \RuntimeException('Could not read the downloaded update.');
        }
        try {
            if (!backup_release_package_matches($stream, $release)) {
                throw new \RuntimeException('The downloaded update does not match its signed size and hash.');
            }
        } finally {
            fclose($stream);
        }
        if (!backup_release_zip_matches($file, $release)) {
            throw new \RuntimeException('The update ZIP does not contain the expected Website Backup plugin.');
        }
        return $file;
    } catch (\Throwable $error) {
        @unlink($file);
        throw $error;
    }
}

/** Check the signed ZIP's layout and WordPress plugin identity without extracting or executing it. */
function backup_release_zip_matches(string $file, array $release): bool {
    if (!class_exists(\ZipArchive::class)) {
        return false;
    }
    $zip = new \ZipArchive();
    if ($zip->open($file, \ZipArchive::RDONLY) !== true) {
        return false;
    }
    try {
        if ($zip->numFiles < 1 || $zip->numFiles > 1000) {
            return false;
        }
        $seen = [];
        $total = 0;
        $prefix = BACKUP_RELEASE_SLUG . '/';
        for ($index = 0; $index < $zip->numFiles; $index++) {
            $entry = $zip->statIndex($index);
            $name = $entry['name'] ?? '';
            $size = $entry['size'] ?? null;
            $directory = substr($name, -1) === '/';
            $path = $directory ? substr($name, 0, -1) : $name;
            $key = strtolower($path);
            if (strpos($name, $prefix) !== 0 || (!$directory && $path === BACKUP_RELEASE_SLUG)
                || !preg_match('~^[a-zA-Z0-9_.-]+(?:/[a-zA-Z0-9_.-]+)*$~D', $path)
                || preg_match('~(?:^|/)(?:\.{1,2}|(?:con|prn|aux|nul|com[1-9]|lpt[1-9])(?:\.[^/]*)?)(?:/|$)|\.(?:/|$)~i', $path)
                || isset($seen[$key]) || !is_int($size) || $size < 0 || $size > 32 * 1024 * 1024
                || ($directory && $size !== 0) || ($total += $size) > 32 * 1024 * 1024
                || !$zip->getExternalAttributesIndex($index, $system, $attributes)) {
                return false;
            }
            if ($system === \ZipArchive::OPSYS_UNIX) {
                $type = ($attributes >> 16) & 0170000;
                if ($type !== 0 && $type !== ($directory ? 0040000 : 0100000)) {
                    return false;
                }
            }
            $seen[$key] = $directory;
        }
        foreach (array_keys($seen) as $path) {
            for ($parent = dirname($path); $parent !== '.'; $parent = dirname($parent)) {
                if (isset($seen[$parent]) && !$seen[$parent]) {
                    return false;
                }
            }
        }
        $header = $zip->getFromName(BACKUP_PLUGIN_FILE, 8192);
        return is_string($header)
            && preg_match('/^[ \t*\/#]*Plugin Name:[ \t]*Website Backup[ \t]*\r?$/mi', $header) === 1
            && preg_match('/^[ \t*\/#]*Version:[ \t]*([0-9.]+)[ \t]*\r?$/mi', $header, $matches) === 1
            && $matches[1] === ($release['version'] ?? null);
    } finally {
        $zip->close();
    }
}

/** Install the native WordPress update filters only when a release origin and public key are configured. */
function register_backup_release_hooks(array $configuration, string $installed, callable $private_directory): void {
    if (empty($configuration['origin']) || empty($configuration['public_key'])) {
        return;
    }
    add_filter('update_plugins_pebkac404.com', static function ($previous, array $plugin, string $file) use ($configuration) {
        if ($file !== BACKUP_PLUGIN_FILE) {
            return $previous;
        }
        return check_backup_wordpress_update($configuration, $plugin, $file, time(), true) ?? false;
    }, 10, 3);
    add_filter('upgrader_pre_download', static function ($previous, $package, $upgrader, array $extra) use ($configuration, $installed, $private_directory) {
        if (($extra['plugin'] ?? null) !== BACKUP_PLUGIN_FILE) {
            return $previous;
        }
        if (!is_string($package)) {
            return new \WP_Error('website_backup_update_invalid', 'The Website Backup update has no signed package URL.');
        }
        try {
            return download_verified_backup_release($configuration, $installed, $package, time(), $private_directory());
        } catch (\RuntimeException $error) {
            return new \WP_Error('website_backup_update_unverified', $error->getMessage());
        }
    }, PHP_INT_MAX, 4);
}

/** Enable native background updates for Website Backup on the two pilot sites. */
function enable_pilot_backup_auto_update($enabled, $update) {
    if (is_object($update) && ($update->plugin ?? null) === BACKUP_PLUGIN_FILE && pilot_site_slug(home_url()) !== '') {
        return true;
    }
    return $enabled;
}

function backup_update_work_directory(): string {
    $parent = backup_temp_parent();
    if ($parent === '') {
        throw new \RuntimeException('Private update staging is unavailable.');
    }
    $name = 'website-backup-update-' . substr(hash_hmac('sha256', home_url(), wp_salt('auth')), 0, 32);
    return private_backup_work_directory($parent, $name, true);
}
