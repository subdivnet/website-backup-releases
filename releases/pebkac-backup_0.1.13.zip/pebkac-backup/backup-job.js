(() => {
    const panel = document.getElementById('pebkac-backup-run');
    const button = panel && panel.querySelector('button');
    if (!button) return;
    const progress = panel.querySelector('.pebkac-backup-progress');
    button.addEventListener('click', async () => {
        if (button.dataset.refresh === '1') {
            window.location.reload();
            return;
        }
        button.disabled = true;
        progress.textContent = 'Running the next backup step…';
        try {
            for (let step = 0; step < 90; step += 1) {
                const body = new URLSearchParams({ action: 'pebkac_backup_step', _ajax_nonce: panel.dataset.nonce });
                if (button.dataset.restart === '1') body.set('restart', '1');
                const response = await fetch(window.ajaxurl, { method: 'POST', credentials: 'same-origin', body });
                const result = await response.json();
                if (!response.ok || !result.success) {
                    throw new Error(typeof result.data === 'string' ? result.data : 'The backup stopped before it could confirm progress.');
                }
                button.dataset.restart = result.data.restartable ? '1' : '0';
                progress.textContent = result.data.message;
                if (result.data.finished) {
                    window.location.reload();
                    return;
                }
            }
            progress.textContent = 'Backup progress was saved. Use Resume backup to continue.';
        } catch (error) {
            progress.textContent = error.message || 'The backup step did not respond. Progress remains saved.';
            button.dataset.refresh = '1';
            button.textContent = 'Refresh backup status';
            button.disabled = false;
            return;
        }
        button.textContent = 'Resume backup';
        button.disabled = false;
    });
})();
