<?php

namespace PEBKAC404\Backup;

if (!defined('ABSPATH')) {
    exit;
}

require_once __DIR__ . '/wordpress-capture.php';
require_once __DIR__ . '/wordpress-transfer.php';
require_once __DIR__ . '/backup-incremental.php';

function backup_job_root(bool $create = false): string {
    $temp = backup_temp_parent();
    if ($temp === '' || dropbox_app_key() === '' || !dropbox_can_encrypt() || is_multisite()) {
        throw new \RuntimeException('Private backup staging is unavailable for this site.');
    }
    $name = hash_hmac('sha256', 'backup-job|' . home_url(), dropbox_encryption_key());
    return private_backup_work_directory($temp, 'website-backup-' . substr($name, 0, 32), $create);
}

/** Resolve a private working directory for a caller-generated name. */
function private_backup_work_directory(string $temp, string $name, bool $create): string {
    $root = $temp . DIRECTORY_SEPARATOR . $name;
    if ($create && !is_dir($root)) {
        @mkdir($root, 0700);
    }
    if (is_link($root) || (($create || file_exists($root)) && (!is_dir($root)
        || (DIRECTORY_SEPARATOR === '/' && (fileperms($root) & 0077) !== 0)))) {
        throw new \RuntimeException('The temporary backup directory is not private.');
    }
    return $root;
}

function read_backup_job(string $root): array {
    $path = $root . '/job.json';
    if (!file_exists($path) && !is_link($path)) {
        return [];
    }
    $bytes = is_link($path) ? false : @file_get_contents($path, false, null, 0, 32769);
    $job = $bytes !== false && strlen($bytes) <= 32768 ? json_decode($bytes, true) : null;
    if (!is_array($job) || !isset($job['phase'], $job['id']) || !is_string($job['id']) || !preg_match('/^[0-9a-f]{32}$/D', $job['id'])) {
        throw new \RuntimeException('The private backup record could not be read.');
    }
    return $job;
}

function write_backup_job(string $root, array $job): void {
    $bytes = wp_json_encode($job);
    if ($bytes === false) {
        throw new \RuntimeException('Could not reserve the private backup record.');
    }
    write_private_backup_record($root . '/job.json', $bytes);
}

function write_private_backup_record(string $path, string $bytes): void {
    $temp = dirname($path) . '/state-' . bin2hex(random_bytes(8));
    $stream = @fopen($temp, 'xb');
    if ($stream === false) {
        throw new \RuntimeException('Could not reserve the private backup record.');
    }
    $written = fwrite($stream, $bytes) === strlen($bytes) && fflush($stream);
    fclose($stream);
    if (!$written || !@rename($temp, $path)) {
        @unlink($temp);
        throw new \RuntimeException('Could not persist backup progress safely.');
    }
}

function with_backup_job_lock(string $root, callable $run) {
    $path = $root . '/job.lock';
    $lock = is_link($path) ? false : @fopen($path, 'c+b');
    if ($lock === false) {
        throw new \RuntimeException('Could not open the private backup lock.');
    }
    try {
        if (!flock($lock, LOCK_EX | LOCK_NB)) {
            throw new \RuntimeException('A backup step is already running. Wait before resuming.');
        }
        return $run();
    } finally {
        fclose($lock);
    }
}

function backup_request_budget(): float {
    $limit = (int) ini_get('max_execution_time');
    return $limit === 0 ? 25.0 : max(1, min(25, $limit - 3));
}

/** Recover the size from a completed job only when both objects match the published evidence. */
function verified_job_archive_size(array $job, array $evidence): ?int {
    $archive = $job['transfer'] ?? [];
    $manifest = $job['manifest_transfer'] ?? [];
    $size = $archive['size'] ?? null;
    if (!isset($evidence['archive_path'], $evidence['manifest_path'], $evidence['manifest_sha256'])
        || !in_array($job['phase'] ?? '', ['publish', 'verified'], true)
        || ($archive['phase'] ?? '') !== 'verified' || ($manifest['phase'] ?? '') !== 'verified'
        || ($archive['sha256'] ?? '') !== $evidence['archive_sha256'] || ($archive['path'] ?? '') !== $evidence['archive_path']
        || ($manifest['sha256'] ?? '') !== $evidence['manifest_sha256'] || ($manifest['path'] ?? '') !== $evidence['manifest_path']
        || !is_int($size) || $size < 1 || $size > SNAPSHOT_MAX_BYTES + 8 * 1024 * 1024) {
        return null;
    }
    return $size;
}

function backup_capture_supported(): bool {
    return class_exists(\ZipArchive::class) && method_exists(\ZipArchive::class, 'registerCancelCallback');
}

function restartable_backup_capture(array $job): bool {
    return in_array($job['phase'] ?? '', ['exporting', 'archiving'], true)
        && !isset($job['transfer']) && !isset($job['manifest_transfer']);
}

/** Clear only an interrupted capture that never reached Dropbox. Caller holds the job lock. */
function restart_backup_capture(string $root, array $job, bool $automatic = false): array {
    if (!restartable_backup_capture($job)) {
        throw new \RuntimeException('Only a backup stopped before transfer can be restarted here.');
    }
    $new = ['id' => $job['id'], 'phase' => 'database'];
    if (isset($job['component'])) {
        $component = $job['component'];
        $claim = get_option(SCHEDULED_BACKUP_JOB_OPTION, []);
        $due = $job['scheduled_due_at'] ?? null;
        if (!isset(COMPONENTS[$component]) || !is_int($due) || $due <= 0
            || ($claim['id'] ?? null) !== $job['id'] || ($claim['component'] ?? null) !== $component
            || ($claim['due_at'] ?? null) !== $due) {
            throw new \RuntimeException('The interrupted backup does not match the saved component schedule.');
        }
        $new['component'] = $component;
        $new['scheduled_due_at'] = $due;
        $new['phase'] = $component === 'database' ? 'database' : 'files';
        if (($job['incremental'] ?? false) === true && $component !== 'database') {
            $new['incremental'] = true;
            $new['phase'] = 'replay_inventory';
        }
    } elseif (isset($job['daily_date'])) {
        $new['daily_date'] = $job['daily_date'];
    } else {
        $new['id'] = bin2hex(random_bytes(16));
    }
    if (isset($job['folder'])) {
        $new['folder'] = backup_dropbox_folder($job);
    }
    if ($automatic) {
        // Spend the retry before touching partial files so a failed cleanup cannot repeat.
        $job['automatic_capture_retry'] = true;
        write_backup_job($root, $job);
    }
    if (isset($job['automatic_capture_retry'])) {
        $new['automatic_capture_retry'] = true;
    }
    $directory = wordpress_capture_directory($root, home_url(), $job['id']);
    if (is_link($directory) || (file_exists($directory) && !is_dir($directory))) {
        throw new \RuntimeException('The interrupted capture directory could not be verified.');
    }
    if (is_dir($directory)) {
        foreach (['database.sql', 'backup.zip', 'manifest.json', COMPONENT_INVENTORY_REPLAY_FILE] as $name) {
            $path = $directory . '/' . $name;
            if ((file_exists($path) || is_link($path)) && !@unlink($path)) {
                throw new \RuntimeException('Could not clear the interrupted capture.');
            }
        }
        if (!@rmdir($directory)) {
            throw new \RuntimeException('The interrupted capture still contains temporary files.');
        }
    }
    write_backup_job($root, $new);
    return $new;
}

/** Retry one local capture for this scheduled occurrence. Caller holds the job lock. */
function retry_scheduled_backup_capture(string $root, array $job): string {
    if (!restartable_backup_capture($job) || isset($job['automatic_capture_retry'])) {
        return 'blocked';
    }
    restart_backup_capture($root, $job, true);
    return 'advanced';
}

/** Persist both transfer plans for a staged incremental capture. Caller holds the job lock. */
function prepare_incremental_backup_job(
    string $root, array $job, array $parent, array $baseline, string $manifest_sha256, float $deadline
): array {
    $component = $job['component'] ?? null;
    if (($job['phase'] ?? '') !== 'archiving' || !restartable_backup_capture($job)
        || !is_string($component) || $component !== ($baseline['component'] ?? null)
        || read_backup_job($root) !== $job) {
        throw new \RuntimeException('The saved backup job does not match this incremental capture.');
    }
    $state = get_option(COMPONENT_RECOVERY_STATE_OPTION, []);
    $head = $state['latest'][$component] ?? null;
    if (!is_string($head) || ($state['records'][$head] ?? null) !== $parent || ($parent['archive_path'] ?? null) !== $head) {
        throw new \RuntimeException('The incremental parent is no longer the latest verified component backup.');
    }
    $site = home_url();
    $directory = wordpress_capture_directory($root, $site, $job['id']);
    $plans = plan_incremental_wordpress_transfer($directory, $site, $job['id'], $parent, $baseline, $manifest_sha256, time(), $deadline, backup_dropbox_folder($job));
    $job = array_replace($job, $plans, ['phase' => 'folder', 'manifest_sha256' => $manifest_sha256]);
    write_backup_job($root, $job);
    return $job;
}

function advance_backup_job(string $root, array $job): array {
    global $wpdb;
    $site = home_url();
    $component = $job['component'] ?? null;
    $folder = backup_dropbox_folder($job);
    $remote_base = pilot_backup_base($site, $job['id'], $component, $folder);
    $directory = wordpress_capture_directory($root, $site, $job['id']);
    $budget = backup_request_budget();
    $deadline = microtime(true) + $budget;
    switch ($job['phase']) {
        case 'database':
            if ($component !== null && $component !== 'database') {
                throw new \RuntimeException('A file component does not use database export.');
            }
            if (!backup_capture_supported()) {
                throw new \RuntimeException('This host cannot safely bound the ZIP capture. See Host readiness.');
            }
            $job['phase'] = 'exporting';
            write_backup_job($root, $job);
            $export = new \wpdb(DB_USER, DB_PASSWORD, DB_NAME, DB_HOST);
            try {
                $export->set_prefix($wpdb->prefix);
                start_wordpress_capture($directory, $export, min($budget, 12));
            } finally {
                $export->close();
            }
            $job['phase'] = 'files';
            break;
        case 'files':
            $job['phase'] = 'archiving';
            write_backup_job($root, $job);
            if ($component !== null && $component !== 'database' && !@mkdir($directory, 0700)) {
                throw new \RuntimeException('Could not reserve the file component staging directory.');
            }
            $manifest = finish_wordpress_capture($directory, ABSPATH, WP_CONTENT_DIR, $deadline, $component);
            $job['manifest_sha256'] = hash_file('sha256', $directory . '/manifest.json');
            if ($job['manifest_sha256'] === false) {
                throw new \RuntimeException('Could not pin the capture manifest for Dropbox.');
            }
            if ($component !== null) {
                $inventory = $component === 'database' ? $manifest['files'] : incremental_file_inventory($component, $manifest['files']);
                $job['component_capture'] = [
                    'component' => $component, 'archive_sha256' => $manifest['archive_sha256'],
                    'manifest_sha256' => $job['manifest_sha256'], 'inventory_sha256' => incremental_inventory_sha256($component, $inventory),
                ];
            }
            $job['phase'] = 'plan_transfer';
            break;
        case 'replay_inventory':
        case 'incremental_files':
            if ($component === null || $component === 'database' || ($job['incremental'] ?? false) !== true) {
                throw new \RuntimeException('Incremental capture requires a scheduled file component.');
            }
            $replaying = $job['phase'] === 'replay_inventory';
            if ($replaying && !is_dir($directory) && !@mkdir($directory, 0700)) {
                throw new \RuntimeException('Could not reserve the private incremental staging directory.');
            }
            $history = get_option(COMPONENT_RECOVERY_STATE_OPTION, []);
            $baseline = advance_component_inventory_replay($directory, $site, $component, $history,
                $replaying ? dropbox_connected_access_token() : null, time());
            if ($replaying) {
                if ($baseline !== null) {
                    $job['phase'] = 'incremental_files';
                }
                break;
            }
            $job['phase'] = 'archiving';
            write_backup_job($root, $job);
            finish_wordpress_incremental_capture($directory, ABSPATH, WP_CONTENT_DIR, $baseline['inventory'], $deadline);
            $manifest_sha256 = hash_file('sha256', $directory . '/manifest.json');
            if ($manifest_sha256 === false) {
                throw new \RuntimeException('Could not pin the incremental capture manifest.');
            }
            return prepare_incremental_backup_job($root, $job, $baseline['parent'], $baseline['inventory'], $manifest_sha256, $deadline);
        case 'plan_transfer':
            $manifest = read_snapshot_manifest($directory . '/manifest.json');
            if (($manifest['component'] ?? null) !== $component) {
                throw new \RuntimeException('The backup manifest belongs to another component.');
            }
            $path = $remote_base . '.zip';
            $job['transfer'] = plan_wordpress_transfer($directory . '/backup.zip', $manifest['archive_sha256'], $path, $deadline, $site, $component, $folder);
            $job['phase'] = 'folder';
            break;
        case 'folder':
            $job['folder_progress'] = advance_backup_dropbox_folder($folder, $job['folder_progress'] ?? [], dropbox_connected_access_token(),
                static function (array $progress) use ($root, $job): void {
                    $job['folder_progress'] = $progress;
                    write_backup_job($root, $job);
                });
            if ($job['folder_progress']['phase'] === 'verified') {
                unset($job['folder_progress']);
                $job['phase'] = 'transfer';
            }
            break;
        case 'transfer':
            if (($job['transfer']['path'] ?? '') !== $remote_base . '.zip') {
                throw new \RuntimeException('The saved archive destination does not match this pilot site.');
            }
            if ($job['transfer']['phase'] !== 'verified') {
                $job['transfer'] = advance_wordpress_transfer($job['transfer'], $directory . '/backup.zip', dropbox_connected_access_token(),
                    static function (array $transfer) use ($root, $job): void {
                        $job['transfer'] = $transfer;
                        write_backup_job($root, $job);
                    });
            }
            if ($job['transfer']['phase'] === 'verified') {
                $job['phase'] = 'plan_manifest';
            }
            break;
        case 'plan_manifest':
            $manifest = read_snapshot_manifest($directory . '/manifest.json');
            $incremental = isset($job['component_capture']['parent_path']);
            $manifest_component = $incremental ? ($manifest['delta']['component'] ?? null) : ($manifest['component'] ?? null);
            if ($manifest_component !== $component || ($incremental && $component === null)) {
                throw new \RuntimeException('The backup manifest belongs to another component.');
            }
            if (($manifest['archive_sha256'] ?? null) !== $job['transfer']['sha256']) {
                throw new \RuntimeException('The backup manifest no longer describes the verified Dropbox archive.');
            }
            $path = $remote_base . '.manifest.json';
            $manifest_transfer = plan_wordpress_transfer($directory . '/manifest.json', $job['manifest_sha256'], $path, $deadline, $site, $component, $folder);
            if ($incremental && ($job['manifest_transfer'] ?? null) !== $manifest_transfer) {
                throw new \RuntimeException('The incremental manifest no longer matches its saved transfer plan.');
            }
            $job['manifest_transfer'] = $manifest_transfer;
            $job['phase'] = 'manifest';
            break;
        case 'manifest':
            if (($job['manifest_transfer']['path'] ?? '') !== $remote_base . '.manifest.json') {
                throw new \RuntimeException('The saved manifest destination does not match this pilot site.');
            }
            if ($job['manifest_transfer']['phase'] !== 'verified') {
                $job['manifest_transfer'] = advance_wordpress_transfer($job['manifest_transfer'], $directory . '/manifest.json', dropbox_connected_access_token(),
                    static function (array $transfer) use ($root, $job): void {
                        $job['manifest_transfer'] = $transfer;
                        write_backup_job($root, $job);
                    });
            }
            if ($job['manifest_transfer']['phase'] === 'verified') {
                $job['phase'] = 'publish';
            }
            break;
        case 'publish':
            if (($job['transfer']['phase'] ?? '') !== 'verified' || ($job['manifest_transfer']['phase'] ?? '') !== 'verified'
                || ($job['manifest_transfer']['sha256'] ?? null) !== $job['manifest_sha256']
                || ($job['transfer']['path'] ?? '') !== $remote_base . '.zip'
                || ($job['manifest_transfer']['path'] ?? '') !== $remote_base . '.manifest.json') {
                throw new \RuntimeException('Both the Dropbox archive and its manifest must be verified before publishing.');
            }
            if ($component !== null) {
                $capture = $job['component_capture'] ?? [];
                if (($capture['component'] ?? null) !== $component) {
                    throw new \RuntimeException('The saved job does not describe the expected component capture.');
                }
                if (isset($job['folder'])) {
                    $capture['folder'] = $folder;
                }
                publish_verified_component($capture, $job['transfer'], $job['manifest_transfer'], $site, time());
            } else {
                $evidence = [
                    'kind' => 'site_snapshot', 'site' => $site,
                    'archive_sha256' => $job['transfer']['sha256'], 'offsite_verified_at' => $job['manifest_transfer']['verified_at'],
                    'manifest_sha256' => $job['manifest_sha256'], 'archive_path' => $job['transfer']['path'],
                    'manifest_path' => $job['manifest_transfer']['path'],
                ];
                if (isset($job['folder'])) {
                    $evidence['folder'] = $folder;
                }
                $size = verified_job_archive_size($job, $evidence);
                if ($size !== null) {
                    $evidence['archive_size_bytes'] = $size;
                }
                $pins = backup_dropbox_object_pins(['archive' => $job['transfer'], 'manifest' => $job['manifest_transfer']]);
                if ($pins !== []) {
                    $evidence['dropbox_objects'] = $pins;
                }
                $previous = get_option(EVIDENCE_OPTION, []);
                $previous_verified = verified_evidence($previous, $site, time());
                $records = isset($previous_verified['manifest_path']) ? [$previous_verified, $evidence] : [$evidence];
                if (($previous_verified['archive_path'] ?? null) === $evidence['archive_path'] && isset($previous_verified['restore'])) {
                    $evidence['restore'] = $previous_verified['restore'];
                }
                remember_verified_backups($records, $site, time());
                if ($previous !== $evidence && !update_option(EVIDENCE_OPTION, $evidence, false)) {
                    throw new \RuntimeException('The Dropbox copy verified, but its Overview record could not be saved.');
                }
            }
            // Recovery reads Dropbox, so clear only this job's exact staged files after both objects verify.
            $job['cleanup_pending'] = false;
            if (is_dir($directory) && !is_link($directory)) {
                foreach (['backup.zip', 'manifest.json', COMPONENT_INVENTORY_REPLAY_FILE] as $name) {
                    $path = $directory . '/' . $name;
                    if ((is_file($path) || is_link($path)) && !@unlink($path)) {
                        $job['cleanup_pending'] = true;
                    }
                }
            }
            $job['phase'] = 'verified';
            break;
        case 'verified':
            return $job;
        default:
            throw new \RuntimeException('A capture step ended before it could confirm completion. This step will not be repeated.');
    }
    write_backup_job($root, $job);
    return $job;
}

function backup_job_upload_uncertain(array $job): bool {
    return in_array($job['transfer']['phase'] ?? '', ['starting', 'appending'], true)
        || in_array($job['manifest_transfer']['phase'] ?? '', ['starting', 'appending'], true);
}

function backup_job_public_state(array $job): array {
    $phase = $job['phase'] ?? '';
    $messages = [
        '' => 'No pilot backup has started.', 'database' => 'Preparing the database export.',
        'files' => isset($job['component']) && $job['component'] !== 'database'
            ? 'Preparing the component archive.'
            : 'The database export is ready. Capturing WordPress files next.',
        'replay_inventory' => 'Reading the verified backup history from Dropbox.',
        'incremental_files' => 'Checking what changed in this component.',
        'plan_transfer' => 'The ZIP is ready. Checking its contents before transfer.',
        'folder' => 'Preparing the private Dropbox app folder.', 'transfer' => 'Sending the backup to Dropbox and verifying it.',
        'plan_manifest' => 'Dropbox verified the ZIP. Preparing its restore manifest.',
        'manifest' => 'Sending the restore manifest to Dropbox and verifying it.',
        'publish' => 'Dropbox verified the ZIP and its manifest. Updating Overview.', 'verified' => 'Dropbox backup verified.',
    ];
    $uncertain = backup_job_upload_uncertain($job);
    $restartable = restartable_backup_capture($job);
    $message = $messages[$phase] ?? 'The last capture step did not confirm completion.';
    if ($uncertain) {
        $message = 'Backup paused because Dropbox did not confirm an upload step. The saved backup is waiting for review.';
    } elseif ($restartable) {
        if (isset($job['automatic_capture_retry']) && (isset($job['daily_date']) || isset($job['component']))) {
            $message = 'This scheduled backup used its automatic retry and is still incomplete. The capture stopped before anything was sent to Dropbox.';
        } else {
            $message = isset($job['daily_date']) || isset($job['component'])
                ? 'Capture stopped before anything was sent to Dropbox. Restart capture to continue the scheduled backup.'
                : 'Backup capture stopped before anything was sent to Dropbox. You can start a new backup.';
        }
    } elseif (in_array($job['transfer']['phase'] ?? '', ['committing', 'verify'], true)
        || in_array($job['manifest_transfer']['phase'] ?? '', ['committing', 'verify'], true)) {
        $message = 'Checking Dropbox to confirm the last upload.';
    } elseif ($phase === 'folder' && ($job['folder_progress']['phase'] ?? null) === 'verify') {
        $message = 'Checking Dropbox to confirm the destination folder is ready.';
    } elseif (!empty($job['cleanup_pending'])) {
        $message = 'Dropbox backup verified. Some temporary files could not be cleared.';
    }
    return [
        'started' => $phase !== '', 'finished' => $phase === 'verified', 'restartable' => $restartable,
        'uncertain' => $uncertain, 'message' => $message,
    ];
}

/** Read the job and check for an in-flight step without creating or modifying the lock. */
function read_backup_job_progress(string $root): array {
    $path = $root . '/job.lock';
    $lock = !is_link($path) && is_file($path) ? @fopen($path, 'rb') : false;
    if ($lock === false) {
        return [read_backup_job($root), false];
    }
    try {
        $running = !flock($lock, LOCK_SH | LOCK_NB);
        return [read_backup_job($root), $running];
    } finally {
        fclose($lock);
    }
}

function render_backup_job(): void {
    if (!is_ssl() || dropbox_saved_refresh_token(dropbox_app_key()) === '') {
        return;
    }
    try {
        [$job, $running] = read_backup_job_progress(backup_job_root());
    } catch (\RuntimeException $error) {
        echo '<p>Private backup staging is unavailable. See Host readiness below.</p>';
        return;
    }
    render_backup_job_progress($job, $running);
}

function render_backup_job_progress(array $job, bool $running): void {
    $state = backup_job_public_state($job);
    $heading = isset($job['daily_date']) ? 'Daily full backup' : 'Pilot backup';
    $component = COMPONENTS[$job['component'] ?? ''] ?? null;
    if ($component !== null) {
        $heading = 'Scheduled backup for ' . $component;
    }
    $scheduled = isset($job['daily_date']) || $component !== null;
    $retry_spent = $scheduled && $state['restartable'] && isset($job['automatic_capture_retry']);
    $show_warning = !$running && ($state['uncertain'] || $retry_spent);
    if ($state['uncertain']) {
        if ($running) {
            $state['message'] = 'WordPress is waiting for Dropbox to confirm the upload step.';
        } else {
            $heading .= ' paused';
        }
    } elseif ($running && $state['restartable']) {
        $state['message'] = 'WordPress is preparing the backup on this site.';
    } elseif ($retry_spent) {
        $heading .= ' needs attention';
    }
    $style = $show_warning ? 'notice-warning' : 'notice-info';
    $restart_label = $scheduled ? 'Restart capture' : 'Start a new backup';
    $can_act = !$running && !$state['finished'] && !$state['uncertain'];
    ?>
    <section id="pebkac-backup-run" class="notice <?php echo esc_attr($style); ?> inline" data-nonce="<?php echo esc_attr(wp_create_nonce('pebkac_backup_step')); ?>">
        <h2><?php echo esc_html($heading); ?></h2>
        <?php if ($show_warning) : ?><details><summary>Show details</summary><?php endif; ?>
        <p aria-live="polite" class="pebkac-backup-progress"><?php echo esc_html($state['message']); ?></p>
        <?php if ($show_warning) : ?></details><?php endif; ?>
        <?php if ($can_act && backup_capture_supported()) : ?>
            <p><button type="button" class="button button-primary" data-restart="<?php echo $state['restartable'] ? '1' : '0'; ?>"><?php echo $state['restartable'] ? $restart_label : ($state['started'] ? 'Resume backup' : 'Back up now'); ?></button></p>
        <?php elseif ($can_act) : ?><p>This host does not support the ZIP time limit required by the pilot.</p>
        <?php endif; ?>
    </section>
    <?php
}

add_action('admin_enqueue_scripts', static function ($page) {
    if ($page === 'toplevel_page_pebkac-backup') {
        wp_enqueue_script('pebkac-backup-job', plugins_url('backup-job.js', __FILE__), [], VERSION, true);
    }
});

add_action('wp_ajax_pebkac_backup_step', static function () {
    if (($_SERVER['REQUEST_METHOD'] ?? '') !== 'POST' || !is_ssl() || !current_user_can('manage_options')) {
        wp_send_json_error('An administrator must run this backup over HTTPS.', 403);
    }
    check_ajax_referer('pebkac_backup_step');
    try {
        if (dropbox_saved_refresh_token(dropbox_app_key()) === '') {
            throw new \RuntimeException('Connect Dropbox in Setup before starting a backup.');
        }
        $root = backup_job_root(true);
        $job = with_backup_job_lock($root, static function () use ($root): array {
            $job = read_backup_job($root);
            if ($job === []) {
                $job = ['id' => bin2hex(random_bytes(16)), 'phase' => 'database'];
                $folder = backup_dropbox_folder(get_plan());
                if ($folder !== PILOT_DROPBOX_FOLDER) {
                    $job['folder'] = $folder;
                }
                write_backup_job($root, $job);
            } elseif (($_POST['restart'] ?? '') === '1') {
                $job = restart_backup_capture($root, $job);
            }
            return advance_backup_job($root, $job);
        });
        wp_send_json_success(backup_job_public_state($job));
    } catch (\RuntimeException $error) {
        wp_send_json_error($error->getMessage(), 409);
    } catch (\Throwable $error) {
        wp_send_json_error('The backup step stopped unexpectedly. Its progress record was preserved.', 500);
    }
});
