<?php

namespace PEBKAC404\Backup;

if (!defined('ABSPATH')) {
    exit;
}

/** Fetch only the pinned Dropbox object and return a validated private temporary file. */
function download_recovery_object(string $root, array $evidence, string $object, string $token): string {
    if (!in_array($object, ['archive', 'manifest'], true) || !isset($evidence['manifest_sha256'])) {
        throw new \RuntimeException('There is no verified recovery set for this request.');
    }
    $path = $evidence[$object . '_path'];
    $hash = $evidence[$object . '_sha256'];
    $limit = $object === 'manifest' ? SNAPSHOT_MAX_MANIFEST_BYTES : SNAPSHOT_MAX_BYTES + 8 * 1024 * 1024;
    $metadata = fetch_dropbox_metadata($path, $token);
    $size = $metadata['size'] ?? null;
    if (($metadata['.tag'] ?? null) !== 'file' || !is_int($size) || $size < 1 || $size > $limit
        || @disk_free_space($root) < $size + 16 * 1024 * 1024) {
        throw new \RuntimeException('Dropbox could not confirm this file or there is insufficient private temporary space.');
    }
    $file = @tempnam($root, 'recovery-');
    if ($file === false || realpath(dirname($file)) !== realpath($root)) {
        if ($file !== false) {
            @unlink($file);
        }
        throw new \RuntimeException('Could not reserve a private recovery download.');
    }
    try {
        $response = wp_remote_post('https://content.dropboxapi.com/2/files/download', [
            'headers' => ['Authorization' => 'Bearer ' . $token, 'Dropbox-API-Arg' => wp_json_encode(['path' => $path])],
            'timeout' => backup_request_budget(), 'redirection' => 0, 'sslverify' => true, 'decompress' => false,
            'stream' => true, 'filename' => $file, 'limit_response_size' => $size + 1,
        ]);
        clearstatcache(true, $file);
        if (is_wp_error($response) || wp_remote_retrieve_response_code($response) !== 200
            || filesize($file) !== $size || hash_file('sha256', $file) !== $hash) {
            throw new \RuntimeException('The downloaded file did not match the verified recovery set.');
        }
        if ($object === 'manifest' && (read_snapshot_manifest($file)['archive_sha256'] ?? null) !== $evidence['archive_sha256']) {
            throw new \RuntimeException('The downloaded manifest does not describe the verified archive.');
        }
        return $file;
    } catch (\Throwable $error) {
        @unlink($file);
        throw $error;
    }
}

/** Read a pinned component manifest and remove its temporary copy. Caller checks the record's site scope first. */
function download_component_manifest_bytes(string $root, array $record, string $token): string {
    $file = download_recovery_object($root, $record, 'manifest', $token);
    try {
        $bytes = @file_get_contents($file, false, null, 0, SNAPSHOT_MAX_MANIFEST_BYTES + 1);
        if ($bytes === false) {
            throw new \RuntimeException('Could not read the verified component manifest.');
        }
        return $bytes;
    } finally {
        @unlink($file);
    }
}

function download_verified_component_baseline_inventory(string $root, string $site, string $component, array $record, string $token, int $now): array {
    require_verified_component_baseline($site, $component, $record, $now);
    $bytes = download_component_manifest_bytes($root, $record, $token);
    return verified_component_baseline_inventory($site, $component, $record, $bytes, $now);
}

/** Read and replay one verified delta manifest after its exact parent, without downloading the ZIP. */
function download_verified_component_delta_inventory(
    string $root, string $site, string $component, array $parent_record, array $parent_inventory, array $record, string $token, int $now
): array {
    require_verified_component_parent($site, $component, $parent_record, $record, $now);
    $bytes = download_component_manifest_bytes($root, $record, $token);
    return replay_verified_component_manifest($site, $component, $parent_record, $parent_inventory, $record, $bytes, $now);
}

const COMPONENT_INVENTORY_REPLAY_FILE = 'inventory-replay.json';

/** Read one manifest per step and atomically save its inventory and position. Caller holds the job lock. */
function advance_component_inventory_replay(
    string $directory, string $site, string $component, array $history, ?string $token, int $now
): ?array {
    if (!is_dir($directory) || is_link($directory)
        || (DIRECTORY_SEPARATOR === '/' && (fileperms($directory) & 0077) !== 0)) {
        throw new \RuntimeException('The incremental replay requires a private backup directory.');
    }
    $chain = plan_component_inventory_replay($site, $component, $history, $now);
    if ($chain === []) {
        throw new \RuntimeException('There is no verified component backup to replay.');
    }
    $fingerprint = hash('sha256', json_encode($chain, JSON_THROW_ON_ERROR));
    $path = $directory . '/' . COMPONENT_INVENTORY_REPLAY_FILE;
    $applied = 0;
    $inventory = [];
    if (file_exists($path) || is_link($path)) {
        $bytes = !is_link($path) && is_file($path) ? @file_get_contents($path, false, null, 0, SNAPSHOT_MAX_MANIFEST_BYTES + 1) : false;
        $saved = $bytes !== false && strlen($bytes) <= SNAPSHOT_MAX_MANIFEST_BYTES ? json_decode($bytes, true) : null;
        $applied = $saved['applied'] ?? null;
        $inventory = $saved['inventory'] ?? null;
        if (($saved['chain'] ?? null) !== $fingerprint || !is_int($applied) || $applied < 1 || $applied > count($chain)
            || ($inventory['component'] ?? null) !== $component || !is_array($inventory['files'] ?? null)
            || incremental_inventory_sha256($component, incremental_file_inventory($component, $inventory['files'])) !== $chain[$applied - 1]['inventory_sha256']) {
            throw new \RuntimeException('The saved incremental replay does not match the verified backup chain.');
        }
    }
    if ($applied === count($chain)) {
        return ['parent' => $chain[$applied - 1], 'inventory' => $inventory];
    }
    if ($token === null) {
        throw new \RuntimeException('The saved incremental replay is incomplete.');
    }
    $record = $chain[$applied];
    $inventory = $applied === 0
        ? download_verified_component_baseline_inventory($directory, $site, $component, $record, $token, $now)
        : download_verified_component_delta_inventory($directory, $site, $component, $chain[$applied - 1], $inventory, $record, $token, $now);
    $applied++;
    $bytes = json_encode(['chain' => $fingerprint, 'applied' => $applied, 'inventory' => $inventory], JSON_THROW_ON_ERROR);
    if (strlen($bytes) > SNAPSHOT_MAX_MANIFEST_BYTES) {
        throw new \RuntimeException('The incremental replay inventory exceeds its staging limit.');
    }
    write_private_backup_record($path, $bytes);
    return $applied === count($chain) ? ['parent' => $record, 'inventory' => $inventory] : null;
}

/** Return a complete, site-bound recovery chain for the latest verified component backup. */
function component_recovery_chain(string $site, string $component, array $history, int $now): array {
    if (!is_array($history['records'] ?? null) || !is_array($history['latest'] ?? null)) {
        return [];
    }
    if ($component === 'database') {
        $head = $history['latest'][$component] ?? null;
        $record = is_string($head) ? ($history['records'][$head] ?? null) : null;
        if (!is_array($record) || ($record['archive_path'] ?? null) !== $head) {
            return [];
        }
        require_verified_component_record($site, $component, $record, $now);
        $chain = [$record];
    } else {
        $chain = plan_component_inventory_replay($site, $component, $history, $now);
    }
    foreach ($chain as $record) {
        if (backup_dropbox_object_pins($record['dropbox_objects'] ?? []) === []) {
            throw new \RuntimeException('The component recovery chain is missing verified Dropbox file information.');
        }
    }
    return $chain;
}

function component_recovery_download_id(array $record): string {
    return hash('sha256', $record['archive_path'] . '|' . $record['manifest_sha256']);
}

/** Resolve an opaque download choice without accepting a Dropbox path from the browser. */
function select_component_recovery_download(string $site, string $component, string $point, array $history, int $now): array {
    foreach (component_recovery_chain($site, $component, $history, $now) as $index => $record) {
        if (hash_equals(component_recovery_download_id($record), $point)) {
            return ['evidence' => $record, 'filename_prefix' => pilot_site_slug($site) . '-' . $component . '-' . ($index + 1)];
        }
    }
    throw new \RuntimeException('The requested component backup is no longer available from this recovery list.');
}

function render_backup_recovery(): void {
    if (!is_ssl() || dropbox_saved_refresh_token(dropbox_app_key()) === '') {
        return;
    }
    $evidence = verified_evidence(get_option(EVIDENCE_OPTION, []), home_url(), time());
    if (!isset($evidence['manifest_sha256'])) {
        return;
    }
    ?>
    <section class="notice notice-info inline">
        <h2>Recovery files</h2>
        <details><summary>Show details</summary>
            <p>Download both verified files from Dropbox for an isolated restore test.</p>
            <form action="<?php echo esc_url(admin_url('admin-post.php')); ?>" method="post">
                <input type="hidden" name="action" value="pebkac_backup_recovery">
                <?php wp_nonce_field('pebkac_backup_recovery'); ?>
                <button class="button" type="submit" name="object" value="archive">Download backup ZIP</button>
                <button class="button" type="submit" name="object" value="manifest">Download restore manifest</button>
            </form>
        </details>
    </section>
    <?php
}

add_action('admin_post_pebkac_backup_recovery', static function () {
    if (($_SERVER['REQUEST_METHOD'] ?? '') !== 'POST' || !is_ssl() || !current_user_can('manage_options')) {
        wp_die('A signed-in administrator must download the recovery files over HTTPS.', '', ['response' => 403]);
    }
    check_admin_referer('pebkac_backup_recovery');
    $object = $_POST['object'] ?? '';
    $component = $_POST['component'] ?? '';
    $point = $_POST['point'] ?? '';
    if (!in_array($object, ['archive', 'manifest'], true) || !is_string($component) || !is_string($point)
        || ($component === '' ? $point !== '' : (!isset(COMPONENTS[$component]) || !preg_match('/^[a-f0-9]{64}$/D', $point)))) {
        wp_die('Choose a recovery file.', '', ['response' => 400]);
    }
    try {
        $root = backup_job_root(true);
        [$file, $prefix] = with_backup_job_lock($root, static function () use ($root, $object, $component, $point): array {
            $site = home_url();
            $now = time();
            if ($component === '') {
                $evidence = verified_evidence(get_option(EVIDENCE_OPTION, []), $site, $now);
                $prefix = pilot_site_slug($site);
            } else {
                $selection = select_component_recovery_download($site, $component, $point, get_option(COMPONENT_RECOVERY_STATE_OPTION, []), $now);
                $evidence = $selection['evidence'];
                $prefix = $selection['filename_prefix'];
            }
            return [download_recovery_object($root, $evidence, $object, dropbox_connected_access_token()), $prefix];
        });
    } catch (\Throwable $error) {
        wp_die('The recovery download could not be verified. Return to Overview and check the Dropbox connection.', '', ['response' => 409]);
    }
    register_shutdown_function(static function () use ($file): void { @unlink($file); });
    nocache_headers();
    header('X-Content-Type-Options: nosniff');
    header('Content-Type: application/octet-stream');
    $filename = $prefix . ($object === 'archive' ? '-backup.zip' : '-restore-manifest.json');
    header('Content-Disposition: attachment; filename="' . $filename . '"');
    header('Content-Length: ' . filesize($file));
    readfile($file);
    exit;
});
