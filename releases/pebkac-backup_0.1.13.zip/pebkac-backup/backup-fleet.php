<?php

namespace PEBKAC404\Backup;

const BACKUP_REPORT_MAX_AGE = 86400;

/** Prepare the two pilot rows from reports fetched through an existing authenticated connection. */
function backup_fleet_rows(array $reports, int $now): array {
    $rows = [];
    foreach (['https://securitylab.subdiv.net' => 'SecurityLab', 'https://pebkac404.com' => 'PEBKAC404'] as $site => $label) {
        $row = [
            'site' => $site, 'label' => $label, 'state' => 'unavailable',
            'observed_at' => null, 'last_backup_at' => null, 'last_backup_bytes' => null,
            'last_restore_at' => null, 'latest_restore_at' => null, 'overdue_since' => null,
        ];
        $report = $reports[$site] ?? [];
        $observed = $report['observed_at'] ?? null;
        $status = $report['status'] ?? null;
        if (!is_int($observed) || $observed < 1 || $observed > $now || !is_array($status)
            || !in_array($status['state'] ?? null, ['setup_only', 'offsite_verified', 'restore_verified'], true)) {
            $rows[] = $row;
            continue;
        }
        $row['observed_at'] = $observed;
        foreach ([
            'last_backup_at' => 'last_verified_offsite_at',
            'last_restore_at' => 'last_verified_restore_at',
            'latest_restore_at' => 'latest_backup_restore_verified_at',
            'overdue_since' => 'oldest_overdue_at',
        ] as $target => $source) {
            $time = $status[$source] ?? null;
            if (is_int($time) && $time > 0 && $time <= $observed) {
                $row[$target] = $time;
            }
        }
        $size = $status['last_verified_offsite_size_bytes'] ?? null;
        if ($row['last_backup_at'] !== null && is_int($size) && $size > 0) {
            $row['last_backup_bytes'] = $size;
        }
        if (!array_key_exists('latest_backup_restore_verified_at', $status) && $status['state'] === 'restore_verified') {
            $row['latest_restore_at'] = $row['last_restore_at'];
        }
        if ($row['last_backup_at'] === null || ($row['latest_restore_at'] ?? 0) < $row['last_backup_at']) {
            $row['latest_restore_at'] = null;
        }
        if ($now - $observed > BACKUP_REPORT_MAX_AGE) {
            $row['state'] = 'stale';
        } elseif (($status['scheduled_upload_paused'] ?? false) === true) {
            $row['state'] = 'paused';
        } elseif ($row['overdue_since'] !== null) {
            $row['state'] = 'overdue';
        } elseif ($row['last_backup_at'] === null) {
            $row['state'] = 'no_verified_backup';
        } else {
            $row['state'] = $row['latest_restore_at'] === null ? 'backup_verified' : 'restore_verified';
        }
        $rows[] = $row;
    }
    return $rows;
}

/** Render an authenticated view's supplied reports without fetching or publishing anything. */
function render_backup_fleet(array $reports, int $now): void {
    $states = [
        'unavailable' => ['notice-warning', 'Status unavailable'],
        'stale' => ['notice-warning', 'Status needs a refresh'],
        'no_verified_backup' => ['notice-error', 'No verified backup'],
        'overdue' => ['notice-warning', 'Backup overdue'],
        'paused' => ['notice-warning', 'Scheduled backup paused'],
        'backup_verified' => ['notice-warning', 'Backup verified, restore test pending'],
        'restore_verified' => ['notice-success', 'Backup and restore verified'],
    ];
    foreach (backup_fleet_rows($reports, $now) as $row) {
        [$class, $label] = $states[$row['state']];
        ?>
        <section class="notice inline <?php echo esc_attr($class); ?>">
            <h2><?php echo esc_html($row['label']); ?></h2>
            <p><strong><?php echo esc_html($label); ?></strong></p>
            <details>
                <summary>Show details</summary>
                <?php if ($row['state'] === 'stale') : ?><p>The last report is more than a day old.</p><?php endif; ?>
                <dl>
                    <dt>Last checked</dt>
                    <dd><?php echo esc_html($row['observed_at'] === null ? 'No report received' : wp_date('M j, Y H:i T', $row['observed_at'])); ?></dd>
                    <dt>Last verified backup</dt>
                    <dd><?php echo esc_html($row['last_backup_at'] === null ? 'Unavailable' : wp_date('M j, Y H:i T', $row['last_backup_at'])); ?></dd>
                    <?php if ($row['last_backup_bytes'] !== null) : ?>
                        <dt>Backup ZIP size</dt>
                        <dd><?php echo esc_html(size_format($row['last_backup_bytes'], 1)); ?></dd>
                    <?php endif; ?>
                    <?php if ($row['last_restore_at'] !== null) : ?>
                        <dt>Last successful restore test</dt>
                        <dd><?php echo esc_html(wp_date('M j, Y H:i T', $row['last_restore_at'])); ?></dd>
                    <?php endif; ?>
                    <?php if ($row['overdue_since'] !== null) : ?>
                        <dt>Overdue since</dt>
                        <dd><?php echo esc_html(wp_date('M j, Y H:i T', $row['overdue_since'])); ?></dd>
                    <?php endif; ?>
                </dl>
                <p><a href="<?php echo esc_url($row['site'] . '/wp-admin/admin.php?page=pebkac-backup'); ?>">
                    Open <?php echo esc_html($row['label']); ?> Overview
                </a></p>
            </details>
        </section>
        <?php
    }
}

/** A privacy-limited report for a Monitor collector already running in the same WordPress process. */
function make_backup_monitor_report(string $site, array $status, int $now): ?array {
    if (!in_array($site, ['https://securitylab.subdiv.net', 'https://pebkac404.com'], true) || $now < 1
        || !in_array($status['state'] ?? null, ['setup_only', 'offsite_verified', 'restore_verified'], true)) {
        return null;
    }
    $public = ['state' => $status['state']];
    foreach (['last_verified_offsite_at', 'last_verified_restore_at', 'latest_backup_restore_verified_at', 'oldest_overdue_at'] as $field) {
        if (!array_key_exists($field, $status)) {
            continue;
        }
        $value = $status[$field];
        $public[$field] = is_int($value) && $value > 0 && $value <= $now ? $value : null;
    }
    $size = $status['last_verified_offsite_size_bytes'] ?? null;
    if (isset($public['last_verified_offsite_at']) && is_int($size) && $size > 0) {
        $public['last_verified_offsite_size_bytes'] = $size;
    }
    return ['schema' => 1, 'observed_at' => $now, 'status' => $public];
}

function monitor_report(): ?array {
    $report = make_backup_monitor_report(home_url(), status(), time());
    if ($report === null) {
        return null;
    }
    try {
        [$job, $running] = read_backup_job_progress(backup_job_root());
        if (!$running && ($job['phase'] ?? '') !== 'verified'
            && (isset($job['daily_date']) || isset(COMPONENTS[$job['component'] ?? '']))
            && backup_job_upload_uncertain($job)) {
            $report['status']['scheduled_upload_paused'] = true;
        }
    } catch (\RuntimeException $error) {
        // Keep the last verified evidence available even when staging cannot be read.
    }
    return $report;
}


/** Add the local report after Website Monitor has authorized and built its private status response. */
function add_backup_to_private_monitor_response($response, array $handler, \WP_REST_Request $request) {
    if (!$response instanceof \WP_REST_Response || $response->get_status() !== 200
        || $request->get_method() !== 'GET' || $request->get_route() !== '/wsm/v1/security-status'
        || ($handler['callback'] ?? null) !== ['WMC_Collector', 'rest_security_status']
        || !current_user_can('manage_options')) {
        return $response;
    }
    $data = $response->get_data();
    if (!is_array($data) || array_key_exists('backup_status', $data)) {
        return $response;
    }
    $report = monitor_report();
    if ($report !== null) {
        $data['backup_status'] = $report;
        $response->set_data($data);
        $response->header('Cache-Control', 'private, no-store');
    }
    return $response;
}

/** Produce the optional backup view for Monitor's existing read-only route. */
function monitor_reader_backup_response() {
    if (!current_user_can('manage_options') && !current_user_can('wmc_read_monitor_status')) {
        return new \WP_Error('backup_status_forbidden', 'Website Monitor reader access is required.', ['status' => 403]);
    }
    $site = home_url();
    $report = monitor_report();
    if ($report === null) {
        return new \WP_Error('backup_status_unavailable', 'Backup status is unavailable.', ['status' => 404]);
    }
    $response = new \WP_REST_Response(['schema' => 1, 'site_url' => $site, 'backup_status' => $report], 200);
    $response->header('Cache-Control', 'private, no-store');
    return $response;
}

/** Normalize an already authenticated report to the small set of fields shown by Sites. */
function normalize_backup_site_report(string $site, $report, int $now): ?array {
    $observed = $report['observed_at'] ?? null;
    if (($report['schema'] ?? null) !== 1 || !is_int($observed) || $observed < 1 || $observed > $now
        || !is_array($report['status'] ?? null)) {
        return null;
    }
    $safe = make_backup_monitor_report($site, $report['status'], $observed);
    if ($safe !== null && ($report['status']['scheduled_upload_paused'] ?? false) === true) {
        $safe['status']['scheduled_upload_paused'] = true;
    }
    return $safe;
}

/** Read only the backup field from responses already authenticated by Website Monitor. */
function backup_site_reports_from_monitor(array $responses, int $now): array {
    $reports = [];
    foreach ($responses as $site => $response) {
        if (!is_string($site) || !is_array($response)
            || (array_key_exists('site_url', $response) && ($response['site_url'] !== $site || ($response['schema'] ?? null) !== 1))) {
            continue;
        }
        $report = normalize_backup_site_report($site, $response['backup_status'] ?? null, $now);
        if ($report !== null) {
            $reports[$site] = $report;
        }
    }
    return $reports;
}

const BACKUP_SITE_REPORTS_OPTION = 'pebkac_backup_site_reports';

/** Use a separate, site-local lock even when Dropbox onboarding is still pending. */
function backup_site_report_lock_root(string $site): string {
    $temp = backup_temp_parent();
    if ($temp === '' || pilot_site_slug($site) === '') {
        throw new \RuntimeException('Private pilot report storage is unavailable for this site.');
    }
    $id = hash_hmac('sha256', 'website-backup/reports|' . $site . '|' . ABSPATH, wp_salt('auth'));
    return private_backup_work_directory($temp, 'website-backup-reports-' . substr($id, 0, 32), true);
}

/** Keep the newest valid peer report. Only a caller that authenticated the source should call this. */
function remember_authenticated_backup_reports(array $responses, int $now): void {
    $reports = backup_site_reports_from_monitor($responses, $now);
    $site = home_url();
    unset($reports[$site]);
    if ($reports === []) {
        return;
    }
    with_backup_job_lock(backup_site_report_lock_root($site), static function () use ($reports, $now): void {
        $saved = get_option(BACKUP_SITE_REPORTS_OPTION, []);
        $next = newest_backup_site_reports($saved, $reports, $now);
        if ($next !== $saved && !update_option(BACKUP_SITE_REPORTS_OPTION, $next, false)) {
            throw new \RuntimeException('Could not save the latest pilot backup report.');
        }
    });
}

function newest_backup_site_reports($saved, $supplied, int $now): array {
    $reports = [];
    foreach ([is_array($saved) ? $saved : [], is_array($supplied) ? $supplied : []] as $source) {
        foreach ($source as $site => $report) {
            $safe = is_string($site) ? normalize_backup_site_report($site, $report, $now) : null;
            if ($safe !== null && $safe['observed_at'] > ($reports[$site]['observed_at'] ?? 0)) {
                $reports[$site] = $safe;
            }
        }
    }
    return $reports;
}

function render_backup_sites(): void {
    $site = home_url();
    // An authenticated collector may supply cached reports from the approved pilots.
    $supplied = apply_filters('pebkac_backup_site_reports', [], $site);
    $reports = newest_backup_site_reports(get_option(BACKUP_SITE_REPORTS_OPTION, []), $supplied, time());
    $reports[$site] = monitor_report();
    render_backup_fleet($reports, time());
}
