<?php

namespace PEBKAC404\Backup;

/** Compute the Dropbox content hash and size from a local archive stream. */
function fingerprint_archive($stream): array {
    $combined = hash_init('sha256');
    $size = 0;
    while (!feof($stream)) {
        $block = stream_get_contents($stream, 4 * 1024 * 1024);
        if ($block === false || ($block === '' && !feof($stream))) {
            throw new \RuntimeException('Could not read backup archive.');
        }
        if ($block !== '') {
            $size += strlen($block);
            hash_update($combined, hash('sha256', $block, true));
        }
    }
    return ['size' => $size, 'content_hash' => hash_final($combined)];
}

/** Compare independently fetched Dropbox file metadata with a trusted manifest. */
function verify_offsite_files(array $expected, callable $fetch_metadata): array {
    if ($expected === []) {
        throw new \InvalidArgumentException('A backup manifest must name at least one archive.');
    }
    $failures = [];
    foreach ($expected as $path => $file) {
        $hash = $file['content_hash'] ?? null;
        $size = $file['size'] ?? null;
        if (!is_string($path) || substr($path, 0, 1) !== '/' || !is_int($size) || $size < 0
            || !is_string($hash) || !preg_match('/^[0-9a-f]{64}$/D', $hash)) {
            throw new \InvalidArgumentException('Invalid backup manifest entry.');
        }
        // The adapter returns null only for a missing file and throws for access or transport errors.
        $actual = $fetch_metadata($path);
        if ($actual === null) {
            $failures[$path] = 'missing';
        } elseif (($actual['.tag'] ?? null) !== 'file' || ($actual['size'] ?? null) !== $size
            || ($actual['content_hash'] ?? null) !== $hash) {
            $failures[$path] = 'metadata_mismatch';
        }
    }
    return ['verified' => $failures === [], 'failures' => $failures];
}
