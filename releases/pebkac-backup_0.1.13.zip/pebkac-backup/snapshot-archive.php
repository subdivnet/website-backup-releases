<?php

namespace PEBKAC404\Backup;

const SNAPSHOT_MAX_BYTES = 256 * 1024 * 1024;
const SNAPSHOT_MAX_FILES = 20000;
const SNAPSHOT_MAX_MANIFEST_BYTES = 16 * 1024 * 1024;
const SNAPSHOT_COMPONENT_DIRECTORIES = [
    'database' => [],
    'uploads' => ['wp-content/uploads'],
    'plugins' => ['wp-content/plugins', 'wp-content/mu-plugins'],
    'themes' => ['wp-content/themes'],
    'core' => ['wp-admin', 'wp-includes', 'wp-content/languages'],
    'configuration' => [],
];
const SNAPSHOT_CORE_FILES = ['index.php', 'wp-activate.php', 'wp-blog-header.php', 'wp-comments-post.php', 'wp-cron.php', 'wp-links-opml.php', 'wp-load.php', 'wp-login.php', 'wp-mail.php', 'wp-settings.php', 'wp-signup.php', 'wp-trackback.php', 'xmlrpc.php'];
const SNAPSHOT_CONFIGURATION_FILES = ['wp-content/advanced-cache.php', 'wp-content/db.php', 'wp-content/object-cache.php', 'wp-content/sunrise.php'];

/** Package a pre-exported SQL dump and selected WordPress files in a new private ZIP. */
function capture_snapshot(string $wordpress, string $database, string $archive, ?float $deadline = null, ?string $component = null): array {
    snapshot_deadline($deadline);
    if ($component !== null && !isset(SNAPSHOT_COMPONENT_DIRECTORIES[$component])) {
        throw new \RuntimeException('Choose a supported backup component.');
    }
    $includes_database = $component === null || $component === 'database';
    $root = realpath($wordpress);
    $parent = realpath(dirname($archive));
    if ($root === false || $parent === false || !is_file($root . '/wp-includes/version.php')
        || ($includes_database && (!is_file($database) || is_link($database) || !filesize($database)))) {
        throw new \RuntimeException('A WordPress tree and any required SQL export must be available.');
    }
    $root_prefix = rtrim(str_replace('\\', '/', $root), '/') . '/';
    $parent_prefix = rtrim(str_replace('\\', '/', $parent), '/') . '/';
    if (stripos($parent_prefix, $root_prefix) === 0) {
        throw new \RuntimeException('Store the archive outside the WordPress tree.');
    }

    $sources = ($includes_database ? ['database.sql' => $database] : []) + snapshot_wordpress_sources($root, $component, $deadline);
    if (count($sources) > SNAPSHOT_MAX_FILES) {
        throw new \RuntimeException('The pilot snapshot exceeds its file count limit.');
    }

    $total = 0;
    foreach ($sources as $path) {
        snapshot_deadline($deadline);
        $size = filesize($path);
        if ($size === false || ($total += $size) > SNAPSHOT_MAX_BYTES) {
            throw new \RuntimeException('The pilot snapshot exceeds its size limit.');
        }
    }
    if (disk_free_space($parent) < 2 * $total + 16 * 1024 * 1024) {
        throw new \RuntimeException('Insufficient private staging space for the pilot snapshot.');
    }

    $zip = new \ZipArchive();
    if ($deadline !== null && !method_exists($zip, 'registerCancelCallback')) {
        throw new \RuntimeException('This host cannot bound the ZIP operation safely.');
    }
    if ($zip->open($archive, \ZipArchive::CREATE | \ZipArchive::EXCL) !== true) {
        throw new \RuntimeException('Choose a new private archive path.');
    }
    if ($deadline !== null && !$zip->registerCancelCallback(static function () use ($deadline): int {
        return microtime(true) >= $deadline ? 1 : 0;
    })) {
        throw new \RuntimeException('Could not set the ZIP time limit.');
    }
    if ($component !== null && !$zip->addFromString('component.json', snapshot_component_marker($component))) {
        $zip->close();
        throw new \RuntimeException('Could not label the component archive.');
    }
    foreach ($sources as $name => $path) {
        snapshot_deadline($deadline);
        if (!$zip->addFile($path, $name)) {
            $zip->close();
            throw new \RuntimeException('Could not add a source file to the snapshot.');
        }
    }
    if (!$zip->close()) {
        throw new \RuntimeException('Could not finish the snapshot ZIP.');
    }
    return inspect_snapshot($archive, $deadline, $component);
}

/** Collect WordPress paths shared by full archives and component scans. */
function snapshot_wordpress_sources(string $root, ?string $component, ?float $deadline): array {
    if (is_link($root . '/wp-content')) {
        throw new \RuntimeException('A required source directory is a symbolic link.');
    }
    $sources = [];
    $directories = $component === null ? array_merge(...array_values(SNAPSHOT_COMPONENT_DIRECTORIES)) : SNAPSHOT_COMPONENT_DIRECTORIES[$component];
    foreach ($directories as $relative) {
        $directory = $root . '/' . $relative;
        if (is_link($directory)) {
            throw new \RuntimeException('A required source directory is a symbolic link.');
        }
        if (!is_dir($directory)) {
            continue;
        }
        $iterator = new \RecursiveIteratorIterator(new \RecursiveDirectoryIterator($directory, \FilesystemIterator::SKIP_DOTS), \RecursiveIteratorIterator::SELF_FIRST);
        foreach ($iterator as $entry) {
            snapshot_deadline($deadline);
            if ($entry->isLink()) {
                throw new \RuntimeException('A backup source contains a symbolic link.');
            }
            if ($entry->isFile()) {
                $path = $entry->getPathname();
                $name = str_replace('\\', '/', substr($path, strlen($root) + 1));
                $sources['wordpress/' . $name] = $path;
                if (count($sources) > SNAPSHOT_MAX_FILES) {
                    throw new \RuntimeException('The pilot snapshot exceeds its file count limit.');
                }
            }
        }
    }
    $root_files = array_merge(
        $component === null || $component === 'core' ? SNAPSHOT_CORE_FILES : [],
        $component === null || $component === 'configuration' ? SNAPSHOT_CONFIGURATION_FILES : []
    );
    foreach ($root_files as $name) {
        $path = $root . '/' . $name;
        if (is_link($path)) {
            throw new \RuntimeException('A WordPress core file is a symbolic link.');
        }
        if (is_file($path)) {
            $sources['wordpress/' . $name] = $path;
        }
    }
    return $sources;
}

function snapshot_component_marker(string $component): string {
    return json_encode(['version' => 1, 'component' => $component]);
}

function snapshot_component_member(string $name, string $component): bool {
    if ($name === 'component.json') {
        return true;
    }
    if ($component === 'database') {
        return $name === 'database.sql';
    }
    foreach (SNAPSHOT_COMPONENT_DIRECTORIES[$component] as $directory) {
        if (strpos($name, 'wordpress/' . $directory . '/') === 0) {
            return true;
        }
    }
    $root_files = $component === 'core' ? SNAPSHOT_CORE_FILES : ($component === 'configuration' ? SNAPSHOT_CONFIGURATION_FILES : []);
    return strpos($name, 'wordpress/') === 0 && in_array(substr($name, strlen('wordpress/')), $root_files, true);
}

function snapshot_deadline(?float $deadline): void {
    if ($deadline !== null && microtime(true) >= $deadline) {
        throw new \RuntimeException('The file backup exceeded the pilot request time limit.');
    }
}

function valid_snapshot_member_name(string $name, ?string $component): bool {
    if ($component !== null && $name === 'component.json') {
        return true;
    }
    return preg_match('~^(?:database\.sql|wordpress/[^/]+(?:/[^/]+)*)$~uD', $name) === 1
        && !preg_match('~[\x00-\x1f\x7f:<>"|?*\\\\]|[. ](?:/|$)|(?:^|/)(?:con|prn|aux|nul|com[1-9]|lpt[1-9])(?:[./]|$)~i', $name)
        && strtolower($name) !== 'wordpress/wp-config.php'
        && ($component === null || snapshot_component_member($name, $component));
}

/** Read and hash the completed archive, so the inventory describes the bytes actually captured. */
function inspect_snapshot(string $archive, ?float $deadline = null, ?string $component = null): array {
    snapshot_deadline($deadline);
    if ($component !== null && !isset(SNAPSHOT_COMPONENT_DIRECTORIES[$component])) {
        throw new \RuntimeException('Choose a supported backup component.');
    }
    $zip = new \ZipArchive();
    if ($zip->open($archive, \ZipArchive::RDONLY) !== true) {
        throw new \RuntimeException('Could not open the snapshot ZIP.');
    }
    $files = [];
    $seen = [];
    $total = 0;
    try {
        if ($zip->numFiles > SNAPSHOT_MAX_FILES + 17) {
            throw new \RuntimeException('Snapshot has too many entries.');
        }
        for ($index = 0; $index < $zip->numFiles; $index++) {
            snapshot_deadline($deadline);
            $entry = $zip->statIndex($index);
            $name = $entry['name'] ?? '';
            $key = strtolower($name);
            if (!valid_snapshot_member_name($name, $component)
                || isset($seen[$key]) || ($total += $entry['size']) > SNAPSHOT_MAX_BYTES) {
                throw new \RuntimeException('Snapshot contains an invalid, repeated or oversized entry.');
            }
            $seen[$key] = true;
            $stream = $zip->getStream($name);
            if ($stream === false) {
                throw new \RuntimeException('Could not read a snapshot entry.');
            }
            $hash = hash_init('sha256');
            $size = hash_update_stream($hash, $stream, $entry['size'] + 1);
            fclose($stream);
            if ($size !== $entry['size']) {
                throw new \RuntimeException('Snapshot entry size changed during inspection.');
            }
            $files[$name] = ['size' => $size, 'sha256' => hash_final($hash)];
        }
        if ($component !== null && $zip->getFromName('component.json', 256) !== snapshot_component_marker($component)) {
            throw new \RuntimeException('The archive does not identify the expected backup component.');
        }
    } finally {
        $zip->close();
    }
    if ((($component === null || $component === 'database') && empty($files['database.sql']['size']))
        || (($component === null || $component === 'core') && empty($files['wordpress/wp-includes/version.php']['size']))) {
        throw new \RuntimeException('Snapshot is missing its SQL export or WordPress version file.');
    }
    ksort($files);
    snapshot_deadline($deadline);
    $manifest = ['archive_sha256' => hash_file('sha256', $archive), 'files' => $files];
    if ($component !== null) {
        $manifest['component'] = $component;
    }
    return $manifest;
}

/** Recover a verified snapshot to a fresh private directory, without running PHP or SQL from it. */
function stage_snapshot_restore(string $archive, array $trusted_manifest, string $destination, ?string $component = null): void {
    if (inspect_snapshot($archive, null, $component) !== $trusted_manifest) {
        throw new \RuntimeException('Downloaded snapshot does not match the trusted capture manifest.');
    }
    if (!@mkdir($destination, 0700)) {
        throw new \RuntimeException('Choose a new isolated restore directory.');
    }
    $zip = new \ZipArchive();
    if ($zip->open($archive, \ZipArchive::RDONLY) !== true) {
        throw new \RuntimeException('Could not reopen the verified snapshot.');
    }
    try {
        foreach ($trusted_manifest['files'] as $name => $expected) {
            extract_verified_backup_member($zip, $name, $expected, $destination);
        }
    } finally {
        $zip->close();
    }
}

function extract_verified_backup_member(\ZipArchive $zip, string $name, array $expected, string $destination): void {
    $target = $destination . '/' . $name;
    $parent = dirname($target);
    if (!is_dir($parent) && !mkdir($parent, 0700, true)) {
        throw new \RuntimeException('Could not make an isolated restore subdirectory.');
    }
    $input = $zip->getStream($name);
    if ($input === false) {
        throw new \RuntimeException('Could not read a snapshot entry for recovery.');
    }
    $output = @fopen($target, 'xb');
    if ($output === false) {
        fclose($input);
        throw new \RuntimeException('Could not open a snapshot entry for recovery.');
    }
    try {
        $written = stream_copy_to_stream($input, $output, $expected['size'] + 1);
    } finally {
        fclose($input);
        fclose($output);
    }
    if ($written !== $expected['size'] || hash_file('sha256', $target) !== $expected['sha256']) {
        throw new \RuntimeException('Recovered snapshot file does not match its manifest.');
    }
}
