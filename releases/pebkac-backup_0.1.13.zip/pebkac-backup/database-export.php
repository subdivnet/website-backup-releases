<?php

namespace PEBKAC404\Backup;

if (!defined('ABSPATH')) {
    exit;
}

const BACKUP_SQL_MAX = 32 * 1024 * 1024;

function backup_sql_identifier(string $name): string {
    if (!preg_match('/^[a-zA-Z0-9_]{1,64}$/D', $name)) {
        throw new \RuntimeException('A database identifier is outside the pilot export format.');
    }
    return '`' . $name . '`';
}

/** Export a bounded, transaction-consistent single-site database using the current WordPress connection. */
function export_wordpress_database($wpdb, $stream, float $seconds = 12.0): int {
    if (!in_array($wpdb->charset, ['utf8mb4', 'utf8', 'utf8mb3'], true)) {
        throw new \RuntimeException('This pilot requires a UTF-8 WordPress database connection.');
    }
    $deadline = microtime(true) + $seconds;
    $bytes = 0;
    $write = static function (string $sql) use ($stream, &$bytes, &$deadline): void {
        if (microtime(true) >= $deadline || ($bytes += strlen($sql)) > BACKUP_SQL_MAX) {
            throw new \RuntimeException('The database export exceeded the pilot time or size limit.');
        }
        if (fwrite($stream, $sql) !== strlen($sql)) {
            throw new \RuntimeException('Could not write the private database export.');
        }
    };
    $previous = $wpdb->suppress_errors(true);
    $read = static function (string $query) use ($wpdb): array {
        $result = $wpdb->get_results($query, ARRAY_A);
        if ($wpdb->last_error !== '' || !is_array($result)) {
            throw new \RuntimeException('WordPress could not read a database table for backup.');
        }
        return $result;
    };
    $transaction = false;
    $locked = false;
    $session = null;
    try {
        // A session reconnect would discard the snapshot. Record and recheck its identity.
        $identity = $read('SELECT CONNECTION_ID() AS id')[0]['id'] ?? null;
        $tables = $read($wpdb->prepare(
            'SELECT TABLE_NAME AS name, ENGINE AS engine FROM information_schema.TABLES WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME LIKE %s ORDER BY TABLE_NAME',
            $wpdb->esc_like($wpdb->prefix) . '%'
        ));
        $names = array_column($tables, 'name');
        $required = array_map(static function ($name) use ($wpdb) { return $wpdb->prefix . $name; },
            ['options', 'posts', 'postmeta', 'users', 'usermeta', 'terms', 'term_taxonomy', 'term_relationships', 'comments', 'commentmeta']);
        if ($identity === null || array_diff($required, $names) || count($tables) > 250) {
            throw new \RuntimeException('Could not verify the expected WordPress database tables.');
        }
        $identifiers = [];
        $mixed = false;
        foreach ($tables as $table) {
            $name = $table['name'];
            $engine = strtolower((string) $table['engine']);
            if (strpos($name, $wpdb->prefix) !== 0 || !in_array($engine, ['innodb', 'myisam'], true)) {
                throw new \RuntimeException('A site table cannot be included in a consistent pilot export.');
            }
            $identifiers[$name] = backup_sql_identifier($name);
            $mixed = $mixed || $engine === 'myisam';
        }
        if ($mixed) {
            $session = $read('SELECT @@SESSION.autocommit AS autocommit, @@SESSION.lock_wait_timeout AS lock_timeout, @@SESSION.innodb_table_locks AS innodb_locks, @@SESSION.innodb_lock_wait_timeout AS innodb_timeout')[0] ?? [];
            if ((int) ($session['autocommit'] ?? 0) !== 1 || (int) ($session['innodb_locks'] ?? 0) !== 1
                || $wpdb->query('SET SESSION autocommit = 0, SESSION lock_wait_timeout = 2, SESSION innodb_lock_wait_timeout = 2') === false
                || $wpdb->query('LOCK TABLES ' . implode(' READ, ', $identifiers) . ' READ') === false) {
                throw new \RuntimeException('WordPress could not obtain short read locks for this mixed database.');
            }
            $locked = true;
            $deadline = min($deadline, microtime(true) + 6);
        } else {
            if ($wpdb->query('SET TRANSACTION ISOLATION LEVEL REPEATABLE READ') === false
                || $wpdb->query('START TRANSACTION WITH CONSISTENT SNAPSHOT, READ ONLY') === false) {
                throw new \RuntimeException('WordPress could not start a consistent database export.');
            }
            $transaction = true;
        }
        $write("SET NAMES utf8mb4;\nSET FOREIGN_KEY_CHECKS=0;\n");
        foreach ($identifiers as $name => $identifier) {
            $definition = $read('SHOW CREATE TABLE ' . $identifier)[0]['Create Table'] ?? '';
            if (strpos($definition, 'CREATE TABLE ') !== 0) {
                throw new \RuntimeException('Could not read a table definition.');
            }
            $columns = [];
            $binary = [];
            foreach ($read('SHOW FULL COLUMNS FROM ' . $identifier) as $column) {
                if (stripos($column['Extra'], 'GENERATED') === false) {
                    $columns[] = backup_sql_identifier($column['Field']);
                    $binary[$column['Field']] = preg_match('/^(?:bit|binary|varbinary|(?:tiny|medium|long)?blob)(?:\(|$)/i', $column['Type']) === 1;
                }
            }
            $primary = $read('SHOW INDEX FROM ' . $identifier . " WHERE Key_name = 'PRIMARY'");
            usort($primary, static function ($left, $right) { return (int) $left['Seq_in_index'] <=> (int) $right['Seq_in_index']; });
            if (!$columns || !$primary) {
                throw new \RuntimeException('A site table has no stable primary key for the pilot export.');
            }
            $order = implode(', ', array_map('PEBKAC404\\Backup\\backup_sql_identifier', array_column($primary, 'Column_name')));
            $fields = implode(', ', $columns);
            $where = '';
            if ($name === $wpdb->options) {
                $where = $wpdb->prepare(' WHERE `option_name` <> %s AND `option_name` NOT LIKE %s AND `option_name` NOT LIKE %s',
                    DROPBOX_CREDENTIAL_OPTION, $wpdb->esc_like('_transient_pebkac_dbx_') . '%',
                    $wpdb->esc_like('_transient_timeout_pebkac_dbx_') . '%');
            }
            $write($definition . ";\n");
            for ($offset = 0; ; $offset += 25) {
                if (microtime(true) >= $deadline) {
                    throw new \RuntimeException('The database export exceeded the pilot time limit.');
                }
                $rows = $read("SELECT $fields FROM $identifier$where ORDER BY $order LIMIT 25 OFFSET $offset");
                foreach ($rows as $row) {
                    $values = [];
                    foreach ($binary as $field => $is_binary) {
                        $value = $row[$field];
                        $hex = "X'" . bin2hex((string) $value) . "'";
                        $values[] = $value === null ? 'NULL' : ($is_binary ? $hex : "CONVERT($hex USING utf8mb4)");
                    }
                    $write("INSERT INTO $identifier ($fields) VALUES (" . implode(', ', $values) . ");\n");
                }
                if (count($rows) < 25) {
                    break;
                }
            }
        }
        if (($read('SELECT CONNECTION_ID() AS id')[0]['id'] ?? null) !== $identity) {
            throw new \RuntimeException('The database connection changed during export.');
        }
        $write("SET FOREIGN_KEY_CHECKS=1;\n");
        return $bytes;
    } finally {
        if ($transaction) {
            $wpdb->query('ROLLBACK');
        }
        if ($locked) {
            $wpdb->query('UNLOCK TABLES');
        }
        if (isset($session['autocommit'], $session['lock_timeout'], $session['innodb_timeout'])) {
            $wpdb->query('SET SESSION autocommit = ' . (int) $session['autocommit']
                . ', SESSION lock_wait_timeout = ' . (int) $session['lock_timeout']
                . ', SESSION innodb_lock_wait_timeout = ' . (int) $session['innodb_timeout']);
        }
        $wpdb->suppress_errors($previous);
    }
}
