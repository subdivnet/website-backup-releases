<?php

namespace PEBKAC404\Backup;

/** Advance one request-sized step of a daily full backup. The caller supplies the job runner. */
function advance_daily_backup(string $root, string $local_time, \DateTimeZone $timezone, int $now, callable $advance): string {
    $local = (new \DateTimeImmutable('@' . $now))->setTimezone($timezone);
    $day = $local->format('Y-m-d');
    $due = backup_schedule_occurrence(['frequency' => 'daily', 'time' => $local_time], $timezone, $local->setTime(0, 0)->getTimestamp());
    if ($due === null) {
        throw new \RuntimeException('The daily backup time is invalid.');
    }

    return with_backup_job_lock($root, static function () use ($root, $local_time, $timezone, $now, $day, $due, $advance): string {
        $job = read_backup_job($root);
        if (isset($job['component'])) {
            $claim = get_option(SCHEDULED_BACKUP_JOB_OPTION, []);
            if ($job['phase'] !== 'verified' || ($claim['id'] ?? null) === $job['id']) {
                return 'busy';
            }
        }
        if ($job !== [] && $job['phase'] !== 'verified') {
            if (!isset($job['daily_date']) || backup_job_upload_uncertain($job)) {
                return 'blocked';
            }
            if (in_array($job['phase'], ['exporting', 'archiving'], true)) {
                return retry_scheduled_backup_capture($root, $job);
            }
        } else {
            if (!empty($job['cleanup_pending'])) {
                return 'blocked';
            }
            $proof = verified_evidence(get_option(EVIDENCE_OPTION, []), home_url(), $now);
            if (isset($proof['manifest_path'])) {
                $verified_day = (new \DateTimeImmutable('@' . $proof['offsite_verified_at']))->setTimezone($timezone)->format('Y-m-d');
                if ($verified_day === $day) {
                    return 'verified_today';
                }
            } elseif ($job !== [] && !isset($job['component'])) {
                return 'blocked';
            }
            if (($job['daily_date'] ?? '') === $day) {
                return 'verified_today';
            }
            if ($now < $due) {
                $timing = active_daily_backup_status(['enabled' => true, 'time' => $local_time],
                    get_option(DAILY_BACKUP_TIMING_OPTION, []), $timezone, $now, $proof['offsite_verified_at'] ?? null);
                if (!isset($timing['overdue_since'])) {
                    return 'waiting';
                }
            }
            $job = ['id' => bin2hex(random_bytes(16)), 'phase' => 'database', 'daily_date' => $day];
            $folder = backup_dropbox_folder(get_plan());
            if ($folder !== PILOT_DROPBOX_FOLDER) {
                $job['folder'] = $folder;
            }
            write_backup_job($root, $job);
        }
        $advance($root, $job);
        return 'advanced';
    });
}

const DAILY_BACKUP_HOOK = 'pebkac_backup_daily_step';

function daily_backup_settings(array $plan): array {
    $settings = $plan['daily'] ?? [];
    $time = $settings['time'] ?? '';
    if (!is_string($time) || !preg_match('/^(?:[01][0-9]|2[0-3]):[0-5][0-9]$/D', $time)) {
        return ['enabled' => false, 'time' => '02:00'];
    }
    return ['enabled' => ($settings['enabled'] ?? false) === true, 'time' => $time];
}

function next_daily_backup_event(array $settings, \DateTimeZone $timezone, int $now, string $result): ?int {
    if (!$settings['enabled']) {
        return null;
    }
    if (in_array($result, ['advanced', 'busy'], true)) {
        return $now + 60;
    }
    return backup_schedule_occurrence(['frequency' => 'daily', 'time' => $settings['time']], $timezone, $now + 1);
}

function queue_daily_backup_event(?int $at): void {
    if ($at !== null && wp_next_scheduled(DAILY_BACKUP_HOOK) === false) {
        wp_schedule_single_event($at, DAILY_BACKUP_HOOK);
    }
}

function run_daily_backup_event(): void {
    $settings = daily_backup_settings(get_plan());
    if (!$settings['enabled']) {
        return;
    }
    $timezone = wp_timezone();
    $result = 'blocked';
    try {
        if (backup_capture_supported() && dropbox_saved_refresh_token(dropbox_app_key()) !== '') {
            $result = advance_daily_backup(backup_job_root(true), $settings['time'], $timezone, time(), __NAMESPACE__ . '\\advance_backup_job');
        }
        if ($result === 'verified_today') {
            queue_backup_retention_event();
        }
    } catch (\RuntimeException $error) {
        // The durable job is left available for the next run or for an administrator to inspect.
    } finally {
        queue_daily_backup_event(next_daily_backup_event($settings, $timezone, time(), $result));
    }
}

add_action(DAILY_BACKUP_HOOK, __NAMESPACE__ . '\\run_daily_backup_event');

add_action('init', static function (): void {
    queue_component_backup_event(time() + 60);
    $settings = daily_backup_settings(get_plan());
    if ($settings['enabled']) {
        $timezone = wp_timezone();
        if (refresh_daily_backup_timing($settings, $timezone, time())) {
            wp_clear_scheduled_hook(DAILY_BACKUP_HOOK);
        }
        queue_daily_backup_event(next_daily_backup_event($settings, $timezone, time(), 'waiting'));
    }
});

add_action('update_option_' . OPTION, static function ($old, $new): void {
    reconcile_component_backup_event((array) $old, (array) $new);
    if (automatic_backup_retention_enabled((array) $old) && !automatic_backup_retention_enabled((array) $new)) {
        wp_clear_scheduled_hook(BACKUP_RETENTION_HOOK);
    }
    if (daily_backup_settings((array) $old) !== daily_backup_settings((array) $new)) {
        refresh_daily_backup_timing(daily_backup_settings((array) $new), wp_timezone(), time());
        wp_clear_scheduled_hook(DAILY_BACKUP_HOOK);
        queue_daily_backup_event(next_daily_backup_event(daily_backup_settings((array) $new), wp_timezone(), time(), 'waiting'));
    }
}, 10, 2);

add_action('add_option_' . OPTION, static function ($option, $value): void {
    queue_component_backup_event(time() + 60);
    $settings = daily_backup_settings((array) $value);
    if ($settings['enabled']) {
        refresh_daily_backup_timing($settings, wp_timezone(), time());
        queue_daily_backup_event(next_daily_backup_event($settings, wp_timezone(), time(), 'waiting'));
    }
}, 10, 2);

const DAILY_BACKUP_TIMING_OPTION = 'pebkac_backup_daily_timing';

/** Preserve when the current daily rule took effect, independently of continuation events. */
function refresh_daily_backup_timing(array $settings, \DateTimeZone $timezone, int $now): bool {
    $saved = get_option(DAILY_BACKUP_TIMING_OPTION, []);
    $rules = ['time' => $settings['time'], 'timezone' => $timezone->getName()];
    if (!$settings['enabled']) {
        return $saved !== [] && update_option(DAILY_BACKUP_TIMING_OPTION, [], false);
    }
    if (($saved['rules'] ?? null) === $rules && is_int($saved['enabled_at'] ?? null) && $saved['enabled_at'] > 0) {
        return false;
    }
    return update_option(DAILY_BACKUP_TIMING_OPTION, ['rules' => $rules, 'enabled_at' => $now], false);
}

/** Use the saved daily rule and last verified full backup, never the next cron callback. */
function active_daily_backup_status(array $settings, $timing, \DateTimeZone $timezone, int $now, ?int $verified_at): array {
    $enabled_at = $timing['enabled_at'] ?? null;
    if (!$settings['enabled'] || ($timing['rules'] ?? null) !== ['time' => $settings['time'], 'timezone' => $timezone->getName()]
        || !is_int($enabled_at) || $enabled_at < 1 || $enabled_at > $now) {
        return [];
    }
    $from = $enabled_at;
    if ($verified_at !== null && $verified_at > 0 && $verified_at <= $now) {
        $verified_day = (new \DateTimeImmutable('@' . $verified_at))->setTimezone($timezone);
        $following_day = $verified_day->modify('+1 day')->setTime(0, 0)->getTimestamp();
        $from = max($from, $following_day);
    }
    $due = backup_schedule_occurrence(['frequency' => 'daily', 'time' => $settings['time']], $timezone, $from);
    return ['next_due_at' => $due, 'overdue_since' => $due !== null && $due < $now ? $due : null];
}
