<?php

namespace PEBKAC404\Backup;

if (!defined('ABSPATH')) {
    exit;
}

require_once __DIR__ . '/dropbox-snapshot.php';
require_once __DIR__ . '/backup-incremental.php';

/** Pin the archive and each bounded chunk before initiating a Dropbox upload. */
function plan_wordpress_transfer(string $archive, string $sha256, string $remote, float $deadline, ?string $site = null, ?string $component = null, string $folder = PILOT_DROPBOX_FOLDER): array {
    $destination_valid = $site !== null
        ? pilot_backup_object_path($site, $remote, $component, $folder)
        : $component === null && $folder === PILOT_DROPBOX_FOLDER && preg_match('~^' . preg_quote(PILOT_DROPBOX_FOLDER, '~') . '/(?:securitylab|pebkac404)-[a-f0-9]{32}\.(?:zip|manifest\.json)$~D', $remote);
    if (!$destination_valid || !preg_match('/^[a-f0-9]{64}$/D', $sha256) || is_link($archive)) {
        throw new \RuntimeException('The pilot archive or destination is invalid.');
    }
    $stream = @fopen($archive, 'rb');
    if ($stream === false) {
        throw new \RuntimeException('The private ZIP could not be opened.');
    }
    $blocks = [];
    $total = 0;
    $whole = hash_init('sha256');
    $dropbox = hash_init('sha256');
    try {
        while (!feof($stream)) {
            snapshot_deadline($deadline);
            $chunk = stream_get_contents($stream, SNAPSHOT_CHUNK_BYTES);
            if ($chunk === false || ($chunk === '' && !feof($stream)) || ($total += strlen($chunk)) > SNAPSHOT_MAX_BYTES + 8 * 1024 * 1024) {
                throw new \RuntimeException('The pilot ZIP exceeds its transfer limit or could not be read.');
            }
            if ($chunk !== '') {
                $digest = hash('sha256', $chunk, true);
                $blocks[] = bin2hex($digest);
                hash_update($dropbox, $digest);
                hash_update($whole, $chunk);
            }
        }
    } finally {
        fclose($stream);
    }
    if ($total === 0 || hash_final($whole) !== $sha256) {
        throw new \RuntimeException('The pilot ZIP no longer matches its capture manifest.');
    }
    return ['phase' => 'start', 'path' => $remote, 'size' => $total, 'sha256' => $sha256,
        'content_hash' => hash_final($dropbox), 'blocks' => $blocks, 'offset' => 0];
}

/** Pin both staged incremental objects to the verified parent before starting any upload. */
function plan_incremental_wordpress_transfer(
    string $directory, string $site, string $job_id, array $parent, array $baseline,
    string $manifest_sha256, int $now, float $deadline, string $folder = PILOT_DROPBOX_FOLDER
): array {
    $component = $baseline['component'] ?? null;
    if (!is_string($component) || !is_array($baseline['files'] ?? null)) {
        throw new \RuntimeException('A verified incremental parent inventory is required.');
    }
    require_verified_component_record($site, $component, $parent, $now);
    $remote_base = pilot_backup_base($site, $job_id, $component, $folder);
    $parent_hash = incremental_inventory_sha256($component, incremental_file_inventory($component, $baseline['files']));
    if ($remote_base . '.zip' === $parent['archive_path'] || ($parent['inventory_sha256'] ?? null) !== $parent_hash) {
        throw new \RuntimeException('The staged backup must follow its verified parent at a new destination.');
    }
    snapshot_deadline($deadline);
    $archive = $directory . '/backup.zip';
    $sidecar = $directory . '/manifest.json';
    $bytes = !is_link($sidecar) ? @file_get_contents($sidecar, false, null, 0, SNAPSHOT_MAX_MANIFEST_BYTES + 1) : false;
    if ($bytes === false || strlen($bytes) > SNAPSHOT_MAX_MANIFEST_BYTES || !hash_equals($manifest_sha256, hash('sha256', $bytes))) {
        throw new \RuntimeException('The incremental manifest no longer matches its staged capture.');
    }
    $manifest = json_decode($bytes, true);
    $delta = $manifest['delta'] ?? null;
    if (!is_array($delta) || inspect_incremental_file_backup($archive, $baseline, $delta, $deadline) !== $manifest) {
        throw new \RuntimeException('The staged incremental ZIP and manifest do not match.');
    }
    return [
        'component_capture' => [
            'component' => $component, 'archive_sha256' => $manifest['archive_sha256'],
            'manifest_sha256' => $manifest_sha256, 'inventory_sha256' => $delta['result_inventory_sha256'],
            'parent_path' => $parent['archive_path'], 'base_inventory_sha256' => $parent_hash,
        ],
        'transfer' => plan_wordpress_transfer($archive, $manifest['archive_sha256'], $remote_base . '.zip', $deadline, $site, $component, $folder),
        'manifest_transfer' => plan_wordpress_transfer($sidecar, $manifest_sha256, $remote_base . '.manifest.json', $deadline, $site, $component, $folder),
    ];
}

/** Run one provider operation per request. $save must persist under the controller's lock. */
function advance_wordpress_transfer(array $state, string $archive, string $token, callable $save): array {
    validate_snapshot_token($token);
    $phase = $state['phase'];
    if (in_array($phase, ['starting', 'appending'], true)) {
        throw new \RuntimeException('Dropbox did not confirm an earlier step. This upload will not be repeated.');
    }
    if ($phase === 'start') {
        $state['phase'] = 'starting';
        $save($state);
        $response = snapshot_dropbox_request('upload_session/start', ['close' => false], '', $token);
        $session = json_decode(wp_remote_retrieve_body($response), true)['session_id'] ?? null;
        if (wp_remote_retrieve_response_code($response) !== 200 || !is_string($session) || $session === '') {
            throw new \RuntimeException('Dropbox did not confirm the start of the upload.');
        }
        $state['session'] = $session;
        $state['phase'] = 'append';
    } elseif ($phase === 'append') {
        $offset = $state['offset'];
        $length = min(SNAPSHOT_CHUNK_BYTES, $state['size'] - $offset);
        $index = intdiv($offset, SNAPSHOT_CHUNK_BYTES);
        $chunk = !is_link($archive) && $length > 0 ? @file_get_contents($archive, false, null, $offset, $length) : false;
        if ($chunk === false || strlen($chunk) !== $length || hash('sha256', $chunk) !== ($state['blocks'][$index] ?? '')) {
            throw new \RuntimeException('A ZIP chunk no longer matches the captured archive.');
        }
        $state['phase'] = 'appending';
        $save($state);
        $response = snapshot_dropbox_request('upload_session/append_v2', [
            'cursor' => ['session_id' => $state['session'], 'offset' => $offset], 'close' => false,
        ], $chunk, $token);
        if (wp_remote_retrieve_response_code($response) !== 200) {
            throw new \RuntimeException('Dropbox did not confirm the uploaded chunk.');
        }
        $state['offset'] += $length;
        $state['phase'] = $state['offset'] === $state['size'] ? 'commit' : 'append';
    } elseif ($phase === 'commit') {
        $state['phase'] = 'committing';
        $save($state);
        snapshot_dropbox_request('upload_session/finish', [
            'cursor' => ['session_id' => $state['session'], 'offset' => $state['offset']],
            'commit' => ['path' => $state['path'], 'mode' => 'add', 'autorename' => false, 'strict_conflict' => true, 'mute' => true],
        ], '', $token, true);
        $state['phase'] = 'verify';
    } elseif ($phase === 'committing' || $phase === 'verify') {
        $result = verify_dropbox_manifest([
            $state['path'] => ['size' => $state['size'], 'content_hash' => $state['content_hash']],
        ], $token);
        if (!$result['verified']) {
            throw new \RuntimeException('Dropbox has no matching copy at the recorded backup path.');
        }
        unset($state['session'], $state['blocks']);
        $state['phase'] = 'verified';
        $state['verified_at'] = time();
    } else {
        throw new \RuntimeException('The backup is not in a transferable state.');
    }
    $save($state);
    return $state;
}
