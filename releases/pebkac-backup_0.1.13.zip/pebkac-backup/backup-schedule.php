<?php

namespace PEBKAC404\Backup;

const BACKUP_SCHEDULE_STATE_OPTION = 'pebkac_backup_schedule_state';
const SCHEDULED_BACKUP_JOB_OPTION = 'pebkac_backup_scheduled_job';

/** Find the first occurrence at or after the supplied timestamp in the site's timezone. */
function backup_schedule_occurrence($schedule, \DateTimeZone $timezone, int $from): ?int {
    if (!is_array($schedule)) {
        return null;
    }
    $frequency = $schedule['frequency'] ?? '';
    $time = $schedule['time'] ?? '';
    if (!in_array($frequency, ['daily', 'weekly'], true) || !is_string($time)
        || !preg_match('/^(?:[01][0-9]|2[0-3]):[0-5][0-9]$/D', $time)) {
        return null;
    }
    $local = (new \DateTimeImmutable('@' . $from))->setTimezone($timezone);
    $offset = 0;
    if ($frequency === 'weekly') {
        $weekday = array_search($schedule['day'] ?? '', DAYS, true);
        if ($weekday === false) {
            return null;
        }
        $offset = ($weekday + 8 - (int) $local->format('N')) % 7;
    }
    $day = $local->modify('+' . $offset . ' days');
    $candidate = new \DateTimeImmutable($day->format('Y-m-d') . ' ' . $time, $timezone);
    if ($candidate->getTimestamp() < $from) {
        $day = $day->modify($frequency === 'daily' ? '+1 day' : '+7 days');
        $candidate = new \DateTimeImmutable($day->format('Y-m-d') . ' ' . $time, $timezone);
    }
    return $candidate->getTimestamp();
}

/** Preserve the oldest unfulfilled occurrence until that occurrence is verified off-site. */
function backup_schedule_status($schedule, \DateTimeZone $timezone, int $enabled_at, ?int $verified_due_at, int $now): array {
    $from = $verified_due_at !== null && $verified_due_at >= $enabled_at && $verified_due_at <= $now
        ? $verified_due_at + 1 : $enabled_at;
    $due = backup_schedule_occurrence($schedule, $timezone, $from);
    return [
        'next_due_at' => $due,
        'overdue_since' => $due !== null && $due < $now ? $due : null,
    ];
}

function component_schedule_rules($schedule, \DateTimeZone $timezone, int $now): ?array {
    if (backup_schedule_occurrence($schedule, $timezone, $now) === null) {
        return null;
    }
    return [
        'frequency' => $schedule['frequency'],
        'time' => $schedule['time'],
        'day' => $schedule['frequency'] === 'weekly' ? $schedule['day'] : null,
        'timezone' => $timezone->getName(),
    ];
}

/** Reconcile active schedules while holding the backup job lock. Call only when the worker is enabled. */
function sync_backup_schedule_state(array $plan, \DateTimeZone $timezone, int $now): array {
    $saved = get_option(BACKUP_SCHEDULE_STATE_OPTION, []);
    $state = [];
    foreach (COMPONENTS as $component => $label) {
        $rules = component_schedule_rules($plan['schedules'][$component] ?? null, $timezone, $now);
        if ($rules === null) {
            continue;
        }
        $previous = $saved[$component] ?? null;
        if (is_array($previous) && ($previous['rules'] ?? null) === $rules
            && is_int($previous['enabled_at'] ?? null) && $previous['enabled_at'] > 0
            && array_key_exists('verified_due_at', $previous)
            && ($previous['verified_due_at'] === null || is_int($previous['verified_due_at']))) {
            $state[$component] = $previous;
        } else {
            $state[$component] = ['rules' => $rules, 'enabled_at' => $now, 'verified_due_at' => null];
        }
    }
    if ($state !== $saved && !update_option(BACKUP_SCHEDULE_STATE_OPTION, $state, false)) {
        throw new \RuntimeException('Could not save the backup schedule state.');
    }
    return $state;
}

/** Advance an occurrence after its off-site verification, while holding the backup job lock. */
function record_backup_schedule_verification(string $component, array $claimed, int $due, int $verified_at, int $now): bool {
    $state = get_option(BACKUP_SCHEDULE_STATE_OPTION, []);
    $current = $state[$component] ?? null;
    if (!isset(COMPONENTS[$component]) || !is_array($current) || $verified_at < $due || $verified_at > $now) {
        return false;
    }
    $verified = $claimed;
    $verified['verified_due_at'] = $due;
    if ($current === $verified) {
        return true;
    }
    if ($current !== $claimed) {
        return false;
    }
    $rules = $claimed['rules'];
    $timezone = new \DateTimeZone($rules['timezone']);
    $expected = backup_schedule_status($rules, $timezone, $claimed['enabled_at'], $claimed['verified_due_at'], $now);
    if ($expected['next_due_at'] !== $due) {
        return false;
    }
    $state[$component] = $verified;
    if (!update_option(BACKUP_SCHEDULE_STATE_OPTION, $state, false)) {
        throw new \RuntimeException('Could not save the verified scheduled backup.');
    }
    return true;
}

/** Read the schedule without writing options or starting backup work. */
function scheduled_backup_due_times(array $state, int $now): array {
    $times = [];
    foreach ($state as $component => $record) {
        $rules = $record['rules'];
        $timezone = new \DateTimeZone($rules['timezone']);
        $times[$component] = backup_schedule_status($rules, $timezone, $record['enabled_at'], $record['verified_due_at'], $now);
    }
    return $times;
}

/** Reserve one due component while holding the backup job lock, before any transfer. */
function claim_scheduled_backup(array $state, int $now): ?array {
    $pending = get_option(SCHEDULED_BACKUP_JOB_OPTION, []);
    if ($pending !== []) {
        if (!is_array($pending) || !is_string($pending['id'] ?? null) || !preg_match('/^[a-f0-9]{32}$/D', $pending['id'])
            || !isset(COMPONENTS[$pending['component'] ?? '']) || !is_int($pending['due_at'] ?? null)
            || !is_array($pending['schedule'] ?? null)) {
            throw new \RuntimeException('Could not read the saved scheduled backup.');
        }
        return $pending;
    }
    $job = null;
    foreach (scheduled_backup_due_times($state, $now) as $component => $timing) {
        $due = $timing['next_due_at'];
        if ($due !== null && $due <= $now && ($job === null || $due < $job['due_at'])) {
            $job = ['component' => $component, 'due_at' => $due, 'schedule' => $state[$component]];
        }
    }
    if ($job === null) {
        return null;
    }
    $job['id'] = bin2hex(random_bytes(16));
    if (!update_option(SCHEDULED_BACKUP_JOB_OPTION, $job, false)) {
        throw new \RuntimeException('Could not save the scheduled backup before starting it.');
    }
    return $job;
}

/** Settle a claimed job only after its own Dropbox objects were verified. Caller holds the backup job lock. */
function settle_scheduled_backup(array $job, string $verified_job_id, int $verified_at, int $now): bool {
    if (get_option(SCHEDULED_BACKUP_JOB_OPTION, []) !== $job || ($job['id'] ?? null) !== $verified_job_id
        || $verified_at < $job['due_at'] || $verified_at > $now) {
        return false;
    }
    $schedules = get_option(BACKUP_SCHEDULE_STATE_OPTION, []);
    $current = $schedules[$job['component']] ?? [];
    $same_schedule = ($current['rules'] ?? null) === $job['schedule']['rules']
        && ($current['enabled_at'] ?? null) === $job['schedule']['enabled_at'];
    if ($same_schedule && !record_backup_schedule_verification($job['component'], $job['schedule'], $job['due_at'], $verified_at, $now)) {
        return false;
    }
    if (!update_option(SCHEDULED_BACKUP_JOB_OPTION, [], false)) {
        throw new \RuntimeException('The scheduled backup verified but its saved job could not be closed.');
    }
    return true;
}

/** Advance a single scheduled component while sharing the full backup's private job lock. */
function run_scheduled_component_step(string $root, array $plan, \DateTimeZone $timezone, int $now, callable $advance): string {
    return with_backup_job_lock($root, static function () use ($root, $plan, $timezone, $now, $advance): string {
        $job = read_backup_job($root);
        if ($job !== [] && !isset($job['component']) && ($job['phase'] !== 'verified' || !empty($job['cleanup_pending']))) {
            return 'busy';
        }
        if (isset($job['component']) && $job['phase'] !== 'verified') {
            $pending = get_option(SCHEDULED_BACKUP_JOB_OPTION, []);
            if (($pending['id'] ?? null) !== $job['id']) {
                return 'blocked';
            }
        }
        $state = sync_backup_schedule_state($plan, $timezone, $now);
        $claim = claim_scheduled_backup($state, $now);
        if ($claim === null) {
            return 'waiting';
        }
        if (isset($job['component']) && $job['id'] === $claim['id']) {
            if ($job['component'] !== $claim['component'] || ($job['scheduled_due_at'] ?? null) !== $claim['due_at']) {
                throw new \RuntimeException('The saved component job does not match its scheduled occurrence.');
            }
            if ($job['phase'] === 'verified') {
                $path = pilot_backup_base(home_url(), $claim['id'], $claim['component'], backup_dropbox_folder($job)) . '.zip';
                $recovery = get_option(COMPONENT_RECOVERY_STATE_OPTION, []);
                $record = $recovery['records'][$path] ?? [];
                if (($record['archive_sha256'] ?? null) !== ($job['transfer']['sha256'] ?? false)
                    || ($record['manifest_sha256'] ?? null) !== ($job['manifest_transfer']['sha256'] ?? false)
                    || !is_int($record['offsite_verified_at'] ?? null)
                    || !settle_scheduled_backup($claim, $job['id'], $record['offsite_verified_at'], $now)) {
                    throw new \RuntimeException('The scheduled component could not be confirmed as verified.');
                }
                return 'settled';
            }
            if (backup_job_upload_uncertain($job)) {
                return 'blocked';
            }
            if (in_array($job['phase'], ['exporting', 'archiving'], true)) {
                return retry_scheduled_backup_capture($root, $job);
            }
        } else {
            if ($job !== [] && ($job['phase'] !== 'verified' || !empty($job['cleanup_pending']))) {
                return 'busy';
            }
            $component = $claim['component'];
            $job = ['id' => $claim['id'], 'component' => $component, 'scheduled_due_at' => $claim['due_at'],
                'phase' => $component === 'database' ? 'database' : 'files'];
            $folder = backup_dropbox_folder($plan);
            if ($folder !== PILOT_DROPBOX_FOLDER) {
                $job['folder'] = $folder;
            }
            if ($component !== 'database' && ($plan['incremental_components'] ?? false) === true) {
                $history = get_option(COMPONENT_RECOVERY_STATE_OPTION, ['records' => [], 'latest' => []]);
                $chain = plan_component_inventory_replay(home_url(), $component, $history, $now);
                if ($chain !== [] && count($chain) < COMPONENT_REPLAY_MAX_MANIFESTS) {
                    $job['phase'] = 'replay_inventory';
                    $job['incremental'] = true;
                }
            }
            write_backup_job($root, $job);
        }
        $advance($root, $job);
        return 'advanced';
    });
}

const COMPONENT_BACKUP_HOOK = 'pebkac_backup_component_step';

function component_backups_enabled(array $plan): bool {
    return ($plan['component_jobs'] ?? false) === true;
}

function queue_component_backup_event(int $at): void {
    if (component_backups_enabled(get_plan()) && wp_next_scheduled(COMPONENT_BACKUP_HOOK) === false) {
        wp_schedule_single_event($at, COMPONENT_BACKUP_HOOK);
    }
}

function run_component_backup_event(): void {
    $plan = get_plan();
    if (!component_backups_enabled($plan)) {
        return;
    }
    $now = time();
    $timezone = wp_timezone();
    $next = $now + 3600;
    try {
        if (backup_capture_supported() && dropbox_saved_refresh_token(dropbox_app_key()) !== '') {
            $result = run_scheduled_component_step(backup_job_root(true), $plan, $timezone, $now, __NAMESPACE__ . '\\advance_backup_job');
            if (in_array($result, ['advanced', 'settled', 'busy'], true)) {
                $next = $now + 60;
            } elseif ($result === 'waiting') {
                $state = get_option(BACKUP_SCHEDULE_STATE_OPTION, []);
                $due_times = array_filter(array_column(scheduled_backup_due_times($state, $now), 'next_due_at'), 'is_int');
                $next = $due_times === [] ? $now + 3600 : max($now + 60, min($due_times));
            }
        }
    } catch (\RuntimeException $error) {
        // Keep a saved claim intact; a later callback can inspect its last known state.
    } finally {
        queue_component_backup_event($next);
    }
}

function reconcile_component_backup_event(array $old, array $new): void {
    if (component_backups_enabled($old) !== component_backups_enabled($new)
        || ($old['schedules'] ?? []) !== ($new['schedules'] ?? [])) {
        wp_clear_scheduled_hook(COMPONENT_BACKUP_HOOK);
        queue_component_backup_event(time() + 60);
    }
}

add_action(COMPONENT_BACKUP_HOOK, __NAMESPACE__ . '\\run_component_backup_event');

/** Report only enabled component schedules that the worker has reconciled. */
function active_component_backup_status(array $plan, $state, \DateTimeZone $timezone, int $now): array {
    if (!component_backups_enabled($plan) || !is_array($state)) {
        return [];
    }
    $current = [];
    foreach (array_keys(COMPONENTS) as $component) {
        $record = $state[$component] ?? null;
        $rules = component_schedule_rules($plan['schedules'][$component] ?? null, $timezone, $now);
        if ($rules !== null && is_array($record) && ($record['rules'] ?? null) === $rules
            && is_int($record['enabled_at'] ?? null) && $record['enabled_at'] > 0
            && $record['enabled_at'] <= $now && array_key_exists('verified_due_at', $record)
            && ($record['verified_due_at'] === null || is_int($record['verified_due_at']))) {
            $current[$component] = $record;
        }
    }
    return scheduled_backup_due_times($current, $now);
}
