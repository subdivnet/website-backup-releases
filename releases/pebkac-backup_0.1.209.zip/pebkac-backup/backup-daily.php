<?php

namespace PEBKAC404\Backup;

/** Let a due daily run replace an older local capture while preserving any component claim. */
function can_replace_older_local_capture(array $job, string $day, \DateTimeZone $timezone): bool {
    if (!restartable_backup_capture($job)) {
        return false;
    }
    $previous_day = scheduled_backup_day_for_followup($job, $timezone);
    if ($previous_day === '' || $previous_day >= $day) {
        return false;
    }
    if (!isset($job['component'])) {
        return true;
    }
    $claim = get_option(SCHEDULED_BACKUP_JOB_OPTION, []);
    return ($job['automatic_capture_retry'] ?? false) === true && ($claim['id'] ?? null) === $job['id']
        && ($claim['component'] ?? null) === $job['component'] && ($claim['due_at'] ?? null) === $job['scheduled_due_at'];
}

/** Leave recently interrupted manual captures available to resume from Overview. */
function can_replace_abandoned_manual_capture(array $job, ?int $saved_at, int $now): bool {
    return !isset($job['daily_date']) && !isset($job['component']) && restartable_backup_capture($job)
        && $saved_at !== null && $saved_at <= $now - DAY_IN_SECONDS;
}

/** Advance one request-sized step of a daily full backup. The caller supplies the job runner. */
function advance_daily_backup(string $root, string $local_time, \DateTimeZone $timezone, int $now, callable $advance, ?array $plan = null): string {
    $local = (new \DateTimeImmutable('@' . $now))->setTimezone($timezone);
    $day = $local->format('Y-m-d');
    $due = backup_schedule_occurrence(['frequency' => 'daily', 'time' => $local_time], $timezone, $local->setTime(0, 0)->getTimestamp());
    if ($due === null) {
        throw new \RuntimeException('The daily backup time is invalid.');
    }

    return with_backup_job_lock($root, static function () use ($root, $local_time, $timezone, $now, $day, $due, $advance, $plan): string {
        clear_abandoned_backup_records($root, $now);
        $job = read_backup_job($root);
        if ($plan !== null && !component_backups_enabled($plan)) {
            $job = release_disabled_component_backup($root, $job, $now);
        }
        $uncertain = backup_job_upload_uncertain($job);
        $failed_readback = backup_job_readback_needs_attention($job, $due);
        $previous_day = $uncertain || $failed_readback ? scheduled_backup_day_for_followup($job, $timezone) : '';
        $can_follow_up = $previous_day !== '' && $previous_day < $day && $now >= $due;
        if ($can_follow_up && !$uncertain) {
            try {
                $parked = read_parked_daily_backup($root);
                $proof = verified_evidence(get_option(EVIDENCE_OPTION, []), home_url(), $now);
                $verified_day = isset($proof['manifest_path'])
                    ? (new \DateTimeImmutable('@' . $proof['offsite_verified_at']))->setTimezone($timezone)->format('Y-m-d') : '';
                $can_follow_up = $verified_day !== $day && ($parked === [] || ($parked['parked'] ?? []) === $job);
                if ($can_follow_up) {
                    require_parked_backup_space($job, static function () use ($root) { return @disk_free_space($root); });
                }
            } catch (\RuntimeException $error) {
                // The old upload can still be checked when its replacement cannot be reserved.
                $can_follow_up = false;
            }
        }
        $older_local_capture = $now >= $due && (can_replace_older_local_capture($job, $day, $timezone)
            || can_replace_abandoned_manual_capture($job, backup_job_saved_time($root, $now), $now));
        if (isset($job['component'])) {
            $claim = get_option(SCHEDULED_BACKUP_JOB_OPTION, []);
            $same_claim = ($claim['id'] ?? null) === $job['id'];
            $can_park_component = $can_follow_up && $same_claim && ($claim['component'] ?? null) === $job['component']
                && ($claim['due_at'] ?? null) === ($job['scheduled_due_at'] ?? null);
            $finished_component = $job['phase'] === 'verified';
            if (($finished_component && $same_claim) || (!$finished_component && !$can_park_component && !$older_local_capture)) {
                return $uncertain ? 'blocked' : 'busy';
            }
        }
        if ($job !== [] && $job['phase'] !== 'verified' && !$older_local_capture) {
            if ($uncertain || $can_follow_up) {
                if (!$can_follow_up) {
                    return 'blocked';
                }
                $site = home_url();
                $proof = verified_evidence(get_option(EVIDENCE_OPTION, []), $site, $now);
                if (isset($proof['manifest_path'])
                    && (new \DateTimeImmutable('@' . $proof['offsite_verified_at']))->setTimezone($timezone)->format('Y-m-d') === $day) {
                    return 'verified_today';
                }
                $followup = advance_parked_daily_replacement($root, $job, $site, $day, backup_dropbox_folder($plan ?? get_plan()),
                    static function () use ($root) { return @disk_free_space($root); }, $timezone);
                if ($followup['state'] === 'reserved') {
                    return 'advanced';
                }
                $job = read_backup_job($root);
                if (($job['id'] ?? null) !== $followup['id'] || ($job['phase'] ?? null) !== 'database') {
                    throw new \RuntimeException('The separate daily backup could not be confirmed.');
                }
            } elseif (!isset($job['daily_date'])) {
                if ($now >= $due && manual_backup_can_continue($job)) {
                    queue_manual_backup_event($job['id']);
                }
                return 'blocked';
            }
            if (in_array($job['phase'], ['exporting', 'archiving'], true)) {
                return retry_scheduled_backup_capture($root, $job);
            }
        } else {
            if (!empty($job['cleanup_pending'])) {
                try {
                    $job = retry_verified_backup_staging($root, $job, $job['id']);
                } catch (\RuntimeException $error) {
                    return 'waiting_for_local_cleanup';
                }
            }
            $proof = verified_evidence(get_option(EVIDENCE_OPTION, []), home_url(), $now);
            if (isset($proof['manifest_path'])) {
                $verified_day = (new \DateTimeImmutable('@' . $proof['offsite_verified_at']))->setTimezone($timezone)->format('Y-m-d');
                if ($verified_day === $day) {
                    return 'verified_today';
                }
            } elseif ($job !== [] && !isset($job['component']) && !$older_local_capture) {
                return 'blocked';
            }
            if (($job['daily_date'] ?? '') === $day) {
                return 'verified_today';
            }
            if ($now < $due) {
                $timing = active_daily_backup_status(['enabled' => true, 'time' => $local_time],
                    get_option(DAILY_BACKUP_TIMING_OPTION, []), $timezone, $now, $proof['offsite_verified_at'] ?? null);
                if (!isset($timing['overdue_since'])) {
                    return 'waiting';
                }
            }
            if ($older_local_capture) {
                clear_interrupted_backup_capture($root, $job);
            } else {
                preserve_completed_backup_size($job, home_url(), $now);
            }
            $job = ['id' => bin2hex(random_bytes(16)), 'phase' => 'database', 'daily_date' => $day];
            $folder = backup_dropbox_folder($plan ?? get_plan());
            if ($folder !== PILOT_DROPBOX_FOLDER) {
                $job['folder'] = $folder;
            }
            write_backup_job($root, $job);
        }
        $advance($root, $job);
        return 'advanced';
    });
}

const DAILY_BACKUP_HOOK = 'pebkac_backup_daily_step';

function daily_backup_settings(array $plan): array {
    $settings = $plan['daily'] ?? [];
    $time = $settings['time'] ?? '';
    if (!is_string($time) || !preg_match('/^(?:[01][0-9]|2[0-3]):[0-5][0-9]$/D', $time)) {
        return ['enabled' => false, 'time' => '02:00'];
    }
    return ['enabled' => ($settings['enabled'] ?? false) === true, 'time' => $time];
}

function next_daily_backup_event(array $settings, \DateTimeZone $timezone, int $now, string $result): ?int {
    if (!$settings['enabled']) {
        return null;
    }
    if (in_array($result, ['advanced', 'busy'], true)) {
        return $now + 60;
    }
    $next = backup_schedule_occurrence(['frequency' => 'daily', 'time' => $settings['time']], $timezone, $now + 1);
    if ($result === 'waiting_for_local_cleanup') {
        return min($next ?? PHP_INT_MAX, $now + 3600);
    }
    return $result === 'retry' ? $now + 900 : $next;
}

/** Continue only a saved daily step whose next operation can be attempted safely. */
function daily_backup_can_continue(array $job): bool {
    return valid_parked_backup_day($job['daily_date'] ?? '') && !isset($job['component'])
        && backup_job_can_retry_safely($job);
}

function queue_daily_backup_event(?int $at): void {
    if ($at !== null && wp_next_scheduled(DAILY_BACKUP_HOOK) === false) {
        wp_schedule_single_event($at, DAILY_BACKUP_HOOK);
    }
}

/** Recreate a missing callback without repeating an unconfirmed Dropbox upload. */
function repair_daily_backup_queue(array $settings, \DateTimeZone $timezone, int $now): void {
    if (!$settings['enabled'] || wp_next_scheduled(DAILY_BACKUP_HOOK) !== false) {
        return;
    }
    $at = next_daily_backup_event($settings, $timezone, $now, 'waiting');
    try {
        [$job, $running, $saved_at] = read_backup_job_progress(backup_job_root());
        if ($running) {
            return;
        }
        if (daily_backup_can_continue($job)) {
            $at = next_daily_backup_event($settings, $timezone, $now, 'advanced');
        } elseif (backup_job_upload_uncertain($job) || backup_job_readback_needs_attention($job) || restartable_backup_capture($job)) {
            $previous_day = scheduled_backup_day_for_followup($job, $timezone);
            $local = (new \DateTimeImmutable('@' . $now))->setTimezone($timezone);
            $due = backup_schedule_occurrence(['frequency' => 'daily', 'time' => $settings['time']], $timezone, $local->setTime(0, 0)->getTimestamp());
            $day = $local->format('Y-m-d');
            $can_follow_up = $previous_day !== '' && $previous_day < $day
                && (backup_job_upload_uncertain($job) || backup_job_readback_needs_attention($job) || can_replace_older_local_capture($job, $day, $timezone));
            if ($due !== null && $now >= $due && ($can_follow_up || can_replace_abandoned_manual_capture($job, $saved_at, $now))) {
                $at = next_daily_backup_event($settings, $timezone, $now, 'advanced');
            }
        } elseif (($job['phase'] ?? null) === 'verified' && !empty($job['cleanup_pending'])) {
            $at = next_daily_backup_event($settings, $timezone, $now, 'retry');
        } elseif ($job === [] || $job['phase'] === 'verified') {
            $proof = verified_evidence(get_option(EVIDENCE_OPTION, []), home_url(), $now);
            $active = active_daily_backup_status($settings, get_option(DAILY_BACKUP_TIMING_OPTION, []),
                $timezone, $now, $proof['offsite_verified_at'] ?? null);
            if (isset($active['overdue_since'])) {
                $at = next_daily_backup_event($settings, $timezone, $now, 'advanced');
            }
        }
    } catch (\RuntimeException $error) {
        // Keep the normal schedule when private staging cannot be read.
    }
    queue_daily_backup_event($at);
}

function run_daily_backup_event(): void {
    $plan = get_plan();
    $settings = daily_backup_settings($plan);
    if (!$settings['enabled']) {
        return;
    }
    $timezone = wp_timezone();
    $result = 'blocked';
    $root = '';
    try {
        if (backup_capture_supported() && dropbox_saved_refresh_token(dropbox_app_key()) !== '') {
            $root = backup_job_root(true);
            $result = advance_daily_backup($root, $settings['time'], $timezone, time(), __NAMESPACE__ . '\\advance_backup_job', $plan);
        }
        if ($result === 'verified_today') {
            queue_backup_retention_event();
        }
    } catch (\RuntimeException $error) {
        if ($root !== '') {
            try {
                [$job, $running] = read_backup_job_progress($root);
                if ($running || daily_backup_can_continue($job)) {
                    $result = $running ? 'busy' : 'retry';
                }
            } catch (\RuntimeException $unavailable) {
                // Keep the normal schedule when private staging cannot be read.
            }
        }
    } finally {
        queue_daily_backup_event(next_daily_backup_event($settings, $timezone, time(), $result));
    }
    if ($root !== '' && in_array($result, ['blocked', 'retry'], true)) {
        notify_paused_scheduled_backup($root, $plan);
    }
}

add_action(DAILY_BACKUP_HOOK, __NAMESPACE__ . '\\run_daily_backup_event');

add_action('init', static function (): void {
    queue_component_backup_event(time() + 60);
    $settings = daily_backup_settings(get_plan());
    if ($settings['enabled']) {
        $timezone = wp_timezone();
        $now = time();
        if (refresh_daily_backup_timing($settings, $timezone, $now)) {
            wp_clear_scheduled_hook(DAILY_BACKUP_HOOK);
        }
        repair_daily_backup_queue($settings, $timezone, $now);
    }
});

add_action('update_option_' . OPTION, static function ($old, $new): void {
    reconcile_component_backup_event((array) $old, (array) $new);
    reconcile_backup_retention_event((array) $old, (array) $new);
    if (daily_backup_settings((array) $old) !== daily_backup_settings((array) $new)) {
        refresh_daily_backup_timing(daily_backup_settings((array) $new), wp_timezone(), time());
        wp_clear_scheduled_hook(DAILY_BACKUP_HOOK);
        queue_daily_backup_event(next_daily_backup_event(daily_backup_settings((array) $new), wp_timezone(), time(), 'waiting'));
    }
}, 10, 2);

add_action('add_option_' . OPTION, static function ($option, $value): void {
    reconcile_component_backup_event([], (array) $value);
    reconcile_backup_retention_event([], (array) $value);
    $settings = daily_backup_settings((array) $value);
    if ($settings['enabled']) {
        refresh_daily_backup_timing($settings, wp_timezone(), time());
        queue_daily_backup_event(next_daily_backup_event($settings, wp_timezone(), time(), 'waiting'));
    }
}, 10, 2);

const DAILY_BACKUP_TIMING_OPTION = 'pebkac_backup_daily_timing';

/** Preserve when the current daily rule took effect, independently of continuation events. */
function refresh_daily_backup_timing(array $settings, \DateTimeZone $timezone, int $now): bool {
    $saved = get_option(DAILY_BACKUP_TIMING_OPTION, []);
    $rules = ['time' => $settings['time'], 'timezone' => $timezone->getName()];
    if (!$settings['enabled']) {
        return $saved !== [] && update_option(DAILY_BACKUP_TIMING_OPTION, [], false);
    }
    if (($saved['rules'] ?? null) === $rules && is_int($saved['enabled_at'] ?? null) && $saved['enabled_at'] > 0) {
        return false;
    }
    return update_option(DAILY_BACKUP_TIMING_OPTION, ['rules' => $rules, 'enabled_at' => $now], false);
}

/** Use the saved daily rule and last verified full backup, never the next cron callback. */
function active_daily_backup_status(array $settings, $timing, \DateTimeZone $timezone, int $now, ?int $verified_at): array {
    $enabled_at = $timing['enabled_at'] ?? null;
    if (!$settings['enabled'] || ($timing['rules'] ?? null) !== ['time' => $settings['time'], 'timezone' => $timezone->getName()]
        || !is_int($enabled_at) || $enabled_at < 1 || $enabled_at > $now) {
        return [];
    }
    $from = $enabled_at;
    if ($verified_at !== null && $verified_at > 0 && $verified_at <= $now) {
        $verified_day = (new \DateTimeImmutable('@' . $verified_at))->setTimezone($timezone);
        $following_day = $verified_day->modify('+1 day')->setTime(0, 0)->getTimestamp();
        $from = max($from, $following_day);
    }
    $due = backup_schedule_occurrence(['frequency' => 'daily', 'time' => $settings['time']], $timezone, $from);
    return ['next_due_at' => $due, 'overdue_since' => $due !== null && $due < $now ? $due : null];
}
