<?php

namespace PEBKAC404\Backup;

if (!defined('ABSPATH')) {
    exit;
}

/** Clear abandoned downloads from private staging while the caller holds the backup job lock. */
function clear_abandoned_recovery_downloads(string $root, int $now): void {
    clear_abandoned_backup_files($root, $now, '/^recovery-[a-f0-9]{32}\.part$/D');
}

/** Remove only old, unclaimed files with the caller's exact temporary filename pattern. */
function clear_abandoned_backup_files(string $root, int $now, string $pattern): void {
    $directory = @opendir($root);
    if ($directory === false) {
        return;
    }
    $remaining = 8;
    try {
        while ($remaining > 0 && ($name = readdir($directory)) !== false) {
            if (!preg_match($pattern, $name)) {
                continue;
            }
            $path = $root . '/' . $name;
            clearstatcache(true, $path);
            $modified = !is_link($path) && is_file($path) ? @filemtime($path) : false;
            if ($modified === false || $modified >= $now - 7200) {
                continue;
            }
            $stream = @fopen($path, 'rb');
            if ($stream === false) {
                continue;
            }
            $unclaimed = flock($stream, LOCK_EX | LOCK_NB);
            fclose($stream);
            if ($unclaimed && @unlink($path)) {
                $remaining--;
            }
        }
    } finally {
        closedir($directory);
    }
}

final class ComponentRecoveryObjectChanged extends \RuntimeException {}
final class RecoveryDownloadUnavailable extends \RuntimeException {}

/** Fetch only the pinned Dropbox object and return a validated private temporary file. */
function download_recovery_object(string $root, array $evidence, string $object, string $token): string {
    if (!in_array($object, ['archive', 'manifest'], true) || !isset($evidence['manifest_sha256'])) {
        throw new \RuntimeException('There is no verified recovery set for this request.');
    }
    $path = $evidence[$object . '_path'];
    $hash = $evidence[$object . '_sha256'];
    $limit = $object === 'manifest' ? SNAPSHOT_MAX_MANIFEST_BYTES : SNAPSHOT_MAX_BYTES + 8 * 1024 * 1024;
    clear_abandoned_recovery_downloads($root, time());
    $metadata = fetch_dropbox_metadata($path, $token);
    $size = $metadata['size'] ?? null;
    if ($object === 'manifest' && isset($evidence['component'])) {
        $pin = backup_dropbox_object_pins($evidence['dropbox_objects'] ?? [])['manifest'] ?? null;
        $content_hash = $metadata['content_hash'] ?? null;
        if ($metadata === null || ($metadata['.tag'] ?? null) === 'folder'
            || ($pin !== null && ($metadata['.tag'] ?? null) === 'file' && is_int($size) && $size > 0
                && is_string($content_hash) && preg_match('/^[a-f0-9]{64}$/D', $content_hash)
                && ($size !== $pin['size'] || !hash_equals($pin['content_hash'], $content_hash)))) {
            throw new ComponentRecoveryObjectChanged('Dropbox reported a missing or changed component manifest.');
        }
    }
    if (($metadata['.tag'] ?? null) !== 'file' || !is_int($size) || $size < 1 || $size > $limit) {
        throw new RecoveryDownloadUnavailable('Dropbox could not confirm this recovery file.');
    }
    $pin = backup_dropbox_object_pins($evidence['dropbox_objects'] ?? [])[$object] ?? null;
    if ($pin !== null && ($size !== $pin['size'] || ($metadata['content_hash'] ?? null) !== $pin['content_hash'])) {
        throw new RecoveryDownloadUnavailable('Dropbox reported a changed recovery file. The file was not downloaded.');
    }
    $free = @disk_free_space($root);
    if ($free === false || $free < $size + 16 * 1024 * 1024) {
        throw new RecoveryDownloadUnavailable('The server needs more private temporary space to download this recovery file.');
    }
    $file = $root . '/recovery-' . bin2hex(random_bytes(16)) . '.part';
    $stream = @fopen($file, 'xb');
    if ($stream === false) {
        throw new \RuntimeException('Could not reserve a private recovery download.');
    }
    fclose($stream);
    @chmod($file, 0600);
    try {
        $response = wp_remote_post('https://content.dropboxapi.com/2/files/download', [
            'headers' => ['Authorization' => 'Bearer ' . $token, 'Dropbox-API-Arg' => wp_json_encode(['path' => $path])],
            'timeout' => backup_request_budget(), 'redirection' => 0, 'sslverify' => true, 'decompress' => false,
            'stream' => true, 'filename' => $file, 'limit_response_size' => $size + 1,
        ]);
        clearstatcache(true, $file);
        if (is_wp_error($response) || wp_remote_retrieve_response_code($response) !== 200
            || filesize($file) !== $size || snapshot_archive_sha256($file, microtime(true) + backup_request_budget()) !== $hash) {
            throw new \RuntimeException('The downloaded file did not match the verified recovery set.');
        }
        if ($object === 'manifest' && (read_snapshot_manifest($file)['archive_sha256'] ?? null) !== $evidence['archive_sha256']) {
            throw new \RuntimeException('The downloaded manifest does not describe the verified archive.');
        }
        return $file;
    } catch (\Throwable $error) {
        @unlink($file);
        throw $error;
    }
}

/** Read a pinned component manifest and remove its temporary copy. Caller checks the record's site scope first. */
function download_component_manifest_bytes(string $root, array $record, string $token): string {
    $file = download_recovery_object($root, $record, 'manifest', $token);
    try {
        $bytes = @file_get_contents($file, false, null, 0, SNAPSHOT_MAX_MANIFEST_BYTES + 1);
        if ($bytes === false) {
            throw new \RuntimeException('Could not read the verified component manifest.');
        }
        return $bytes;
    } finally {
        @unlink($file);
    }
}

function download_verified_component_baseline_inventory(string $root, string $site, string $component, array $record, string $token, int $now): array {
    require_verified_component_baseline($site, $component, $record, $now);
    $bytes = download_component_manifest_bytes($root, $record, $token);
    return verified_component_baseline_inventory($site, $component, $record, $bytes, $now);
}

/** Read and replay one verified delta manifest after its exact parent, without downloading the ZIP. */
function download_verified_component_delta_inventory(
    string $root, string $site, string $component, array $parent_record, array $parent_inventory, array $record, string $token, int $now
): array {
    require_verified_component_parent($site, $component, $parent_record, $record, $now);
    $bytes = download_component_manifest_bytes($root, $record, $token);
    return replay_verified_component_manifest($site, $component, $parent_record, $parent_inventory, $record, $bytes, $now);
}

const COMPONENT_INVENTORY_REPLAY_FILE = 'inventory-replay.json';

/** Read one manifest per step and atomically save its inventory and position. Caller holds the job lock. */
function advance_component_inventory_replay(
    string $directory, string $site, string $component, array $history, ?string $token, int $now
): ?array {
    if (!is_dir($directory) || is_link($directory)
        || (DIRECTORY_SEPARATOR === '/' && (fileperms($directory) & 0077) !== 0)) {
        throw new \RuntimeException('The incremental replay requires a private backup directory.');
    }
    $chain = plan_component_inventory_replay($site, $component, $history, $now);
    if ($chain === []) {
        throw new \RuntimeException('There is no verified component backup to replay.');
    }
    $fingerprint = hash('sha256', json_encode($chain, JSON_THROW_ON_ERROR));
    $path = $directory . '/' . COMPONENT_INVENTORY_REPLAY_FILE;
    $applied = 0;
    $inventory = [];
    if (file_exists($path) || is_link($path)) {
        $bytes = !is_link($path) && is_file($path) ? @file_get_contents($path, false, null, 0, SNAPSHOT_MAX_MANIFEST_BYTES + 1) : false;
        $saved = $bytes !== false && strlen($bytes) <= SNAPSHOT_MAX_MANIFEST_BYTES ? json_decode($bytes, true) : null;
        $applied = $saved['applied'] ?? null;
        $inventory = $saved['inventory'] ?? null;
        if (($saved['chain'] ?? null) !== $fingerprint || !is_int($applied) || $applied < 1 || $applied > count($chain)
            || ($inventory['component'] ?? null) !== $component || !is_array($inventory['files'] ?? null)
            || incremental_inventory_sha256($component, incremental_file_inventory($component, $inventory['files'])) !== $chain[$applied - 1]['inventory_sha256']) {
            throw new \RuntimeException('The saved incremental replay does not match the verified backup chain.');
        }
    }
    if ($applied === count($chain)) {
        return ['parent' => $chain[$applied - 1], 'inventory' => $inventory];
    }
    if ($token === null) {
        throw new \RuntimeException('The saved incremental replay is incomplete.');
    }
    $record = $chain[$applied];
    $inventory = $applied === 0
        ? download_verified_component_baseline_inventory($directory, $site, $component, $record, $token, $now)
        : download_verified_component_delta_inventory($directory, $site, $component, $chain[$applied - 1], $inventory, $record, $token, $now);
    $applied++;
    $bytes = json_encode(['chain' => $fingerprint, 'applied' => $applied, 'inventory' => $inventory], JSON_THROW_ON_ERROR);
    if (strlen($bytes) > SNAPSHOT_MAX_MANIFEST_BYTES) {
        throw new \RuntimeException('The incremental replay inventory exceeds its staging limit.');
    }
    write_private_backup_record($path, $bytes);
    return $applied === count($chain) ? ['parent' => $record, 'inventory' => $inventory] : null;
}

/** Return a complete, site-bound recovery chain for the latest verified component backup. */
function component_recovery_chain(string $site, string $component, array $history, int $now): array {
    if (!is_array($history['records'] ?? null) || !is_array($history['latest'] ?? null)) {
        return [];
    }
    if ($component === 'database') {
        $head = $history['latest'][$component] ?? null;
        $record = is_string($head) ? ($history['records'][$head] ?? null) : null;
        if (!is_array($record) || ($record['archive_path'] ?? null) !== $head) {
            return [];
        }
        require_verified_component_record($site, $component, $record, $now);
        $chain = [$record];
    } else {
        $chain = plan_component_inventory_replay($site, $component, $history, $now);
    }
    foreach ($chain as $record) {
        if (backup_dropbox_object_pins($record['dropbox_objects'] ?? []) === []) {
            throw new \RuntimeException('The component recovery chain is missing verified Dropbox file information.');
        }
    }
    return $chain;
}

/** Collect each complete chain independently so one unavailable component does not hide the others. */
function available_component_recovery_chains(string $site, array $history, int $now): array {
    $chains = [];
    foreach (array_keys(COMPONENTS) as $component) {
        try {
            $chain = component_recovery_chain($site, $component, $history, $now);
            if ($chain !== []) {
                $chains[$component] = $chain;
            }
        } catch (\RuntimeException $error) {
            continue;
        }
    }
    return $chains;
}

/** Export the verified file identities and replay order, without Dropbox paths or credentials. */
function component_recovery_plan(string $site, array $chains): array {
    $components = [];
    $points = [];
    foreach ($chains as $component => $chain) {
        $files = [];
        foreach ($chain as $index => $record) {
            $prefix = component_recovery_file_prefix($site, $component, $index + 1);
            $pair = ['verified_at' => $record['offsite_verified_at']];
            foreach (['archive', 'manifest'] as $object) {
                $pair[$object] = [
                    'name' => recovery_filename($prefix, $object),
                    'bytes' => $record['dropbox_objects'][$object]['size'],
                    'sha256' => $record[$object . '_sha256'],
                ];
            }
            $files[] = $pair;
        }
        $components[$component] = $files;
        if ($chain !== []) {
            $points[$component] = recovery_download_id($chain[count($chain) - 1]);
        }
    }
    return [
        'schema' => 1,
        'site' => $site,
        'components' => $components,
        'component_points' => $points,
        'unavailable_components' => array_values(array_diff(array_keys(COMPONENTS), array_keys($components))),
    ];
}

function component_recovery_plan_id(array $plan): string {
    return hash('sha256', json_encode($plan, JSON_UNESCAPED_SLASHES | JSON_THROW_ON_ERROR));
}

function full_recovery_plan(string $site, array $selection): array {
    $record = $selection['evidence'];
    if (!isset($record['manifest_sha256'])) {
        throw new \RuntimeException('There is no verified full backup for this recovery plan.');
    }
    $pins = backup_dropbox_object_pins($record['dropbox_objects'] ?? []);
    $files = [];
    foreach (['archive', 'manifest'] as $object) {
        $files[$object] = [
            'name' => recovery_filename($selection['filename_prefix'], $object),
            'bytes' => $pins[$object]['size'] ?? ($object === 'archive' ? ($record['archive_size_bytes'] ?? null) : null),
            'sha256' => $record[$object . '_sha256'],
        ];
    }
    return [
        'schema' => 1, 'kind' => 'full_backup', 'site' => $site,
        'point' => substr(recovery_download_id($record), 0, 12),
        'verified_at' => $record['offsite_verified_at'], 'files' => $files,
    ];
}

function send_backup_recovery_plan(array $plan, string $filename): void {
    nocache_headers();
    header('X-Content-Type-Options: nosniff');
    header('Content-Type: application/json; charset=UTF-8');
    header('Content-Disposition: attachment; filename="' . $filename . '"');
    echo json_encode($plan, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES | JSON_THROW_ON_ERROR) . "\n";
    exit;
}

add_action('admin_post_pebkac_backup_component_recovery_plan', static function (): void {
    if (($_SERVER['REQUEST_METHOD'] ?? '') !== 'POST' || !is_ssl() || !current_user_can('manage_options')) {
        wp_die('A signed-in administrator must download the recovery plan over HTTPS.', '', ['response' => 403]);
    }
    check_admin_referer('pebkac_backup_component_recovery_plan');
    $point = $_POST['plan'] ?? '';
    $earlier = $_POST['earlier'] ?? '';
    $site = home_url();
    $history = get_option(COMPONENT_RECOVERY_STATE_OPTION, []);
    $now = time();
    $chains = [];
    if (is_array($history) && is_string($earlier)) {
        if ($earlier === '') {
            $chains = available_component_recovery_chains($site, $history, $now);
        } elseif (preg_match('/^[a-f0-9]{64}$/D', $earlier)) {
            try {
                $kept = retained_component_recovery_records($site, $history, $now);
                $chain = retained_component_chain_at($site, $earlier, $history, $kept, $now);
                $chains[$chain[0]['component']] = $chain;
            } catch (\RuntimeException $error) {
                // An older point can become unavailable between selection and download.
            }
        }
    }
    $plan = component_recovery_plan($site, $chains);
    if ($chains === [] || !is_string($point) || !hash_equals(component_recovery_plan_id($plan), $point)) {
        wp_die('The recovery plan changed. Return to Overview and download the current plan.', '', ['response' => 409]);
    }
    $suffix = $earlier === '' ? '' : '-' . substr($earlier, 0, 12);
    send_backup_recovery_plan($plan, pilot_site_slug($site) . '-component-recovery-plan' . $suffix . '.json');
});

function recovery_download_id(array $record): string {
    return hash('sha256', $record['archive_path'] . '|' . $record['manifest_sha256']);
}

/** Resolve an opaque download choice without accepting a Dropbox path from the browser. */
function select_component_recovery_download(string $site, string $component, string $point, array $history, int $now): array {
    foreach (component_recovery_chain($site, $component, $history, $now) as $index => $record) {
        if (hash_equals(recovery_download_id($record), $point)) {
            return ['evidence' => $record, 'filename_prefix' => component_recovery_file_prefix($site, $component, $index + 1)];
        }
    }
    return retained_component_recovery_download($site, $component, $point, $history, $now);
}

/** Resolve a selected file from an earlier chain while retention still protects it. */
function retained_component_recovery_download(string $site, string $component, string $point, array $history, int $now): array {
    $kept = retained_component_recovery_records($site, $history, $now);
    $chain = retained_component_chain_at($site, $point, $history, $kept, $now);
    $record = $chain[count($chain) - 1];
    if ($record['component'] !== $component) {
        throw new \RuntimeException('The requested component backup is no longer available from this recovery list.');
    }
    return ['evidence' => $record, 'filename_prefix' => component_recovery_file_prefix($site, $component, count($chain))];
}

function retained_component_recovery_records(string $site, array $history, int $now): array {
    $journal = get_option(COMPONENT_CLEANUP_PREFLIGHT_OPTION, []);
    if (!is_array($journal)) {
        throw new \RuntimeException('Component cleanup progress could not be read.');
    }
    $checks = component_restore_retention_checks($history, $site, $now);
    $kept = component_backup_retention_plan($history, $checks, $site, wp_timezone(), $now)['keep'];
    unset($kept[$journal['candidate']['archive_path'] ?? '']);
    uasort($kept, __NAMESPACE__ . '\\compare_backup_retention_sets');
    return $kept;
}

/** Rebuild the exact chain ending at an earlier retained component backup. */
function retained_component_chain_at(string $site, string $point, array $history, array $kept, int $now): array {
    foreach ($kept as $record) {
        if (!hash_equals(recovery_download_id($record), $point)) {
            continue;
        }
        $component = $record['component'];
        $history['latest'][$component] = $record['archive_path'];
        $chain = component_recovery_chain($site, $component, $history, $now);
        if ($chain === [] || array_diff(array_column($chain, 'archive_path'), array_keys($kept)) !== []) {
            break;
        }
        return $chain;
    }
    throw new \RuntimeException('The requested component backup is no longer available from this recovery list.');
}

/** Return the earlier full backup sets selected by retention, newest first. */
function retained_full_recovery_points($history, array $latest, string $site, \DateTimeZone $timezone, int $now): array {
    $sets = backup_retention_sets($history, $latest, $site, $now);
    $kept = backup_retention_plan($sets, $site, $timezone, $now, $latest['archive_path'] ?? null)['keep'];
    unset($kept[$latest['archive_path'] ?? '']);
    return array_values($kept);
}

/** Find already verified earlier copies whose cleanup has not begun. Caller holds the job lock. */
function available_earlier_full_backups(array $latest, string $site, int $now): array {
    $history = get_option(VERIFIED_BACKUP_HISTORY_OPTION, []);
    $journal = get_option(BACKUP_RETENTION_JOURNAL_OPTION, []);
    if (!is_array($history) || !is_array($journal)) {
        throw new \RuntimeException('The earlier recovery files could not be checked.');
    }
    $excluded = [$latest['archive_path'] ?? null, $journal['candidate']['archive_path'] ?? null];
    $available = [];
    foreach ($history as $path => $saved) {
        $record = verified_evidence($saved, $site, $now);
        if (isset($record['manifest_path']) && $record['archive_path'] === $path && !in_array($path, $excluded, true)) {
            $available[] = $record;
        }
    }
    return $available;
}

function select_full_recovery_download(string $point, array $records): array {
    foreach ($records as $record) {
        if (hash_equals(recovery_download_id($record), $point)) {
            return $record;
        }
    }
    throw new \RuntimeException('The requested backup is no longer available from recovery history.');
}

/** Resolve the same immutable backup on both requests, even if the current backup changed. */
function resolve_full_recovery_download(string $site, string $point, int $now): array {
    $evidence = verified_evidence(get_option(EVIDENCE_OPTION, []), $site, $now);
    $prefix = pilot_site_slug($site);
    if ($point !== '') {
        if (!isset($evidence['manifest_sha256']) || !hash_equals(recovery_download_id($evidence), $point)) {
            $evidence = select_full_recovery_download($point, available_earlier_full_backups($evidence, $site, $now));
        }
        $prefix .= '-' . substr($point, 0, 12);
    }
    return ['evidence' => $evidence, 'filename_prefix' => $prefix];
}

const FULL_RECOVERY_CHECK_OPTION = 'pebkac_backup_full_recovery_check';
const LATEST_FULL_RECOVERY_CHECK_OPTION = 'pebkac_backup_latest_full_recovery_check';
const FULL_RECOVERY_RECONNECT_CHECK_OPTION = 'pebkac_backup_full_recovery_reconnect_check';
const FULL_RECOVERY_READBACK_HOOK = 'pebkac_backup_full_recovery_readback';
const FULL_RECOVERY_READBACK_INTERVAL = 86400;

/** Check both pinned objects without downloading them or changing the backup or restore evidence. */
function check_full_recovery_files(array $record, int $now, callable $metadata, bool $manual = true): void {
    if (!isset($record['manifest_sha256'])) {
        throw new \RuntimeException('There is no verified recovery point to check.');
    }
    $pins = backup_dropbox_object_pins($record['dropbox_objects'] ?? []);
    $state = 'older';
    if ($pins !== []) {
        $expected = [];
        foreach ($pins as $object => $pin) {
            $expected[$record[$object . '_path']] = $pin;
        }
        $state = 'confirmed';
        foreach ($expected as $path => $pin) {
            try {
                if (!verify_offsite_files([$path => $pin], $metadata)['verified']) {
                    $state = 'changed';
                }
            } catch (\RuntimeException $error) {
                if ($state === 'confirmed') {
                    $state = 'unavailable';
                }
                break;
            }
        }
    }
    $check = ['point' => recovery_download_id($record), 'at' => $now, 'state' => $state];
    $current = verified_evidence(get_option(EVIDENCE_OPTION, []), $record['site'], $now);
    if (isset($current['manifest_path']) && recovery_download_id($current) === $check['point']) {
        $previous = get_option(LATEST_FULL_RECOVERY_CHECK_OPTION, []);
        if ($state === 'unavailable') {
            $same_point = ($previous['point'] ?? null) === $check['point'];
            $failures = $same_point ? ($previous['failures'] ?? 0) : 0;
            $previous_at = $previous['at'] ?? null;
            $check['failures'] = in_array($failures, [1, 2], true) && is_int($previous_at)
                && $previous_at <= $now && $now - $previous_at < FULL_RECOVERY_READBACK_INTERVAL ? $failures + 1 : 1;
            if ($same_point && ($previous['state'] ?? null) === 'changed' && is_int($previous_at)) {
                $check['missing_since'] = $previous_at;
            } elseif ($same_point && is_int($previous['missing_since'] ?? null)) {
                $check['missing_since'] = $previous['missing_since'];
            }
        }
        if ($previous !== $check && !update_option(LATEST_FULL_RECOVERY_CHECK_OPTION, $check, false)) {
            throw new \RuntimeException('Could not save the latest backup file check.');
        }
    }
    if ($manual && get_option(FULL_RECOVERY_CHECK_OPTION, []) !== $check && !update_option(FULL_RECOVERY_CHECK_OPTION, $check, false)) {
        throw new \RuntimeException('Could not save the recovery file check.');
    }
}

/** Schedule readback from the most recent verification of this exact recovery point. */
function next_full_recovery_readback(array $record, $check, int $now): ?int {
    if (!isset($record['manifest_path']) || backup_dropbox_object_pins($record['dropbox_objects'] ?? []) === []) {
        return null;
    }
    $anchor = $record['offsite_verified_at'];
    $checked_at = $check['at'] ?? null;
    if (($check['point'] ?? null) === recovery_download_id($record) && is_int($checked_at)
        && $checked_at >= $anchor && $checked_at <= $now) {
        if (($check['state'] ?? null) === 'unavailable' && in_array($check['failures'] ?? null, [1, 2], true)) {
            return $checked_at + 900;
        }
        $anchor = $checked_at;
    }
    return $anchor + FULL_RECOVERY_READBACK_INTERVAL;
}

function expected_full_recovery_readback_at(int $now): ?int {
    if (!is_string(get_option(DROPBOX_CREDENTIAL_OPTION, false))) {
        return null;
    }
    $record = verified_evidence(get_option(EVIDENCE_OPTION, []), home_url(), $now);
    $due = next_full_recovery_readback($record, get_option(LATEST_FULL_RECOVERY_CHECK_OPTION, []), $now);
    return $due !== null && get_option(FULL_RECOVERY_RECONNECT_CHECK_OPTION, '') === recovery_download_id($record) ? $now : $due;
}

function queue_full_recovery_readback(int $delay = 60): void {
    if (wp_next_scheduled(FULL_RECOVERY_READBACK_HOOK) !== false) {
        return;
    }
    $now = time();
    $due = expected_full_recovery_readback_at($now);
    if ($due !== null) {
        wp_schedule_single_event(max($now + $delay, $due), FULL_RECOVERY_READBACK_HOOK);
    }
}

/** Recheck a full recovery warning promptly after a successful reconnect. */
function queue_full_readback_after_dropbox_authorization(): void {
    $now = time();
    $site = home_url();
    $record = verified_evidence(get_option(EVIDENCE_OPTION, []), $site, $now);
    $check = get_option(LATEST_FULL_RECOVERY_CHECK_OPTION, []);
    $due = next_full_recovery_readback($record, $check, $now);
    if ($due === null || !in_array(latest_full_recovery_readback($site, $now)['state'] ?? null, ['changed', 'unavailable'], true)) {
        return;
    }
    // Keep the warning visible until the scheduled request confirms both files.
    $point = recovery_download_id($record);
    if (get_option(FULL_RECOVERY_RECONNECT_CHECK_OPTION, '') !== $point
        && !update_option(FULL_RECOVERY_RECONNECT_CHECK_OPTION, $point, false)) {
        return;
    }
    bring_forward_backup_event(FULL_RECOVERY_READBACK_HOOK, [], $now + 60);
}

/** Recheck the latest pinned ZIP and manifest without downloading or changing either object. */
function run_full_recovery_readback(): void {
    if (!is_string(get_option(DROPBOX_CREDENTIAL_OPTION, false))) {
        return;
    }
    $delay = 60;
    try {
        $root = backup_job_root(true);
        with_backup_job_lock($root, static function () use ($root): void {
            $now = time();
            clear_abandoned_recovery_downloads($root, $now);
            $record = verified_evidence(get_option(EVIDENCE_OPTION, []), home_url(), $now);
            $due = next_full_recovery_readback($record, get_option(LATEST_FULL_RECOVERY_CHECK_OPTION, []), $now);
            $reconnect = $due !== null && get_option(FULL_RECOVERY_RECONNECT_CHECK_OPTION, '') === recovery_download_id($record);
            if ($due === null || (!$reconnect && $due > $now)) {
                return;
            }
            $app = dropbox_app_key();
            $refresh = dropbox_saved_refresh_token($app);
            $timeout = max(1, min(5, intdiv((int) backup_request_budget(), 3)));
            $token = null;
            check_full_recovery_files($record, $now, static function (string $path) use ($app, $refresh, $timeout, &$token): ?array {
                if ($refresh === '') {
                    throw new \RuntimeException('Dropbox authorization is unavailable.');
                }
                $token = $token ?? refresh_dropbox_access_token($app, $refresh, $timeout);
                return fetch_dropbox_metadata($path, $token, $timeout);
            }, false);
            if ($reconnect) {
                delete_option(FULL_RECOVERY_RECONNECT_CHECK_OPTION);
            }
        });
    } catch (\RuntimeException $error) {
        $delay = 900;
    } finally {
        queue_full_recovery_readback($delay);
    }
}

add_action('init', __NAMESPACE__ . '\\queue_full_recovery_readback', 10, 0);
add_action(FULL_RECOVERY_READBACK_HOOK, __NAMESPACE__ . '\\run_full_recovery_readback');

function full_recovery_check_label($check, array $records, int $now): string {
    $messages = [
        'confirmed' => 'Dropbox confirmed both matching recovery files.',
        'changed' => 'Dropbox reported a missing or changed recovery file.',
        'unavailable' => 'Dropbox could not confirm the recovery files.',
        'older' => 'This backup has no saved Dropbox file checksums. Download its files to verify their contents.',
    ];
    $state = $check['state'] ?? null;
    $point = $check['point'] ?? null;
    $at = $check['at'] ?? null;
    if (!is_string($state) || !isset($messages[$state]) || !is_string($point) || !is_int($at) || $at < 1 || $at > $now) {
        return '';
    }
    foreach ($records as $record) {
        if (hash_equals(recovery_download_id($record), $point)) {
            return 'Backup verified ' . wp_date('M j, Y H:i:s T', $record['offsite_verified_at']) . '. Checked '
                . wp_date('M j, Y H:i T', $at) . '. ' . $messages[$state];
        }
    }
    return '';
}

function latest_full_recovery_readback(string $site, int $now): array {
    $record = verified_evidence(get_option(EVIDENCE_OPTION, []), $site, $now);
    if (!isset($record['manifest_path'])) {
        return [];
    }
    $check = get_option(LATEST_FULL_RECOVERY_CHECK_OPTION, []);
    if ($check === []) {
        $check = get_option(FULL_RECOVERY_CHECK_OPTION, []);
    }
    $label = full_recovery_check_label($check, [$record], $now);
    if ($label === '') {
        return [];
    }
    $missing = $check['missing_since'] ?? null;
    if ($check['state'] === 'unavailable' && is_int($missing) && $missing >= $record['offsite_verified_at'] && $missing <= $check['at']) {
        $label .= ' A check on ' . wp_date('M j, Y H:i T', $missing) . ' reported a missing or changed file.';
        return ['state' => 'changed', 'label' => $label, 'checked_at' => $check['at']];
    }
    return ['state' => $check['state'], 'label' => $label, 'checked_at' => $check['at']];
}

function latest_full_recovery_warning(string $site, int $now): array {
    $states = [
        'changed' => ['notice-error', 'Latest backup files are missing or changed'],
        'unavailable' => ['notice-warning', 'Dropbox could not confirm the latest backup files'],
    ];
    $readback = latest_full_recovery_readback($site, $now);
    $warning = $states[$readback['state'] ?? ''] ?? [];
    return $warning === [] ? [] : [$warning[0], $warning[1], $readback['label']];
}

function render_backup_recovery(): void {
    if (!is_ssl() || dropbox_saved_refresh_token(dropbox_app_key()) === '') {
        return;
    }
    $site = home_url();
    $now = time();
    $evidence = verified_evidence(get_option(EVIDENCE_OPTION, []), $site, $now);
    if (!isset($evidence['manifest_sha256'])) {
        return;
    }
    try {
        $earlier = retained_full_recovery_points(get_option(VERIFIED_BACKUP_HISTORY_OPTION, []), $evidence, $site, wp_timezone(), $now);
    } catch (\RuntimeException $error) {
        $earlier = [];
    }
    $points = array_merge([$evidence], $earlier);
    $requested = $_GET['recovery_checked'] ?? '';
    $selected_point = recovery_download_id($evidence);
    $reopen = is_string($requested) && preg_match('/^[a-f0-9]{64}$/D', $requested) === 1;
    $selected_records = $points;
    if ($reopen) {
        $selected_records = [];
        foreach ($points as $point) {
            if (hash_equals(recovery_download_id($point), $requested)) {
                $selected_point = $requested;
                $selected_records = [$point];
                break;
            }
        }
    }
    $check_option = $reopen ? FULL_RECOVERY_CHECK_OPTION : LATEST_FULL_RECOVERY_CHECK_OPTION;
    $checked = full_recovery_check_label(get_option($check_option, []), $selected_records, $now);
    ?>
    <section id="pebkac-backup-recovery" class="notice notice-info inline">
        <h2>Recovery files</h2>
        <details<?php if ($reopen) : ?> open<?php endif; ?>><summary>Show details</summary>
            <p>Download both verified files from Dropbox for an isolated restore test.</p>
            <p>Website Backup checks the latest backup files in Dropbox when they have gone a day without verification.</p>
            <?php if ($selected_records === []) : ?><p>That recovery point is no longer listed. Choose a retained backup to continue.</p><?php endif; ?>
            <?php if ($checked !== '') : ?><p><?php echo esc_html($checked); ?></p><?php endif; ?>
            <form action="<?php echo esc_url(admin_url('admin-post.php')); ?>" method="post">
                <input type="hidden" name="action" value="pebkac_backup_recovery">
                <?php wp_nonce_field('pebkac_backup_recovery'); ?>
                <?php if ($earlier !== []) : ?>
                    <p>
                        <label for="pebkac-backup-recovery-point">Recovery point</label>
                        <select id="pebkac-backup-recovery-point" name="point">
                            <?php $latest_point = recovery_download_id($evidence); ?>
                            <option value="<?php echo esc_attr($latest_point); ?>"<?php selected($selected_point, $latest_point); ?>>Latest backup</option>
                            <?php foreach ($earlier as $record) : ?>
                                <?php $point_id = recovery_download_id($record); ?>
                                <option value="<?php echo esc_attr($point_id); ?>"<?php selected($selected_point, $point_id); ?>>
                                    <?php
                                    $label = wp_date('M j, Y H:i:s T', $record['offsite_verified_at']);
                                    if (isset($record['restore'])) {
                                        $label .= ' (isolated restore verified)';
                                    }
                                    echo esc_html($label);
                                    ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </p>
                <?php else : ?>
                    <input type="hidden" name="point" value="<?php echo esc_attr(recovery_download_id($evidence)); ?>">
                <?php endif; ?>
                <button class="button" type="submit" name="object" value="archive">Download backup ZIP</button>
                <button class="button" type="submit" name="object" value="manifest">Download restore manifest</button>
                <button class="button" type="submit" name="object" value="plan">Download recovery plan</button>
                <button class="button" type="submit" name="object" value="check">Check recovery files in Dropbox</button>
            </form>
        </details>
    </section>
    <?php
}

add_action('admin_post_pebkac_backup_recovery', static function () {
    if (($_SERVER['REQUEST_METHOD'] ?? '') !== 'POST' || !is_ssl() || !current_user_can('manage_options')) {
        wp_die('A signed-in administrator must download the recovery files over HTTPS.', '', ['response' => 403]);
    }
    check_admin_referer('pebkac_backup_recovery');
    $object = $_POST['object'] ?? '';
    $component = $_POST['component'] ?? '';
    $point = $_POST['point'] ?? '';
    if (!in_array($object, ['archive', 'manifest', 'plan', 'check'], true) || !is_string($component) || !is_string($point)
        || (in_array($object, ['plan', 'check'], true) && ($component !== '' || $point === ''))
        || ($point !== '' && !preg_match('/^[a-f0-9]{64}$/D', $point))
        || ($component !== '' && ($point === '' || !isset(COMPONENTS[$component])))) {
        wp_die('Choose a recovery file.', '', ['response' => 400]);
    }
    try {
        $root = backup_job_root(true);
        [$file, $prefix, $plan] = with_backup_job_lock($root, static function () use ($root, $object, $component, $point): array {
            $site = home_url();
            $now = time();
            $selection = $component === ''
                ? resolve_full_recovery_download($site, $point, $now)
                : select_component_recovery_download($site, $component, $point, get_option(COMPONENT_RECOVERY_STATE_OPTION, []), $now);
            if ($object === 'plan') {
                return [null, $selection['filename_prefix'], full_recovery_plan($site, $selection)];
            }
            if ($object === 'check') {
                $token = null;
                check_full_recovery_files($selection['evidence'], $now, static function (string $path) use (&$token): ?array {
                    $token = $token ?? dropbox_connected_access_token();
                    return fetch_dropbox_metadata($path, $token);
                });
                return [null, $selection['filename_prefix'], null];
            }
            $file = download_recovery_object($root, $selection['evidence'], $object, dropbox_connected_access_token());
            return [$file, $selection['filename_prefix'], null];
        });
    } catch (RecoveryDownloadUnavailable $error) {
        wp_die(esc_html($error->getMessage() . ' Return to Overview to check the recovery files.'), '', ['response' => 409]);
    } catch (\Throwable $error) {
        wp_die('The recovery request could not be completed. Return to Overview to check the recovery files.', '', ['response' => 409]);
    }
    if ($object === 'check') {
        wp_safe_redirect(admin_url('admin.php?page=pebkac-backup&tab=overview&recovery_checked=' . $point . '#pebkac-backup-recovery'), 303);
        exit;
    }
    if ($plan !== null) {
        send_backup_recovery_plan($plan, $prefix . '-recovery-plan.json');
    }
    $stream = @fopen($file, 'rb');
    if ($stream === false || !flock($stream, LOCK_SH | LOCK_NB)) {
        if (is_resource($stream)) {
            fclose($stream);
        }
        wp_die('The verified download could not be opened. Return to Overview to download it again.', '', ['response' => 409]);
    }
    $size = fstat($stream)['size'] ?? null;
    if (!is_int($size) || $size < 1) {
        fclose($stream);
        @unlink($file);
        wp_die('The verified download size is unavailable. Return to Overview to download it again.', '', ['response' => 409]);
    }
    register_shutdown_function(static function () use ($file, $stream): void {
        fclose($stream);
        @unlink($file);
    });
    nocache_headers();
    header('X-Content-Type-Options: nosniff');
    header('Content-Type: application/octet-stream');
    $filename = recovery_filename($prefix, $object);
    header('Content-Disposition: attachment; filename="' . $filename . '"');
    header('Content-Length: ' . $size);
    fpassthru($stream);
    exit;
});
