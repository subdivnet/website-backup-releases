<?php

namespace PEBKAC404\Backup;

/** Reserve each result before calling mail: an interrupted send must not be repeated. */
function notify_backup_result(string $root, array $job, bool $verified): array {
    if ((get_plan()['result_email'] ?? false) !== true) {
        return $job;
    }
    $result = $verified ? 'verified' : 'failed';
    if (!empty($job['result_email'][$result])) {
        return $job;
    }
    $recipient = get_option('admin_email', '');
    if (!is_string($recipient) || !is_email($recipient)) {
        return $job;
    }
    $now = time();
    $started = $job['started_at'] ?? null;
    $duration = is_int($started) && $started > 0 && $started <= $now
        ? ($now - $started) . ' seconds' : 'Not available';
    $bytes = $job['transfer']['size'] ?? null;
    if (!is_int($bytes) || $bytes < 0) {
        $evidence = verified_evidence(get_option(EVIDENCE_OPTION, []), home_url(), $now);
        $bytes = $verified ? verified_job_archive_size($job, $evidence) : null;
    }
    $size = is_int($bytes) && $bytes >= 0 ? $bytes . ' bytes' : 'Not available';
    $message = 'Site: ' . home_url() . "\n"
        . 'Result: ' . ($verified ? 'Backup completed' : 'Backup failed or paused; review Overview') . "\n"
        . 'Size: ' . $size . "\nDuration: " . $duration . "\n"
        . 'Verified in Dropbox: ' . ($verified ? 'Yes' : 'No') . "\n\n"
        . admin_url('admin.php?page=pebkac-backup&tab=overview');
    $job['result_email'][$result] = ['attempted_at' => $now, 'accepted' => null];
    write_backup_job($root, $job);
    try {
        $job['result_email'][$result]['accepted'] = (bool) wp_mail($recipient,
            'Website Backup: ' . ($verified ? 'verified backup' : 'backup needs attention') . ' — ' . home_url(), $message);
    } catch (\Throwable $error) {
        $job['result_email'][$result]['accepted'] = false;
    }
    write_backup_job($root, $job);
    return $job;
}
