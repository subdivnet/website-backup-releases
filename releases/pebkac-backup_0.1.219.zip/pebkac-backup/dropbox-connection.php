<?php

namespace PEBKAC404\Backup;

if (!defined('ABSPATH')) {
    exit;
}

const DROPBOX_SCOPES = 'files.metadata.read files.content.read files.content.write';
const DROPBOX_CREDENTIAL_OPTION = 'pebkac_backup_dropbox_connection';

const DROPBOX_PEBKAC404_CALLBACK_REGISTERED = true;
const DROPBOX_ILLUSTRATION_CALLBACK_REGISTERED = true;

function dropbox_pilot_callback(string $site): ?string {
    if (!in_array($site, ['https://securitylab.subdiv.net', 'https://pebkac404.com', 'https://johnrossillustration.com', 'https://www.s-comp.com', 'https://johnrossphoto.com'], true)) {
        return null;
    }
    return $site . '/wp-admin/admin-post.php?action=pebkac_backup_dropbox_callback';
}

function dropbox_pilot_callback_ready(string $site, string $callback, bool $second_registered = DROPBOX_PEBKAC404_CALLBACK_REGISTERED): bool {
    return $callback === dropbox_pilot_callback($site)
        && ($site === 'https://securitylab.subdiv.net' || ($site === 'https://pebkac404.com' && $second_registered)
            || ($site === 'https://johnrossillustration.com' && DROPBOX_ILLUSTRATION_CALLBACK_REGISTERED));
}

function dropbox_app_key(): string {
    // Keep the second callback disabled until its exact URI has been registered and read back.
    return dropbox_pilot_callback_ready(home_url(), dropbox_callback_url()) ? 'cnsewl5o3156prm' : '';
}

function dropbox_can_encrypt(): bool {
    return defined('AUTH_KEY') && defined('AUTH_SALT') && is_string(AUTH_KEY) && is_string(AUTH_SALT)
        && strlen(AUTH_KEY) >= 32 && strlen(AUTH_SALT) >= 32 && AUTH_KEY !== AUTH_SALT
        && function_exists('openssl_encrypt') && function_exists('openssl_decrypt')
        && in_array('aes-256-gcm', openssl_get_cipher_methods(), true);
}

function dropbox_encryption_key(): string {
    return hash_hmac('sha256', 'website-backup/dropbox/v1', AUTH_KEY . "\0" . AUTH_SALT, true);
}

function dropbox_saved_refresh_token(string $app): string {
    return dropbox_open_refresh_record($app, get_option(DROPBOX_CREDENTIAL_OPTION, ''));
}

function dropbox_open_refresh_record(string $app, $record): string {
    if ($app === '' || !dropbox_can_encrypt()) {
        return '';
    }
    $sealed = is_string($record) && strlen($record) <= 16384 ? base64_decode($record, true) : false;
    if ($sealed === false || strlen($sealed) < 29) {
        return '';
    }
    $token = openssl_decrypt(substr($sealed, 28), 'aes-256-gcm', dropbox_encryption_key(), OPENSSL_RAW_DATA,
        substr($sealed, 0, 12), substr($sealed, 12, 16), $app . '|' . dropbox_callback_url());
    return dropbox_valid_token($token) ? $token : '';
}

function dropbox_valid_token($token): bool {
    return is_string($token) && strlen($token) >= 16 && strlen($token) <= 8192 && !preg_match('/[\x00-\x20\x7f]/', $token);
}

function dropbox_callback_url(): string {
    return admin_url('admin-post.php?action=pebkac_backup_dropbox_callback', 'https');
}

/** Explain what the local authorization can establish without contacting Dropbox. */
function dropbox_overview_card(): array {
    if (!is_ssl()) {
        return ['notice-warning', 'Dropbox needs a secure WordPress connection', 'Open WordPress over HTTPS before connecting Dropbox.'];
    }
    if (home_url() === 'https://pebkac404.com' && !DROPBOX_PEBKAC404_CALLBACK_REGISTERED) {
        return ['notice-warning', 'Dropbox setup is pending', 'Connect Dropbox becomes available after this site is registered with the Dropbox app.'];
    }
    $app = dropbox_app_key();
    if ($app === '' || !dropbox_can_encrypt() || is_multisite()) {
        return ['notice-warning', 'Dropbox connection unavailable', 'Open Setup to see what this site needs to connect.'];
    }
    if (dropbox_saved_refresh_token($app) !== '') {
        try {
            [$job, $running] = read_backup_job_progress(backup_job_root());
            if (!$running && backup_job_can_retry_safely($job)) {
                if (($job['dropbox_refresh_failed'] ?? false) === true) {
                    return ['notice-warning', 'Dropbox connection could not refresh',
                        'If the next attempt also fails, open Setup and choose Reconnect Dropbox.'];
                }
                if (($job['dropbox_destination_check_failed'] ?? false) === true && backup_job_needs_connection_check($job)) {
                    return ['notice-warning', 'Dropbox folder check could not finish', 'The saved backup can check again before preparing its files.'];
                }
                if (($job['dropbox_destination_is_file'] ?? false) === true) {
                    $detail = backup_job_needs_connection_check($job) ? 'Part of the destination is a file. Open Setup and choose a folder for backups.'
                        : 'The last Dropbox check found a file at the backup destination. Move that file in Dropbox to continue the saved backup.';
                    return ['notice-warning', 'The Dropbox destination needs a folder', $detail];
                }
            }
        } catch (\RuntimeException $error) {
            // The authorization is still saved if the separate backup progress cannot be read.
        }
        return ['notice-success', 'Dropbox authorization saved', 'A backup run confirms that Dropbox accepts the connection.'];
    }
    if (get_option(DROPBOX_CREDENTIAL_OPTION, false) !== false) {
        return ['notice-warning', 'Reconnect Dropbox', 'Open Setup and choose Reconnect Dropbox with the account that holds your backups.'];
    }
    return ['notice-warning', 'Connect Dropbox', 'Open Setup and choose Connect Dropbox.'];
}

function dropbox_authorize_url(string $app, string $callback, string $state, string $verifier): string {
    $challenge = rtrim(strtr(base64_encode(hash('sha256', $verifier, true)), '+/', '-_'), '=');
    return 'https://www.dropbox.com/oauth2/authorize?' . http_build_query([
        'client_id' => $app, 'redirect_uri' => $callback, 'response_type' => 'code',
        'token_access_type' => 'offline', 'scope' => DROPBOX_SCOPES,
        'state' => $state, 'code_challenge_method' => 'S256', 'code_challenge' => $challenge,
    ], '', '&', PHP_QUERY_RFC3986);
}

function dropbox_token_request(array $body, int $timeout = 20): array {
    $response = wp_remote_post('https://api.dropboxapi.com/oauth2/token', [
        'body' => $body, 'redirection' => 0, 'sslverify' => true, 'timeout' => $timeout, 'limit_response_size' => 16384,
    ]);
    if (is_wp_error($response) || wp_remote_retrieve_response_code($response) !== 200) {
        throw new \RuntimeException('Dropbox did not authorize the backup connection.');
    }
    $payload = json_decode(wp_remote_retrieve_body($response), true);
    if (!is_array($payload) || !dropbox_valid_token($payload['access_token'] ?? null)) {
        throw new \RuntimeException('Dropbox returned an incomplete authorization.');
    }
    return $payload;
}

/** The backup worker refreshes access without persisting the short-lived token. */
function dropbox_connected_access_token(): string {
    $app = dropbox_app_key();
    $refresh = dropbox_saved_refresh_token($app);
    if ($refresh === '') {
        throw new \RuntimeException('Connect the Dropbox app folder in Website Backup first.');
    }
    return refresh_dropbox_access_token($app, $refresh, 20);
}

function refresh_dropbox_access_token(string $app, string $refresh, int $timeout): string {
    return dropbox_token_request(['grant_type' => 'refresh_token', 'refresh_token' => $refresh, 'client_id' => $app], $timeout)['access_token'];
}

function dropbox_connection_matches(string $fingerprint): bool {
    $existing = get_option(DROPBOX_CREDENTIAL_OPTION, false);
    return is_string($existing) && hash_equals($fingerprint, hash('sha256', $existing));
}

function save_dropbox_connection(string $app, string $token, ?string $previous = null): void {
    if ($app === '' || !dropbox_can_encrypt() || !dropbox_valid_token($token)) {
        throw new \RuntimeException('Dropbox authorization could not be protected.');
    }
    $nonce = random_bytes(12);
    $ciphertext = openssl_encrypt($token, 'aes-256-gcm', dropbox_encryption_key(), OPENSSL_RAW_DATA,
        $nonce, $tag, $app . '|' . dropbox_callback_url(), 16);
    if ($ciphertext === false) {
        throw new \RuntimeException('The private Dropbox connection could not be saved.');
    }
    $sealed = base64_encode($nonce . $tag . $ciphertext);
    if ($previous === null) {
        $saved = add_option(DROPBOX_CREDENTIAL_OPTION, $sealed, '', false);
    } else {
        $saved = dropbox_connection_matches($previous) && update_option(DROPBOX_CREDENTIAL_OPTION, $sealed, false);
    }
    if (!$saved) {
        throw new \RuntimeException('The private Dropbox connection could not be saved.');
    }
}

/** Find a verified backup that the replacement connection must still be able to read. */
function dropbox_reconnection_backup(string $site, int $now): array {
    $saved = get_option(EVIDENCE_OPTION, []);
    if ($saved !== []) {
        $full = verified_evidence($saved, $site, $now);
        if (!isset($full['manifest_path'])) {
            throw new \RuntimeException('The latest full backup could not be confirmed for reconnecting Dropbox.');
        }
        return $full;
    }
    $history = get_option(COMPONENT_RECOVERY_STATE_OPTION, []);
    if (!is_array($history) || ($history !== [] && !is_array($history['records'] ?? null))) {
        throw new \RuntimeException('The saved component backups could not be read.');
    }
    if (($history['records'] ?? []) === []) {
        return [];
    }
    $latest = [];
    foreach (available_component_recovery_chains($site, $history, $now) as $chain) {
        $head = $chain[count($chain) - 1];
        if ($head['offsite_verified_at'] > ($latest['offsite_verified_at'] ?? 0)) {
            $latest = $head;
        }
    }
    if ($latest === []) {
        throw new \RuntimeException('The latest component backup could not be confirmed for reconnecting Dropbox.');
    }
    return $latest;
}

/** Confirm the existing recovery destination before replacing a saved authorization. */
function renew_dropbox_connection(string $root, string $app, array $tokens, string $previous): void {
    with_backup_job_lock($root, static function () use ($root, $app, $tokens, $previous): void {
        if (!dropbox_connection_matches($previous)) {
            throw new \RuntimeException('A newer Dropbox authorization is already saved.');
        }
        $record = dropbox_reconnection_backup(home_url(), time());
        $pins = backup_dropbox_object_pins($record['dropbox_objects'] ?? []);
        if ($pins !== []) {
            $expected = [$record['archive_path'] => $pins['archive'], $record['manifest_path'] => $pins['manifest']];
            $timeout = max(1, min(5, intdiv((int) backup_request_budget(), 2)));
            $result = verify_offsite_files($expected, static function (string $path) use ($tokens, $timeout): ?array {
                return fetch_dropbox_metadata($path, $tokens['access_token'], $timeout);
            });
            if (!$result['verified']) {
                throw new \RuntimeException('The replacement Dropbox connection could not confirm the saved backup files.');
            }
        } elseif ($record !== []) {
            $file = download_recovery_object($root, $record, 'manifest', $tokens['access_token']);
            if (!@unlink($file)) {
                throw new \RuntimeException('The temporary verification file could not be removed.');
            }
        } else {
            $job = read_backup_job($root);
            $before_capture = in_array($job['phase'] ?? '', ['database', 'files'], true) && !isset($job['transfer']);
            $before_folder = ($job['phase'] ?? null) === 'folder' && ($job['transfer']['phase'] ?? null) === 'start'
                && ($job['transfer']['offset'] ?? null) === 0;
            $before_dropbox = ($job['dropbox_refresh_failed'] ?? false) === true && ($before_capture || $before_folder)
                && !isset($job['folder_progress']) && !isset($job['transfer']['session']) && !isset($job['manifest_transfer']);
            if ($job !== [] && $job['phase'] !== 'verified' && !$before_dropbox) {
                throw new \RuntimeException('Resolve the current backup before changing its Dropbox authorization.');
            }
        }
        save_dropbox_connection($app, $tokens['refresh_token'], $previous);
    });
}

function dropbox_admin_redirect(string $status): void {
    wp_safe_redirect(admin_url('admin.php?page=pebkac-backup&tab=setup&dropbox=' . $status), 303);
    exit;
}

function dropbox_require_admin(): void {
    if (!is_ssl() || !current_user_can('manage_options') || is_multisite()) {
        wp_die('Dropbox setup requires a signed-in administrator over HTTPS.', '', ['response' => 403]);
    }
    nocache_headers();
    header('Referrer-Policy: no-referrer');
}

add_action('admin_post_pebkac_backup_dropbox_connect', static function () {
    dropbox_require_admin();
    if (($_SERVER['REQUEST_METHOD'] ?? '') !== 'POST') {
        wp_die('Use the Connect Dropbox button.', '', ['response' => 405]);
    }
    check_admin_referer('pebkac_backup_dropbox_connect');
    $app = dropbox_app_key();
    $existing = get_option(DROPBOX_CREDENTIAL_OPTION, false);
    $renew = ($_POST['reconnect'] ?? '') === '1';
    if ($app === '' || !dropbox_can_encrypt() || ($renew ? !is_string($existing) : $existing !== false)) {
        dropbox_admin_redirect('unavailable');
    }
    $state = bin2hex(random_bytes(32));
    $verifier = bin2hex(random_bytes(32));
    $callback = dropbox_callback_url();
    $pending = [
        'user' => get_current_user_id(), 'app' => $app, 'site' => home_url(), 'verifier' => $verifier,
        'previous' => $renew ? hash('sha256', $existing) : null,
    ];
    if (!set_transient('pebkac_dbx_' . hash('sha256', $state), $pending, 600)) {
        dropbox_admin_redirect('failed');
    }
    wp_redirect(dropbox_authorize_url($app, $callback, $state, $verifier), 303);
    exit;
});

add_action('admin_post_pebkac_backup_dropbox_callback', static function () {
    dropbox_require_admin();
    $state = $_GET['state'] ?? '';
    if (!is_string($state) || !preg_match('/^[a-f0-9]{64}$/D', $state)) {
        dropbox_admin_redirect('failed');
    }
    $name = 'pebkac_dbx_' . hash('sha256', $state);
    $pending = get_transient($name);
    $app = dropbox_app_key();
    if (!is_array($pending) || ($pending['user'] ?? null) !== get_current_user_id()
        || ($pending['site'] ?? null) !== home_url() || ($pending['app'] ?? null) !== $app
        || !delete_transient($name) || $app === '' || !dropbox_can_encrypt()) {
        dropbox_admin_redirect('failed');
    }
    $code = $_GET['code'] ?? '';
    if (!is_string($code) || !dropbox_valid_token($code)) {
        dropbox_admin_redirect('failed');
    }
    try {
        $tokens = dropbox_token_request([
            'code' => $code, 'grant_type' => 'authorization_code', 'client_id' => $app,
            'redirect_uri' => dropbox_callback_url(), 'code_verifier' => $pending['verifier'],
        ]);
        if (!dropbox_valid_token($tokens['refresh_token'] ?? null)) {
            throw new \RuntimeException('Dropbox did not grant background access.');
        }
        $previous = $pending['previous'] ?? null;
        if (is_string($previous)) {
            renew_dropbox_connection(backup_job_root(true), $app, $tokens, $previous);
        } else {
            save_dropbox_connection($app, $tokens['refresh_token']);
        }
    } catch (\RuntimeException $error) {
        dropbox_admin_redirect('failed');
    }
    queue_backup_after_dropbox_authorization();
    dropbox_admin_redirect('connected');
});
