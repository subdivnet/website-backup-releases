(() => {
    const panel = document.getElementById('pebkac-backup-run');
    const button = panel && panel.querySelector('button');
    if (!button) return;
    const progress = panel.querySelector('.pebkac-backup-progress');

    async function requestBackupStep(body) {
        const controller = new AbortController();
        const timeout = window.setTimeout(() => controller.abort(), 120000);
        let response;
        let result;
        try {
            response = await fetch(window.ajaxurl, { method: 'POST', credentials: 'same-origin', body, signal: controller.signal });
            result = await response.json();
        } catch {
            throw new Error(controller.signal.aborted
                ? 'The backup step took too long to respond. Refresh backup status to see where it stopped.'
                : 'The backup step did not return a status. Refresh backup status before continuing.');
        } finally {
            window.clearTimeout(timeout);
        }
        if (!response.ok || !result || result.success !== true) {
            throw new Error(result && typeof result.data === 'string' ? result.data : 'The backup stopped before it could confirm progress.');
        }
        if (!result.data || typeof result.data.message !== 'string' || typeof result.data.finished !== 'boolean'
            || typeof result.data.job_id !== 'string' || !/^[0-9a-f]{32}$/.test(result.data.job_id)) {
            throw new Error('The backup step did not return a status. Refresh backup status before continuing.');
        }
        return result.data;
    }

    button.addEventListener('click', async () => {
        if (button.dataset.refresh === '1') {
            window.location.reload();
            return;
        }
        button.disabled = true;
        progress.textContent = button.dataset.clearTemp ? 'Clearing temporary files…' : 'Running the next backup step…';
        let backgroundQueued = false;
        try {
            for (let step = 0; step < 90; step += 1) {
                const body = new URLSearchParams({ action: 'pebkac_backup_step', _ajax_nonce: panel.dataset.nonce, expected_job: panel.dataset.jobId });
                if (button.dataset.restart === '1') body.set('restart', '1');
                if (button.dataset.newAfter) body.set('new_after', button.dataset.newAfter);
                if (button.dataset.clearTemp) body.set('clear_temp', button.dataset.clearTemp);
                const state = await requestBackupStep(body);
                panel.dataset.jobId = state.job_id;
                backgroundQueued = state.background_queued === true;
                delete button.dataset.newAfter;
                button.dataset.restart = state.restartable ? '1' : '0';
                progress.textContent = state.message;
                if (state.finished || state.uncertain) {
                    window.location.reload();
                    return;
                }
            }
            progress.textContent = backgroundQueued
                ? 'WordPress queued the next backup step. You can close this page.'
                : 'Backup progress was saved. Use Resume backup to continue.';
        } catch (error) {
            progress.textContent = error.message || 'The backup step did not respond. Progress remains saved.';
            button.dataset.refresh = '1';
            button.textContent = 'Refresh backup status';
            button.disabled = false;
            return;
        }
        button.textContent = 'Resume backup';
        button.disabled = false;
    });
})();
