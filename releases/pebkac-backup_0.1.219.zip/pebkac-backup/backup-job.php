<?php

namespace PEBKAC404\Backup;

if (!defined('ABSPATH')) {
    exit;
}

require_once __DIR__ . '/wordpress-capture.php';
require_once __DIR__ . '/wordpress-transfer.php';
require_once __DIR__ . '/backup-incremental.php';

const BACKUP_JOB_RECORD_MAX_BYTES = 32 * 1024;

/** Called under the backup job lock so a new write cannot race cleanup. */
function clear_abandoned_backup_records(string $root, int $now): void {
    clear_abandoned_backup_files($root, $now, '/^state-[a-f0-9]{16}$/D');
}

function backup_job_root(bool $create = false): string {
    $temp = backup_temp_parent();
    if ($temp === '' || dropbox_app_key() === '' || !dropbox_can_encrypt() || is_multisite()) {
        throw new \RuntimeException('Private backup staging is unavailable for this site.');
    }
    $name = hash_hmac('sha256', 'backup-job|' . home_url(), dropbox_encryption_key());
    return private_backup_work_directory($temp, 'website-backup-' . substr($name, 0, 32), $create);
}

/** Resolve a private working directory for a caller-generated name. */
function private_backup_work_directory(string $temp, string $name, bool $create): string {
    $root = $temp . DIRECTORY_SEPARATOR . $name;
    if ($create && !is_dir($root)) {
        @mkdir($root, 0700);
    }
    if (is_link($root) || (($create || file_exists($root)) && (!is_dir($root)
        || (DIRECTORY_SEPARATOR === '/' && (fileperms($root) & 0077) !== 0)))) {
        throw new \RuntimeException('The temporary backup directory is not private.');
    }
    return $root;
}

function read_backup_job(string $root): array {
    $path = $root . '/job.json';
    if (!file_exists($path) && !is_link($path)) {
        return [];
    }
    $bytes = is_link($path) ? false : @file_get_contents($path, false, null, 0, BACKUP_JOB_RECORD_MAX_BYTES + 1);
    $job = $bytes !== false && strlen($bytes) <= BACKUP_JOB_RECORD_MAX_BYTES ? json_decode($bytes, true) : null;
    $component = $job['component'] ?? null;
    if (!is_array($job) || !is_string($job['phase'] ?? null) || $job['phase'] === ''
        || !is_string($job['id'] ?? null) || !preg_match('/^[0-9a-f]{32}$/D', $job['id'])
        || ($component !== null && (!is_string($component) || !isset(COMPONENTS[$component])))) {
        throw new \RuntimeException('The private backup record could not be read.');
    }
    return $job;
}

function write_backup_job(string $root, array $job): void {
    $bytes = wp_json_encode($job);
    if ($bytes === false) {
        throw new \RuntimeException('Could not reserve the private backup record.');
    }
    if (strlen($bytes) > BACKUP_JOB_RECORD_MAX_BYTES) {
        throw new \RuntimeException('The backup progress record is too large to save.');
    }
    write_private_backup_record($root . '/job.json', $bytes);
}

function write_private_backup_record(string $path, string $bytes): void {
    $temp = dirname($path) . '/state-' . bin2hex(random_bytes(8));
    $stream = @fopen($temp, 'xb');
    if ($stream === false) {
        throw new \RuntimeException('Could not reserve the private backup record.');
    }
    try {
        $written = fwrite($stream, $bytes) === strlen($bytes) && fflush($stream);
        fclose($stream);
        if ($written) {
            $attempts = DIRECTORY_SEPARATOR === '\\' ? 4 : 1;
            for ($attempt = 0; $attempt < $attempts; $attempt++) {
                if (@rename($temp, $path)) {
                    return;
                }
                clearstatcache(true, $temp);
                clearstatcache(true, $path);
                if (!is_file($temp)) {
                    if (!is_link($path) && is_file($path) && @file_get_contents($path, false, null, 0, strlen($bytes) + 1) === $bytes) {
                        return;
                    }
                    break;
                }
                if ($attempt + 1 < $attempts) {
                    usleep(25000);
                }
            }
        }
        throw new \RuntimeException('Could not persist backup progress safely.');
    } finally {
        if (is_resource($stream)) {
            fclose($stream);
        }
        if (is_file($temp)) {
            @unlink($temp);
        }
    }
}

final class BackupJobLockBusy extends \RuntimeException {}

function with_backup_job_lock(string $root, callable $run) {
    $path = $root . '/job.lock';
    $lock = is_link($path) ? false : @fopen($path, 'c+b');
    if ($lock === false) {
        throw new \RuntimeException('Could not open the private backup lock.');
    }
    try {
        $would_block = 0;
        if (!flock($lock, LOCK_EX | LOCK_NB, $would_block)) {
            if ($would_block === 1) {
                throw new BackupJobLockBusy('A backup step is already running. Wait before resuming.');
            }
            throw new \RuntimeException('Could not lock the private backup staging area.');
        }
        return $run();
    } finally {
        fclose($lock);
    }
}

function backup_request_budget(): float {
    $limit = (int) ini_get('max_execution_time');
    return $limit === 0 ? 25.0 : max(1, min(25, $limit - 3));
}

/** Recover the size from a completed job only when both objects match the published evidence. */
function verified_job_archive_size(array $job, array $evidence): ?int {
    $archive = $job['transfer'] ?? [];
    $manifest = $job['manifest_transfer'] ?? [];
    $size = $archive['size'] ?? null;
    if (!isset($evidence['archive_path'], $evidence['manifest_path'], $evidence['manifest_sha256'])
        || !in_array($job['phase'] ?? '', ['publish', 'verified'], true)
        || ($archive['phase'] ?? '') !== 'verified' || ($manifest['phase'] ?? '') !== 'verified'
        || ($archive['sha256'] ?? '') !== $evidence['archive_sha256'] || ($archive['path'] ?? '') !== $evidence['archive_path']
        || ($manifest['sha256'] ?? '') !== $evidence['manifest_sha256'] || ($manifest['path'] ?? '') !== $evidence['manifest_path']
        || !is_int($size) || $size < 1 || $size > SNAPSHOT_MAX_BYTES + 8 * 1024 * 1024) {
        return null;
    }
    return $size;
}

/** Preserve a legacy full backup's size before replacing its private job record. */
function preserve_completed_backup_size(array $job, string $site, int $now): void {
    if (($job['phase'] ?? '') !== 'verified' || isset($job['component'])) {
        return;
    }
    $saved = get_option(EVIDENCE_OPTION, []);
    $proof = verified_evidence($saved, $site, $now);
    if (isset($proof['archive_size_bytes'])) {
        return;
    }
    $size = verified_job_archive_size($job, $proof);
    if ($size !== null) {
        $saved['archive_size_bytes'] = $size;
        if (!update_option(EVIDENCE_OPTION, $saved, false)) {
            throw new \RuntimeException('Could not preserve the last verified backup size.');
        }
    }
}

function backup_capture_supported(): bool {
    return class_exists(\ZipArchive::class) && method_exists(\ZipArchive::class, 'registerCancelCallback');
}

function restartable_backup_capture(array $job): bool {
    return in_array($job['phase'] ?? '', ['exporting', 'archiving'], true)
        && !isset($job['transfer']) && !isset($job['manifest_transfer']);
}

/** Save a known reason for an interrupted local capture without saving its error text. */
function record_backup_capture_problem(string $root, array $job, callable $capture) {
    try {
        return $capture();
    } catch (BackupCaptureProblem $error) {
        if (restartable_backup_capture($job) && backup_capture_problem_message($error->getCode()) !== '') {
            $job['capture_problem'] = $error->getCode();
            try {
                write_backup_job($root, $job);
            } catch (\RuntimeException $save_error) {
                // The saved capture phase still identifies a safe restart point.
            }
        }
        throw $error;
    }
}

/** Clear only an interrupted capture that never reached Dropbox. Caller holds the job lock. */
function restart_backup_capture(string $root, array $job, bool $automatic = false): array {
    if (!restartable_backup_capture($job)) {
        throw new \RuntimeException('Only a backup stopped before transfer can be restarted here.');
    }
    $new = ['id' => $job['id'], 'phase' => 'database'];
    if (isset($job['component'])) {
        $component = $job['component'];
        $claim = get_option(SCHEDULED_BACKUP_JOB_OPTION, []);
        $due = $job['scheduled_due_at'] ?? null;
        if (!isset(COMPONENTS[$component]) || !is_int($due) || $due <= 0
            || ($claim['id'] ?? null) !== $job['id'] || ($claim['component'] ?? null) !== $component
            || ($claim['due_at'] ?? null) !== $due) {
            throw new \RuntimeException('The interrupted backup does not match the saved component schedule.');
        }
        $new['component'] = $component;
        $new['scheduled_due_at'] = $due;
        $new['phase'] = $component === 'database' ? 'database' : 'files';
        if (($job['incremental'] ?? false) === true && $component !== 'database') {
            $new['incremental'] = true;
            $new['preflight_incremental_destination'] = true;
            $new['phase'] = 'replay_inventory';
        }
    } elseif (isset($job['daily_date'])) {
        $new['daily_date'] = $job['daily_date'];
    } else {
        $new['id'] = bin2hex(random_bytes(16));
    }
    if (isset($job['folder'])) {
        $new['folder'] = backup_dropbox_folder($job);
    }
    if ($automatic) {
        // Spend the retry before touching partial files so a failed cleanup cannot repeat.
        $job['automatic_capture_retry'] = true;
        write_backup_job($root, $job);
    }
    if (isset($job['automatic_capture_retry'])) {
        $new['automatic_capture_retry'] = true;
    }
    clear_interrupted_backup_capture($root, $job);
    write_backup_job($root, $new);
    return $new;
}

/** Remove only the known local artifacts of a capture that never reached Dropbox. */
function clear_interrupted_backup_capture(string $root, array $job): void {
    if (!restartable_backup_capture($job)) {
        throw new \RuntimeException('Only a backup stopped before transfer can be cleared here.');
    }
    clear_local_backup_capture_files($root, $job['id']);
}

/** Remove only the known artifacts of a job already proved to be local. */
function clear_local_backup_capture_files(string $root, string $id): void {
    $directory = wordpress_capture_directory($root, home_url(), $id);
    clearstatcache(true, $directory);
    if (is_link($directory) || (file_exists($directory) && !is_dir($directory))) {
        throw new \RuntimeException('The interrupted capture directory could not be verified.');
    }
    if (!is_dir($directory)) {
        return;
    }
    clear_abandoned_backup_records($directory, time());
    $entries = @scandir($directory);
    $known = ['.', '..', 'database.sql', 'backup.zip', 'manifest.json', COMPONENT_INVENTORY_REPLAY_FILE];
    if ($entries === false || array_diff($entries, $known) !== []) {
        throw new \RuntimeException('The interrupted capture still contains temporary files.');
    }
    $files = array_diff($entries, ['.', '..']);
    foreach ($files as $name) {
        $path = $directory . '/' . $name;
        if (is_link($path) || !is_file($path)) {
            throw new \RuntimeException('The interrupted capture still contains temporary files.');
        }
    }
    foreach ($files as $name) {
        if (!@unlink($directory . '/' . $name)) {
            throw new \RuntimeException('Could not clear the interrupted capture.');
        }
    }
    if (!@rmdir($directory)) {
        throw new \RuntimeException('The interrupted capture still contains temporary files.');
    }
}

/** Retry one local capture for this scheduled occurrence. Caller holds the job lock. */
function retry_scheduled_backup_capture(string $root, array $job): string {
    if (!restartable_backup_capture($job) || isset($job['automatic_capture_retry'])) {
        return 'blocked';
    }
    restart_backup_capture($root, $job, true);
    return 'advanced';
}

/** Persist both transfer plans for a staged incremental capture. Caller holds the job lock. */
function prepare_incremental_backup_job(
    string $root, array $job, array $parent, array $baseline, string $manifest_sha256, float $deadline
): array {
    $component = $job['component'] ?? null;
    if (($job['phase'] ?? '') !== 'archiving' || !restartable_backup_capture($job)
        || !is_string($component) || $component !== ($baseline['component'] ?? null)
        || read_backup_job($root) !== $job) {
        throw new \RuntimeException('The saved backup job does not match this incremental capture.');
    }
    $state = get_option(COMPONENT_RECOVERY_STATE_OPTION, []);
    $head = $state['latest'][$component] ?? null;
    if (!is_string($head) || ($state['records'][$head] ?? null) !== $parent || ($parent['archive_path'] ?? null) !== $head) {
        throw new \RuntimeException('The incremental parent is no longer the latest verified component backup.');
    }
    $site = home_url();
    $directory = wordpress_capture_directory($root, $site, $job['id']);
    $plans = plan_incremental_wordpress_transfer($directory, $site, $job['id'], $parent, $baseline, $manifest_sha256, time(), $deadline, backup_dropbox_folder($job));
    $job = array_replace($job, $plans, ['phase' => 'folder', 'manifest_sha256' => $manifest_sha256]);
    write_backup_job($root, $job);
    return $job;
}

/** Remove only the known artifacts of a job whose Dropbox copies have verified. */
function clear_verified_backup_staging(string $directory): bool {
    clearstatcache(true, $directory);
    if (is_link($directory)) {
        return false;
    }
    if (!file_exists($directory)) {
        return true;
    }
    if (!is_dir($directory) || (DIRECTORY_SEPARATOR === '/' && (fileperms($directory) & 0077) !== 0)) {
        return false;
    }
    clear_abandoned_backup_records($directory, time());
    $cleared = true;
    foreach (['backup.zip', 'manifest.json', COMPONENT_INVENTORY_REPLAY_FILE] as $name) {
        $path = $directory . '/' . $name;
        clearstatcache(true, $path);
        if ((is_file($path) || is_link($path)) && !@unlink($path)) {
            $cleared = false;
        }
    }
    return $cleared && @rmdir($directory);
}

/** Retry local staging cleanup while holding the same lock used by backup. */
function retry_verified_backup_staging(string $root, array $job, string $id): array {
    if (($job['id'] ?? '') !== $id || ($job['phase'] ?? '') !== 'verified' || empty($job['cleanup_pending'])) {
        throw new \RuntimeException('The backup status changed. Refresh Overview to see its temporary files.');
    }
    $directory = wordpress_capture_directory($root, home_url(), $job['id']);
    if (!clear_verified_backup_staging($directory)) {
        throw new \RuntimeException('Some temporary files could not be cleared. Your Dropbox backup is still verified.');
    }
    $job['cleanup_pending'] = false;
    write_backup_job($root, $job);
    return $job;
}

/** Keep a fixed connection result on the saved job without recording provider errors. */
function backup_job_dropbox_access_token(string $root, array $job): string {
    try {
        return dropbox_connected_access_token();
    } catch (\RuntimeException $error) {
        if (($job['dropbox_refresh_failed'] ?? false) !== true) {
            $job['dropbox_refresh_failed'] = true;
            try {
                write_backup_job($root, $job);
            } catch (\RuntimeException $save_error) {
                // Keep the original connection error if the progress file cannot be written.
            }
        }
        throw $error;
    }
}

function backup_job_needs_connection_check(array $job): bool {
    $phase = $job['phase'] ?? '';
    return ($job['dropbox_checked_before_capture'] ?? false) !== true
        && (in_array($phase, ['database', 'files'], true)
            || ($phase === 'replay_inventory' && ($job['preflight_incremental_destination'] ?? false) === true));
}

function record_occupied_backup_destination(string $root, array $job): void {
    if (($job['dropbox_destination_is_file'] ?? false) !== true
        || isset($job['dropbox_refresh_failed']) || isset($job['dropbox_destination_check_failed'])) {
        $job['dropbox_destination_is_file'] = true;
        unset($job['dropbox_refresh_failed'], $job['dropbox_destination_check_failed']);
        write_backup_job($root, $job);
    }
}

/** Start a replacement under the same saved occurrence before any upload intent exists. */
function replace_incomplete_component_capture(string $root, array $job): array {
    clear_local_backup_capture_files($root, $job['id']);
    $job['phase'] = 'files';
    $job['replacement_component_copy'] = true;
    unset($job['incremental'], $job['preflight_incremental_destination']);
    return $job;
}

function advance_backup_job(string $root, array $job): array {
    $was_verified = ($job['phase'] ?? '') === 'verified';
    if (!$was_verified && !isset($job['started_at']) && (get_plan()['result_email'] ?? false) === true) {
        $job['started_at'] = time();
        write_backup_job($root, $job);
    }
    try {
        $job = advance_backup_job_step($root, $job);
    } catch (\Throwable $error) {
        try {
            $saved = read_backup_job($root);
            if (($saved['id'] ?? '') === $job['id']) {
                $saved = remember_backup_failure($root, $saved);
                notify_backup_result($root, $saved, false);
            }
        } catch (\Throwable $mail_error) {
            // Reporting must never replace the original backup error.
        }
        throw $error;
    }
    if (!$was_verified && ($job['phase'] ?? '') === 'verified') {
        try {
            $job = notify_backup_result($root, $job, true);
        } catch (\Throwable $mail_error) {
            // A reporting problem does not invalidate a verified backup.
        }
    }
    return $job;
}

function advance_backup_job_step(string $root, array $job): array {
    global $wpdb;
    $site = home_url();
    $component = $job['component'] ?? null;
    $folder = backup_dropbox_folder($job);
    $remote_base = pilot_backup_base($site, $job['id'], $component, $folder);
    $directory = wordpress_capture_directory($root, $site, $job['id']);
    $destination_blocked = ($job['dropbox_destination_is_file'] ?? false) === true
        || ($job['dropbox_destination_check_failed'] ?? false) === true;
    if ($destination_blocked && backup_job_needs_connection_check($job)
        && !isset($job['transfer']) && !isset($job['manifest_transfer']) && !isset($job['folder_progress'])
        && !file_exists($directory) && !is_link($directory)) {
        $new_folder = backup_dropbox_folder(get_plan());
        if ($new_folder !== $folder) {
            if ($new_folder === PILOT_DROPBOX_FOLDER) {
                unset($job['folder']);
            } else {
                $job['folder'] = $new_folder;
            }
            unset($job['dropbox_destination_is_file'], $job['dropbox_folder_preflight'], $job['dropbox_destination_check_failed']);
            $folder = $new_folder;
            $remote_base = pilot_backup_base($site, $job['id'], $component, $folder);
            write_backup_job($root, $job);
        }
    }
    if (backup_job_needs_connection_check($job) && backup_capture_supported()) {
        $preflight = $job['dropbox_folder_preflight'] ?? [];
        $index = $preflight['index'] ?? null;
        if (!is_array($preflight) || ($preflight !== [] && (($preflight['phase'] ?? null) !== 'check'
            || !is_int($index) || $index < 0 || $index >= substr_count($folder, '/')))) {
            throw new \RuntimeException('The saved Dropbox destination check is invalid.');
        }
        $token = backup_job_dropbox_access_token($root, $job);
        if (isset($job['dropbox_refresh_failed'])) {
            unset($job['dropbox_refresh_failed']);
            write_backup_job($root, $job);
        }
        try {
            $preflight = advance_backup_dropbox_folder($folder, $preflight, $token, static function (): void {
                throw new \LogicException('A destination preflight cannot create Dropbox folders.');
            }, 5);
        } catch (DropboxDestinationOccupied $error) {
            record_occupied_backup_destination($root, $job);
            throw new \RuntimeException('Part of the Dropbox destination is a file. Choose a folder in Setup.', 0, $error);
        } catch (\RuntimeException $error) {
            if (($job['dropbox_destination_check_failed'] ?? false) !== true) {
                $job['dropbox_destination_check_failed'] = true;
                write_backup_job($root, $job);
            }
            throw new \RuntimeException('Dropbox could not confirm the selected backup folder. The saved backup can check again.', 0, $error);
        }
        if ($preflight['phase'] === 'check') {
            $job['dropbox_folder_preflight'] = $preflight;
        } elseif (in_array($preflight['phase'], ['verified', 'create'], true)) {
            $job['dropbox_checked_before_capture'] = true;
            unset($job['dropbox_folder_preflight']);
        } else {
            throw new \RuntimeException('Dropbox could not confirm the backup destination.');
        }
        unset($job['dropbox_destination_is_file'], $job['dropbox_destination_check_failed']);
        write_backup_job($root, $job);
        return $job;
    }
    $budget = backup_request_budget();
    $deadline = microtime(true) + $budget;
    switch ($job['phase']) {
        case 'database':
            if ($component !== null && $component !== 'database') {
                throw new \RuntimeException('A file component does not use database export.');
            }
            clear_abandoned_recovery_downloads($root, time());
            if (!backup_capture_supported()) {
                throw new \RuntimeException('This host cannot safely bound the ZIP capture. See Host readiness.');
            }
            $job['phase'] = 'exporting';
            write_backup_job($root, $job);
            $export = new \wpdb(DB_USER, DB_PASSWORD, DB_NAME, DB_HOST);
            try {
                $export->set_prefix($wpdb->prefix);
                record_backup_capture_problem($root, $job, static function () use ($directory, $export, $budget): void {
                    start_wordpress_capture($directory, $export, min($budget, 12));
                });
            } finally {
                $export->close();
            }
            $job['phase'] = 'files';
            break;
        case 'files':
            if ($component !== null && $component !== 'database') {
                clear_abandoned_recovery_downloads($root, time());
            }
            $job['phase'] = 'archiving';
            write_backup_job($root, $job);
            if ($component !== null && $component !== 'database' && !@mkdir($directory, 0700)) {
                throw new \RuntimeException('Could not reserve the file component staging directory.');
            }
            $manifest = record_backup_capture_problem($root, $job, static function () use ($directory, $deadline, $component): array {
                return finish_wordpress_capture($directory, ABSPATH, WP_CONTENT_DIR, $deadline, $component);
            });
            $job['manifest_sha256'] = hash_file('sha256', $directory . '/manifest.json');
            if ($job['manifest_sha256'] === false) {
                throw new \RuntimeException('Could not pin the capture manifest for Dropbox.');
            }
            if ($component !== null) {
                $inventory = $component === 'database' ? $manifest['files'] : incremental_file_inventory($component, $manifest['files']);
                $job['component_capture'] = [
                    'component' => $component, 'archive_sha256' => $manifest['archive_sha256'],
                    'manifest_sha256' => $job['manifest_sha256'], 'inventory_sha256' => incremental_inventory_sha256($component, $inventory),
                ];
            }
            $job['phase'] = 'plan_transfer';
            break;
        case 'replay_inventory':
        case 'incremental_files':
            if ($component === null || $component === 'database' || ($job['incremental'] ?? false) !== true) {
                throw new \RuntimeException('Incremental capture requires a scheduled file component.');
            }
            $history = get_option(COMPONENT_RECOVERY_STATE_OPTION, []);
            $check = component_readback_records()[$component] ?? [];
            if (($check['previous']['state'] ?? $check['state'] ?? '') === 'changed'
                && local_component_capture_without_transfer($job) && is_array($history)
                && component_readback_status(plan_component_inventory_replay($site, $component, $history, time()), $check) !== []) {
                $job = replace_incomplete_component_capture($root, $job);
                break;
            }
            $replaying = $job['phase'] === 'replay_inventory';
            if ($replaying && !is_dir($directory) && !@mkdir($directory, 0700)) {
                throw new \RuntimeException('Could not reserve the private incremental staging directory.');
            }
            $authorization = $replaying ? component_readback_authorization() : '';
            try {
                $baseline = advance_component_inventory_replay($directory, $site, $component, $history,
                    $replaying ? backup_job_dropbox_access_token($root, $job) : null, time());
            } catch (ComponentRecoveryObjectChanged $error) {
                if (!local_component_capture_without_transfer($job) || $authorization !== component_readback_authorization()) {
                    throw $error;
                }
                $now = time();
                remember_changed_component_recovery(plan_component_inventory_replay($site, $component, $history, $now), $component, $now);
                $job = replace_incomplete_component_capture($root, $job);
                break;
            }
            if ($replaying) {
                if ($baseline !== null) {
                    $job['phase'] = 'incremental_files';
                }
                break;
            }
            $job['phase'] = 'archiving';
            write_backup_job($root, $job);
            record_backup_capture_problem($root, $job, static function () use ($directory, $baseline, $deadline): void {
                finish_wordpress_incremental_capture($directory, ABSPATH, WP_CONTENT_DIR, $baseline['inventory'], $deadline);
            });
            $manifest_sha256 = hash_file('sha256', $directory . '/manifest.json');
            if ($manifest_sha256 === false) {
                throw new \RuntimeException('Could not pin the incremental capture manifest.');
            }
            return prepare_incremental_backup_job($root, $job, $baseline['parent'], $baseline['inventory'], $manifest_sha256, $deadline);
        case 'plan_transfer':
            $manifest = read_snapshot_manifest($directory . '/manifest.json');
            if (($manifest['component'] ?? null) !== $component) {
                throw new \RuntimeException('The backup manifest belongs to another component.');
            }
            $path = $remote_base . '.zip';
            $job['transfer'] = plan_wordpress_transfer($directory . '/backup.zip', $manifest['archive_sha256'], $path, $deadline, $site, $component, $folder);
            $job['phase'] = 'folder';
            break;
        case 'folder':
            $token = backup_job_dropbox_access_token($root, $job);
            try {
                $job['folder_progress'] = advance_backup_dropbox_folder($folder, $job['folder_progress'] ?? [], $token,
                    static function (array $progress) use ($root, $job): void {
                        $job['folder_progress'] = $progress;
                        write_backup_job($root, $job);
                    });
            } catch (DropboxDestinationOccupied $error) {
                record_occupied_backup_destination($root, $job);
                throw new \RuntimeException('Move the file at the Dropbox destination to continue the saved backup.', 0, $error);
            }
            unset($job['dropbox_destination_is_file']);
            if ($job['folder_progress']['phase'] === 'verified') {
                unset($job['folder_progress']);
                $job['phase'] = 'transfer';
            }
            break;
        case 'transfer':
            if (($job['transfer']['path'] ?? '') !== $remote_base . '.zip') {
                throw new \RuntimeException('The saved archive destination does not match this pilot site.');
            }
            if ($job['transfer']['phase'] !== 'verified') {
                $job['transfer'] = advance_wordpress_transfer($job['transfer'], $directory . '/backup.zip', backup_job_dropbox_access_token($root, $job),
                    static function (array $transfer) use ($root, $job): void {
                        $job['transfer'] = $transfer;
                        write_backup_job($root, $job);
                    });
            }
            if ($job['transfer']['phase'] === 'verified') {
                $job['phase'] = 'plan_manifest';
            }
            break;
        case 'plan_manifest':
            $manifest = read_snapshot_manifest($directory . '/manifest.json');
            $incremental = isset($job['component_capture']['parent_path']);
            $manifest_component = $incremental ? ($manifest['delta']['component'] ?? null) : ($manifest['component'] ?? null);
            if ($manifest_component !== $component || ($incremental && $component === null)) {
                throw new \RuntimeException('The backup manifest belongs to another component.');
            }
            if (($manifest['archive_sha256'] ?? null) !== $job['transfer']['sha256']) {
                throw new \RuntimeException('The backup manifest no longer describes the verified Dropbox archive.');
            }
            $path = $remote_base . '.manifest.json';
            $manifest_transfer = plan_wordpress_transfer($directory . '/manifest.json', $job['manifest_sha256'], $path, $deadline, $site, $component, $folder);
            if ($incremental && ($job['manifest_transfer'] ?? null) !== $manifest_transfer) {
                throw new \RuntimeException('The incremental manifest no longer matches its saved transfer plan.');
            }
            $job['manifest_transfer'] = $manifest_transfer;
            $job['phase'] = 'manifest';
            break;
        case 'manifest':
            if (($job['manifest_transfer']['path'] ?? '') !== $remote_base . '.manifest.json') {
                throw new \RuntimeException('The saved manifest destination does not match this pilot site.');
            }
            if ($job['manifest_transfer']['phase'] !== 'verified') {
                $job['manifest_transfer'] = advance_wordpress_transfer($job['manifest_transfer'], $directory . '/manifest.json', backup_job_dropbox_access_token($root, $job),
                    static function (array $transfer) use ($root, $job): void {
                        $job['manifest_transfer'] = $transfer;
                        write_backup_job($root, $job);
                    });
            }
            if ($job['manifest_transfer']['phase'] === 'verified') {
                $job['phase'] = 'publish';
            }
            break;
        case 'publish':
            if (($job['transfer']['phase'] ?? '') !== 'verified' || ($job['manifest_transfer']['phase'] ?? '') !== 'verified'
                || ($job['manifest_transfer']['sha256'] ?? null) !== $job['manifest_sha256']
                || ($job['transfer']['path'] ?? '') !== $remote_base . '.zip'
                || ($job['manifest_transfer']['path'] ?? '') !== $remote_base . '.manifest.json') {
                throw new \RuntimeException('Both the Dropbox archive and its manifest must be verified before publishing.');
            }
            if ($component !== null) {
                $capture = $job['component_capture'] ?? [];
                if (($capture['component'] ?? null) !== $component) {
                    throw new \RuntimeException('The saved job does not describe the expected component capture.');
                }
                if (isset($job['folder'])) {
                    $capture['folder'] = $folder;
                }
                publish_verified_component($capture, $job['transfer'], $job['manifest_transfer'], $site, time());
            } else {
                $evidence = [
                    'kind' => 'site_snapshot', 'site' => $site,
                    'run_type' => isset($job['daily_date']) ? 'daily' : 'manual',
                    'archive_sha256' => $job['transfer']['sha256'], 'offsite_verified_at' => $job['manifest_transfer']['verified_at'],
                    'manifest_sha256' => $job['manifest_sha256'], 'archive_path' => $job['transfer']['path'],
                    'manifest_path' => $job['manifest_transfer']['path'],
                ];
                if (isset($job['folder'])) {
                    $evidence['folder'] = $folder;
                }
                $size = verified_job_archive_size($job, $evidence);
                if ($size !== null) {
                    $evidence['archive_size_bytes'] = $size;
                }
                $pins = backup_dropbox_object_pins(['archive' => $job['transfer'], 'manifest' => $job['manifest_transfer']]);
                if ($pins !== []) {
                    $evidence['dropbox_objects'] = $pins;
                }
                $previous = get_option(EVIDENCE_OPTION, []);
                $previous_verified = verified_evidence($previous, $site, time());
                $records = isset($previous_verified['manifest_path']) ? [$previous_verified, $evidence] : [$evidence];
                if (($previous_verified['archive_path'] ?? null) === $evidence['archive_path'] && isset($previous_verified['restore'])) {
                    $evidence['restore'] = $previous_verified['restore'];
                }
                remember_verified_backups($records, $site, time());
                if ($previous !== $evidence && !update_option(EVIDENCE_OPTION, $evidence, false)) {
                    throw new \RuntimeException('The Dropbox copy verified, but its Overview record could not be saved.');
                }
            }
            $job['cleanup_pending'] = !clear_verified_backup_staging($directory);
            $job['phase'] = 'verified';
            break;
        case 'verified':
            return $job;
        default:
            throw new \RuntimeException('A capture step ended before it could confirm completion. This step will not be repeated.');
    }
    unset($job['dropbox_refresh_failed']);
    write_backup_job($root, $job);
    if ($job['phase'] === 'verified' && $component === null && !isset($job['daily_date']) && empty($job['cleanup_pending'])) {
        queue_backup_retention_event();
    }
    return $job;
}

function backup_job_upload_uncertain(array $job): bool {
    return in_array($job['transfer']['phase'] ?? '', ['starting', 'appending'], true)
        || in_array($job['manifest_transfer']['phase'] ?? '', ['starting', 'appending'], true);
}

function backup_job_readback_needs_attention(array $job, ?int $since = null): bool {
    foreach (['transfer', 'manifest_transfer'] as $key) {
        $transfer = $job[$key] ?? [];
        $failed_at = $transfer['confirmation_failed_at'] ?? null;
        if (($transfer['confirmation_failed'] ?? false) === true && in_array($transfer['phase'] ?? '', ['committing', 'verify'], true)
            && ($since === null || (is_int($failed_at) && $failed_at >= $since))) {
            return true;
        }
    }
    return false;
}

/** Retry only saved steps that cannot repeat an unconfirmed upload. */
function backup_job_can_retry_safely(array $job): bool {
    $resumable = ['database', 'files', 'replay_inventory', 'incremental_files', 'plan_transfer',
        'folder', 'transfer', 'plan_manifest', 'manifest', 'publish'];
    return !backup_job_upload_uncertain($job)
        && (in_array($job['phase'] ?? '', $resumable, true)
            || (restartable_backup_capture($job) && !isset($job['automatic_capture_retry'])));
}

/** An occupied destination needs attention now. Wait a day for an overdue temporary failure. */
function scheduled_dropbox_notice(array $job, array $plan, int $now): string {
    if (!backup_job_can_retry_safely($job)) {
        return '';
    }
    if (($job['dropbox_destination_is_file'] ?? false) === true) {
        return 'Dropbox found a file at the backup destination. Open Overview to see how to continue the saved backup.';
    }
    $reason = '';
    if (($job['dropbox_refresh_failed'] ?? false) === true) {
        $reason = 'The last attempt could not refresh the Dropbox connection.';
    } elseif (($job['dropbox_destination_check_failed'] ?? false) === true) {
        $reason = 'The last attempt could not confirm the Dropbox backup folder.';
    } elseif (backup_job_readback_needs_attention($job)) {
        $reason = 'Dropbox has yet to confirm a matching uploaded backup file.';
    }
    if ($reason === '') {
        return '';
    }
    $due = $job['scheduled_due_at'] ?? null;
    $day = $job['daily_date'] ?? '';
    if (!is_int($due) && valid_parked_backup_day($day)) {
        $timezone = wp_timezone();
        $midnight = new \DateTimeImmutable($day, $timezone);
        $due = backup_schedule_occurrence(['frequency' => 'daily', 'time' => daily_backup_settings($plan)['time']],
            $timezone, $midnight->getTimestamp());
    }
    return is_int($due) && $due > 0 && $due <= $now - DAY_IN_SECONDS
        ? 'A scheduled backup is at least a day late. ' . $reason : '';
}

/** Use WordPress mail once per scheduled job, after persisting the attempt. */
function notify_paused_scheduled_backup(string $root, array $plan): void {
    if (($plan['pause_email'] ?? false) !== true) {
        return;
    }
    $recipient = backup_mail_recipient($plan);
    if (!is_string($recipient) || !is_email($recipient)) {
        return;
    }
    try {
        $message = with_backup_job_lock($root, static function () use ($root, $plan): string {
            $job = read_backup_job($root);
            if ((!isset($job['daily_date']) && !isset($job['scheduled_due_at'])) || !empty($job['pause_email_attempted'])) {
                return '';
            }
            if (backup_job_upload_uncertain($job)) {
                $message = 'Dropbox did not confirm an upload step.';
            } elseif (isset($job['automatic_capture_retry']) && restartable_backup_capture($job)) {
                $message = 'The capture is still incomplete after its automatic retry.';
                $reason = backup_capture_problem_message($job['capture_problem'] ?? null);
                if ($reason !== '') {
                    $message .= ' ' . $reason;
                }
            } else {
                $message = scheduled_dropbox_notice($job, $plan, time());
                if ($message === '') {
                    return '';
                }
            }
            $job['pause_email_attempted'] = true;
            write_backup_job($root, $job);
            return $message;
        });
    } catch (\RuntimeException $error) {
        return;
    }
    if ($message !== '') {
        wp_mail($recipient, 'Website Backup needs review', $message . "\n\n" . admin_url('admin.php?page=pebkac-backup&tab=overview'));
    }
}

function backup_job_public_state(array $job): array {
    $phase = $job['phase'] ?? '';
    $messages = [
        '' => 'No pilot backup has started.', 'database' => 'Preparing the database export.',
        'files' => isset($job['component']) && $job['component'] !== 'database'
            ? 'Preparing the component archive.'
            : 'The database export is ready. Capturing WordPress files next.',
        'replay_inventory' => 'Reading the verified backup history from Dropbox.',
        'incremental_files' => 'Checking what changed in this component.',
        'plan_transfer' => 'The ZIP is ready. Checking its contents before transfer.',
        'folder' => 'Preparing the private Dropbox app folder.', 'transfer' => 'Sending the backup to Dropbox and verifying it.',
        'plan_manifest' => 'Dropbox verified the ZIP. Preparing its restore manifest.',
        'manifest' => 'Sending the restore manifest to Dropbox and verifying it.',
        'publish' => 'Dropbox verified the ZIP and its manifest. Updating Overview.', 'verified' => 'Dropbox backup verified.',
    ];
    $uncertain = backup_job_upload_uncertain($job);
    $restartable = restartable_backup_capture($job);
    $message = $messages[$phase] ?? 'The last capture step did not confirm completion.';
    if ($phase === 'files' && ($job['replacement_component_copy'] ?? false) === true) {
        $message = 'Preparing a full component copy because Dropbox reported a missing or changed recovery file.';
    }
    if (backup_job_needs_connection_check($job)) {
        $message = 'Checking the Dropbox connection and destination before preparing the backup.';
        if (($job['dropbox_destination_check_failed'] ?? false) === true) {
            $message = 'Dropbox could not confirm the selected backup folder. The saved backup can check again.';
        } elseif (($job['dropbox_destination_is_file'] ?? false) === true) {
            $message = 'Part of the Dropbox destination is a file. Choose a folder in Setup.';
        }
    } elseif ($phase === 'folder' && ($job['dropbox_destination_is_file'] ?? false) === true) {
        $message = 'The last Dropbox check found a file at the backup destination. Move that file in Dropbox to continue the saved backup.';
    }
    if ($uncertain) {
        $message = 'Backup paused because Dropbox did not confirm an upload step. The saved backup is waiting for review.';
    } elseif ($restartable) {
        if (isset($job['automatic_capture_retry']) && (isset($job['daily_date']) || isset($job['component']))) {
            $message = 'This scheduled backup used its automatic retry and is still incomplete. The capture stopped before anything was sent to Dropbox.';
        } else {
            $message = isset($job['daily_date']) || isset($job['component'])
                ? 'Capture stopped before anything was sent to Dropbox. Restart capture to continue the scheduled backup.'
                : 'Backup capture stopped before anything was sent to Dropbox. You can start a new backup.';
        }
        $reason = backup_capture_problem_message($job['capture_problem'] ?? null);
        if ($reason !== '') {
            $message .= ' ' . $reason;
        }
    } elseif (in_array($job['transfer']['phase'] ?? '', ['committing', 'verify'], true)
        || in_array($job['manifest_transfer']['phase'] ?? '', ['committing', 'verify'], true)) {
        $message = backup_job_readback_needs_attention($job)
            ? 'Dropbox has no matching copy at the recorded backup path. WordPress can check that path again.'
            : 'Checking Dropbox to confirm the last upload.';
    } elseif ($phase === 'folder' && ($job['folder_progress']['phase'] ?? null) === 'verify') {
        $message = 'Checking Dropbox to confirm the destination folder is ready.';
    } elseif (!empty($job['cleanup_pending'])) {
        $message = 'Dropbox backup verified. Some temporary files could not be cleared.';
    }
    if (!$uncertain && $phase !== 'verified' && ($job['dropbox_refresh_failed'] ?? false) === true) {
        $message = 'The last attempt could not refresh the Dropbox connection. ' . $message;
    }
    return [
        'started' => $phase !== '', 'finished' => $phase === 'verified', 'restartable' => $restartable,
        'uncertain' => $uncertain, 'message' => $message,
    ];
}

/** Read the job and check for an in-flight step without creating or modifying the lock. */
function read_backup_job_progress(string $root): array {
    $path = $root . '/job.lock';
    $lock = !is_link($path) && is_file($path) ? @fopen($path, 'rb') : false;
    try {
        $running = $lock !== false && !flock($lock, LOCK_SH | LOCK_NB);
        $job = read_backup_job($root);
        return [$job, $running, $job === [] ? null : backup_job_saved_time($root, time())];
    } finally {
        if ($lock !== false) {
            fclose($lock);
        }
    }
}

function backup_job_saved_time(string $root, int $now): ?int {
    $record = $root . '/job.json';
    clearstatcache(true, $record);
    $modified = @filemtime($record);
    return is_int($modified) && $modified > 0 && $modified <= $now ? $modified : null;
}

function can_start_manual_backup_after(array $job): bool {
    if (($job['phase'] ?? '') !== 'verified' || !empty($job['cleanup_pending'])) {
        return false;
    }
    if (isset($job['component'])) {
        $claim = get_option(SCHEDULED_BACKUP_JOB_OPTION, []);
        return ($claim['id'] ?? null) !== $job['id'];
    }
    $proof = verified_evidence(get_option(EVIDENCE_OPTION, []), home_url(), time());
    return isset($proof['manifest_path']);
}

/** Select the job to advance while the caller holds its lock. */
function select_manual_backup_job(string $root, array $job, string $new_after, bool $restart, ?string $expected_job = null): array {
    if ($expected_job !== null && ($job['id'] ?? '') !== $expected_job) {
        throw new \RuntimeException('The backup on Overview changed. Refresh the page to see the current backup.');
    }
    if ($new_after !== '' && (($job['id'] ?? '') !== $new_after || !can_start_manual_backup_after($job))) {
        throw new \RuntimeException('The backup status changed. Refresh Overview before starting a new backup.');
    }
    if ($job === [] || $new_after !== '') {
        preserve_completed_backup_size($job, home_url(), time());
        $job = ['id' => bin2hex(random_bytes(16)), 'phase' => 'database'];
        $folder = backup_dropbox_folder(get_plan());
        if ($folder !== PILOT_DROPBOX_FOLDER) {
            $job['folder'] = $folder;
        }
        write_backup_job($root, $job);
    } elseif ($restart) {
        $job = restart_backup_capture($root, $job);
    }
    return $job;
}

const MANUAL_BACKUP_HOOK = 'pebkac_backup_manual_step';

function manual_backup_can_continue(array $job): bool {
    return isset($job['id']) && !isset($job['daily_date']) && !isset($job['component'])
        && !restartable_backup_capture($job) && backup_job_can_retry_safely($job);
}

function queue_manual_backup_event(string $id, int $delay = 60): void {
    if (wp_next_scheduled(MANUAL_BACKUP_HOOK, [$id]) === false) {
        wp_schedule_single_event(time() + $delay, MANUAL_BACKUP_HOOK, [$id]);
    }
}

function manual_backup_next_attempt(array $job): ?int {
    $at = manual_backup_can_continue($job) ? wp_next_scheduled(MANUAL_BACKUP_HOOK, [$job['id']]) : false;
    return is_int($at) && $at > 0 ? $at : null;
}

/** Continue only the manual backup started by the administrator, even after its browser closes. */
function run_manual_backup_event(string $id): void {
    if (!preg_match('/^[0-9a-f]{32}$/D', $id) || !backup_capture_supported() || dropbox_saved_refresh_token(dropbox_app_key()) === '') {
        return;
    }
    try {
        $root = backup_job_root();
        with_backup_job_lock($root, static function () use ($root, $id): void {
            $job = read_backup_job($root);
            if (($job['id'] ?? null) !== $id || !manual_backup_can_continue($job)) {
                return;
            }
            queue_manual_backup_event($id, 900);
            $advanced = false;
            try {
                $job = advance_backup_job($root, $job);
                $advanced = true;
            } catch (\RuntimeException $error) {
                $job = read_backup_job($root);
            }
            if (($job['id'] ?? null) !== $id || !manual_backup_can_continue($job)) {
                wp_clear_scheduled_hook(MANUAL_BACKUP_HOOK, [$id]);
            } elseif ($advanced) {
                bring_forward_backup_event(MANUAL_BACKUP_HOOK, [$id], time() + 60);
            }
        });
    } catch (BackupJobLockBusy $busy) {
        queue_manual_backup_event($id);
    } catch (\RuntimeException $unavailable) {
        // The saved backup can be resumed from Overview after staging is available.
    }
}

add_action(MANUAL_BACKUP_HOOK, __NAMESPACE__ . '\\run_manual_backup_event');

function render_backup_job(): void {
    if (!is_ssl() || dropbox_app_key() === '') {
        return;
    }
    try {
        $root = backup_job_root();
        $progress = read_backup_job_progress($root);
    } catch (\RuntimeException $error) {
        echo '<p>Private backup staging is unavailable. See Host readiness below.</p>';
        return;
    }
    if (dropbox_saved_refresh_token(dropbox_app_key()) === '') {
        if (($progress[0]['phase'] ?? null) === 'verified' && !empty($progress[0]['cleanup_pending'])) {
            render_backup_job_progress(...$progress);
        }
        render_parked_daily_backup($root, home_url(), false);
        return;
    }
    render_backup_job_progress(...$progress);
    render_parked_daily_backup($root, home_url());
}

/** Select the WordPress callback for a resumable scheduled job. */
function scheduled_backup_hook_for_job(array $job): ?string {
    if (!backup_job_can_retry_safely($job)) {
        return null;
    }
    $plan = get_plan();
    if (daily_backup_can_continue($job) && daily_backup_settings($plan)['enabled']) {
        return DAILY_BACKUP_HOOK;
    }
    return isset($job['component']) && component_backup_worker_has_job($plan, $job) ? COMPONENT_BACKUP_HOOK : null;
}

function scheduled_backup_next_attempt(array $job): ?int {
    $hook = scheduled_backup_hook_for_job($job);
    $at = $hook === null ? false : wp_next_scheduled($hook);
    return is_int($at) && $at > 0 ? $at : null;
}

/** Check again soon after authorization for the same job that could not refresh Dropbox. */
function queue_backup_after_dropbox_authorization(): void {
    queue_component_readback_after_dropbox_authorization();
    queue_full_readback_after_dropbox_authorization();
    queue_retention_after_dropbox_authorization();
    try {
        [$job, $running] = read_backup_job_progress(backup_job_root());
    } catch (\RuntimeException $error) {
        return;
    }
    if ($running || ($job['dropbox_refresh_failed'] ?? false) !== true) {
        return;
    }
    $manual = manual_backup_can_continue($job);
    $hook = $manual ? MANUAL_BACKUP_HOOK : scheduled_backup_hook_for_job($job);
    $args = $manual ? [$job['id']] : [];
    if ($hook === null) {
        return;
    }
    bring_forward_backup_event($hook, $args, time() + 60);
}

function bring_forward_backup_event(string $hook, array $args, int $at): void {
    $previous = wp_next_scheduled($hook, $args);
    if (is_int($previous) && ($previous <= $at || wp_unschedule_event($previous, $hook, $args) !== true)) {
        return;
    }
    if (wp_schedule_single_event($at, $hook, $args) !== true && is_int($previous) && wp_next_scheduled($hook, $args) === false) {
        wp_schedule_single_event($previous, $hook, $args);
    }
}

function render_backup_job_progress(array $job, bool $running, ?int $saved_at = null): void {
    $state = backup_job_public_state($job);
    $heading = isset($job['daily_date']) ? 'Daily full backup' : 'Manual full backup';
    $component = COMPONENTS[$job['component'] ?? ''] ?? null;
    if ($component !== null) {
        $heading = 'Scheduled backup for ' . $component;
    }
    $scheduled = isset($job['daily_date']) || $component !== null;
    $retry_spent = $scheduled && $state['restartable'] && isset($job['automatic_capture_retry']);
    $capture_needs_attention = $retry_spent || (!$scheduled && $state['restartable']);
    $readback_needs_attention = backup_job_readback_needs_attention($job);
    $cleanup_pending = $state['finished'] && !empty($job['cleanup_pending']);
    $show_warning = !$running && ($state['uncertain'] || $capture_needs_attention || $readback_needs_attention || $cleanup_pending);
    if ($state['uncertain']) {
        if ($running) {
            $state['message'] = 'WordPress is waiting for Dropbox to confirm the upload step.';
        } else {
            $heading .= ' paused';
        }
    } elseif ($running && $state['restartable']) {
        $state['message'] = 'WordPress is preparing the backup on this site.';
    } elseif ($capture_needs_attention || (!$running && $readback_needs_attention)) {
        $heading .= ' needs attention';
    } elseif ($cleanup_pending && !$running) {
        $heading .= ' verified. Temporary cleanup pending';
    }
    $style = $show_warning ? 'notice-warning' : 'notice-info';
    $restart_label = $scheduled ? 'Restart capture' : 'Start a new backup';
    $new_after = !$running && can_start_manual_backup_after($job) ? $job['id'] : '';
    $can_act = !$running && !$state['uncertain'] && (!$state['finished'] || $new_after !== '');
    $show_saved_at = $state['started'] && !$state['finished'] && $saved_at !== null;
    $next_attempt = $running ? null : ($scheduled ? scheduled_backup_next_attempt($job) : manual_backup_next_attempt($job));
    $show_details = $show_warning || $show_saved_at || $next_attempt !== null;
    ?>
    <section id="pebkac-backup-run" class="notice <?php echo esc_attr($style); ?> inline" data-nonce="<?php echo esc_attr(wp_create_nonce('pebkac_backup_step')); ?>" data-job-id="<?php echo esc_attr($job['id'] ?? ''); ?>">
        <h2><?php echo esc_html($heading); ?></h2>
        <?php if ($show_warning) : ?><details><summary>Show details</summary><?php endif; ?>
        <p aria-live="polite" class="pebkac-backup-progress"><?php echo esc_html($state['message']); ?></p>
        <?php if ($show_details && !$show_warning) : ?><details><summary>Show details</summary><?php endif; ?>
        <?php if ($show_saved_at) : ?>
            <p><?php echo esc_html('Backup progress was last saved on ' . wp_date('M j, Y H:i T', $saved_at) . '.'); ?></p>
        <?php endif; ?>
        <?php if ($next_attempt !== null) : ?>
            <p><?php echo esc_html('WordPress queued the next attempt for ' . wp_date('M j, Y H:i T', $next_attempt) . '.'); ?></p>
            <?php if (!$scheduled) : ?><p>You can close this page while WordPress continues the backup.</p><?php endif; ?>
        <?php endif; ?>
        <?php if ($show_details) : ?></details><?php endif; ?>
        <?php if (!$running && $cleanup_pending) : ?>
            <p><button type="button" class="button" data-clear-temp="<?php echo esc_attr($job['id']); ?>">Retry temporary cleanup</button></p>
        <?php elseif ($can_act && backup_capture_supported()) : ?>
            <p><button type="button" class="button button-primary" data-restart="<?php echo $state['restartable'] ? '1' : '0'; ?>"<?php if ($new_after !== '') : ?> data-new-after="<?php echo esc_attr($new_after); ?>"<?php endif; ?>><?php echo $state['restartable'] ? $restart_label : ($state['started'] && $new_after === '' ? 'Resume backup' : 'Back up now'); ?></button></p>
        <?php elseif ($can_act) : ?><p>This host does not support the ZIP time limit required by the pilot.</p>
        <?php endif; ?>
    </section>
    <?php
}

add_action('admin_enqueue_scripts', static function ($page) {
    if ($page === 'toplevel_page_pebkac-backup') {
        wp_enqueue_script('pebkac-backup-job', plugins_url('backup-job.js', __FILE__), [], VERSION, true);
    }
});

add_action('wp_ajax_pebkac_backup_step', static function () {
    if (($_SERVER['REQUEST_METHOD'] ?? '') !== 'POST' || !is_ssl() || !current_user_can('manage_options')) {
        wp_send_json_error('An administrator must run this backup over HTTPS.', 403);
    }
    check_ajax_referer('pebkac_backup_step');
    try {
        $new_after = $_POST['new_after'] ?? '';
        $clear_temp = $_POST['clear_temp'] ?? '';
        $expected_job = $_POST['expected_job'] ?? null;
        foreach ([$new_after, $clear_temp, $expected_job] as $id) {
            if (!is_string($id) || ($id !== '' && !preg_match('/^[0-9a-f]{32}$/D', $id))) {
                throw new \RuntimeException('Refresh Overview before continuing the backup.');
            }
        }
        if ($clear_temp === '' && dropbox_saved_refresh_token(dropbox_app_key()) === '') {
            throw new \RuntimeException('Connect Dropbox in Setup before starting a backup.');
        }
        $root = backup_job_root(true);
        $job = with_backup_job_lock($root, static function () use ($root, $new_after, $clear_temp, $expected_job): array {
            $saved = read_backup_job($root);
            if ($clear_temp !== '') {
                $job = retry_verified_backup_staging($root, $saved, $clear_temp);
                if (!isset($job['component'])) {
                    queue_backup_retention_event();
                } else {
                    queue_waiting_backup_retention_event();
                }
                return $job;
            }
            $job = select_manual_backup_job($root, $saved, $new_after, ($_POST['restart'] ?? '') === '1', $expected_job);
            if (manual_backup_can_continue($job)) {
                queue_manual_backup_event($job['id']);
            }
            return advance_backup_job($root, $job);
        });
        wp_send_json_success(backup_job_public_state($job) + ['job_id' => $job['id'],
            'background_queued' => manual_backup_next_attempt($job) !== null]);
    } catch (\RuntimeException $error) {
        wp_send_json_error($error->getMessage(), 409);
    } catch (\Throwable $error) {
        wp_send_json_error('The backup step stopped unexpectedly. Its progress record was preserved.', 500);
    }
});
