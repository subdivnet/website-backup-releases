<?php

namespace PEBKAC404\Backup;

final class BackupCaptureProblem extends \RuntimeException {
    const TEMPORARY_SPACE = 1;
    const FILE_LIMIT = 2;
    const FILE_TIME = 3;
    const DATABASE_LIMIT = 4;
    const DATABASE_KEY = 5;
    const CONTENT_LAYOUT = 6;
    const DATABASE_ROW_LIMIT = 7;
    const DATABASE_TABLE_LIMIT = 8;
}

function backup_capture_problem_message($code): string {
    $messages = [
        BackupCaptureProblem::TEMPORARY_SPACE => 'WordPress needs more private temporary disk space for this backup.',
        BackupCaptureProblem::FILE_LIMIT => 'The source files exceeded this backup’s size or file count limit.',
        BackupCaptureProblem::FILE_TIME => 'Capturing the files reached the backup’s time limit.',
        BackupCaptureProblem::DATABASE_LIMIT => 'The database export reached its time or size limit.',
        BackupCaptureProblem::DATABASE_KEY => 'A database table has no stable key for a consistent backup.',
        BackupCaptureProblem::CONTENT_LAYOUT => 'This site’s WordPress content is in a custom folder.',
        BackupCaptureProblem::DATABASE_ROW_LIMIT => 'A database row is too large for the memory or size available to export it.',
        BackupCaptureProblem::DATABASE_TABLE_LIMIT => 'This site has more database tables than this version can export.',
    ];
    return is_int($code) ? ($messages[$code] ?? '') : '';
}
