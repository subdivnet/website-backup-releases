<?php

namespace PEBKAC404\Backup;

if (!defined('ABSPATH')) {
    exit;
}

require_once __DIR__ . '/snapshot-archive.php';
require_once __DIR__ . '/backup-incremental.php';

/** A site-bound path under a non-public PHP temporary directory. */
function wordpress_capture_directory(string $parent, string $site, string $id): string {
    if ($parent === '' || !preg_match('/^[0-9a-f]{32}$/D', $id)) {
        throw new \RuntimeException('Private backup staging is unavailable.');
    }
    return $parent . DIRECTORY_SEPARATOR . 'website-backup-' . substr(hash('sha256', $site), 0, 12) . '-' . $id;
}

function start_wordpress_capture(string $directory, $wpdb, float $seconds): void {
    $free = @disk_free_space(dirname($directory));
    if ($free === false || $free < SNAPSHOT_MIN_STAGING_BYTES) {
        throw new BackupCaptureProblem('Could not reserve private temporary backup space.', BackupCaptureProblem::TEMPORARY_SPACE);
    }
    if (!@mkdir($directory, 0700)) {
        throw new \RuntimeException('Could not reserve private temporary backup space.');
    }
    $path = $directory . '/database.sql';
    $stream = @fopen($path, 'xb');
    if ($stream === false) {
        throw new \RuntimeException('Could not reserve the database export.');
    }
    try {
        export_wordpress_database($wpdb, $stream, $seconds);
        if (!fflush($stream)) {
            throw new \RuntimeException('Could not flush the database export.');
        }
    } catch (\Throwable $error) {
        fclose($stream);
        @unlink($path);
        throw $error;
    }
    fclose($stream);
}

function wordpress_content_uses_standard_path(string $root, string $content): bool {
    $actual = realpath($content);
    return $actual !== false && $actual === realpath(rtrim($root, '/\\') . '/wp-content');
}

function require_wordpress_capture_directory(string $directory, string $root, string $content): void {
    if (!is_dir($directory) || is_link($directory) || (DIRECTORY_SEPARATOR === '/' && (fileperms($directory) & 0077) !== 0)) {
        throw new \RuntimeException('The pilot requires a private staging directory and standard WordPress content folders.');
    }
    if (!wordpress_content_uses_standard_path($root, $content)) {
        throw new BackupCaptureProblem('The pilot requires a private staging directory and standard WordPress content folders.', BackupCaptureProblem::CONTENT_LAYOUT);
    }
}

function finish_wordpress_capture(string $directory, string $root, string $content, float $deadline, ?string $component = null): array {
    require_wordpress_capture_directory($directory, $root, $content);
    $database = $directory . '/database.sql';
    $archive = $directory . '/backup.zip';
    $manifest = capture_snapshot($root, $database, $archive, $deadline, $component);
    save_wordpress_capture_manifest($archive, $manifest, $deadline);
    if (($component === null || $component === 'database') && !@unlink($database)) {
        throw new \RuntimeException('Could not clear the temporary database export.');
    }
    return $manifest;
}


/** Stage a delta from a verified file inventory without building a second full ZIP. */
function finish_wordpress_incremental_capture(string $directory, string $root, string $content, array $baseline, float $deadline): array {
    require_wordpress_capture_directory($directory, $root, $content);
    $archive = $directory . '/backup.zip';
    $sidecar = $directory . '/manifest.json';
    if (file_exists($sidecar) || is_link($sidecar) || !is_string($baseline['component'] ?? null)) {
        throw new \RuntimeException('Choose a fresh staging directory and a verified file component.');
    }
    $current = scan_incremental_file_inventory($root, $baseline['component'], $deadline);
    $delta = plan_incremental_file_backup($baseline, $current);
    $changed_bytes = array_sum(array_column($delta['changed'], 'size'));
    $free = @disk_free_space($directory);
    if ($free === false || $free < snapshot_staging_bytes($changed_bytes)) {
        throw new BackupCaptureProblem('Insufficient private staging space for the incremental backup.', BackupCaptureProblem::TEMPORARY_SPACE);
    }
    $manifest = package_incremental_file_backup($root, $baseline, $delta, $archive, $deadline);
    save_wordpress_capture_manifest($archive, $manifest, $deadline);
    return $manifest;
}

/** Reserve a new manifest and discard this capture's ZIP if its manifest cannot be saved. */
function save_wordpress_capture_manifest(string $archive, array $manifest, float $deadline): void {
    $sidecar = dirname($archive) . '/manifest.json';
    $stream = false;
    try {
        snapshot_deadline($deadline);
        $bytes = json_encode($manifest, JSON_UNESCAPED_SLASHES);
        if (!is_string($bytes) || strlen($bytes) > SNAPSHOT_MAX_MANIFEST_BYTES || ($stream = @fopen($sidecar, 'xb')) === false
            || fwrite($stream, $bytes) !== strlen($bytes) || !fflush($stream)) {
            throw new \RuntimeException('Could not save the capture manifest.');
        }
        fclose($stream);
    } catch (\Throwable $error) {
        if (is_resource($stream)) {
            fclose($stream);
            @unlink($sidecar);
        }
        @unlink($archive);
        throw $error;
    }
}
