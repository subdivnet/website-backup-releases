<?php

namespace PEBKAC404\Backup;

require_once __DIR__ . '/backup-fleet-relay.php';
require_once __DIR__ . '/dropbox-snapshot.php';

/** Read a revision on the fixed pilot path and refuse a response for a replacement revision. */
function download_private_fleet_bytes(string $site, string $revision, string $token, int $timeout): string {
    \PEBKAC404\Backup\validate_snapshot_token($token);
    $path = private_fleet_report_path($site);
    if (!\PEBKAC404\Backup\valid_dropbox_file_revision($revision)) {
        throw new \RuntimeException('The backup report revision is invalid.');
    }
    $response = wp_remote_post('https://content.dropboxapi.com/2/files/download', [
        'headers' => ['Authorization' => 'Bearer ' . $token, 'Dropbox-API-Arg' => wp_json_encode(['path' => $path])],
        'timeout' => $timeout, 'redirection' => 0, 'sslverify' => true, 'decompress' => false, 'limit_response_size' => FLEET_RELAY_MAX_BYTES + 1,
    ]);
    if (is_wp_error($response) || wp_remote_retrieve_response_code($response) !== 200) {
        throw new \RuntimeException('Dropbox did not provide the private backup report.');
    }
    $metadata = json_decode((string) wp_remote_retrieve_header($response, 'dropbox-api-result'), true);
    $bytes = wp_remote_retrieve_body($response);
    if (($metadata['rev'] ?? null) !== $revision || ($metadata['path_lower'] ?? null) !== strtolower($path)
        || strlen($bytes) > FLEET_RELAY_MAX_BYTES) {
        throw new \RuntimeException('Dropbox returned a different revision of the backup report.');
    }
    return $bytes;
}

/** Upload only a locally validated report and require the expected prior file revision. */
function write_private_fleet_bytes(string $site, string $bytes, ?string $revision, string $token, int $now, int $timeout): void {
    \PEBKAC404\Backup\validate_snapshot_token($token);
    $path = private_fleet_report_path($site);
    if (strlen($bytes) > FLEET_RELAY_MAX_BYTES || ($revision !== null && !\PEBKAC404\Backup\valid_dropbox_file_revision($revision))) {
        throw new \RuntimeException('The backup report or expected Dropbox revision is invalid.');
    }
    decode_private_fleet_report($site, $bytes, $now, true);
    $mode = $revision === null ? 'add' : ['.tag' => 'update', 'update' => $revision];
    $response = wp_remote_post('https://content.dropboxapi.com/2/files/upload', [
        'headers' => ['Authorization' => 'Bearer ' . $token, 'Content-Type' => 'application/octet-stream',
            'Dropbox-API-Arg' => wp_json_encode(['path' => $path, 'mode' => $mode, 'autorename' => false, 'strict_conflict' => true, 'mute' => true])],
        'body' => $bytes, 'timeout' => $timeout, 'redirection' => 0, 'sslverify' => true, 'limit_response_size' => 4096,
    ]);
    if (is_wp_error($response) || wp_remote_retrieve_response_code($response) !== 200) {
        throw new \RuntimeException('Dropbox did not confirm the backup report write. Its saved intent can be checked.');
    }
}

function wordpress_fleet_peer_metadata(string $peer, string $token, int $timeout): ?array {
    \PEBKAC404\Backup\validate_snapshot_token($token);
    $metadata = \PEBKAC404\Backup\fetch_dropbox_metadata(private_fleet_report_path($peer), $token, $timeout);
    if ($metadata === null) {
        return null;
    }
    if (($metadata['.tag'] ?? null) !== 'file' || !is_int($metadata['size'] ?? null) || $metadata['size'] < 1
        || $metadata['size'] > FLEET_RELAY_MAX_BYTES || !\PEBKAC404\Backup\valid_dropbox_file_revision($metadata['rev'] ?? null)) {
        throw new \RuntimeException('Dropbox did not confirm a bounded peer backup report.');
    }
    return array_intersect_key($metadata, array_flip(['.tag', 'size', 'content_hash', 'rev']));
}

/** Continue a saved exchange using the same Dropbox connection. Caller holds the private report lock. */
function advance_wordpress_fleet_relay(
    string $site, array $status, array $state, string $connection_fingerprint, string $token, int $now, callable $save, int $timeout = 8
): array {
    private_fleet_report_path($site);
    if (!preg_match('/^[a-f0-9]{64}$/D', $connection_fingerprint)
        || ($state !== [] && (($state['site'] ?? null) !== $site || ($state['connection'] ?? null) !== $connection_fingerprint))) {
        throw new \RuntimeException('The private backup report exchange belongs to a different Dropbox connection.');
    }
    if ($state === []) {
        $state = ['phase' => 'folder', 'site' => $site, 'connection' => $connection_fingerprint,
            'observed_at' => $now, 'report' => describe_private_fleet_report($site, $status, $now)];
    }
    $phase = $state['phase'] ?? null;
    if ($phase === 'folder') {
        $state['folder'] = \PEBKAC404\Backup\advance_backup_dropbox_folder(FLEET_RELAY_FOLDER, $state['folder'] ?? [], $token,
            static function (array $folder) use ($state, $save): void {
                $state['folder'] = $folder;
                $save($state);
            }, $timeout);
        if ($state['folder']['phase'] === 'verified') {
            $state['phase'] = 'publication';
            unset($state['folder']);
        }
    } elseif ($phase === 'publication') {
        $state['publication'] = advance_private_fleet_publication($site, $state['report'], $state['publication'] ?? [], $now,
            static function (string $path) use ($token, $timeout): ?array { return \PEBKAC404\Backup\fetch_dropbox_metadata($path, $token, $timeout); },
            static function (string $path, string $revision) use ($site, $token, $timeout): string { return download_private_fleet_bytes($site, $revision, $token, $timeout); },
            static function (string $path, string $bytes, ?string $revision) use ($site, $token, $now, $timeout): void {
                write_private_fleet_bytes($site, $bytes, $revision, $token, $now, $timeout);
            },
            static function (array $publication) use ($state, $save): void {
                $state['publication'] = $publication;
                $save($state);
            });
        if ($state['publication']['phase'] === 'verified') {
            $state['phase'] = 'peer_metadata';
            unset($state['report']);
        }
    } elseif ($phase === 'peer_metadata') {
        $peer = $site === 'https://securitylab.subdiv.net' ? 'https://pebkac404.com' : 'https://securitylab.subdiv.net';
        $state['peer'] = $peer;
        $metadata = wordpress_fleet_peer_metadata($peer, $token, $timeout);
        if ($metadata === null) {
            $state['peer_report'] = null;
            $state['phase'] = 'complete';
        } else {
            $state['peer_metadata'] = $metadata;
            $state['phase'] = 'peer_download';
        }
    } elseif ($phase === 'peer_download') {
        $peer = $site === 'https://securitylab.subdiv.net' ? 'https://pebkac404.com' : 'https://securitylab.subdiv.net';
        $metadata = $state['peer_metadata'] ?? null;
        if (!is_array($metadata) || !\PEBKAC404\Backup\valid_dropbox_file_revision($metadata['rev'] ?? null)) {
            throw new \RuntimeException('The saved peer report revision is invalid.');
        }
        try {
            $bytes = download_private_fleet_bytes($peer, $metadata['rev'], $token, $timeout);
            $state['peer_report'] = read_private_fleet_report($peer, $bytes, $metadata, $now);
        } catch (\RuntimeException | \JsonException $error) {
            $state['phase'] = 'peer_metadata';
            unset($state['peer_metadata']);
            $save($state);
            throw $error;
        }
        $state['phase'] = 'complete';
        unset($state['peer_metadata']);
    } elseif ($phase === 'complete') {
        return $state;
    } else {
        throw new \RuntimeException('The private backup report exchange has an invalid saved step.');
    }
    $save($state);
    return $state;
}
