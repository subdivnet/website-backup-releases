<?php

namespace PEBKAC404\Backup;

/** Plan retention only from complete, site-bound recovery sets. Never deletes Dropbox files. */
function backup_retention_plan(array $records, string $site, \DateTimeZone $timezone, int $now, ?string $current_path = null, array $restore_test = []): array {
    $sets = [];
    foreach ($records as $record) {
        $set = verified_evidence($record, $site, $now);
        if (!isset($set['manifest_path']) || isset($sets[$set['archive_path']])) {
            throw new \RuntimeException('The backup history could not be verified for retention.');
        }
        $sets[$set['archive_path']] = $set;
    }
    uasort($sets, static function (array $left, array $right) use ($current_path): int {
        return compare_backup_retention_sets($left, $right, $current_path);
    });
    $protected = null;
    foreach ($sets as $path => $set) {
        if (isset($set['restore']) && ($protected === null || $set['restore']['verified_at'] > $sets[$protected]['restore']['verified_at'])) {
            $protected = $path;
        }
    }
    $kept = retention_calendar_paths($sets, $timezone);
    if ($protected !== null) {
        $kept[] = $protected;
    }
    if ($current_path !== null && isset($sets[$current_path])) {
        $kept[] = $current_path;
    }
    $pending = pending_full_restore_retention_path($sets, $site, $now, $restore_test);
    if ($pending !== null) {
        $kept[] = $pending;
    }
    return [
        'keep' => array_intersect_key($sets, array_flip($kept)),
        'candidates' => array_diff_key($sets, array_flip($kept)),
    ];
}

/** Keep a queued test's exact pair while its offline PC is allowed to pick it up. */
function pending_full_restore_retention_path(array $sets, string $site, int $now, array $state): ?string {
    $request = $state['request'] ?? [];
    $backup = $request['backup'] ?? [];
    if (!in_array($state['phase'] ?? null, ['folder', 'publish', 'request_check', 'waiting'], true)
        || ($request['version'] ?? null) !== 1 || ($request['site'] ?? null) !== $site
        || !is_string($request['id'] ?? null) || !preg_match('/^[a-f0-9]{32}$/D', $request['id'])
        || !is_int($request['requested_at'] ?? null) || $request['requested_at'] > $now || $request['requested_at'] < $now - 86400
        || ($backup['site'] ?? null) !== $site || !is_string($backup['archive_path'] ?? null)) {
        return null;
    }
    $saved = $sets[$backup['archive_path']] ?? [];
    foreach (['archive_path', 'manifest_path', 'archive_sha256', 'manifest_sha256', 'archive_size_bytes', 'offsite_verified_at'] as $field) {
        if (!isset($saved[$field]) || ($backup[$field] ?? null) !== $saved[$field]) { return null; }
    }
    return $saved['archive_path'];
}

function pending_full_restore_retention_state(): array {
    $state = function_exists('get_option') ? get_option('pebkac_backup_restore_test', []) : [];
    return is_array($state) ? $state : [];
}

function compare_backup_retention_sets(array $left, array $right, ?string $current_path = null): int {
    return $right['offsite_verified_at'] <=> $left['offsite_verified_at']
        ?: (($right['archive_path'] === $current_path) <=> ($left['archive_path'] === $current_path))
        ?: strcmp($left['archive_path'], $right['archive_path']);
}

/** Keep seven daily points and four older weekly points from newest-first evidence. */
function retention_calendar_paths(array $sets, \DateTimeZone $timezone): array {
    $daily = [];
    $weekly = [];
    foreach ($sets as $path => $set) {
        $local = (new \DateTimeImmutable('@' . $set['offsite_verified_at']))->setTimezone($timezone);
        $day = $local->format('Y-m-d');
        $week = $local->format('o-W');
        if (count($daily) < 7 || isset($daily[$day])) {
            $daily[$day] = $daily[$day] ?? $path;
        } elseif (count($weekly) < 4 || isset($weekly[$week])) {
            $weekly[$week] = $weekly[$week] ?? $path;
        }
    }
    return array_merge(array_values($daily), array_values($weekly));
}

/** Pin one most recent checked restore per component, including an earlier selected point. */
function component_restore_retention_checks(array $history, string $site, int $now): array {
    $current = get_option(COMPONENT_RESTORE_OPTION, []);
    $earlier = get_option(COMPONENT_EARLIER_RESTORE_OPTION, []);
    if (!is_array($current) || !is_array($earlier)) {
        throw new \RuntimeException('Component restore checks could not be read.');
    }
    foreach ($earlier as $component => $check) {
        $path = $check['archive_path'] ?? null;
        $at = $check['verified_at'] ?? null;
        $record = is_string($path) ? ($history['records'][$path] ?? []) : [];
        if (($check['site'] ?? null) === $site && ($check['method'] ?? null) === 'isolated_component_staging'
            && ($record['component'] ?? null) === $component
            && is_int($at) && $at >= ($record['offsite_verified_at'] ?? PHP_INT_MAX) && $at <= $now
            && $at > ($current[$component]['verified_at'] ?? 0)) {
            $current[$component] = $check;
        }
    }
    return $current;
}

/** Keep calendar points, current heads, recorded restore checks and every required ancestor. */
function component_backup_retention_plan(array $history, array $restore_checks, string $site, \DateTimeZone $timezone, int $now): array {
    if (!is_array($history['records'] ?? null) || !is_array($history['latest'] ?? null)) {
        throw new \RuntimeException('The verified component history could not be read.');
    }
    $groups = [];
    foreach ($history['records'] as $path => $record) {
        $component = $record['component'] ?? null;
        if (!is_array($record) || ($record['archive_path'] ?? null) !== $path || !is_string($component) || !isset(COMPONENTS[$component])) {
            throw new \RuntimeException('The component history could not be verified for retention.');
        }
        require_verified_component_record($site, $component, $record, $now);
        $groups[$component][$path] = $record;
    }
    if (array_diff_key($history['latest'], $groups) !== [] || array_diff_key($restore_checks, $groups) !== []) {
        throw new \RuntimeException('A protected component backup is missing from history.');
    }
    $kept = [];
    foreach ($groups as $component => $sets) {
        $latest = $history['latest'][$component] ?? null;
        if (!is_string($latest) || !isset($sets[$latest])) {
            throw new \RuntimeException('The latest verified component backup is missing from history.');
        }
        uasort($sets, __NAMESPACE__ . '\\compare_backup_retention_sets');
        $kept = array_merge($kept, retention_calendar_paths($sets, $timezone), [$latest]);
        if (isset($restore_checks[$component])) {
            $check = $restore_checks[$component];
            $tested = $check['archive_path'] ?? null;
            if (($check['site'] ?? null) !== $site || !is_string($tested) || !isset($sets[$tested])) {
                throw new \RuntimeException('The most recent component restore check could not be matched to its backup.');
            }
            $kept[] = $tested;
        }
    }
    return plan_component_archive_retention(array_values($history['records']), $kept, $site);
}

/** Pin one cleanup candidate and the complete current recovery chain for that component. */
function plan_component_cleanup_preflight(array $history, array $restore_checks, string $site, \DateTimeZone $timezone, int $now): ?array {
    $retention = component_backup_retention_plan($history, $restore_checks, $site, $timezone, $now);
    return pin_component_cleanup_candidate($retention, $history, $site, $now);
}

function pin_component_cleanup_candidate(array $retention, array $history, string $site, int $now): ?array {
    $candidate = reset($retention['candidates']);
    if ($candidate === false) {
        return null;
    }
    $chain = component_recovery_chain($site, $candidate['component'], $history, $now);
    $pins = backup_dropbox_object_pins($candidate['dropbox_objects'] ?? []);
    if ($chain === [] || $pins === []) {
        throw new \RuntimeException('The component cleanup candidate or current recovery chain has no verified Dropbox file information.');
    }
    $objects = [];
    $records = array_column($chain, null, 'archive_path');
    foreach ($retention['keep'] as $path => $record) {
        if ($record['component'] === $candidate['component']) {
            $records[$path] = $record;
        }
    }
    $records[$candidate['archive_path']] = $candidate;
    foreach ($records as $record) {
        foreach (backup_dropbox_object_pins($record['dropbox_objects']) as $object => $pin) {
            $objects[$record[$object . '_path']] = $pin;
        }
    }
    return ['candidate' => $candidate, 'objects' => $objects];
}

/** Verify one planned object without writing to Dropbox. */
function advance_component_cleanup_preflight(array $plan, int $checked, callable $metadata): int {
    $objects = $plan['objects'];
    if ($checked < 0 || $checked > count($objects)) {
        throw new \RuntimeException('The component cleanup preflight position is invalid.');
    }
    if ($checked === count($objects)) {
        return $checked;
    }
    $object = array_slice($objects, $checked, 1, true);
    if (!verify_offsite_files($object, $metadata)['verified']) {
        throw new \RuntimeException('Dropbox no longer matches the verified component cleanup records.');
    }
    return $checked + 1;
}

const COMPONENT_CLEANUP_PREFLIGHT_OPTION = 'pebkac_backup_component_cleanup_preflight';

/** Advance a component preflight or use an explicitly supplied, revision-guarded removal adapter. */
function run_component_cleanup_preflight_step(
    string $root, string $site, \DateTimeZone $timezone, int $now, callable $metadata, ?callable $remove = null
): string {
    return with_backup_job_lock($root, static function () use ($root, $site, $timezone, $now, $metadata, $remove): string {
        $job = read_backup_job($root);
        if (($job !== [] && ($job['phase'] !== 'verified' || !empty($job['cleanup_pending'])))
            || get_option(BACKUP_RETENTION_JOURNAL_OPTION, []) !== []) {
            return 'busy';
        }
        $history = get_option(COMPONENT_RECOVERY_STATE_OPTION, ['records' => [], 'latest' => []]);
        $journal = get_option(COMPONENT_CLEANUP_PREFLIGHT_OPTION, []);
        if (!is_array($history) || !is_array($journal)) {
            throw new \RuntimeException('The saved component retention progress could not be read.');
        }
        $checks = component_restore_retention_checks($history, $site, $now);
        if ($remove !== null && ($journal['manifest']['phase'] ?? null) === 'removed' && ($journal['archive']['phase'] ?? null) === 'removed') {
            close_component_retention_pair($history, $checks, $journal, $site, $timezone, $now);
            return 'retired';
        }
        $plan = plan_component_cleanup_preflight($history, $checks, $site, $timezone, $now);
        if ($plan === null) {
            return $journal === [] ? 'none' : 'changed';
        }
        $total = count($plan['objects']);
        $fingerprint = hash('sha256', json_encode($plan, JSON_THROW_ON_ERROR));
        $checked = 0;
        if ($journal !== []) {
            if (($journal['plan_sha256'] ?? null) !== $fingerprint || ($journal['total'] ?? null) !== $total) {
                return 'changed';
            }
            $checked = $journal['checked'] ?? null;
            if (!is_int($checked) || $checked < 1 || $checked > $total) {
                throw new \RuntimeException('The saved component retention progress is invalid.');
            }
        }
        if ($checked === $total) {
            return $remove === null ? 'ready' : advance_component_retention_pair($plan['candidate'], $journal, $metadata, $remove);
        }
        $checked = advance_component_cleanup_preflight($plan, $checked, $metadata);
        $progress = ['plan_sha256' => $fingerprint, 'checked' => $checked, 'total' => $total];
        if (!update_option(COMPONENT_CLEANUP_PREFLIGHT_OPTION, $progress, false)) {
            throw new \RuntimeException('Could not save the component retention progress.');
        }
        return $checked === $total ? 'ready' : 'pending';
    });
}

/** Confirm one removal at a time. An uncertain request is only checked by reading Dropbox. */
function advance_component_retention_pair(array $candidate, array $journal, callable $metadata, callable $remove): string {
    if (isset($journal['candidate']) && $journal['candidate'] !== $candidate) {
        throw new \RuntimeException('The saved component cleanup candidate changed.');
    }
    $journal['candidate'] = $candidate;
    $manifest = $journal['manifest'] ?? [];
    $archive = $journal['archive'] ?? [];
    if (!is_array($manifest) || !is_array($archive) || ($archive !== [] && ($manifest['phase'] ?? null) !== 'removed')) {
        throw new \RuntimeException('The saved component retention pair could not be verified.');
    }
    if (($archive['phase'] ?? null) === 'removed') {
        return 'removed';
    }
    $object = ($manifest['phase'] ?? null) === 'removed' ? 'archive' : 'manifest';
    $intent = $journal[$object] ?? [];
    if ($object === 'archive' && $intent === [] && $metadata($candidate['manifest_path']) !== null) {
        throw new \RuntimeException('The retention manifest reappeared before archive cleanup.');
    }
    $path = $candidate[$object . '_path'];
    $pin = backup_dropbox_object_pins($candidate['dropbox_objects'])[$object];
    $updated = advance_pinned_retention_object_removal($path, $pin, $intent, $metadata, $remove,
        static function (array $saved) use ($journal, $object): void {
            $journal[$object] = $saved;
            if (!update_option(COMPONENT_CLEANUP_PREFLIGHT_OPTION, $journal, false)) {
                throw new \RuntimeException('Could not save the component retention intent.');
            }
        });
    return $object === 'archive' && $updated['phase'] === 'removed' ? 'removed' : 'pending';
}

/** Retire only the exact pair confirmed absent. The caller holds the backup job lock. */
function close_component_retention_pair(array $history, array $checks, array $journal, string $site, \DateTimeZone $timezone, int $now): void {
    $candidate = $journal['candidate'] ?? null;
    $component = $candidate['component'] ?? null;
    if (!is_array($candidate) || !is_string($component)) {
        throw new \RuntimeException('The completed component cleanup is missing its verified backup record.');
    }
    require_verified_component_record($site, $component, $candidate, $now);
    $pins = backup_dropbox_object_pins($candidate['dropbox_objects'] ?? []);
    if ($pins === []) {
        throw new \RuntimeException('The completed component cleanup has no verified Dropbox file information.');
    }
    foreach ($pins as $object => $pin) {
        $intent = $journal[$object] ?? [];
        if (($intent['phase'] ?? null) !== 'removed' || ($intent['path'] ?? null) !== $candidate[$object . '_path']
            || ($intent['pin'] ?? null) !== $pin || !valid_dropbox_file_revision($intent['revision'] ?? null)) {
            throw new \RuntimeException('The completed component cleanup does not match both verified files.');
        }
    }
    $path = $candidate['archive_path'];
    $selection = component_backup_retention_plan($history, $checks, $site, $timezone, $now);
    if (isset($history['records'][$path])) {
        if (($selection['candidates'][$path] ?? null) !== $candidate) {
            throw new \RuntimeException('The confirmed component cleanup no longer matches an eligible history entry.');
        }
        unset($history['records'][$path]);
        component_backup_retention_plan($history, $checks, $site, $timezone, $now);
        if (!update_option(COMPONENT_RECOVERY_STATE_OPTION, $history, false)) {
            throw new \RuntimeException('Could not retire the confirmed component backup from history.');
        }
    }
    if (!update_option(COMPONENT_CLEANUP_PREFLIGHT_OPTION, [], false)) {
        throw new \RuntimeException('Could not close the confirmed component cleanup.');
    }
}

/** Describe saved progress without contacting Dropbox or exposing the saved file identifiers. */
function component_cleanup_progress_label(?array $plan, $journal): string {
    if ($journal === []) {
        return '';
    }
    $checked = $journal['checked'] ?? null;
    $total = $journal['total'] ?? null;
    if (!is_int($checked) || !is_int($total) || $checked < 1 || $checked > $total) {
        return 'The saved cleanup progress needs verification.';
    }
    $manifest = $journal['manifest']['phase'] ?? '';
    $archive = $journal['archive']['phase'] ?? '';
    if ($checked === $total && $manifest === 'removed' && $archive === 'removed') {
        return 'Dropbox confirmed both files are gone. The backup history update is pending.';
    }
    if ($plan === null || count($plan['objects']) !== $total
        || hash('sha256', json_encode($plan, JSON_THROW_ON_ERROR)) !== ($journal['plan_sha256'] ?? null)) {
        return 'Cleanup is paused because the verified backup plan changed.';
    }
    if ($manifest === 'readback' || $archive === 'readback') {
        return 'Waiting for Dropbox to confirm a cleanup request.';
    }
    if ($manifest === 'removed') {
        return 'Dropbox confirmed the manifest is gone. The ZIP is next.';
    }
    if ($checked === $total) {
        return 'Dropbox file checks passed for the proposed cleanup.';
    }
    return sprintf('Checked %1$d of %2$d Dropbox files for the proposed cleanup.', $checked, $total);
}

function render_component_backup_retention(): void {
    $history = get_option(COMPONENT_RECOVERY_STATE_OPTION, ['records' => [], 'latest' => []]);
    $journal = get_option(COMPONENT_CLEANUP_PREFLIGHT_OPTION, []);
    if (empty($history['records']) && $journal === []) {
        return;
    }
    $candidate_plan = null;
    $site = home_url();
    $now = time();
    try {
        if (!is_array($history)) {
            throw new \RuntimeException('Component retention evidence could not be read.');
        }
        $checks = component_restore_retention_checks($history, $site, $now);
        $retention = component_backup_retention_plan($history, $checks, $site, wp_timezone(), $now);
        $detail = sprintf('Keep %1$d component backup sets. %2$d sets are outside the retention window.',
            count($retention['keep']), count($retention['candidates']));
        if ($journal !== []) {
            $candidate_plan = pin_component_cleanup_candidate($retention, $history, $site, $now);
        }
    } catch (\RuntimeException $error) {
        $detail = 'Component backup history needs verification before retention can be calculated.';
    }
    $progress = component_cleanup_progress_label($candidate_plan, $journal);
    ?>
    <section class="notice notice-info inline">
        <h2>Component retention preview</h2>
        <details><summary>Show details</summary>
            <p>Keep seven daily and four weekly backups per component when available. Keep the latest restore check and any earlier backups needed to restore a saved point.</p>
            <p><?php echo esc_html($detail); ?></p>
            <?php if ($progress !== '') : ?><p><?php echo esc_html($progress); ?></p><?php endif; ?>
        </details>
    </section>
    <?php
}

const VERIFIED_BACKUP_HISTORY_OPTION = 'pebkac_backup_verified_history';

/** Save verified recovery sets while holding the same lock as the backup job. */
function remember_verified_backups(array $records, string $site, int $now): void {
    $saved = get_option(VERIFIED_BACKUP_HISTORY_OPTION, []);
    if (!is_array($saved)) {
        throw new \RuntimeException('The verified backup history could not be read.');
    }
    $history = $saved;
    foreach ($records as $record) {
        $set = verified_evidence($record, $site, $now);
        if (!isset($set['manifest_path'])) {
            throw new \RuntimeException('Only a complete recovery set can be saved for retention.');
        }
        $path = $set['archive_path'];
        if (isset($history[$path])) {
            $previous = verified_evidence($history[$path], $site, $now);
            foreach (['archive_path', 'archive_sha256', 'manifest_path', 'manifest_sha256', 'offsite_verified_at'] as $field) {
                if (($previous[$field] ?? null) !== $set[$field]) {
                    throw new \RuntimeException('The same backup path identifies different recovery evidence.');
                }
            }
            if (($previous['restore']['verified_at'] ?? 0) > ($set['restore']['verified_at'] ?? 0)) {
                $set['restore'] = $previous['restore'];
            }
            if (isset($previous['dropbox_objects'])) {
                if (isset($set['dropbox_objects']) && $set['dropbox_objects'] !== $previous['dropbox_objects']) {
                    throw new \RuntimeException('The same backup path identifies different Dropbox fingerprints.');
                }
                $set['dropbox_objects'] = $previous['dropbox_objects'];
            }
            if (!isset($set['archive_size_bytes']) && isset($previous['archive_size_bytes'])) {
                $set['archive_size_bytes'] = $previous['archive_size_bytes'];
            }
            if (isset($previous['run_type'])) {
                if (isset($set['run_type']) && $set['run_type'] !== $previous['run_type']) {
                    throw new \RuntimeException('The same backup path identifies a different run type.');
                }
                $set['run_type'] = $previous['run_type'];
            }
        }
        $history[$path] = $set;
    }
    if ($history !== $saved && !update_option(VERIFIED_BACKUP_HISTORY_OPTION, $history, false)) {
        throw new \RuntimeException('Could not save the verified backup history.');
    }
}

/** Combine stored recovery history with the current verified backup. */
function backup_retention_sets($history, $latest, string $site, int $now): array {
    if (!is_array($history)) {
        throw new \RuntimeException('The backup history could not be verified for retention.');
    }
    $latest = verified_evidence($latest, $site, $now);
    if (isset($latest['manifest_path'])) {
        $path = $latest['archive_path'];
        if (isset($history[$path])) {
            $saved = verified_evidence($history[$path], $site, $now);
            foreach (['archive_path', 'archive_sha256', 'manifest_path', 'manifest_sha256', 'offsite_verified_at'] as $field) {
                if (($saved[$field] ?? null) !== $latest[$field]) {
                    throw new \RuntimeException('The backup history could not be verified for retention.');
                }
            }
            if (($saved['restore']['verified_at'] ?? 0) > ($latest['restore']['verified_at'] ?? 0)) {
                $latest['restore'] = $saved['restore'];
            }
        }
        $history[$path] = $latest;
    }
    return array_values($history);
}

/** Count complete recovery sets using the history and the latest verified backup. */
function backup_retention_preview($history, $latest, string $site, \DateTimeZone $timezone, int $now): array {
    $sets = backup_retention_sets($history, $latest, $site, $now);
    $current = verified_evidence($latest, $site, $now);
    $selection = backup_retention_plan($sets, $site, $timezone, $now, $current['archive_path'] ?? null, pending_full_restore_retention_state());
    return ['keep' => count($selection['keep']), 'candidates' => count($selection['candidates'])];
}

const BACKUP_RETENTION_STATUS_OPTION = 'pebkac_backup_retention_status';

/** Remember the latest meaningful cleanup outcome without exposing Dropbox errors. */
function record_backup_cleanup_status(string $state, int $now): void {
    if (!in_array($state, ['none', 'pending', 'retired', 'unavailable', 'blocked', 'busy'], true)) {
        return;
    }
    $saved = get_option(BACKUP_RETENTION_STATUS_OPTION, []);
    if (($saved['state'] ?? null) !== $state || $state === 'retired') {
        $result = ['state' => $state, 'at' => $now];
        $last = $saved['last_retired_at'] ?? (($saved['state'] ?? null) === 'retired' ? ($saved['at'] ?? null) : null);
        if ($state === 'retired') {
            $result['last_retired_at'] = $now;
        } elseif (is_int($last) && $last > 0 && $last <= $now) {
            $result['last_retired_at'] = $last;
        }
        update_option(BACKUP_RETENTION_STATUS_OPTION, $result, false);
    }
}

function backup_cleanup_status_label($status, int $now): string {
    $messages = [
        'none' => 'No older backups were eligible for cleanup.',
        'pending' => 'Cleanup is checking an older backup set.',
        'retired' => 'Dropbox confirmed removal of an older backup set.',
        'unavailable' => 'Cleanup needs a verified backup before it can start.',
        'blocked' => 'Cleanup paused. Check the Dropbox connection and verified backup files.',
        'busy' => 'Cleanup waited because a backup was still in progress.',
    ];
    $state = $status['state'] ?? null;
    $at = $status['at'] ?? null;
    if (!is_string($state) || !isset($messages[$state]) || !is_int($at) || $at < 1 || $at > $now) {
        return '';
    }
    $label = wp_date('M j, Y H:i T', $at) . ' — ' . $messages[$state];
    $last = $status['last_retired_at'] ?? null;
    if ($state !== 'retired' && is_int($last) && $last > 0 && $last <= $at) {
        $label .= ' Last successful cleanup on ' . wp_date('M j, Y H:i T', $last) . '.';
    }
    return $label;
}

function render_backup_retention(): void {
    $history = get_option(VERIFIED_BACKUP_HISTORY_OPTION, []);
    $latest = get_option(EVIDENCE_OPTION, []);
    if ($history === [] && $latest === []) {
        return;
    }
    try {
        $preview = backup_retention_preview($history, $latest, home_url(), wp_timezone(), time());
        $detail = sprintf(
            'Keep %1$d verified backup sets. %2$d sets are outside the retention window.',
            $preview['keep'],
            $preview['candidates']
        );
    } catch (\RuntimeException $error) {
        $detail = 'Backup history needs verification before retention can be calculated.';
    }
    $cleanup_status = backup_cleanup_status_label(get_option(BACKUP_RETENTION_STATUS_OPTION, []), time());
    $automatic = automatic_backup_retention_enabled(get_plan());
    $next = $automatic ? wp_next_scheduled(BACKUP_RETENTION_HOOK) : false;
    ?>
    <section class="notice notice-info inline">
        <h2>Backup retention preview</h2>
        <details><summary>Show details</summary>
            <p>Keep seven daily backups and four weekly backups when available. Keep the most recently verified restore.</p>
            <p>A queued test restore also protects its backup for up to one day while waiting for your PC.</p>
            <p><?php echo esc_html($detail); ?></p>
            <p><?php echo $automatic ? 'Automatic cleanup is enabled.' : 'Automatic cleanup is off.'; ?></p>
            <?php if (is_int($next) && $next > 0) : ?>
                <p><?php echo esc_html('WordPress queued the next cleanup check for ' . wp_date('M j, Y H:i T', $next) . '.'); ?></p>
            <?php endif; ?>
            <?php if ($cleanup_status !== '') : ?><p><?php echo esc_html($cleanup_status); ?></p><?php endif; ?>
            <?php if (get_option(BACKUP_RETENTION_JOURNAL_OPTION, []) !== []) : ?>
                <p>One cleanup is still being checked. Its backup stays in history until both files are confirmed removed.</p>
            <?php endif; ?>
        </details>
    </section>
    <?php
}

/** Preserve the exact Dropbox fingerprints confirmed during transfer. */
function backup_dropbox_object_pins($objects): array {
    $pins = [];
    foreach (['archive' => SNAPSHOT_MAX_BYTES + 8 * 1024 * 1024, 'manifest' => 16 * 1024 * 1024] as $object => $limit) {
        $size = $objects[$object]['size'] ?? null;
        $hash = $objects[$object]['content_hash'] ?? null;
        if (!is_int($size) || $size < 1 || $size > $limit || !is_string($hash) || !preg_match('/^[a-f0-9]{64}$/D', $hash)) {
            return [];
        }
        $pins[$object] = ['size' => $size, 'content_hash' => $hash];
    }
    return $pins;
}

/** Check one proposed cleanup set and the latest kept backup without changing Dropbox. */
function preflight_backup_retention(array $records, string $latest_path, string $site, \DateTimeZone $timezone, int $now, callable $metadata): ?array {
    $selection = backup_retention_plan($records, $site, $timezone, $now, $latest_path, pending_full_restore_retention_state());
    $latest = $selection['keep'][$latest_path] ?? [];
    if (empty($latest['dropbox_objects'])) {
        return null;
    }
    foreach (array_reverse($selection['candidates'], true) as $candidate) {
        if (empty($candidate['dropbox_objects'])) {
            continue;
        }
        $expected = [];
        foreach ([$latest, $candidate] as $set) {
            foreach ($set['dropbox_objects'] as $object => $pin) {
                $expected[$set[$object . '_path']] = $pin;
            }
        }
        if (!verify_offsite_files($expected, $metadata)['verified']) {
            throw new \RuntimeException('Dropbox no longer matches the verified retention records.');
        }
        return $candidate;
    }
    return null;
}

/**
 * Advance one object from a preflighted candidate. The caller holds the backup job lock.
 * The removal adapter must enforce the observed revision. The save callback must be durable.
 */
function advance_retention_object_removal(
    array $candidate,
    string $site,
    string $object,
    int $now,
    array $journal,
    callable $metadata,
    callable $remove,
    callable $save
): array {
    $candidate = verified_evidence($candidate, $site, $now);
    $pin = $candidate['dropbox_objects'][$object] ?? null;
    if (!in_array($object, ['archive', 'manifest'], true) || $pin === null) {
        throw new \RuntimeException('Only a verified retention object can be considered for cleanup.');
    }
    return advance_pinned_retention_object_removal($candidate[$object . '_path'], $pin, $journal, $metadata, $remove, $save);
}

/** Shared removal mechanics for a path and fingerprint already validated by the caller. */
function advance_pinned_retention_object_removal(
    string $path, array $pin, array $journal, callable $metadata, callable $remove, callable $save
): array {
    if ($journal !== []) {
        if (($journal['path'] ?? null) !== $path || ($journal['pin'] ?? null) !== $pin
            || !in_array($journal['phase'] ?? null, ['readback', 'removed'], true)) {
            throw new \RuntimeException('The saved retention intent does not match the candidate.');
        }
        if ($journal['phase'] === 'readback' && $metadata($path) === null) {
            $journal['phase'] = 'removed';
            $save($journal);
        }
        return $journal;
    }

    $actual = $metadata($path);
    $revision = $actual['rev'] ?? null;
    if (($actual['.tag'] ?? null) !== 'file' || ($actual['size'] ?? null) !== $pin['size']
        || ($actual['content_hash'] ?? null) !== $pin['content_hash']
        || !valid_dropbox_file_revision($revision)) {
        throw new \RuntimeException('The Dropbox object changed after retention preflight.');
    }

    $journal = ['path' => $path, 'pin' => $pin, 'revision' => $revision, 'phase' => 'readback'];
    $save($journal);
    $remove($path, $revision);
    return $journal;
}

/** Advance one step of paired cleanup. The caller saves the journal under the backup job lock. */
function advance_paired_retention_cleanup(
    array $records,
    string $latest_path,
    string $site,
    \DateTimeZone $timezone,
    int $now,
    array $journal,
    callable $metadata,
    callable $remove,
    callable $save
): array {
    if ($journal === []) {
        $candidate = preflight_backup_retention($records, $latest_path, $site, $timezone, $now, $metadata);
        if ($candidate === null) {
            return [];
        }
        $journal = ['candidate' => $candidate, 'manifest' => [], 'archive' => []];
        $save($journal);
        return $journal;
    }
    $candidate = verified_evidence($journal['candidate'] ?? null, $site, $now);
    if (empty($candidate['dropbox_objects']) || !is_array($journal['manifest'] ?? null) || !is_array($journal['archive'] ?? null)) {
        throw new \RuntimeException('The saved retention pair could not be verified.');
    }
    if (($journal['archive']['phase'] ?? '') === 'removed' && ($journal['manifest']['phase'] ?? '') === 'removed') {
        return $journal;
    }

    $object = ($journal['manifest']['phase'] ?? '') === 'removed' ? 'archive' : 'manifest';
    if ($journal[$object] === []) {
        $selection = backup_retention_plan($records, $site, $timezone, $now, $latest_path, pending_full_restore_retention_state());
        $latest = $selection['keep'][$latest_path] ?? [];
        if (($selection['candidates'][$candidate['archive_path']] ?? null) !== $candidate || empty($latest['dropbox_objects'])) {
            throw new \RuntimeException('The saved pair is no longer eligible for retention cleanup.');
        }
        $expected = [];
        foreach ($latest['dropbox_objects'] as $name => $pin) {
            $expected[$latest[$name . '_path']] = $pin;
        }
        if (!verify_offsite_files($expected, $metadata)['verified']) {
            throw new \RuntimeException('The latest kept backup could not be verified in Dropbox.');
        }
        if ($object === 'archive' && $metadata($candidate['manifest_path']) !== null) {
            throw new \RuntimeException('The retention manifest reappeared before archive cleanup.');
        }
    }

    $journal[$object] = advance_retention_object_removal($candidate, $site, $object, $now, $journal[$object], $metadata, $remove,
        static function (array $intent) use ($journal, $object, $save): void {
            $journal[$object] = $intent;
            $save($journal);
        });
    return $journal;
}

const BACKUP_RETENTION_JOURNAL_OPTION = 'pebkac_backup_retention_journal';

/** Advance one retention step inside WordPress. No scheduler calls this until cleanup is enabled. */
function run_backup_retention_step(string $root, string $site, \DateTimeZone $timezone, int $now, callable $metadata, callable $remove): string {
    return with_backup_job_lock($root, static function () use ($root, $site, $timezone, $now, $metadata, $remove): string {
        $job = read_backup_job($root);
        if ($job !== [] && ($job['phase'] !== 'verified' || !empty($job['cleanup_pending']))) {
            return 'busy';
        }
        $history = get_option(VERIFIED_BACKUP_HISTORY_OPTION, []);
        $journal = get_option(BACKUP_RETENTION_JOURNAL_OPTION, []);
        $latest = verified_evidence(get_option(EVIDENCE_OPTION, []), $site, $now);
        if (!is_array($history) || !is_array($journal) || empty($latest['dropbox_objects'])) {
            return 'unavailable';
        }
        $latest_path = $latest['archive_path'];
        if (($journal['candidate']['archive_path'] ?? null) === $latest_path) {
            throw new \RuntimeException('The current recovery point cannot be removed.');
        }
        $save = static function (array $record): void {
            if (!update_option(BACKUP_RETENTION_JOURNAL_OPTION, $record, false)) {
                throw new \RuntimeException('Could not save retention progress.');
            }
        };
        $records = backup_retention_sets($history, $latest, $site, $now);
        $journal = advance_paired_retention_cleanup($records, $latest_path, $site, $timezone, $now,
            $journal, $metadata, $remove, $save);
        if ($journal === []) {
            return 'none';
        }
        if (($journal['manifest']['phase'] ?? '') !== 'removed' || ($journal['archive']['phase'] ?? '') !== 'removed') {
            return 'pending';
        }
        $path = $journal['candidate']['archive_path'];
        if (isset($history[$path])) {
            if (verified_evidence($history[$path], $site, $now) !== $journal['candidate']) {
                throw new \RuntimeException('The removed pair no longer matches the stored backup history.');
            }
            unset($history[$path]);
            if (!update_option(VERIFIED_BACKUP_HISTORY_OPTION, $history, false)) {
                throw new \RuntimeException('Could not retire the removed recovery set from backup history.');
            }
        }
        $save([]);
        return 'retired';
    });
}

const BACKUP_RETENTION_HOOK = 'pebkac_backup_retention_step';

function automatic_backup_retention_enabled(array $plan): bool {
    return daily_backup_settings($plan)['enabled'] && ($plan['daily']['retention'] ?? false) === true;
}

function queue_backup_retention_event(int $delay = 60): void {
    if (automatic_backup_retention_enabled(get_plan()) && wp_next_scheduled(BACKUP_RETENTION_HOOK) === false) {
        wp_schedule_single_event(time() + $delay, BACKUP_RETENTION_HOOK);
    }
}

function queue_waiting_backup_retention_event(): void {
    if ((get_option(BACKUP_RETENTION_STATUS_OPTION, [])['state'] ?? null) === 'busy') {
        queue_backup_retention_event();
    }
}

/** Resume a pending cleanup check promptly after Dropbox reconnects. */
function queue_retention_after_dropbox_authorization(): void {
    if (automatic_backup_retention_enabled(get_plan()) && get_option(BACKUP_RETENTION_JOURNAL_OPTION, []) !== []) {
        bring_forward_backup_event(BACKUP_RETENTION_HOOK, [], time() + 60);
    }
}

/** Restore a missing callback for an unfinished cleanup without starting a new one. */
function repair_pending_backup_retention_queue(): void {
    if (!automatic_backup_retention_enabled(get_plan()) || wp_next_scheduled(BACKUP_RETENTION_HOOK) !== false) {
        return;
    }
    $journal = get_option(BACKUP_RETENTION_JOURNAL_OPTION, []);
    if ($journal === [] && dropbox_saved_refresh_token(dropbox_app_key()) !== '') {
        // Repair the missing handoff after a restore changes which point is protected.
        // Only queue the existing revision-pinned worker; do not delete during init.
        try {
            $preview = backup_retention_preview(get_option(VERIFIED_BACKUP_HISTORY_OPTION, []),
                get_option(EVIDENCE_OPTION, []), home_url(), wp_timezone(), time());
            if ($preview['candidates'] > 0) {
                queue_backup_retention_event();
            }
        } catch (\RuntimeException $error) {
            // Unverified history is never a reason to start cleanup.
        }
        return;
    }
    if (is_array($journal) && (in_array($journal['manifest']['phase'] ?? null, ['readback', 'removed'], true)
        || in_array($journal['archive']['phase'] ?? null, ['readback', 'removed'], true))
        && dropbox_saved_refresh_token(dropbox_app_key()) !== '') {
        queue_backup_retention_event(900);
    }
}

function reconcile_backup_retention_event(array $old, array $new): void {
    $was_enabled = automatic_backup_retention_enabled($old);
    $enabled = automatic_backup_retention_enabled($new);
    if ($was_enabled === $enabled) {
        return;
    }
    if (!$enabled) {
        wp_clear_scheduled_hook(BACKUP_RETENTION_HOOK);
        return;
    }
    $latest = verified_evidence(get_option(EVIDENCE_OPTION, []), home_url(), time());
    if (!empty($latest['dropbox_objects']) && dropbox_saved_refresh_token(dropbox_app_key()) !== '') {
        queue_backup_retention_event();
    }
}

function run_backup_retention_event(): void {
    if (!automatic_backup_retention_enabled(get_plan())) {
        return;
    }
    $app = dropbox_app_key();
    $refresh = dropbox_saved_refresh_token($app);
    if ($refresh === '') {
        return;
    }
    $before = get_option(BACKUP_RETENTION_JOURNAL_OPTION, []);
    try {
        $site = home_url();
        // One callback can use one token request and at most five file requests.
        $timeout = max(1, min(5, intdiv((int) backup_request_budget(), 6)));
        $token = null;
        $access_token = static function () use (&$token, $app, $refresh, $timeout): string {
            return $token ?? ($token = refresh_dropbox_access_token($app, $refresh, $timeout));
        };
        $result = run_backup_retention_step(backup_job_root(true), $site, wp_timezone(), time(),
            static function (string $path) use ($access_token, $timeout): ?array { return fetch_dropbox_metadata($path, $access_token(), $timeout); },
            static function (string $path, string $revision) use ($site, $access_token, $timeout): void {
                request_dropbox_retention_removal($site, $path, $revision, $access_token(), $timeout);
            });
        record_backup_cleanup_status($result, time());
        if ($result === 'retired' || ($result === 'pending' && $before !== get_option(BACKUP_RETENTION_JOURNAL_OPTION, []))) {
            queue_backup_retention_event();
        } elseif ($result === 'pending') {
            queue_backup_retention_event(900);
        }
    } catch (BackupJobLockBusy $busy) {
        record_backup_cleanup_status('busy', time());
        queue_backup_retention_event();
    } catch (\RuntimeException $error) {
        record_backup_cleanup_status('blocked', time());
        $after = get_option(BACKUP_RETENTION_JOURNAL_OPTION, []);
        if (($after['manifest']['phase'] ?? null) === 'readback' || ($after['archive']['phase'] ?? null) === 'readback') {
            queue_backup_retention_event($after !== $before ? 60 : 900);
        }
    }
}

add_action(BACKUP_RETENTION_HOOK, __NAMESPACE__ . '\\run_backup_retention_event');
add_action('init', __NAMESPACE__ . '\\repair_pending_backup_retention_queue');
