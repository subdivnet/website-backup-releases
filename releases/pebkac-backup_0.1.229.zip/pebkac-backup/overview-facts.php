<?php
namespace PEBKAC404\Backup;

/** Count exact recorded Dropbox objects once; conflicting or missing metadata is incomplete. */
function backup_storage_totals(array $records): array {
    $objects = []; $complete = true;
    foreach ($records as $record) {
        foreach (['archive','manifest'] as $kind) {
            $path = $record[$kind . '_path'] ?? null;
            $bytes = $record['dropbox_objects'][$kind]['size'] ?? null;
            $hash = $record[$kind . '_sha256'] ?? null;
            if (!is_string($path) || !is_int($bytes) || $bytes < 1 || $bytes > SNAPSHOT_MAX_BYTES + SNAPSHOT_MAX_MANIFEST_BYTES
                || !is_string($hash) || !preg_match('/^[a-f0-9]{64}$/D', $hash)) { $complete = false; continue; }
            $pin = ['bytes'=>$bytes,'hash'=>$hash];
            if (isset($objects[$path]) && $objects[$path] !== $pin) { throw new \RuntimeException('Dropbox storage records conflict.'); }
            $objects[$path] = $pin;
        }
    }
    return ['bytes'=>array_sum(array_column($objects,'bytes')),'objects'=>count($objects),'complete'=>$complete && $objects !== []];
}

/** Use site-bound verified history, including retained component dependencies. No Dropbox calls. */
function recorded_backup_storage(string $site, int $now): array {
    $records = backup_retention_sets(get_option(VERIFIED_BACKUP_HISTORY_OPTION, []), get_option(EVIDENCE_OPTION, []), $site, $now);
    $components = get_option(COMPONENT_RECOVERY_STATE_OPTION, []);
    if (!is_array($components) || (isset($components['records']) && !is_array($components['records']))) { throw new \RuntimeException('Component storage records are unavailable.'); }
    foreach (($components['records'] ?? []) as $record) {
        if (!is_array($record) || !is_string($record['component'] ?? null)) { throw new \RuntimeException('Component storage records are invalid.'); }
        require_verified_component_record($site, $record['component'] ?? '', $record, $now);
        $records[] = $record;
    }
    return backup_storage_totals($records);
}

function render_backup_storage(): void {
    try { $storage = recorded_backup_storage(home_url(), time()); }
    catch (\RuntimeException $error) { $storage = ['bytes'=>0,'objects'=>0,'complete'=>false]; }
    ?>
    <section class="notice inline <?php echo $storage['complete'] ? 'notice-success' : 'notice-warning'; ?>">
        <h2>Dropbox space used</h2>
        <p><?php echo esc_html($storage['objects'] > 0 ? size_format($storage['bytes'],1) . ' in recorded backup files' : 'No complete storage total yet'); ?></p>
        <details><summary>Show details</summary><p>This site’s recorded ZIPs and recovery manifests, including retained incremental dependencies. The total uses their last verified Dropbox sizes.</p>
            <?php if (!$storage['complete']) : ?><p>Some sizes are unavailable. The displayed amount is a partial total.</p><?php endif; ?>
        </details>
    </section>
    <?php
}
