<?php
namespace PEBKAC404\Backup;

/** Rewrite PHP serialization without instantiating any class from a recovered value. */
function bounded_migration_replace(string $value,array $replace): string {
    $keys=array_keys($replace);
    usort($keys,static function ($a,$b) { return strlen($b)<=>strlen($a); });
    $pattern='#(?:'.implode('|',array_map(static function ($key) { return preg_quote($key,'#'); },$keys)).')(?![A-Za-z0-9._~%:@+\x80-\xff-])#';
    $length=strlen($value);
    // Count expansion first: PCRE may grow its result buffer before a later callback can refuse it.
    $checked=preg_replace_callback($pattern,static function ($match) use ($replace,&$length) {
        $new=$replace[$match[0]]; $length+=strlen($new)-strlen($match[0]);
        if ($length>32*1024*1024) { throw new \RuntimeException('A rewritten migration value exceeds its size limit.'); }
        return $match[0];
    },$value);
    if ($checked===null) { throw new \RuntimeException('The migration URL map could not be applied.'); }
    unset($checked);
    $result=''; $offset=0;
    while (preg_match($pattern,$value,$match,PREG_OFFSET_CAPTURE,$offset)) {
        $at=$match[0][1];
        $result.=substr($value,$offset,$at-$offset).$replace[$match[0][0]];
        $offset=$at+strlen($match[0][0]);
    }
    $result.=substr($value,$offset);
    return $result;
}

final class BackupMigrationValue {
    private $input; private $position=0; private $replace; private $estimated;
    function __construct(string $input,array $replace) { $this->input=$input; $this->replace=$replace; $this->estimated=strlen($input); }
    private function take(string $pattern): array {
        $pattern='/\\G'.substr($pattern,2);
        if (!preg_match($pattern,$this->input,$match,0,$this->position)) { throw new \RuntimeException('A serialized migration value is malformed.'); }
        $this->position+=strlen($match[0]); return $match;
    }
    private function literal(string $expected): void {
        if (substr($this->input,$this->position,strlen($expected))!==$expected) { throw new \RuntimeException('A serialized migration value has an invalid length.'); }
        $this->position+=strlen($expected);
    }
    private function bytes(int $length): string {
        if ($length<0 || $length>16*1024*1024 || $length>strlen($this->input)-$this->position) { throw new \RuntimeException('A serialized migration value exceeds its bounds.'); }
        $value=substr($this->input,$this->position,$length); $this->position+=$length; return $value;
    }
    private function node(int $depth): string {
        if ($depth>64) { throw new \RuntimeException('A migration value is nested too deeply.'); }
        $type=$this->input[$this->position]??'';
        if ($type==='N') { $this->literal('N;'); return 'N;'; }
        if (in_array($type,['b','i','d','r','R'],true)) {
            return $this->take('/^(?:b:[01];|i:-?[0-9]+;|[rR]:[1-9][0-9]*;|d:(?:[+-]?(?:[0-9]+(?:\.[0-9]*)?|\.[0-9]+)(?:[Ee][+-]?[0-9]+)?|NAN|-?INF);)/D')[0];
        }
        if ($type==='s' || $type==='E') {
            $header=$this->take('/^[sE]:([0-9]+):"/D');
            $value=$this->bytes((int)$header[1]); $this->literal('";');
            $new=$type==='s'?bounded_migration_replace($value,$this->replace):$value;
            $this->estimated+=strlen($new)-strlen($value)+strlen($type.':'.strlen($new).':"')-strlen($header[0]);
            if ($this->estimated>32*1024*1024) { throw new \RuntimeException('A serialized migration value exceeds its output bounds.'); }
            return $type.':'.strlen($new).':"'.$new.'";';
        }
        if ($type==='a') {
            $count=(int)$this->take('/^a:([0-9]+):\{/D')[1];
            if ($count>1000000 || $count>strlen($this->input)) { throw new \RuntimeException('A serialized array exceeds migration bounds.'); }
            $out='a:'.$count.':{';
            for ($entry=0;$entry<$count;$entry++) { $out.=$this->node($depth+1).$this->node($depth+1); }
            $this->literal('}'); return $out.'}';
        }
        if ($type==='O' || $type==='C') {
            $header=$this->take('/^[OC]:([0-9]+):"/D');
            $class=$this->bytes((int)$header[1]); $this->literal('":');
            $count=(int)$this->take('/^([0-9]+):\{/D')[1];
            $out=$type.':'.strlen($class).':"'.$class.'":'.$count.':{';
            if ($type==='C') {
                $payload=$this->bytes($count);
                if (bounded_migration_replace($payload,$this->replace)!==$payload) { throw new \RuntimeException('A custom serialized plugin value needs a migration adapter.'); }
                $out.=$payload;
            } else {
                if ($count>1000000 || $count>strlen($this->input)) { throw new \RuntimeException('A serialized object exceeds migration bounds.'); }
                for ($entry=0;$entry<$count;$entry++) { $out.=$this->node($depth+1).$this->node($depth+1); }
            }
            $this->literal('}'); return $out.'}';
        }
        throw new \RuntimeException('An unsupported serialized value needs migration review.');
    }
    function rewrite(): string {
        $result=$this->node(0);
        if ($this->position!==strlen($this->input) || strlen($result)>32*1024*1024) { throw new \RuntimeException('A serialized migration value has trailing data or exceeds its output bounds.'); }
        return $result;
    }
}

function migration_url_map(array $urls): array {
    if ($urls===[] || count($urls)>8) { throw new \RuntimeException('Choose the old and new site URLs.'); }
    $replace=[];
    foreach ($urls as $old=>$new) {
        foreach ([$old,$new] as $url) {
            $parts=is_string($url)?parse_url($url):false;
            if (!is_string($url) || strlen($url)>2048 || preg_match('/[\x00-\x20\x7f]/',$url) || !is_array($parts)
                || !in_array($parts['scheme']??null,['http','https'],true) || empty($parts['host'])
                || isset($parts['user']) || isset($parts['pass']) || isset($parts['query']) || isset($parts['fragment'])) {
                throw new \RuntimeException('Migration requires plain HTTP or HTTPS site URLs without credentials.');
            }
        }
        $old=rtrim($old,'/');$new=rtrim($new,'/');
        $replace[$old]=$new;
        $replace[str_replace('/','\\/',$old)]=str_replace('/','\\/',$new);
    }
    return $replace;
}

/** For an isolated imported database value. No SQL, filesystem writes or object execution. */
function rewrite_migration_value(string $value,array $urls): string {
    if (strlen($value)>16*1024*1024) { throw new \RuntimeException('A migration value exceeds its size limit.'); }
    $replace=migration_url_map($urls);
    if (preg_match('/^(?:N;|[bidrR]:[^;]*;|[sEOC]:[0-9]+:|a:[0-9]+:\{)/D',$value)) {
        return (new BackupMigrationValue($value,$replace))->rewrite();
    }
    $result=bounded_migration_replace($value,$replace);
    if (strlen($result)>32*1024*1024) { throw new \RuntimeException('A rewritten migration value exceeds its size limit.'); }
    return $result;
}
