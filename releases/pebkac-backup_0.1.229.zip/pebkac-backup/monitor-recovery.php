<?php
namespace PEBKAC404\Backup;

/** A completion before the supplied earliest problem time is a candidate, not proof of cleanliness. */
function backup_before_problem(array $records, string $site, int $before, int $now): ?array {
    if ($before < 1 || $before > $now) { throw new \RuntimeException('Choose a known problem time in the past.'); }
    $candidate = null;
    foreach ($records as $record) {
        $proof = verified_evidence($record, $site, $now);
        if (!isset($proof['manifest_path']) || $proof['offsite_verified_at'] >= $before) { continue; }
        if ($candidate === null || $proof['offsite_verified_at'] > $candidate['offsite_verified_at']) { $candidate = $proof; }
    }
    return $candidate;
}

function local_backup_before_problem(int $before, int $now): ?array {
    $site = home_url();
    $latest = verified_evidence(get_option(EVIDENCE_OPTION, []), $site, $now);
    $records = available_earlier_full_backups($latest, $site, $now);
    if (isset($latest['manifest_path'])) { $records[] = $latest; }
    return backup_before_problem($records, $site, $before, $now);
}

add_action('rest_api_init', static function (): void {
    register_rest_route('pebkac-backup/v1', '/recovery-point', [
        'methods'=>'GET',
        'permission_callback'=>static function () { return current_user_can('manage_options') || current_user_can('wmc_read_monitor_status'); },
        'args'=>['before'=>['type'=>'integer','required'=>true,'minimum'=>1]],
        'callback'=>static function ($request) {
            $before = (int)$request->get_param('before');
            try { $record = local_backup_before_problem($before,time()); }
            catch (\RuntimeException $error) { return new \WP_Error('backup_candidate_unavailable','A retained recovery point could not be confirmed.',['status'=>409]); }
            $candidate = $record === null ? null : [
                'point'=>recovery_download_id($record), 'verified_at'=>$record['offsite_verified_at'],
                'size_bytes'=>$record['archive_size_bytes'] ?? null,
                'test_restore_passed'=>isset($record['restore']),
                'review_url'=>admin_url('admin.php?page=pebkac-backup&tab=overview&before_problem=' . $before . '#backup-before-problem'),
            ];
            $response = new \WP_REST_Response(['schema'=>1,'site_url'=>home_url(),'before'=>$before,'candidate'=>$candidate,
                'cleanliness'=>'not_determined'],200);
            $response->header('Cache-Control','private, no-store');
            return $response;
        },
    ]);
});

function render_backup_before_problem(): void {
    $before = filter_var($_GET['before_problem'] ?? null,FILTER_VALIDATE_INT,['options'=>['min_range'=>1,'max_range'=>time()]]);
    if ($before === false || $before === null) { return; }
    try { $record = local_backup_before_problem($before,time()); } catch (\RuntimeException $error) { $record = null; }
    ?>
    <section id="backup-before-problem" class="notice notice-warning inline">
        <h2>Last retained backup before this problem</h2>
        <p><?php echo esc_html($record === null ? 'No retained full backup is confirmed before that time.' : 'Backup verified ' . wp_date('M j, Y H:i T',$record['offsite_verified_at'])); ?></p>
        <p>The supplied problem time selects an earlier backup. A test restore checks recovery; it does not establish that a backup is free of a compromise.</p>
        <?php if ($record !== null) : ?>
        <form method="post" action="<?php echo esc_url(admin_url('admin-post.php')); ?>">
            <input type="hidden" name="action" value="pebkac_backup_test_restore">
            <input type="hidden" name="point" value="<?php echo esc_attr(recovery_download_id($record)); ?>">
            <?php wp_nonce_field('pebkac_backup_test_restore'); ?>
            <button class="button button-primary" type="submit">Test restore this earlier backup</button>
        </form>
        <?php endif; ?>
    </section>
    <?php
}
