<?php

namespace PEBKAC404\Backup;

const PARKED_DAILY_BACKUP_FILE = 'parked-daily-backup.json';

function read_parked_daily_backup(string $root): array {
    $file = $root . '/' . PARKED_DAILY_BACKUP_FILE;
    if (is_link($file)) {
        throw new \RuntimeException('The private parked backup record cannot be used.');
    }
    if (!is_file($file)) {
        return [];
    }
    $bytes = @file_get_contents($file, false, null, 0, 65537);
    $record = $bytes !== false && strlen($bytes) <= 65536 ? json_decode($bytes, true, 12) : null;
    if (!is_array($record) || !isset($record['site'], $record['parked'], $record['followup'])) {
        throw new \RuntimeException('The private parked backup record cannot be read.');
    }
    return $record;
}

/** Reserve a different daily backup while holding the normal job lock. */
function advance_parked_daily_replacement(
    string $root, array $active, string $site, string $day, string $folder, callable $free_space, ?\DateTimeZone $timezone = null
): array {
    if (pilot_site_slug($site) === '' || !valid_parked_backup_day($day) || !valid_backup_dropbox_folder($folder)) {
        throw new \RuntimeException('The follow-up must belong to the approved site and scheduled day.');
    }
    $record = read_parked_daily_backup($root);
    if ($record !== []) {
        $followup = $record['followup'];
        $parked = $record['parked'];
        if ($record['site'] !== $site || !is_array($followup) || !is_array($parked)
            || !is_string($followup['id'] ?? null) || !preg_match('/^[a-f0-9]{32}$/D', $followup['id'])
            || !valid_parked_backup_day($followup['daily_date'] ?? '') || $followup['daily_date'] > $day
            || ($followup['phase'] ?? null) !== 'database' || ($followup['folder'] ?? null) !== $folder) {
            throw new \RuntimeException('The parked record does not belong to this daily backup.');
        }
        if ($active !== $parked) {
            throw new \RuntimeException('An earlier unconfirmed backup is already parked.');
        }
        require_parked_backup_space($active, $free_space);
        write_backup_job($root, $followup);
        return ['state' => 'activated', 'id' => $followup['id']];
    }
    $previous_day = scheduled_backup_day_for_followup($active, $timezone);
    if ($previous_day === '' || $previous_day >= $day
        || !in_array($active['phase'] ?? null, ['transfer', 'manifest'], true)
        || (!backup_job_upload_uncertain($active) && !backup_job_readback_needs_attention($active))) {
        throw new \RuntimeException('Only an earlier day’s unconfirmed scheduled backup can be parked.');
    }
    require_parked_backup_space($active, $free_space);
    $id = bin2hex(random_bytes(16));
    $followup = ['id' => $id, 'phase' => 'database', 'daily_date' => $day, 'folder' => $folder];
    $record = ['site' => $site, 'parked_day' => $previous_day, 'parked' => $active, 'followup' => $followup];
    save_parked_daily_backup($root, $record);
    return ['state' => 'reserved', 'id' => $id];
}

function save_parked_daily_backup(string $root, array $record): void {
    $bytes = wp_json_encode($record);
    if (!is_string($bytes) || strlen($bytes) > 65536) {
        throw new \RuntimeException('The private parked backup record could not be saved.');
    }
    write_private_backup_record($root . '/' . PARKED_DAILY_BACKUP_FILE, $bytes);
}

/** Identify the one component which remains on hold for this site. */
function parked_component_job(array $record, string $site): array {
    $job = $record['parked'] ?? [];
    if (($record['site'] ?? null) !== $site || !isset($job['component'])) {
        return [];
    }
    if (!is_string($job['component']) || !isset(SNAPSHOT_COMPONENT_DIRECTORIES[$job['component']])
        || !is_string($job['id'] ?? null) || !preg_match('/^[a-f0-9]{32}$/D', $job['id'])
        || !is_int($job['scheduled_due_at'] ?? null) || $job['scheduled_due_at'] < 1) {
        throw new \RuntimeException('The earlier component upload record is invalid.');
    }
    return $job;
}

/** Preserve the old claim before making the shared queue available to other components. */
function release_parked_component_claim(string $root, array $record, array $parked): void {
    $pending = get_option(SCHEDULED_BACKUP_JOB_OPTION, []);
    if (($pending['id'] ?? null) !== $parked['id']) {
        if (($pending['component'] ?? null) === $parked['component']) {
            throw new \RuntimeException('The component on hold has a different pending claim.');
        }
        return;
    }
    if (($pending['component'] ?? null) !== $parked['component'] || ($pending['due_at'] ?? null) !== $parked['scheduled_due_at']
        || !is_array($pending['schedule'] ?? null)
        || (isset($record['component_claim']) && $record['component_claim'] !== $pending)) {
        throw new \RuntimeException('The earlier component claim changed before it could be parked.');
    }
    if (!isset($record['component_claim'])) {
        $record['component_claim'] = $pending;
        save_parked_daily_backup($root, $record);
    }
    if (!update_option(SCHEDULED_BACKUP_JOB_OPTION, [], false)) {
        throw new \RuntimeException('The earlier component claim was saved but the active queue could not be cleared.');
    }
}

function scheduled_backup_day_for_followup(array $job, ?\DateTimeZone $timezone): string {
    $day = $job['daily_date'] ?? '';
    if (valid_parked_backup_day($day)) {
        return $day;
    }
    $component = $job['component'] ?? null;
    $due = $job['scheduled_due_at'] ?? null;
    if ($timezone === null || !is_string($component) || !isset(SNAPSHOT_COMPONENT_DIRECTORIES[$component]) || !is_int($due) || $due < 1) {
        return '';
    }
    return (new \DateTimeImmutable('@' . $due))->setTimezone($timezone)->format('Y-m-d');
}

function valid_parked_backup_day($day): bool {
    if (!is_string($day) || !preg_match('/^[0-9]{4}-[0-9]{2}-[0-9]{2}$/D', $day)) {
        return false;
    }
    $date = \DateTimeImmutable::createFromFormat('!Y-m-d', $day, new \DateTimeZone('UTC'));
    return $date !== false && $date->format('Y-m-d') === $day;
}

function require_parked_backup_space(array $job, callable $free_space): void {
    $free = $free_space();
    $size = $job['transfer']['size'] ?? 0;
    $minimum = is_int($size) && $size > 0 && $size <= SNAPSHOT_MAX_BYTES + 8 * 1024 * 1024
        ? max(SNAPSHOT_MIN_STAGING_BYTES, snapshot_staging_bytes($size)) : SNAPSHOT_MIN_STAGING_BYTES;
    if ((!is_int($free) && !is_float($free)) || !is_finite((float) $free) || $free < $minimum) {
        throw new \RuntimeException('There is not enough temporary space for an independent daily backup.');
    }
}

function parked_daily_backup_day(array $record, string $site): string {
    $day = $record['parked_day'] ?? $record['parked']['daily_date'] ?? '';
    return ($record['site'] ?? null) === $site && valid_parked_backup_day($day) ? $day : '';
}

function render_parked_daily_backup(string $root, string $site, bool $connected = true): void {
    try {
        $record = read_parked_daily_backup($root);
    } catch (\RuntimeException $error) {
        return;
    }
    $day = parked_daily_backup_day($record, $site);
    if ($day === '') {
        return;
    }
    try {
        $can_check = parked_daily_recovery_pins($record, $site) !== [];
        $can_recover = isset(parked_full_recovery_evidence($record, $site, time())['manifest_path']);
    } catch (\RuntimeException $error) {
        $can_check = false;
        $can_recover = false;
    }
    $now = time();
    $check = get_option(PARKED_DAILY_CHECK_OPTION, []);
    $label = parked_daily_recovery_check_label($record, $check, $now);
    $can_clear = $connected && parked_backup_can_offer_local_cleanup($record, $site, $check, $now);
    $size = parked_daily_staging_size($root, $site, $record);
    $component = $record['parked']['component'] ?? '';
    $component_name = is_string($component) ? (COMPONENTS[$component] ?? null) : null;
    ?>
    <section id="pebkac-backup-parked-daily" class="notice notice-warning inline">
        <h2><?php echo $component_name === null ? 'An earlier daily upload needs review' : 'An earlier component upload needs review'; ?></h2>
        <details<?php if (($_GET['parked_checked'] ?? '') === '1' && ($label !== '' || isset($record['recovered_full']))) : ?> open<?php endif; ?>><summary>Show details</summary>
            <p><?php echo esc_html(($component_name === null ? 'Dropbox did not confirm an upload from ' : 'Dropbox did not confirm the ' . $component_name . ' upload from ')
                . $day . '. WordPress kept the earlier upload record.'); ?></p>
            <p>A later scheduled backup can use a separate upload.</p>
            <?php if (!$connected) : ?><p>Reconnect Dropbox in Setup to check the earlier upload.</p><?php endif; ?>
            <?php if ($size !== null) : ?><p><?php echo esc_html('Private temporary files for this upload use ' . size_format($size, 1) . '.'); ?></p><?php endif; ?>
            <?php if (isset($record['recovered_full'])) : ?><p>Dropbox confirmed both recovery files. The local recovery record can be finished below.</p><?php endif; ?>
            <?php if ($label !== '') : ?><p><?php echo esc_html($label); ?></p><?php endif; ?>
            <?php if ($connected && $can_check) : ?>
                <form action="<?php echo esc_url(admin_url('admin-post.php')); ?>" method="post">
                    <input type="hidden" name="action" value="pebkac_backup_check_parked_daily">
                    <input type="hidden" name="parked" value="<?php echo esc_attr($record['parked']['id']); ?>">
                    <?php wp_nonce_field('pebkac_backup_check_parked_daily_' . $record['parked']['id']); ?>
                    <button class="button" type="submit">Check this upload in Dropbox</button>
                </form>
            <?php endif; ?>
            <?php if ($connected && $can_recover) : ?>
                <form action="<?php echo esc_url(admin_url('admin-post.php')); ?>" method="post">
                    <input type="hidden" name="action" value="pebkac_backup_recover_parked_full">
                    <input type="hidden" name="parked" value="<?php echo esc_attr($record['parked']['id']); ?>">
                    <?php wp_nonce_field('pebkac_backup_recover_parked_full_' . $record['parked']['id']); ?>
                    <button class="button" type="submit"><?php echo isset($record['recovered_full']) ? 'Finish recovery and clear temporary files' : 'Verify and recover this backup'; ?></button>
                </form>
            <?php endif; ?>
            <?php if ($can_clear) : ?>
                <p>WordPress will recheck the newer Dropbox backup and both saved paths before removing the earlier local files.</p>
                <form action="<?php echo esc_url(admin_url('admin-post.php')); ?>" method="post">
                    <input type="hidden" name="action" value="pebkac_backup_clear_unstored">
                    <input type="hidden" name="parked" value="<?php echo esc_attr($record['parked']['id']); ?>">
                    <?php wp_nonce_field('pebkac_backup_clear_unstored_' . $record['parked']['id']); ?>
                    <button class="button" type="submit">Clear earlier temporary files</button>
                </form>
            <?php endif; ?>
        </details>
    </section>
    <?php
}
