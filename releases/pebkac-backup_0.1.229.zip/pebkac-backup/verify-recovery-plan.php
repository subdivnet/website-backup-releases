<?php

namespace PEBKAC404\Backup;

if (PHP_SAPI !== 'cli') {
    return;
}

require_once __DIR__ . '/backup-incremental.php';

/** Stage verified component files under a new private directory. No recovered code or SQL runs. */
function stage_local_recovery_plan(array $files, string $site, string $destination, array $points = [], bool $assemble = false): void {
    if (!class_exists(\ZipArchive::class)) {
        throw new \RuntimeException('The PHP ZIP extension is required to stage a restore.');
    }
    $parent = realpath(dirname($destination));
    $name = basename($destination);
    if ($parent === false || !is_dir($parent) || is_link(dirname($destination))
        || !preg_match('/^[a-zA-Z0-9][a-zA-Z0-9_.-]*$/D', $name)
        || !valid_snapshot_member_name('wordpress/' . $name, null)) {
        throw new \RuntimeException('Choose a new restore directory under an existing private directory.');
    }
    $destination = $parent . DIRECTORY_SEPARATOR . $name;
    if (!@mkdir($destination, 0700)) {
        throw new \RuntimeException('The restore directory already exists or could not be created.');
    }
    $incomplete = $destination . '/INCOMPLETE';
    if (@file_put_contents($incomplete, "A restore check is incomplete until this file disappears.\n") === false) {
        throw new \RuntimeException('Could not reserve the isolated restore directory.');
    }
    $receipts = [];
    $written = [];
    try {
        $combined = $assemble && !isset($files['full']) ? $destination . '/site' : '';
        $moved = [];
        if ($combined !== '' && !@mkdir($combined, 0700)) {
            throw new \RuntimeException('Could not reserve the combined restore tree.');
        }
        foreach ($files as $component => $pairs) {
            $steps = [];
            $fingerprints = [];
            foreach ($pairs as $pair) {
                $manifest_path = $pair['manifest']['path'];
                $manifest_bytes = !is_link($manifest_path) && is_file($manifest_path)
                    ? @file_get_contents($manifest_path, false, null, 0, $pair['manifest']['bytes'] + 1) : false;
                $archive_path = $pair['archive']['path'];
                if (is_link($archive_path) || !is_file($archive_path)) {
                    throw new \RuntimeException('Choose a regular file for each recovery ZIP.');
                }
                $manifest = $manifest_bytes !== false && hash('sha256', $manifest_bytes) === $pair['manifest']['sha256']
                    ? json_decode($manifest_bytes, true, 512) : null;
                $manifest_component = $steps === [] ? ($manifest['component'] ?? null) : ($manifest['delta']['component'] ?? null);
                if (!is_array($manifest) || ($manifest['archive_sha256'] ?? null) !== $pair['archive']['sha256']
                    || $manifest_component !== ($component === 'full' ? null : $component)) {
                    throw new \RuntimeException('A recovery manifest does not describe the expected component ZIP.');
                }
                $steps[] = ['archive' => $archive_path, 'manifest' => $manifest];
                $fingerprints[] = ['archive_sha256' => $pair['archive']['sha256'], 'manifest_sha256' => $pair['manifest']['sha256']];
            }
            $baseline = array_shift($steps);
            if ($component === 'full') {
                stage_snapshot_restore($baseline['archive'], $baseline['manifest'], $destination . '/site');
                continue;
            }
            $component_directory = $destination . '/' . $component;
            if ($component === 'database') {
                stage_snapshot_restore($baseline['archive'], $baseline['manifest'], $component_directory, $component);
                $inventory = array_diff_key($baseline['manifest']['files'], ['component.json' => true]);
            } else {
                $restored = stage_incremental_file_restore($baseline['archive'], $baseline['manifest'], $steps, $component_directory);
                $inventory = $restored['files'];
            }
            if ($combined !== '') {
                combine_staged_component($component, $inventory, $component_directory, $combined, $moved);
            }
            $receipt = [
                'kind' => 'component_restore', 'method' => 'isolated_component_staging', 'site' => $site,
                'component' => $component, 'verified_at' => time(), 'file_count' => count($inventory), 'chain' => $fingerprints,
            ];
            if (isset($points[$component])) {
                $receipt['point'] = $points[$component];
            }
            $receipts[$component_directory . '/component-restore-receipt.json'] = json_encode($receipt, JSON_UNESCAPED_SLASHES | JSON_THROW_ON_ERROR) . PHP_EOL;
        }
        foreach ($receipts as $path => $receipt) {
            $stream = @fopen($path, 'xb');
            if ($stream === false) {
                throw new \RuntimeException('Could not reserve a component restore receipt.');
            }
            $written[] = $path;
            $saved = fwrite($stream, $receipt) === strlen($receipt);
            if (!fclose($stream) || !$saved) {
                throw new \RuntimeException('Could not save a component restore receipt.');
            }
        }
        if (!@unlink($incomplete)) {
            throw new \RuntimeException('Could not clear the incomplete marker.');
        }
    } catch (\Throwable $error) {
        foreach ($written as $path) {
            @unlink($path);
        }
        throw new \RuntimeException('Staging stopped. The new directory is marked incomplete. ' . $error->getMessage(), 0, $error);
    }
    $description = isset($files['full']) ? 'the full backup' : count($files) . ' components';
    echo 'Staged and verified ' . $description . '. No recovered PHP or SQL ran.' . PHP_EOL;
    if ($assemble) {
        echo 'The verified files are together in the site folder.' . PHP_EOL;
    }
}

/** Move checked files within the new private restore tree while preserving their relative paths. */
function combine_staged_component(string $component, array $files, string $source, string $destination, array &$moved): void {
    foreach ($files as $member => $pin) {
        $key = strtolower($member);
        if (!valid_snapshot_member_name($member, $component) || isset($moved[$key])) {
            throw new \RuntimeException('Two recovery files have a conflicting path.');
        }
        $input = $source . '/' . $member;
        $output = $destination . '/' . $member;
        $parent = dirname($output);
        if (is_link($input) || !is_file($input) || file_exists($output) || is_link($output)
            || (!is_dir($parent) && !@mkdir($parent, 0700, true)) || !@rename($input, $output)
            || @filesize($output) !== $pin['size'] || @hash_file('sha256', $output) !== $pin['sha256']) {
            throw new \RuntimeException('A checked recovery file could not be placed in the combined tree.');
        }
        $moved[$key] = true;
    }
}

/** Verify and stage a matching full ZIP and companion manifest when WordPress is unavailable. */
function stage_local_full_recovery_pair(string $archive, string $manifest_path, string $destination): void {
    $archive_size = is_file($archive) && !is_link($archive) ? @filesize($archive) : false;
    $bytes = is_file($manifest_path) && !is_link($manifest_path)
        ? @file_get_contents($manifest_path, false, null, 0, SNAPSHOT_MAX_MANIFEST_BYTES + 1) : false;
    $manifest = is_string($bytes) && strlen($bytes) <= SNAPSHOT_MAX_MANIFEST_BYTES ? json_decode($bytes, true) : null;
    $digest = $manifest['archive_sha256'] ?? null;
    if ($archive_size === false || $archive_size < 1 || $archive_size > SNAPSHOT_MAX_BYTES + 8 * 1024 * 1024
        || !is_array($manifest) || isset($manifest['component']) || !is_array($manifest['files'] ?? null)
        || !is_string($digest) || !preg_match('/^[a-f0-9]{64}$/D', $digest)) {
        throw new \RuntimeException('Choose the full backup ZIP and the companion restore manifest from the same backup.');
    }
    $pair = [
        'archive' => ['path' => $archive, 'bytes' => $archive_size, 'sha256' => $digest],
        'manifest' => ['path' => $manifest_path, 'bytes' => strlen($bytes), 'sha256' => hash('sha256', $bytes)],
    ];
    stage_local_recovery_plan(['full' => [$pair]], '', $destination);
    echo 'The ZIP and companion manifest match. A saved recovery plan can also confirm the backup’s identity.' . PHP_EOL;
}

try {
    umask(0077);
    if ($argc === 5 && $argv[1] === '--full-pair') {
        stage_local_full_recovery_pair($argv[2], $argv[3], $argv[4]);
        exit(0);
    }
    $standalone = $argc === 5 && $argv[3] === '--standalone';
    $stage = $argc === 5 && in_array($argv[3], ['--stage', '--assemble'], true);
    $assemble = $stage && $argv[3] === '--assemble';
    if ($argc !== 3 && !$stage && !$standalone) {
        throw new \RuntimeException('php verify-recovery-plan.php RECOVERY_PLAN_JSON DOWNLOAD_DIRECTORY [--stage|--assemble NEW_RESTORE_DIRECTORY | --standalone NEW_ZIP]'
            . PHP_EOL . 'php verify-recovery-plan.php --full-pair BACKUP_ZIP RESTORE_MANIFEST NEW_RESTORE_DIRECTORY');
    }
    [, $plan_file, $downloads] = $argv;
    $directory = realpath($downloads);
    if ($directory === false || !is_dir($directory) || is_link($downloads) || !is_file($plan_file) || is_link($plan_file)) {
        throw new \RuntimeException('Choose a saved recovery plan and its download directory.');
    }
    $limit = 64 * 1024;
    $bytes = @file_get_contents($plan_file, false, null, 0, $limit + 1);
    $plan = $bytes !== false && strlen($bytes) <= $limit ? json_decode($bytes, true, 12) : null;
    $site = $plan['site'] ?? null;
    $full = ($plan['kind'] ?? null) === 'full_backup';
    $point = $plan['point'] ?? null;
    $components = $full ? ['full' => [$plan['files'] ?? null]] : ($plan['components'] ?? null);
    if (($plan['schema'] ?? null) !== 1 || !is_string($site) || pilot_site_slug($site) === ''
        || !is_array($components) || $components === []
        || ($full ? (!is_string($point) || !preg_match('/^[a-f0-9]{12}$/D', $point))
            : array_diff_key($components, SNAPSHOT_COMPONENT_DIRECTORIES) !== [])) {
        throw new \RuntimeException('This is not a supported Website Backup recovery plan.');
    }
    if ($assemble && !$full && (!isset($components['database']) || !isset($components['core']))) {
        throw new \RuntimeException('The combined site folder needs a verified Database copy and WordPress core copy.');
    }
    $component_points = $plan['component_points'] ?? [];
    if (!is_array($component_points) || ($component_points !== [] && ($full
        || array_diff_key($components, $component_points) !== [] || array_diff_key($component_points, $components) !== []))) {
        throw new \RuntimeException('The plan does not identify the requested component recovery points.');
    }
    foreach ($component_points as $identity) {
        if (!is_string($identity) || !preg_match('/^[a-f0-9]{64}$/D', $identity)) {
            throw new \RuntimeException('The plan contains an invalid component recovery point.');
        }
    }

    $verified = 0;
    $verified_files = [];
    foreach ($components as $component => $pairs) {
        if (!is_array($pairs) || array_values($pairs) !== $pairs || $pairs === [] || count($pairs) > COMPONENT_REPLAY_MAX_MANIFESTS
            || ($component === 'database' && count($pairs) !== 1)) {
            throw new \RuntimeException('The plan contains an invalid component recovery order.');
        }
        foreach ($pairs as $index => $pair) {
            $prefix = $full ? pilot_site_slug($site) . '-' . $point : component_recovery_file_prefix($site, $component, $index + 1);
            foreach (['archive' => SNAPSHOT_MAX_BYTES + 8 * 1024 * 1024, 'manifest' => SNAPSHOT_MAX_MANIFEST_BYTES] as $object => $maximum) {
                $name = recovery_filename($prefix, $object);
                $expected = $pair[$object] ?? null;
                $size = $expected['bytes'] ?? null;
                $digest = $expected['sha256'] ?? null;
                $size_known = $size !== null;
                if (($expected['name'] ?? null) !== $name || (!$size_known && !$full)
                    || ($size_known && (!is_int($size) || $size < 1 || $size > $maximum))
                    || !is_string($digest) || !preg_match('/^[a-f0-9]{64}$/D', $digest)) {
                    throw new \RuntimeException('The plan contains invalid details for ' . $name . '.');
                }
                $path = $directory . DIRECTORY_SEPARATOR . $name;
                $actual_size = is_file($path) && !is_link($path) ? @filesize($path) : false;
                if ($actual_size === false || $actual_size < 1 || $actual_size > $maximum
                    || ($size_known && $actual_size !== $size) || @hash_file('sha256', $path) !== $digest) {
                    throw new \RuntimeException($name . ' is missing or does not match the recovery plan.');
                }
                $verified_files[$component][$index][$object] = ['path' => $path, 'bytes' => $actual_size, 'sha256' => $digest];
                $verified++;
            }
        }
    }

    echo 'Verified ' . $verified . ' files against the recovery plan for ' . $site . '.' . PHP_EOL;
    if ($standalone) {
        if ($full || count($verified_files) !== 1 || isset($verified_files['database'])) {
            throw new \RuntimeException('A standalone export needs one complete file-component recovery plan.');
        }
        $output_parent = realpath(dirname($argv[4]));
        $output_name = basename($argv[4]);
        if ($output_parent === false || is_link(dirname($argv[4])) || !preg_match('/^[a-zA-Z0-9][a-zA-Z0-9_.-]*\.zip$/D', $output_name)) {
            throw new \RuntimeException('Choose a new ZIP in an existing private directory.');
        }
        $output = $output_parent . DIRECTORY_SEPARATOR . $output_name;
        $sidecar = $output . '.manifest.json';
        if (file_exists($output) || is_link($output) || file_exists($sidecar) || is_link($sidecar)) {
            throw new \RuntimeException('The standalone output already exists. Choose a new filename.');
        }
        $component = array_keys($verified_files)[0];
        $steps = [];
        foreach ($verified_files[$component] as $pair) {
            $manifest_bytes = @file_get_contents($pair['manifest']['path'],false,null,0,$pair['manifest']['bytes']+1);
            if (!is_string($manifest_bytes) || hash('sha256',$manifest_bytes) !== $pair['manifest']['sha256']) {
                throw new \RuntimeException('A standalone input manifest changed after verification.');
            }
            $steps[] = ['archive'=>$pair['archive']['path'], 'manifest'=>json_decode($manifest_bytes,true,512,JSON_THROW_ON_ERROR)];
        }
        $baseline = array_shift($steps);
        $temporary = $output_parent . DIRECTORY_SEPARATOR . 'standalone-' . bin2hex(random_bytes(16));
        $reserved = false;
        $archive_created = false;
        try {
            $sealed = package_standalone_file_point($baseline['archive'],$baseline['manifest'],$steps,$temporary,$output,microtime(true)+120);
            $archive_created = true;
            $stream = @fopen($sidecar,'xb');
            if ($stream === false) { throw new \RuntimeException('Could not reserve the standalone recovery manifest.'); }
            $reserved = true;
            $bytes = json_encode($sealed,JSON_THROW_ON_ERROR);
            $saved = fwrite($stream,$bytes) === strlen($bytes);
            $closed = fclose($stream);
            if (!$saved || !$closed) { throw new \RuntimeException('Could not save the standalone recovery manifest.'); }
            echo 'Standalone ' . $component . ' recovery point: ' . filesize($output) . ' bytes; SHA-256 ' . $sealed['archive_sha256'] . '. No earlier recovery point is needed to restore this ZIP and manifest.' . PHP_EOL;
        } catch (\Throwable $error) {
            if ($archive_created) { @unlink($output); }
            if ($reserved) { @unlink($sidecar); }
            throw $error;
        } finally {
            if (is_dir($temporary) && !is_link($temporary)) {
                $children = new \RecursiveIteratorIterator(new \RecursiveDirectoryIterator($temporary,\FilesystemIterator::SKIP_DOTS),\RecursiveIteratorIterator::CHILD_FIRST);
                foreach ($children as $child) {
                    if ($child->isDir() && !$child->isLink()) { if (!@rmdir($child->getPathname())) { throw new \RuntimeException('Standalone staging cleanup is incomplete.'); } }
                    elseif (!@unlink($child->getPathname())) { throw new \RuntimeException('Standalone staging cleanup is incomplete.'); }
                }
                if (!@rmdir($temporary)) { throw new \RuntimeException('Standalone staging cleanup is incomplete.'); }
            }
        }
    }
    if ($stage) {
        stage_local_recovery_plan($verified_files, $site, $argv[4], $component_points, $assemble);
    }
    $missing = $full ? [] : array_diff_key(SNAPSHOT_COMPONENT_DIRECTORIES, $components);
    if ($missing !== []) {
        echo 'Components without files in this plan: ' . implode(', ', array_keys($missing)) . '.' . PHP_EOL;
    }
} catch (\RuntimeException $error) {
    fwrite(STDERR, $error->getMessage() . PHP_EOL);
    exit(1);
}
