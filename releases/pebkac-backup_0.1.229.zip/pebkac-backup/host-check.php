<?php

namespace PEBKAC404\Backup;

if (!defined('ABSPATH')) {
    exit;
}

const HOST_CHECK_OPTION = 'pebkac_backup_host_check';
const BACKUP_QUEUE_DELAY_SECONDS = 300;

/** Use PHP's temporary volume only if it is outside the public site trees. */
function backup_temp_parent(): string {
    $temp = realpath(sys_get_temp_dir());
    $root = realpath(ABSPATH);
    $document_root = (string) ($_SERVER['DOCUMENT_ROOT'] ?? '');
    $document = $document_root === '' ? false : realpath($document_root);
    if ($temp === false || $root === false || ($document_root !== '' && $document === false)
        || !is_dir($temp) || !is_writable($temp)) {
        return '';
    }
    $normalize = static function (string $path): string { return rtrim(str_replace('\\', '/', $path), '/') . '/'; };
    foreach (array_filter([$root, $document]) as $public_root) {
        if (stripos($normalize($temp), $normalize($public_root)) === 0) {
            return '';
        }
    }
    return $temp;
}

function backup_host_limits(): array {
    $temp = backup_temp_parent();
    $free = $temp === '' ? false : @disk_free_space($temp);
    return [
        'staging_free' => $free === false ? null : $free,
        'memory' => ini_get('memory_limit'),
        'execution' => ini_get('max_execution_time'),
        'zip' => class_exists(\ZipArchive::class),
        'zip_deadline' => backup_capture_supported(),
    ];
}

/** Report the actual WordPress queue separately from the dates a backup is due. */
function backup_host_queue(array $plan): array {
    $queue = [];
    if (daily_backup_settings($plan)['enabled']) {
        $queue['Daily full backup'] = wp_next_scheduled(DAILY_BACKUP_HOOK);
    }
    if (component_backups_enabled($plan)) {
        $queue['Component backups'] = wp_next_scheduled(COMPONENT_BACKUP_HOOK);
    }
    if (expected_full_recovery_readback_at(time()) !== null) {
        $queue['Dropbox recovery file check'] = wp_next_scheduled(FULL_RECOVERY_READBACK_HOOK);
    }
    $records = component_readback_records();
    if (in_array('checking', array_column($records, 'state'), true)
        || next_automatic_component_readback(home_url(), $records, time()) !== []) {
        $queue['Dropbox component file check'] = wp_next_scheduled(COMPONENT_READBACK_HOOK);
    }
    if (automatic_backup_retention_enabled($plan) && get_option(BACKUP_RETENTION_JOURNAL_OPTION, []) !== []) {
        $queue['Dropbox cleanup check'] = wp_next_scheduled(BACKUP_RETENTION_HOOK);
    }
    return $queue;
}

/** Count candidate files and bytes from filesystem metadata within the time and entry caps. */
function count_backup_files(array $roots, int $limit = 20000, float $seconds = 1.5, array $root_components = []): array {
    $deadline = microtime(true) + $seconds;
    $files = 0;
    $bytes = 0;
    $entries = 0;
    $complete = true;
    $components = [];
    $component_counts = [];
    $largest_media = 0;
    foreach ($roots as $root) {
        $component = $root_components[$root] ?? '';
        if (is_link($root)) {
            $complete = false;
            continue;
        }
        if (!is_dir($root)) {
            continue;
        }
        try {
            $tree = new \RecursiveIteratorIterator(new \RecursiveDirectoryIterator($root, \FilesystemIterator::SKIP_DOTS), \RecursiveIteratorIterator::SELF_FIRST);
            foreach ($tree as $entry) {
                if (++$entries > $limit || microtime(true) >= $deadline) {
                    $complete = false;
                    break 2;
                }
                if ($entry->isLink()) {
                    $complete = false;
                } elseif ($entry->isFile()) {
                    $size = $entry->getSize();
                    if ($size === false || $size < 0 || $size > PHP_INT_MAX - $bytes) {
                        $complete = false;
                        continue;
                    }
                    ++$files;
                    $bytes += $size;
                    if ($component !== '') {
                        $components[$component] = ($components[$component] ?? 0) + $size;
                        $component_counts[$component] = ($component_counts[$component] ?? 0) + 1;
                    }
                    if ($component === 'uploads') {
                        $largest_media = max($largest_media, $size);
                    }
                }
            }
        } catch (\RuntimeException $error) {
            $complete = false;
        }
    }
    $result = ['files' => $files, 'bytes' => $bytes, 'complete' => $complete];
    if ($root_components !== []) {
        $result['component_bytes'] = $components;
        $result['component_files'] = $component_counts;
        $result['largest_media_bytes'] = $largest_media;
    }
    return $result;
}

/** Read only estimated table data size for this WordPress site. */
function estimate_backup_database(\wpdb $db): ?array {
    if ($db->prefix === '') {
        return null;
    }
    $suppress = $db->suppress_errors(true);
    try {
        $row = $db->get_row($db->prepare(
            "SELECT COUNT(*) AS table_count, COALESCE(SUM(DATA_LENGTH), 0) AS data_bytes FROM information_schema.TABLES
             WHERE TABLE_SCHEMA = DATABASE() AND TABLE_TYPE = 'BASE TABLE' AND TABLE_NAME LIKE %s",
            $db->esc_like($db->prefix) . '%'
        ), ARRAY_A);
    } finally {
        $db->suppress_errors($suppress);
    }
    $tables = filter_var($row['table_count'] ?? null, FILTER_VALIDATE_INT, ['options' => ['min_range' => 1]]);
    $bytes = filter_var($row['data_bytes'] ?? null, FILTER_VALIDATE_INT, ['options' => ['min_range' => 0]]);
    return $tables !== false && $bytes !== false ? ['tables' => $tables, 'bytes' => $bytes] : null;
}

add_action('admin_post_pebkac_backup_host_check', static function () {
    global $wpdb;
    if (($_SERVER['REQUEST_METHOD'] ?? '') !== 'POST' || !current_user_can('manage_options')) {
        wp_die('An administrator must run the host check.', '', ['response' => 403]);
    }
    check_admin_referer('pebkac_backup_host_check');
    $root_components = [];
    foreach (SNAPSHOT_COMPONENT_DIRECTORIES as $component => $directories) {
        foreach ($directories as $directory) {
            $root_components[ABSPATH . $directory] = $component;
        }
    }
    $result = count_backup_files(array_keys($root_components), SNAPSHOT_MAX_FILES + 1, 1.5, $root_components);
    $result['database'] = estimate_backup_database($wpdb);
    $result['checked_at'] = time();
    update_option(HOST_CHECK_OPTION, $result, false);
    wp_safe_redirect(admin_url('admin.php?page=pebkac-backup'), 303);
    exit;
});

function render_host_check(): void {
    $limits = backup_host_limits();
    $count = get_option(HOST_CHECK_OPTION, []);
    $checked_bytes = $count['bytes'] ?? null;
    $largest_media = $count['largest_media_bytes'] ?? null;
    $database = $count['database'] ?? null;
    $large_database = is_int($database['bytes'] ?? null) && $database['bytes'] > BACKUP_SQL_MAX;
    $too_many_tables = is_int($database['tables'] ?? null) && $database['tables'] > BACKUP_DATABASE_MAX_TABLES;
    $plan = get_plan();
    $component_only = component_only_backups_enabled($plan);
    $now = time();
    $timezone = wp_timezone();
    if ($component_only && component_schedule_rules($plan['schedules']['database'] ?? null, $timezone, $now) === null) {
        $large_database = false;
        $too_many_tables = false;
    }
    $component_sizes = is_array($count['component_bytes'] ?? null) ? $count['component_bytes'] : [];
    $component_counts = is_array($count['component_files'] ?? null) ? $count['component_files'] : [];
    $oversized_components = [];
    $overcounted_components = [];
    $over_limit = ($count['files'] ?? 0) > SNAPSHOT_MAX_FILES
        || (is_int($checked_bytes) && $checked_bytes > SNAPSHOT_MAX_BYTES);
    $required = SNAPSHOT_MIN_STAGING_BYTES;
    if ($component_only) {
        $over_limit = false;
        foreach ($plan['schedules'] as $component => $schedule) {
            if (!isset(COMPONENTS[$component]) || component_schedule_rules($schedule, $timezone, $now) === null) {
                continue;
            }
            $bytes = $component_sizes[$component] ?? null;
            if (is_int($component_counts[$component] ?? null) && $component_counts[$component] > SNAPSHOT_MAX_FILES) {
                $overcounted_components[] = COMPONENTS[$component];
            }
            if (is_int($bytes) && $bytes > SNAPSHOT_MAX_BYTES) {
                $oversized_components[] = COMPONENTS[$component];
            } elseif (is_int($bytes) && $bytes >= 0) {
                $required = max($required, snapshot_staging_bytes($bytes));
            }
        }
    } elseif (!$over_limit && is_int($checked_bytes) && $checked_bytes >= 0) {
        $required = max($required, snapshot_staging_bytes($checked_bytes));
    }
    $can_stage = $limits['staging_free'] !== null && $limits['staging_free'] >= $required;
    $queue = backup_host_queue($plan);
    $missing_event = in_array(false, $queue, true);
    $delay_before = time() - BACKUP_QUEUE_DELAY_SECONDS;
    $delayed_events = array_filter($queue, static function ($at) use ($delay_before): bool {
        return is_int($at) && $at <= $delay_before;
    });
    $standard_content = !defined('WP_CONTENT_DIR') || wordpress_content_uses_standard_path(ABSPATH, WP_CONTENT_DIR);
    ?>
    <section class="notice inline <?php echo $limits['zip_deadline'] && $can_stage && !$over_limit && $oversized_components === []
        && $overcounted_components === [] && !$large_database && !$too_many_tables && !$missing_event && $delayed_events === [] && $standard_content ? 'notice-info' : 'notice-warning'; ?>">
        <h2>Host readiness</h2>
        <?php if (!$limits['zip_deadline']) : ?>
            <p><?php echo $limits['zip']
                ? 'This host cannot enforce the time limit needed to create backup ZIPs.'
                : 'This host needs PHP ZIP support to create backups.'; ?></p>
        <?php endif; ?>
        <?php if (!$standard_content) : ?>
            <p>This site uses a custom WordPress content folder. This version cannot capture that layout.</p>
        <?php endif; ?>
        <?php if ($over_limit) : ?>
            <p>The files checked already exceed the full backup limit, before adding the database.</p>
        <?php endif; ?>
        <?php if ($oversized_components !== []) : ?>
            <p><?php echo esc_html('These scheduled components exceed their own backup size limit. ' . implode(', ', $oversized_components) . '.'); ?></p>
        <?php endif; ?>
        <?php if ($overcounted_components !== []) : ?>
            <p><?php echo esc_html('These scheduled components exceed their own file count limit. ' . implode(', ', $overcounted_components) . '.'); ?></p>
        <?php endif; ?>
        <?php if ($large_database) : ?>
            <p>The estimated database data exceeds the current SQL export limit.</p>
        <?php endif; ?>
        <?php if ($too_many_tables) : ?>
            <p>WordPress found more site database tables than this version can export.</p>
        <?php endif; ?>
        <?php if ($delayed_events !== []) : ?>
            <p>WordPress has a backup event waiting to run past its scheduled time.</p>
        <?php endif; ?>
        <?php if ($missing_event) : ?>
            <p>WordPress is missing a scheduled backup or recovery check.</p>
        <?php endif; ?>
        <details><summary>Show details</summary>
            <p>Temporary backup space: <?php echo esc_html($limits['staging_free'] === null ? 'Unavailable' : size_format($limits['staging_free'], 1)); ?>.</p>
            <?php if ($required > SNAPSHOT_MIN_STAGING_BYTES) : ?>
                <p><?php echo esc_html($component_only
                    ? 'The largest scheduled file component needs at least ' . size_format($required, 1) . ' of temporary space for the files counted.'
                    : 'A full backup needs at least ' . size_format($required, 1) . ' of temporary space for the files counted. The database adds to that requirement.'); ?></p>
            <?php endif; ?>
            <?php if ($limits['staging_free'] !== null && !$can_stage) : ?>
                <p><?php echo $component_only ? 'The available temporary space is below the minimum for the scheduled backups.'
                    : 'The available temporary space is below the minimum for a full backup.'; ?></p>
            <?php endif; ?>
            <p>PHP memory limit: <?php echo esc_html((string) $limits['memory']); ?>. Time limit: <?php echo esc_html($limits['execution'] === '0' ? 'No PHP limit' : $limits['execution'] . ' seconds'); ?>. ZIP support: <?php echo $limits['zip'] ? 'Available' : 'Unavailable'; ?>.</p>
            <?php if (isset($count['files'], $count['checked_at'])) : ?>
                <p><?php echo esc_html(($count['complete'] ? '' : 'At least ') . number_format_i18n($count['files']) . ' files checked in standard WordPress folders on ' . wp_date('M j, Y H:i T', $count['checked_at'])); ?>.</p>
            <?php else : ?><p>File count has not been checked yet.</p><?php endif; ?>
            <?php if (is_int($checked_bytes) && $checked_bytes >= 0) : ?>
                <p><?php echo esc_html(($count['complete'] ? '' : 'At least ') . size_format($checked_bytes, 1) . ' in the folders checked, before adding the database.'); ?></p>
            <?php endif; ?>
            <?php if (is_int($database['tables'] ?? null) && $database['tables'] > 0 && is_int($database['bytes'] ?? null) && $database['bytes'] >= 0) : ?>
                <p><?php echo esc_html('WordPress found ' . number_format_i18n($database['tables']) . ' site database tables with about '
                    . size_format($database['bytes'], 1) . ' of data. The exported file size can differ.'); ?></p>
            <?php elseif (is_array($count) && array_key_exists('database', $count)) : ?>
                <p>WordPress could not estimate the size of the site database.</p>
            <?php endif; ?>
            <?php if (!empty($count['component_bytes'])) : ?>
                <ul>
                <?php foreach ($count['component_bytes'] as $component => $bytes) : ?>
                    <?php if (isset(COMPONENTS[$component]) && is_int($bytes) && $bytes >= 0) : ?>
                        <li><?php echo esc_html(COMPONENTS[$component] . ' · ' . ($count['complete'] ? '' : 'at least ') . size_format($bytes, 1)); ?><?php if ($bytes > SNAPSHOT_MAX_BYTES) : ?>. This component also exceeds its own backup size limit.<?php endif; ?></li>
                    <?php endif; ?>
                <?php endforeach; ?>
                </ul>
            <?php endif; ?>
            <?php if (is_int($largest_media) && $largest_media > 0) : ?>
                <p><?php echo esc_html('Largest media file checked was ' . size_format($largest_media, 1) . '.'); ?>
                    <?php if ($largest_media > SNAPSHOT_MAX_BYTES) : ?>This file alone exceeds the current media backup limit.<?php endif; ?></p>
            <?php endif; ?>
            <p><?php echo esc_html('Full backup limit ' . number_format_i18n(SNAPSHOT_MAX_FILES) . ' files and ' . size_format(SNAPSHOT_MAX_BYTES, 0) . ' of source data.'); ?></p>
            <p><?php echo esc_html('Database export limit ' . size_format(BACKUP_SQL_MAX, 0) . ' of SQL and '
                . number_format_i18n(BACKUP_DATABASE_MAX_TABLES) . ' site tables.'); ?></p>
            <?php if ($queue !== []) : ?>
                <p><?php echo defined('DISABLE_WP_CRON') && DISABLE_WP_CRON
                    ? 'Site visits do not trigger scheduled WordPress tasks on this site.'
                    : 'WordPress uses site visits to start scheduled tasks.'; ?></p>
                <?php foreach ($queue as $label => $at) : ?>
                    <?php
                    $queue_detail = ' has no event queued in WordPress.';
                    if ($at !== false) {
                        $queue_detail = (isset($delayed_events[$label]) ? ' is still queued for ' : ' has a WordPress event queued for ')
                            . wp_date('M j, Y H:i T', $at) . '.';
                    }
                    ?>
                    <p><?php echo esc_html($label . $queue_detail); ?></p>
                <?php endforeach; ?>
            <?php endif; ?>
            <form action="<?php echo esc_url(admin_url('admin-post.php')); ?>" method="post">
                <input type="hidden" name="action" value="pebkac_backup_host_check">
                <?php wp_nonce_field('pebkac_backup_host_check'); ?>
                <button type="submit" class="button">Check files and database</button>
            </form>
        </details>
    </section>
    <?php
}
