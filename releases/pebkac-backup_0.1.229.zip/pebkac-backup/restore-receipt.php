<?php

namespace PEBKAC404\Backup;

if (!defined('ABSPATH')) {
    exit;
}

/** Bind a completed local test to the current off-site copy. Caller holds the backup lock. */
function accept_restore_receipt($receipt, array $backup, int $now): array {
    $checked = $receipt['verified_at'] ?? null;
    if (!full_restore_receipt_matches($receipt, $backup)
        || ($receipt['method'] ?? null) !== 'isolated_wordpress'
        || (array_key_exists('site', $receipt) && $receipt['site'] !== ($backup['site'] ?? null))
        || !is_int($checked) || $checked < $backup['offsite_verified_at'] || $checked > $now
        || $checked < ($backup['restore']['verified_at'] ?? 0)
        || ($receipt['wordpress_booted'] ?? null) !== true
        || ($receipt['home_page_rendered'] ?? null) !== true) {
        throw new \RuntimeException('This receipt does not match a completed test of the matching Dropbox backup.');
    }

    $backup['restore'] = [
        'archive_sha256' => $backup['archive_sha256'],
        'method' => 'isolated_wordpress',
        'verified_at' => $checked,
    ];
    return $backup;
}

function full_restore_receipt_matches($receipt, array $backup): bool {
    return is_array($receipt) && isset($backup['archive_sha256'], $backup['manifest_sha256'])
        && ($receipt['archive_sha256'] ?? null) === $backup['archive_sha256']
        && ($receipt['manifest_sha256'] ?? null) === $backup['manifest_sha256'];
}

/** Record an isolated restore of the current backup or an earlier retained set. Caller holds the backup lock. */
function record_full_restore_receipt($receipt, string $site, int $now): void {
    $latest = verified_evidence(get_option(EVIDENCE_OPTION, []), $site, $now);
    if (full_restore_receipt_matches($receipt, $latest)) {
        $updated = accept_restore_receipt($receipt, $latest, $now);
        remember_verified_backups([$updated], $site, $now);
        if ($updated !== $latest && !update_option(EVIDENCE_OPTION, $updated, false)) {
            throw new \RuntimeException('Could not save the restore test result.');
        }
        // A newer passing restore can release the previously protected recovery point.
        queue_backup_retention_event();
        return;
    }

    $earlier = available_earlier_full_backups($latest, $site, $now);
    $matches = array_values(array_filter($earlier, static function (array $backup) use ($receipt): bool {
        return full_restore_receipt_matches($receipt, $backup);
    }));
    if (count($matches) !== 1) {
        throw new \RuntimeException('This receipt does not identify one available Dropbox backup.');
    }
    remember_verified_backups([accept_restore_receipt($receipt, $matches[0], $now)], $site, $now);
    queue_backup_retention_event();
}

const COMPONENT_RESTORE_OPTION = 'pebkac_backup_component_restore';
const COMPONENT_EARLIER_RESTORE_OPTION = 'pebkac_backup_earlier_component_restore';

function component_restore_chain_fingerprints(array $chain): array {
    return array_map(static function (array $record): array {
        return ['archive_sha256' => $record['archive_sha256'], 'manifest_sha256' => $record['manifest_sha256']];
    }, $chain);
}

/** Match a saved file check to the currently verified component chain. */
function component_restore_check_result(string $site, array $chain, $saved, int $now): ?array {
    $checked = $saved['verified_at'] ?? null;
    $digest = $saved['chain_sha256'] ?? null;
    if ($chain === [] || ($saved['site'] ?? null) !== $site || ($saved['method'] ?? null) !== 'isolated_component_staging'
        || !is_int($checked) || $checked < 1 || $checked > $now || !is_string($digest) || !preg_match('/^[a-f0-9]{64}$/D', $digest)) {
        return null;
    }
    $current = hash('sha256', json_encode(component_restore_chain_fingerprints($chain), JSON_THROW_ON_ERROR));
    if (hash_equals($current, $digest) && ($saved['archive_path'] ?? null) === $chain[count($chain) - 1]['archive_path']) {
        return $checked >= $chain[count($chain) - 1]['offsite_verified_at'] ? ['verified_at' => $checked, 'matches_latest' => true] : null;
    }
    return ['verified_at' => $checked, 'matches_latest' => false];
}

function component_restore_check_label(string $site, array $chain, $saved, int $now): string {
    $check = component_restore_check_result($site, $chain, $saved, $now);
    if ($check === null) {
        return 'Waiting for a restore check.';
    }
    $date = wp_date('M j, Y H:i T', $check['verified_at']);
    return $check['matches_latest'] ? 'Isolated file check passed on ' . $date . '.'
        : 'Latest backup is waiting for a check. Earlier file check passed on ' . $date . '.';
}

/** Store a component staging result separately from the immutable off-site backup chain. Caller holds the backup lock. */
function record_component_restore_receipt(array $receipt, string $site, int $now): void {
    $component = $receipt['component'] ?? null;
    $checked = $receipt['verified_at'] ?? null;
    $count = $receipt['file_count'] ?? null;
    $point = $receipt['point'] ?? null;
    if (($receipt['kind'] ?? null) !== 'component_restore' || ($receipt['method'] ?? null) !== 'isolated_component_staging'
        || ($receipt['site'] ?? null) !== $site || !is_string($component) || !isset(COMPONENTS[$component])
        || !is_int($checked) || $checked > $now || !is_int($count) || $count < 0 || $count > SNAPSHOT_MAX_FILES
        || ($component === 'database' && $count !== 1)
        || (array_key_exists('point', $receipt) && (!is_string($point) || !preg_match('/^[a-f0-9]{64}$/D', $point)))) {
        throw new \RuntimeException('This receipt does not match a completed component restore check.');
    }
    $history = get_option(COMPONENT_RECOVERY_STATE_OPTION, []);
    $chain = is_array($history) ? component_recovery_chain($site, $component, $history, $now) : [];
    $option = COMPONENT_RESTORE_OPTION;
    if ($point !== null && $chain !== [] && !hash_equals(recovery_download_id($chain[count($chain) - 1]), $point)) {
        $kept = retained_component_recovery_records($site, $history, $now);
        $chain = retained_component_chain_at($site, $point, $history, $kept, $now);
        $option = COMPONENT_EARLIER_RESTORE_OPTION;
    }
    $fingerprints = component_restore_chain_fingerprints($chain);
    if ($chain === [] || $chain[0]['component'] !== $component || ($receipt['chain'] ?? null) !== $fingerprints
        || $checked < $chain[count($chain) - 1]['offsite_verified_at']) {
        throw new \RuntimeException('This receipt does not match a verified component backup chain.');
    }
    $saved = get_option($option, []);
    if (!is_array($saved) || $checked < ($saved[$component]['verified_at'] ?? 0)) {
        throw new \RuntimeException('This receipt would replace a newer component restore check.');
    }
    $result = [
        'site' => $site, 'method' => 'isolated_component_staging', 'verified_at' => $checked, 'file_count' => $count,
        'archive_path' => $chain[count($chain) - 1]['archive_path'],
        'chain_sha256' => hash('sha256', json_encode($fingerprints, JSON_THROW_ON_ERROR)),
    ];
    if (($saved[$component] ?? null) !== $result) {
        $saved[$component] = $result;
        if (!update_option($option, $saved, false)) {
            throw new \RuntimeException('Could not save the component restore check.');
        }
    }
}

const RESTORE_RECEIPT_MAX_BYTES = 4096;

/** Read one small receipt from the administrator's submission. Do not retain the uploaded file. */
function read_restore_receipt_submission($posted, $upload): array {
    if (!is_string($posted) || strlen($posted) > RESTORE_RECEIPT_MAX_BYTES || !is_array($upload)) {
        throw new \RuntimeException('Enter a valid restore test receipt.');
    }
    $text = wp_unslash($posted);
    $error = $upload['error'] ?? UPLOAD_ERR_NO_FILE;
    if ($error !== UPLOAD_ERR_NO_FILE) {
        $file = $upload['tmp_name'] ?? null;
        if (trim($text) !== '') {
            throw new \RuntimeException('Choose a receipt file or paste the receipt.');
        }
        if ($error !== UPLOAD_ERR_OK || !is_string($file) || !is_uploaded_file($file)) {
            throw new \RuntimeException('WordPress could not read the uploaded receipt.');
        }
        $text = @file_get_contents($file, false, null, 0, RESTORE_RECEIPT_MAX_BYTES + 1);
    }
    if (!is_string($text) || strlen($text) > RESTORE_RECEIPT_MAX_BYTES) {
        throw new \RuntimeException('Choose a restore receipt no larger than 4 KB.');
    }
    $receipt = json_decode($text, true, 8);
    if (!is_array($receipt) || $receipt === []) {
        throw new \RuntimeException('Enter a valid restore test receipt.');
    }
    return $receipt;
}

add_action('admin_post_pebkac_backup_restore_receipt', __NAMESPACE__ . '\\save_restore_receipt');

function save_restore_receipt(): void {
    if (!current_user_can('manage_options') || !is_ssl() || ($_SERVER['REQUEST_METHOD'] ?? '') !== 'POST') {
        wp_die('Administrator access over HTTPS is required.', '', ['response' => 403]);
    }
    check_admin_referer('pebkac_backup_restore_receipt');
    try {
        $receipt = read_restore_receipt_submission($_POST['restore_receipt'] ?? '', $_FILES['restore_receipt_file'] ?? []);
    } catch (\RuntimeException $error) {
        wp_die(esc_html($error->getMessage()), '', ['response' => 400, 'back_link' => true]);
    }
    try {
        with_backup_job_lock(backup_job_root(true), static function () use ($receipt): void {
            $now = time();
            if (($receipt['kind'] ?? null) === 'component_restore') {
                record_component_restore_receipt($receipt, home_url(), $now);
                return;
            }
            record_full_restore_receipt($receipt, home_url(), $now);
        });
    } catch (\RuntimeException $error) {
        wp_die(esc_html($error->getMessage()), '', ['response' => 409, 'back_link' => true]);
    }
    wp_safe_redirect(admin_url('admin.php?page=pebkac-backup&tab=overview'));
    exit;
}

function render_restore_receipt(): void {
    if (!is_ssl()) {
        return;
    }
    $site = home_url();
    $now = time();
    $available = isset(verified_evidence(get_option(EVIDENCE_OPTION, []), $site, $now)['manifest_sha256']);
    if (!$available) {
        $history = get_option(COMPONENT_RECOVERY_STATE_OPTION, []);
        foreach (is_array($history) ? array_keys(COMPONENTS) : [] as $component) {
            try {
                if (component_recovery_chain($site, $component, $history, $now) !== []) {
                    $available = true;
                    break;
                }
            } catch (\RuntimeException $error) {
                continue;
            }
        }
    }
    if (!$available) {
        return;
    }
    ?>
    <details>
        <summary>Record an isolated restore test</summary>
        <form method="post" enctype="multipart/form-data" action="<?php echo esc_url(admin_url('admin-post.php')); ?>">
            <input type="hidden" name="action" value="pebkac_backup_restore_receipt">
            <?php wp_nonce_field('pebkac_backup_restore_receipt'); ?>
            <p><label for="pebkac-backup-receipt-file">Receipt from a completed site restore test or component restore check</label></p>
            <input id="pebkac-backup-receipt-file" type="file" name="restore_receipt_file" accept=".json,application/json">
            <details>
                <summary>Paste receipt instead</summary>
                <p><label for="pebkac-backup-receipt">Receipt from a completed restore test</label></p>
                <textarea id="pebkac-backup-receipt" name="restore_receipt" rows="4" class="large-text code"
                    maxlength="<?php echo esc_attr(RESTORE_RECEIPT_MAX_BYTES); ?>"></textarea>
            </details>
            <?php submit_button('Save restore test result'); ?>
        </form>
    </details>
    <?php
}
