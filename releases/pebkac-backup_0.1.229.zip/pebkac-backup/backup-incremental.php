<?php

namespace PEBKAC404\Backup;

require_once __DIR__ . '/snapshot-archive.php';
require_once __DIR__ . '/pilot-sites.php';

/** Normalize a verified file inventory so its fingerprint does not depend on enumeration order. */
function incremental_file_inventory(string $component, array $files): array {
    if ($component === 'database' || !isset(SNAPSHOT_COMPONENT_DIRECTORIES[$component])) {
        throw new \RuntimeException('Choose a file backup component for incremental planning.');
    }
    $inventory = [];
    $seen = [];
    $total = 0;
    foreach ($files as $path => $entry) {
        if ($path === 'component.json') {
            continue;
        }
        if (!is_string($path) || !valid_snapshot_member_name($path, $component)
            || isset($seen[strtolower($path)]) || !is_int($entry['size'] ?? null) || $entry['size'] < 0
            || $entry['size'] > SNAPSHOT_MAX_BYTES || ($total += $entry['size']) > SNAPSHOT_MAX_BYTES
            || count($inventory) >= SNAPSHOT_MAX_FILES || !is_string($entry['sha256'] ?? null) || !preg_match('/^[a-f0-9]{64}$/D', $entry['sha256'])) {
            throw new \RuntimeException('The incremental file inventory is invalid.');
        }
        $seen[strtolower($path)] = true;
        $inventory[$path] = ['size' => $entry['size'], 'sha256' => $entry['sha256']];
    }
    ksort($inventory, SORT_STRING);
    return $inventory;
}

/** Fingerprint a normalized inventory in its canonical path order. */
function incremental_inventory_sha256(string $component, array $inventory): string {
    return hash('sha256', json_encode([$component, $inventory], JSON_THROW_ON_ERROR));
}

/** Check local evidence before requesting any remote object. */
function require_verified_component_record(string $site, string $component, array $record, int $now): void {
    $archive = $record['archive_path'] ?? null;
    $sidecar = $record['manifest_path'] ?? null;
    $folder = $record['folder'] ?? PILOT_DROPBOX_FOLDER;
    $verified_at = $record['offsite_verified_at'] ?? null;
    if (($record['component'] ?? null) !== $component
        || !is_string($archive) || !is_string($sidecar) || !is_string($folder) || !pilot_recovery_pair($site, $archive, $sidecar, $component, $folder)
        || !is_int($verified_at) || $verified_at < 1 || $verified_at > $now) {
        throw new \RuntimeException('The component manifest does not match a verified backup for this site and component.');
    }
    foreach (['archive_sha256', 'manifest_sha256', 'inventory_sha256'] as $field) {
        if (!is_string($record[$field] ?? null) || !preg_match('/^[a-f0-9]{64}$/D', $record[$field])) {
            throw new \RuntimeException('The component manifest does not match a verified backup for this site and component.');
        }
    }
    $parent = $record['parent_path'] ?? null;
    $base = $record['base_inventory_sha256'] ?? null;
    if (($parent === null && $base !== null) || ($parent !== null && ($component === 'database' || !is_string($parent) || $parent === $archive
        || substr($parent, -4) !== '.zip' || !pilot_backup_object_path($site, $parent, $component, substr($parent, 0, (int) strrpos($parent, '/')))
        || !is_string($base) || !preg_match('/^[a-f0-9]{64}$/D', $base)))) {
        throw new \RuntimeException('The component manifest does not match a verified backup for this site and component.');
    }
}

function require_verified_component_baseline(string $site, string $component, array $record, int $now): void {
    require_verified_component_record($site, $component, $record, $now);
    if ($component === 'database' || isset($record['parent_path'])) {
        throw new \RuntimeException('The baseline manifest must describe a full component backup.');
    }
}

/** Decode the same bounded bytes that matched the stored manifest fingerprint. */
function read_verified_component_manifest(array $record, string $bytes): array {
    if (strlen($bytes) > SNAPSHOT_MAX_MANIFEST_BYTES || !hash_equals($record['manifest_sha256'], hash('sha256', $bytes))) {
        throw new \RuntimeException('The component manifest does not match a verified backup for this site and component.');
    }
    $manifest = json_decode($bytes, true);
    if (($manifest['archive_sha256'] ?? null) !== $record['archive_sha256']) {
        throw new \RuntimeException('The component manifest does not describe the verified component archive.');
    }
    return $manifest;
}

/** Load the initial file inventory only from the manifest pinned by a verified full component backup. */
function verified_component_baseline_inventory(string $site, string $component, array $record, string $manifest_bytes, int $now): array {
    require_verified_component_baseline($site, $component, $record, $now);
    $manifest = read_verified_component_manifest($record, $manifest_bytes);
    $marker = snapshot_component_marker($component);
    if (($manifest['component'] ?? null) !== $component || !is_array($manifest['files'] ?? null)
        || ($manifest['files']['component.json']['size'] ?? null) !== strlen($marker)
        || ($manifest['files']['component.json']['sha256'] ?? null) !== hash('sha256', $marker)) {
        throw new \RuntimeException('The component manifest does not describe the verified component archive.');
    }
    $files = incremental_file_inventory($component, $manifest['files']);
    if ($record['inventory_sha256'] !== incremental_inventory_sha256($component, $files)) {
        throw new \RuntimeException('The baseline files do not match the verified component inventory.');
    }
    return ['component' => $component, 'files' => $files];
}

/** Reject an out-of-order or cross-site delta before downloading it. */
function require_verified_component_parent(string $site, string $component, array $parent_record, array $record, int $now): void {
    require_verified_component_record($site, $component, $parent_record, $now);
    require_verified_component_record($site, $component, $record, $now);
    if (($record['parent_path'] ?? null) !== $parent_record['archive_path']
        || ($record['base_inventory_sha256'] ?? null) !== $parent_record['inventory_sha256']
        || $record['offsite_verified_at'] < $parent_record['offsite_verified_at']) {
        throw new \RuntimeException('The incremental manifest does not follow its verified parent.');
    }
}

const COMPONENT_REPLAY_MAX_MANIFESTS = 7;

/** Return the latest component chain in replay order, without contacting Dropbox. */
function plan_component_inventory_replay(string $site, string $component, array $state, int $now): array {
    if (pilot_site_slug($site) === '' || $component === 'database' || !isset(SNAPSHOT_COMPONENT_DIRECTORIES[$component])) {
        throw new \RuntimeException('Choose an approved pilot and file component for incremental replay.');
    }
    if (!is_array($state['records'] ?? null) || !is_array($state['latest'] ?? null)) {
        throw new \RuntimeException('The verified component history could not be read.');
    }
    if (!array_key_exists($component, $state['latest'])) {
        return [];
    }
    $path = $state['latest'][$component];
    $ordered = [];
    $child = null;
    while (true) {
        if (!is_string($path) || !is_array($state['records'][$path] ?? null)
            || ($state['records'][$path]['archive_path'] ?? null) !== $path || isset($ordered[$path])) {
            throw new \RuntimeException('The incremental replay chain has a missing, mismatched or repeated backup.');
        }
        if (count($ordered) >= COMPONENT_REPLAY_MAX_MANIFESTS) {
            throw new \RuntimeException('The incremental replay chain exceeds its manifest limit.');
        }
        $record = $state['records'][$path];
        if ($child === null) {
            require_verified_component_record($site, $component, $record, $now);
        } else {
            require_verified_component_parent($site, $component, $record, $child, $now);
        }
        $ordered[$path] = $record;
        $path = $record['parent_path'] ?? null;
        if ($path === null) {
            return array_reverse(array_values($ordered));
        }
        $child = $record;
    }
}

/** Replay exactly one verified delta after its recorded parent. */
function replay_verified_component_manifest(
    string $site, string $component, array $parent_record, array $parent_inventory, array $record, string $manifest_bytes, int $now
): array {
    require_verified_component_parent($site, $component, $parent_record, $record, $now);
    $manifest = read_verified_component_manifest($record, $manifest_bytes);
    $delta = $manifest['delta'] ?? null;
    if (!is_array($delta) || ($delta['component'] ?? null) !== $component
        || ($delta['base_inventory_sha256'] ?? null) !== $parent_record['inventory_sha256']
        || ($delta['result_inventory_sha256'] ?? null) !== $record['inventory_sha256']) {
        throw new \RuntimeException('The incremental manifest does not match its verified file inventory.');
    }
    return apply_incremental_file_inventory($parent_inventory, $delta);
}

/** Hash the current component directly from WordPress without staging a full ZIP. */
function scan_incremental_file_inventory(string $wordpress, string $component, ?float $deadline = null): array {
    snapshot_deadline($deadline);
    $root = realpath($wordpress);
    if ($root === false || !is_file($root . '/wp-includes/version.php')
        || $component === 'database' || !isset(SNAPSHOT_COMPONENT_DIRECTORIES[$component])) {
        throw new \RuntimeException('Choose a WordPress tree and a file backup component.');
    }
    $files = [];
    $total = 0;
    foreach (snapshot_wordpress_sources($root, $component, $deadline) as $name => $path) {
        snapshot_deadline($deadline);
        clearstatcache(true, $path);
        $resolved = realpath($path);
        if (!valid_snapshot_member_name($name, $component) || is_link($path) || $resolved === false
            || str_replace('\\', '/', $resolved) !== str_replace('\\', '/', $path) || !is_file($resolved)) {
            throw new \RuntimeException('An incremental source file is invalid or outside WordPress.');
        }
        $stream = @fopen($path, 'rb');
        if ($stream === false) {
            throw new \RuntimeException('Could not read an incremental source file.');
        }
        try {
            $before = fstat($stream);
            if ($before === false || ($before['mode'] & 0170000) !== 0100000 || $before['size'] < 0) {
                throw new \RuntimeException('An incremental source file is invalid or exceeds the size limit.');
            }
            if (($total += $before['size']) > SNAPSHOT_MAX_BYTES) {
                throw new BackupCaptureProblem('An incremental source file is invalid or exceeds the size limit.', BackupCaptureProblem::FILE_LIMIT);
            }
            [$bytes, $digest] = snapshot_hash_stream($stream, $before['size'], $deadline);
            if ($bytes !== $before['size']) {
                throw new \RuntimeException('An incremental source file changed during the scan.');
            }
            $after = fstat($stream);
            if ($after === false || $after['size'] !== $before['size'] || $after['mtime'] !== $before['mtime']
                || $after['ctime'] !== $before['ctime']) {
                throw new \RuntimeException('An incremental source file changed during the scan.');
            }
            $files[$name] = ['size' => $before['size'], 'sha256' => $digest];
        } finally {
            fclose($stream);
        }
    }
    snapshot_deadline($deadline);
    return ['component' => $component, 'files' => incremental_file_inventory($component, $files)];
}

/** Describe changes against a verified component inventory, without writing a backup. */
function plan_incremental_file_backup(array $previous, array $current): array {
    $component = $previous['component'] ?? null;
    if (!is_string($component) || ($current['component'] ?? null) !== $component
        || !is_array($previous['files'] ?? null) || !is_array($current['files'] ?? null)) {
        throw new \RuntimeException('The incremental inventories must describe the same file component.');
    }
    $before = incremental_file_inventory($component, $previous['files']);
    $after = incremental_file_inventory($component, $current['files']);
    $changed = [];
    foreach ($after as $path => $entry) {
        if (($before[$path] ?? null) !== $entry) {
            $changed[$path] = $entry;
        }
    }
    return [
        'component' => $component,
        'base_inventory_sha256' => incremental_inventory_sha256($component, $before),
        'result_inventory_sha256' => incremental_inventory_sha256($component, $after),
        'changed' => $changed,
        'deleted' => array_keys(array_diff_key($before, $after)),
    ];
}

/** Replay a delta in memory after confirming its exact parent and resulting inventories. */
function apply_incremental_file_inventory(array $parent, array $delta): array {
    $component = $parent['component'] ?? null;
    if (!is_string($component) || ($delta['component'] ?? null) !== $component
        || !is_array($parent['files'] ?? null) || !is_array($delta['changed'] ?? null)
        || !is_array($delta['deleted'] ?? null) || array_key_exists('component.json', $delta['changed'])
        || !is_string($delta['base_inventory_sha256'] ?? null) || !is_string($delta['result_inventory_sha256'] ?? null)) {
        throw new \RuntimeException('The incremental record is invalid for this component.');
    }
    $files = incremental_file_inventory($component, $parent['files']);
    if (!hash_equals(incremental_inventory_sha256($component, $files), $delta['base_inventory_sha256'])) {
        throw new \RuntimeException('The incremental record does not match its parent inventory.');
    }
    $changed = incremental_file_inventory($component, $delta['changed']);
    foreach ($delta['deleted'] as $path) {
        if (!is_string($path) || !isset($files[$path]) || isset($changed[$path])) {
            throw new \RuntimeException('The incremental record contains an invalid deletion.');
        }
        unset($files[$path]);
    }
    foreach ($changed as $path => $entry) {
        if (($files[$path] ?? null) === $entry) {
            throw new \RuntimeException('The incremental record contains an unchanged file.');
        }
        $files[$path] = $entry;
    }
    $files = incremental_file_inventory($component, $files);
    if (!hash_equals(incremental_inventory_sha256($component, $files), $delta['result_inventory_sha256'])) {
        throw new \RuntimeException('The replayed files do not match the expected inventory.');
    }
    return ['component' => $component, 'files' => $files];
}

/** Build a ZIP containing the delta and its changed files, then verify the sealed bytes. */
function package_incremental_file_backup(string $wordpress, array $parent, array $delta, string $archive, ?float $deadline = null): array {
    apply_incremental_file_inventory($parent, $delta);
    snapshot_deadline($deadline);
    $root = realpath($wordpress);
    $destination = realpath(dirname($archive));
    if ($root === false || $destination === false || !is_dir($root) || file_exists($archive) || is_link($archive)) {
        throw new \RuntimeException('Choose a verified WordPress directory and a new incremental ZIP path.');
    }
    $root_prefix = rtrim(str_replace('\\', '/', $root), '/') . '/';
    $destination_prefix = rtrim(str_replace('\\', '/', $destination), '/') . '/';
    if (stripos($destination_prefix, $root_prefix) === 0) {
        throw new \RuntimeException('Store the incremental ZIP outside the WordPress directory.');
    }
    $zip = new \ZipArchive();
    if ($zip->open($archive, \ZipArchive::CREATE | \ZipArchive::EXCL) !== true) {
        throw new \RuntimeException('Could not create the incremental ZIP.');
    }
    try {
        try {
            if ($deadline !== null && (!method_exists($zip, 'registerCancelCallback')
                || !$zip->registerCancelCallback(static function () use ($deadline): int { return microtime(true) >= $deadline ? 1 : 0; }))) {
                throw new \RuntimeException('Could not bound the incremental ZIP operation.');
            }
            if (!$zip->addFromString('delta.json', json_encode($delta, JSON_THROW_ON_ERROR))) {
                throw new \RuntimeException('Could not record the incremental ZIP inventory.');
            }
            foreach ($delta['changed'] as $name => $entry) {
                snapshot_deadline($deadline);
                $path = $root_prefix . substr($name, strlen('wordpress/'));
                $resolved = realpath($path);
                if ($resolved === false || is_link($path) || !is_file($resolved)
                    || str_replace('\\', '/', $resolved) !== $path || !$zip->addFile($resolved, $name)) {
                    throw new \RuntimeException('A changed file is unavailable or outside the verified WordPress directory.');
                }
            }
        } finally {
            $closed = $zip->close();
        }
        if (!$closed) {
            snapshot_deadline($deadline);
            throw new \RuntimeException('Could not finish the incremental ZIP.');
        }
        return inspect_incremental_file_backup($archive, $parent, $delta, $deadline);
    } catch (\Throwable $error) {
        @unlink($archive);
        throw $error;
    }
}

/** Verify the exact delta metadata and every changed file without extracting anything. */
function inspect_incremental_file_backup(string $archive, array $parent, array $delta, ?float $deadline = null): array {
    apply_incremental_file_inventory($parent, $delta);
    snapshot_deadline($deadline);
    $zip = new \ZipArchive();
    if (is_link($archive) || $zip->open($archive, \ZipArchive::RDONLY) !== true) {
        throw new \RuntimeException('Could not open the incremental ZIP.');
    }
    try {
        $marker = json_encode($delta, JSON_THROW_ON_ERROR);
        if ($zip->numFiles !== count($delta['changed']) + 1 || $zip->getFromName('delta.json', strlen($marker) + 1) !== $marker) {
            throw new \RuntimeException('The incremental ZIP does not contain the expected record and file count.');
        }
        foreach ($delta['changed'] as $name => $entry) {
            snapshot_deadline($deadline);
            $stream = $zip->getStream($name);
            if ($stream === false) {
                throw new \RuntimeException('The incremental ZIP is missing a changed file.');
            }
            try {
                [$size, $digest] = snapshot_hash_stream($stream, $entry['size'] + 1, $deadline);
            } finally {
                fclose($stream);
            }
            if ($size !== $entry['size'] || $digest !== $entry['sha256']) {
                throw new \RuntimeException('A changed file does not match the incremental inventory.');
            }
        }
    } finally {
        $zip->close();
    }
    return ['archive_sha256' => snapshot_archive_sha256($archive, $deadline), 'delta' => $delta];
}

/** Reconstruct only the final file inventory in a fresh directory. Never executes restored code. */
function stage_incremental_file_restore(string $baseline, array $trusted_baseline, array $steps, string $destination, ?float $deadline = null): array {
    $component = $trusted_baseline['component'] ?? null;
    if (!is_string($component) || !is_array($trusted_baseline['files'] ?? null)
        || inspect_snapshot($baseline, $deadline, $component) !== $trusted_baseline) {
        throw new \RuntimeException('The incremental baseline does not match its verified record.');
    }
    $inventory = ['component' => $component, 'files' => incremental_file_inventory($component, $trusted_baseline['files'])];
    $sources = array_fill_keys(array_keys($inventory['files']), $baseline);

    foreach ($steps as $step) {
        snapshot_deadline($deadline);
        $archive = $step['archive'] ?? null;
        $manifest = $step['manifest'] ?? null;
        if (!is_string($archive) || !is_array($manifest['delta'] ?? null)
            || inspect_incremental_file_backup($archive, $inventory, $manifest['delta'], $deadline) !== $manifest) {
            throw new \RuntimeException('An incremental ZIP does not match its verified record.');
        }
        $delta = $manifest['delta'];
        $inventory = apply_incremental_file_inventory($inventory, $delta);
        foreach ($delta['deleted'] as $path) {
            unset($sources[$path]);
        }
        foreach ($delta['changed'] as $path => $entry) {
            $sources[$path] = $archive;
        }
    }

    require_snapshot_restore_space($destination, array_sum(array_column($inventory['files'], 'size')));
    if (!@mkdir($destination, 0700)) {
        throw new \RuntimeException('Choose a new isolated restore directory.');
    }
    $groups = [];
    foreach ($sources as $path => $archive) {
        $groups[$archive][] = $path;
    }
    foreach ($groups as $archive => $paths) {
        $zip = new \ZipArchive();
        if ($zip->open($archive, \ZipArchive::RDONLY) !== true) {
            throw new \RuntimeException('Could not reopen a verified archive for recovery.');
        }
        try {
            foreach ($paths as $path) {
                snapshot_deadline($deadline);
                extract_verified_backup_member($zip, $path, $inventory['files'][$path], $destination, $deadline);
            }
        } finally {
            $zip->close();
        }
    }
    return $inventory;
}

/** Seal a selected file point as a full component ZIP with no earlier-point dependency.
 * Inputs remain immutable. The caller owns a new private staging directory and its cleanup.
 */
function package_standalone_file_point(string $baseline, array $manifest, array $steps, string $staging, string $archive, ?float $deadline = null): array {
    $component = $manifest['component'] ?? null;
    $parent = realpath(dirname($archive));
    if (!is_string($component) || $component === 'database' || !isset(SNAPSHOT_COMPONENT_DIRECTORIES[$component])
        || $parent === false || is_link(dirname($archive)) || file_exists($archive) || is_link($archive)
        || realpath(dirname($staging)) !== $parent || file_exists($staging) || is_link($staging)) {
        throw new \RuntimeException('Choose new private staging and archive paths for a file component point.');
    }
    $inventory = stage_incremental_file_restore($baseline, $manifest, $steps, $staging, $deadline);
    $zip = new \ZipArchive();
    $opened = false;
    $created = false;
    try {
        if ($zip->open($archive, \ZipArchive::CREATE | \ZipArchive::EXCL) !== true) {
            throw new \RuntimeException('Could not reserve the standalone recovery ZIP.');
        }
        $opened = true;
        $created = true;
        if ($deadline !== null && (!method_exists($zip, 'registerCancelCallback')
            || !$zip->registerCancelCallback(static function () use ($deadline): int { return microtime(true) >= $deadline ? 1 : 0; }))) {
            throw new \RuntimeException('Could not bound standalone ZIP creation.');
        }
        if (!$zip->addFromString('component.json', snapshot_component_marker($component))) {
            throw new \RuntimeException('Could not identify the standalone recovery component.');
        }
        foreach ($inventory['files'] as $member=>$pin) {
            snapshot_deadline($deadline);
            $source = $staging . '/' . $member;
            if (is_link($source) || !is_file($source) || !$zip->addFile($source, $member)) {
                throw new \RuntimeException('A verified standalone recovery file is unavailable.');
            }
        }
        $closed = $zip->close();
        $opened = false;
        if (!$closed) { throw new \RuntimeException('Could not finish the standalone recovery ZIP.'); }
        $sealed = inspect_snapshot($archive, $deadline, $component);
        if (incremental_file_inventory($component, $sealed['files']) !== $inventory['files']) {
            throw new \RuntimeException('The standalone recovery ZIP changed while it was being sealed.');
        }
        return $sealed;
    } catch (\Throwable $error) {
        if ($opened) { @$zip->close(); }
        if ($created) { @unlink($archive); }
        throw $error;
    }
}

/** Protect the archives required by retained component recovery points. No storage is changed. */
function plan_component_archive_retention(array $records, array $retained_paths, string $site): array {
    $slug = pilot_site_slug($site);
    if ($slug === '') {
        throw new \RuntimeException('Choose an approved pilot for incremental retention.');
    }
    $sets = [];
    foreach ($records as $record) {
        $component = $record['component'] ?? null;
        $path = $record['archive_path'] ?? null;
        $parent = $record['parent_path'] ?? null;
        $base = $record['base_inventory_sha256'] ?? null;
        $result = $record['inventory_sha256'] ?? null;
        if (!is_string($component) || !isset(SNAPSHOT_COMPONENT_DIRECTORIES[$component])) {
            throw new \RuntimeException('An incremental recovery record could not be verified.');
        }
        $manifest = $record['manifest_path'] ?? null;
        $folder = $record['folder'] ?? PILOT_DROPBOX_FOLDER;
        if (!is_string($path) || !is_string($manifest) || !is_string($folder) || !pilot_recovery_pair($site, $path, $manifest, $component, $folder)
            || !is_string($record['archive_sha256'] ?? null) || !preg_match('/^[a-f0-9]{64}$/D', $record['archive_sha256'])
            || !is_string($record['manifest_sha256'] ?? null) || !preg_match('/^[a-f0-9]{64}$/D', $record['manifest_sha256'])
            || !is_string($result) || !preg_match('/^[a-f0-9]{64}$/D', $result) || isset($sets[$path])
            || ($parent === null && $base !== null)
            || ($parent !== null && ($component === 'database' || !is_string($parent)
                || !is_string($base) || !preg_match('/^[a-f0-9]{64}$/D', $base)))) {
            throw new \RuntimeException('An incremental recovery record could not be verified.');
        }
        $sets[$path] = $record;
    }

    $depths = [];
    foreach ($sets as $path => $record) {
        $seen = [];
        $cursor = $path;
        while ($cursor !== null && !isset($depths[$cursor])) {
            if (isset($seen[$cursor])) {
                throw new \RuntimeException('An incremental recovery chain contains a cycle.');
            }
            $seen[$cursor] = true;
            $set = $sets[$cursor];
            $parent = $set['parent_path'] ?? null;
            if ($parent !== null && (!isset($sets[$parent]) || $sets[$parent]['component'] !== $set['component']
                || $sets[$parent]['inventory_sha256'] !== $set['base_inventory_sha256'])) {
                throw new \RuntimeException('An incremental recovery chain is missing its matching parent.');
            }
            $cursor = $parent;
        }
        $depth = $cursor === null ? -1 : $depths[$cursor];
        foreach (array_reverse(array_keys($seen)) as $link) {
            $depths[$link] = ++$depth;
        }
    }

    $protected = [];
    foreach ($retained_paths as $path) {
        if (!is_string($path) || !isset($sets[$path])) {
            throw new \RuntimeException('A retained recovery point is missing.');
        }
        while ($path !== null && !isset($protected[$path])) {
            $protected[$path] = true;
            $path = $sets[$path]['parent_path'] ?? null;
        }
    }
    $candidates = array_diff_key($sets, $protected);
    uksort($candidates, static function (string $left, string $right) use ($depths): int {
        return $depths[$right] <=> $depths[$left] ?: strcmp($left, $right);
    });
    return ['keep' => array_intersect_key($sets, $protected), 'candidates' => $candidates];
}

const COMPONENT_RECOVERY_STATE_OPTION = 'pebkac_backup_component_recovery';

/** Publish a component only after both off-site objects verified. Caller holds the backup job lock. */
function publish_verified_component(array $capture, array $archive, array $manifest, string $site, int $now): array {
    $archive_time = $archive['verified_at'] ?? null;
    $manifest_time = $manifest['verified_at'] ?? null;
    $pins = backup_dropbox_object_pins(['archive' => $archive, 'manifest' => $manifest]);
    if (($archive['phase'] ?? null) !== 'verified' || ($manifest['phase'] ?? null) !== 'verified'
        || !is_int($archive_time) || $archive_time < 1 || !is_int($manifest_time) || $manifest_time < $archive_time || $manifest_time > $now
        || ($capture['archive_sha256'] ?? null) !== ($archive['sha256'] ?? null)
        || ($capture['manifest_sha256'] ?? null) !== ($manifest['sha256'] ?? null) || $pins === []) {
        throw new \RuntimeException('Both component objects must match the verified off-site capture.');
    }
    $component = $capture['component'] ?? null;
    $path = $archive['path'] ?? null;
    if (!is_string($component) || !is_string($path)) {
        throw new \RuntimeException('The verified component destination is invalid.');
    }
    $record = [
        'component' => $component,
        'archive_path' => $path,
        'manifest_path' => $manifest['path'] ?? null,
        'archive_sha256' => $archive['sha256'] ?? null,
        'manifest_sha256' => $manifest['sha256'] ?? null,
        'parent_path' => $capture['parent_path'] ?? null,
        'base_inventory_sha256' => $capture['base_inventory_sha256'] ?? null,
        'inventory_sha256' => $capture['inventory_sha256'] ?? null,
        'offsite_verified_at' => $manifest_time,
        'dropbox_objects' => $pins,
    ];
    if (isset($capture['folder'])) {
        $record['folder'] = $capture['folder'];
    }
    $state = get_option(COMPONENT_RECOVERY_STATE_OPTION, ['records' => [], 'latest' => []]);
    if (!is_array($state['records'] ?? null) || !is_array($state['latest'] ?? null)) {
        throw new \RuntimeException('The verified component history could not be read.');
    }
    if (isset($state['records'][$path])) {
        if ($state['records'][$path] !== $record) {
            throw new \RuntimeException('The component path already identifies a different verified capture.');
        }
        return $record;
    }
    $head = $state['latest'][$component] ?? null;
    $head_record = is_string($head) ? ($state['records'][$head] ?? null) : null;
    if (($head !== null && (!is_array($head_record) || ($head_record['component'] ?? null) !== $component
            || !is_int($head_record['offsite_verified_at'] ?? null)))
        || ($head_record !== null && $manifest_time < $head_record['offsite_verified_at'])
        || ($record['parent_path'] !== null && $record['parent_path'] !== $head)) {
        throw new \RuntimeException('The component capture does not follow the latest verified recovery point.');
    }
    $state['records'][$path] = $record;
    $state['latest'][$component] = $path;
    plan_component_archive_retention(array_values($state['records']), array_values($state['latest']), $site);
    if (!update_option(COMPONENT_RECOVERY_STATE_OPTION, $state, false)) {
        throw new \RuntimeException('Could not publish the verified component recovery point.');
    }
    return $record;
}
