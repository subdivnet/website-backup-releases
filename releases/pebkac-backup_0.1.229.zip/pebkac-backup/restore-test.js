(() => {
    const panel = document.getElementById('pebkac-backup-test-restore');
    if (!panel || panel.dataset.pending !== '1') return;
    const tick = async () => {
        try {
            const body = new URLSearchParams({action: 'pebkac_backup_test_restore_status', _ajax_nonce: panel.dataset.nonce});
            const response = await fetch(ajaxurl, {method: 'POST', credentials: 'same-origin', body});
            const result = await response.json();
            if (result.success && result.data.pending === false) { location.reload(); return; }
            if (result.success && typeof result.data.message === 'string') {
                panel.querySelector('.pebkac-restore-test-message').textContent = result.data.message;
            }
        } catch (_) { /* Saved state remains available for a later status check. */ }
        window.setTimeout(tick, 15000);
    };
    tick();
})();
