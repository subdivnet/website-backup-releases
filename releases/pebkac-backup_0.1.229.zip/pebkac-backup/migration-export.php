<?php
namespace PEBKAC404\Backup;

if(!function_exists(__NAMESPACE__.'\\capture_snapshot')){require_once __DIR__.'/snapshot-archive.php';}
if(!function_exists(__NAMESPACE__.'\\rewrite_migration_value')){require_once __DIR__.'/migration-values.php';}

/** Rewrite only text values in this product's hexadecimal SQL export. Never execute recovered SQL. */
function rewrite_migration_sql($input, $output, array $urls, ?float $deadline=null): array {
    migration_url_map($urls);
    $changed=0; $rows=0; $bytes=0;
    while (!feof($input)) {
        snapshot_deadline($deadline);
        $line=fgets($input,32*1024*1024+2);
        if ($line===false) { if (feof($input)) { break; } throw new \RuntimeException('The migration database could not be read.'); }
        if (strlen($line)>32*1024*1024 || (substr($line,-1)!=="\n" && !feof($input))) {
            throw new \RuntimeException('A migration SQL line exceeds its size limit.');
        }
        if (strpos($line,'INSERT INTO ')===0) {
            if (!preg_match('/^INSERT INTO `[a-zA-Z0-9_]{1,64}` \(`[a-zA-Z0-9_]{1,64}`(?:, `[a-zA-Z0-9_]{1,64}`)*\) VALUES \((.*)\);\n?$/D',$line,$row,PREG_OFFSET_CAPTURE)) {
                throw new \RuntimeException('Choose a database export created by Website Backup.');
            }
            // Strict value grammar ensures a replacement cannot affect SQL syntax or binary columns.
            $values=$row[1][0]; $offset=0; $rewritten='';
            while ($offset<strlen($values)) {
                if (!preg_match("/\\G(NULL|X'[0-9a-f]*'|CONVERT\\(X'([0-9a-f]*)' USING utf8mb4\\))(?=, |$)/D",$values,$match,0,$offset)) {
                    throw new \RuntimeException('The migration database has an unsupported value encoding.');
                }
                $token=$match[1];
                if (strpos($token,'CONVERT(')===0) {
                    if (strlen($match[2])%2!==0) { throw new \RuntimeException('The migration database has invalid text encoding.'); }
                    $raw=hex2bin($match[2]);
                    if ($raw===false) { throw new \RuntimeException('The migration database has invalid text encoding.'); }
                    $new=rewrite_migration_value($raw,$urls);
                    if ($new!==$raw) { $changed++; }
                    $token="CONVERT(X'".bin2hex($new)."' USING utf8mb4)";
                }
                if (strlen($rewritten)+strlen($token)>32*1024*1024) { throw new \RuntimeException('A migrated SQL row exceeds its size limit.'); }
                $rewritten.=$token; $offset+=strlen($match[0]);
                if ($offset<strlen($values)) { $rewritten.=', '; $offset+=2; }
            }
            $line=substr($line,0,$row[1][1]).$rewritten.substr($line,$row[1][1]+strlen($values));
            $rows++;
        }
        $bytes+=strlen($line);
        if ($bytes>512*1024*1024 || fwrite($output,$line)!==strlen($line)) {
            throw new \RuntimeException('The migrated database exceeds its size limit or could not be written.');
        }
    }
    if ($rows===0) { throw new \RuntimeException('The migration database contains no supported rows.'); }
    return ['rows'=>$rows,'changed_values'=>$changed,'bytes'=>$bytes];
}

/** Remove only the private directory created by this export, never follow recovered links. */
function remove_migration_workspace(string $path): void {
    if (is_link($path) || !is_dir($path)) {
        if ((file_exists($path) || is_link($path)) && !unlink($path)) { throw new \RuntimeException('Could not clean up a migration temporary file.'); }
        return;
    }
    foreach (new \FilesystemIterator($path,\FilesystemIterator::SKIP_DOTS) as $file) { remove_migration_workspace($file->getPathname()); }
    if (!rmdir($path)) { throw new \RuntimeException('Could not clean up a migration temporary directory.'); }
}

/** Prepare a private, portable copy; the original archive remains immutable. Destination must be new. */
function export_migration_snapshot(string $archive,array $manifest,string $destination,array $urls,?float $deadline=null): array {
    migration_url_map($urls);
    if (isset($manifest['component']) || isset($manifest['delta'])) { throw new \RuntimeException('Choose a full backup for migration.'); }
    // Use the same strict fresh-directory and ancestor checks as selective recovery.
    if(!function_exists(__NAMESPACE__.'\\stage_selective_snapshot')){require_once __DIR__.'/selective-recovery.php';}
    $parent=realpath(dirname($destination));
    if ($parent===false || !preg_match('/^[a-zA-Z0-9][a-zA-Z0-9_.-]*$/D',basename($destination))) {
        throw new \RuntimeException('Choose a new private migration directory.');
    }
    for ($p=dirname($destination); ; $p=dirname($p)) {
        if (is_link($p)) { throw new \RuntimeException('The migration path contains a link.'); }
        if (dirname($p)===$p || $p==='.') { break; }
    }
    if (!@mkdir($destination,0700)) { throw new \RuntimeException('The migration destination already exists or is unavailable.'); }
    $complete=false;
    try {
    stage_snapshot_restore($archive,$manifest,$destination.'/source',null,$deadline);
    $input=fopen($destination.'/source/database.sql','rb');
    $output=fopen($destination.'/migrated.sql','x+b');
    if ($input===false || $output===false) {
        if (is_resource($input)) { fclose($input); } if (is_resource($output)) { fclose($output); }
        throw new \RuntimeException('Could not open the private migration database.');
    }
    try { $stats=rewrite_migration_sql($input,$output,$urls,$deadline); }
    finally { fclose($input); fclose($output); }
    $migrated=capture_snapshot($destination.'/source/wordpress',$destination.'/migrated.sql',$destination.'/migration.zip',$deadline);
    $json=json_encode($migrated,JSON_THROW_ON_ERROR|JSON_UNESCAPED_SLASHES);
    if (file_put_contents($destination.'/migration.manifest.json',$json,LOCK_EX)!==strlen($json)) {
        throw new \RuntimeException('Could not write the migration recovery manifest.');
    }
    remove_migration_workspace($destination.'/source'); remove_migration_workspace($destination.'/migrated.sql');
    $complete=true;
    return ['kind'=>'migration_export','archive_sha256'=>$migrated['archive_sha256'],'manifest_sha256'=>hash('sha256',$json),
        'source_archive_sha256'=>$manifest['archive_sha256'],'database'=>$stats,'tested'=>false];
    } finally { if (!$complete) { remove_migration_workspace($destination); } }
}

if (PHP_SAPI==='cli' && realpath($_SERVER['SCRIPT_FILENAME']??'')===__FILE__) {
    try {
        if ($argc!==7 || !preg_match('/^[a-f0-9]{64}$/D',$argv[3]) || is_link($argv[2]) || !is_file($argv[2]) || filesize($argv[2])>SNAPSHOT_MAX_MANIFEST_BYTES) {
            throw new \RuntimeException('Usage: php migration-export.php BACKUP.zip MANIFEST.json MANIFEST_SHA256 NEW_DIRECTORY OLD_URL NEW_URL');
        }
        $json=file_get_contents($argv[2]);
        if (!hash_equals($argv[3],hash('sha256',$json))) { throw new \RuntimeException('The migration manifest does not match its trusted checksum.'); }
        $manifest=json_decode($json,true,512,JSON_THROW_ON_ERROR);
        echo json_encode(export_migration_snapshot($argv[1],$manifest,$argv[4],[$argv[5]=>$argv[6]]),JSON_THROW_ON_ERROR).PHP_EOL;
    } catch (\Throwable $error) { fwrite(STDERR,$error->getMessage().PHP_EOL);exit(1); }
}
