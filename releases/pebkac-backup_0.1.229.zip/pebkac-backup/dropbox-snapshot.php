<?php

namespace PEBKAC404\Backup;

require_once __DIR__ . '/dropbox-metadata.php';
require_once __DIR__ . '/snapshot-archive.php';
require_once __DIR__ . '/pilot-sites.php';

const SNAPSHOT_CHUNK_BYTES = 4 * 1024 * 1024;

function ensure_dropbox_pilot_folder(string $token, string $path = PILOT_DROPBOX_FOLDER): void {
    validate_snapshot_token($token);
    if (!valid_backup_dropbox_folder($path)) {
        throw new \RuntimeException('The saved Dropbox folder is invalid.');
    }
    $existing = fetch_dropbox_metadata($path, $token);
    if ($existing === null && $path === PILOT_DROPBOX_FOLDER) {
        request_dropbox_folder_creation($path, $token);
        $existing = fetch_dropbox_metadata($path, $token);
    }
    if (($existing['.tag'] ?? null) !== 'folder') {
        throw new \RuntimeException('The pilot folder could not be verified inside the Dropbox app folder.');
    }
}

/** Create one exact app-relative directory. The caller checks the outcome by reading metadata. */
function request_dropbox_folder_creation(string $path, string $token, int $timeout = 15): void {
    wp_remote_post('https://api.dropboxapi.com/2/files/create_folder_v2', [
        'headers' => ['Authorization' => 'Bearer ' . $token, 'Content-Type' => 'application/json'],
        'body' => wp_json_encode(['path' => $path, 'autorename' => false]),
        'timeout' => $timeout, 'redirection' => 0, 'sslverify' => true, 'limit_response_size' => 65536,
    ]);
}

final class DropboxDestinationOccupied extends \RuntimeException {}

/** Verify or prepare one level of the pinned destination, one Dropbox request at a time. */
function advance_backup_dropbox_folder(string $folder, array $progress, string $token, callable $save, int $timeout = 15): array {
    validate_snapshot_token($token);
    if (!valid_backup_dropbox_folder($folder)) {
        throw new \RuntimeException('The saved Dropbox folder is invalid.');
    }
    $parts = explode('/', substr($folder, 1));
    $depth = count($parts);
    if ($progress === []) {
        $existing = fetch_dropbox_metadata($folder, $token, $timeout);
        if (($existing['.tag'] ?? null) === 'folder') {
            return ['phase' => 'verified'];
        }
        if (($existing['.tag'] ?? null) === 'file') {
            throw new DropboxDestinationOccupied('The Dropbox destination is occupied by a file.');
        }
        if ($existing !== null) {
            throw new \RuntimeException('Dropbox could not confirm the backup destination.');
        }
        return ['phase' => $depth === 1 ? 'create' : 'check', 'index' => 0];
    }
    $phase = $progress['phase'] ?? null;
    $index = $progress['index'] ?? null;
    if (!in_array($phase, ['check', 'create', 'verify'], true) || !is_int($index) || $index < 0 || $index >= $depth) {
        throw new \RuntimeException('The saved Dropbox folder progress is invalid.');
    }
    $path = '/' . implode('/', array_slice($parts, 0, $index + 1));
    if ($phase === 'create') {
        $progress['phase'] = 'verify';
        $save($progress);
        request_dropbox_folder_creation($path, $token, $timeout);
        return $progress;
    }
    $existing = fetch_dropbox_metadata($path, $token, $timeout);
    if (($existing['.tag'] ?? null) === 'folder') {
        return $index + 1 === $depth ? ['phase' => 'verified'] : ['phase' => 'check', 'index' => $index + 1];
    }
    if (($existing['.tag'] ?? null) === 'file') {
        throw new DropboxDestinationOccupied('A part of the Dropbox destination is occupied by a file.');
    }
    if ($existing !== null) {
        throw new \RuntimeException('Dropbox could not confirm the backup destination.');
    }
    if ($phase === 'verify') {
        throw new \RuntimeException('Dropbox has not confirmed the folder creation. Its status can be checked again.');
    }
    return ['phase' => 'create', 'index' => $index];
}

/** Record the immutable Dropbox path, then stream a captured site ZIP through an upload session. */
function upload_dropbox_snapshot(string $capture, string $remote, string $token): array {
    if (!preg_match('~^/PEBKAC Backup Pilot/securitylab-[a-f0-9]{32}\.zip$~D', $remote)) {
        throw new \InvalidArgumentException('Choose a unique SecurityLab ZIP path in the approved Dropbox pilot folder.');
    }
    validate_snapshot_token($token);
    $archive = $capture . '/backup.zip';
    $expected = read_snapshot_manifest($capture . '/manifest.json');
    if (!is_file($archive) || is_link($archive) || filesize($archive) > SNAPSHOT_MAX_BYTES + 8 * 1024 * 1024
        || inspect_snapshot($archive) !== $expected) {
        throw new \RuntimeException('The captured ZIP must match its trusted manifest before upload.');
    }
    $stream = @fopen($archive, 'rb');
    if ($stream === false) {
        throw new \RuntimeException('Could not open the private capture ZIP.');
    }
    try {
        $fingerprint = fingerprint_archive($stream);
        if (!rewind($stream)) {
            throw new \RuntimeException('Could not rewind the private capture ZIP.');
        }
        $intent = ['remote_path' => $remote, 'sha256' => $expected['archive_sha256'], 'fingerprint' => $fingerprint];
        $record = @fopen($capture . '/dropbox-intent.json', 'xb');
        if ($record === false) {
            throw new \RuntimeException('An upload was already recorded for this capture. Check Dropbox before taking further action.');
        }
        try {
            $json = wp_json_encode($intent);
            if ($json === false || fwrite($record, $json) !== strlen($json) || !fflush($record)) {
                throw new \RuntimeException('Could not record the Dropbox upload intent.');
            }
        } finally {
            fclose($record);
        }

        $start = snapshot_dropbox_request('upload_session/start', ['close' => false], '', $token);
        $session = json_decode(wp_remote_retrieve_body($start), true)['session_id'] ?? null;
        if (wp_remote_retrieve_response_code($start) !== 200 || !is_string($session) || $session === '') {
            throw new \RuntimeException('Dropbox did not start the snapshot upload session.');
        }
        $offset = 0;
        $hash = hash_init('sha256');
        while ($offset < $fingerprint['size']) {
            $length = min(SNAPSHOT_CHUNK_BYTES, $fingerprint['size'] - $offset);
            $chunk = stream_get_contents($stream, $length);
            if ($chunk === false || strlen($chunk) !== $length) {
                throw new \RuntimeException('The private ZIP changed during upload.');
            }
            hash_update($hash, $chunk);
            $append = snapshot_dropbox_request('upload_session/append_v2', [
                'cursor' => ['session_id' => $session, 'offset' => $offset], 'close' => false,
            ], $chunk, $token);
            if (wp_remote_retrieve_response_code($append) !== 200) {
                throw new \RuntimeException('Dropbox did not accept a snapshot chunk. The archive was not committed.');
            }
            $offset += $length;
        }
        if (hash_final($hash) !== $expected['archive_sha256']) {
            throw new \RuntimeException('The ZIP no longer matches the capture manifest. The archive was not committed.');
        }
        // The commit may have succeeded despite a timeout. Always read the exact path independently.
        snapshot_dropbox_request('upload_session/finish', [
            'cursor' => ['session_id' => $session, 'offset' => $offset],
            'commit' => ['path' => $remote, 'mode' => 'add', 'autorename' => false, 'strict_conflict' => true, 'mute' => true],
        ], '', $token, true);
        return check_dropbox_snapshot($capture, $token);
    } finally {
        fclose($stream);
    }
}

function check_dropbox_snapshot(string $capture, string $token): array {
    validate_snapshot_token($token);
    $intent = read_snapshot_manifest($capture . '/dropbox-intent.json');
    $manifest = read_snapshot_manifest($capture . '/manifest.json');
    $remote = $intent['remote_path'] ?? '';
    if (!is_string($remote) || !preg_match('~^/PEBKAC Backup Pilot/securitylab-[a-f0-9]{32}\.zip$~D', $remote)
        || !isset($intent['sha256'], $intent['fingerprint'], $manifest['archive_sha256'])
        || $intent['sha256'] !== $manifest['archive_sha256'] || !is_array($intent['fingerprint'])) {
        throw new \RuntimeException('The recorded Dropbox intent does not match the capture manifest.');
    }
    return verify_dropbox_manifest([$remote => $intent['fingerprint']], $token);
}

function download_dropbox_snapshot(string $capture, string $destination, string $token): void {
    if (!check_dropbox_snapshot($capture, $token)['verified']) {
        throw new \RuntimeException('Dropbox does not have a verified copy of this snapshot.');
    }
    $intent = read_snapshot_manifest($capture . '/dropbox-intent.json');
    $size = $intent['fingerprint']['size'];
    if ($size < 1 || $size > SNAPSHOT_MAX_BYTES + 8 * 1024 * 1024 || !@mkdir($destination, 0700)) {
        throw new \RuntimeException('Choose a new private directory for the bounded Dropbox download.');
    }
    $partial = $destination . '/backup.zip.part';
    $response = wp_remote_post('https://content.dropboxapi.com/2/files/download', [
        'headers' => ['Authorization' => 'Bearer ' . $token, 'Dropbox-API-Arg' => wp_json_encode(['path' => $intent['remote_path']])],
        'timeout' => 180, 'redirection' => 0, 'sslverify' => true, 'decompress' => false,
        'stream' => true, 'filename' => $partial, 'limit_response_size' => $size + 1,
    ]);
    clearstatcache(true, $partial);
    if (is_wp_error($response) || wp_remote_retrieve_response_code($response) !== 200
        || !is_file($partial) || filesize($partial) !== $size || hash_file('sha256', $partial) !== $intent['sha256']) {
        if (is_file($partial)) {
            @unlink($partial);
        }
        throw new \RuntimeException('The downloaded ZIP did not match the original capture.');
    }
    if (!rename($partial, $destination . '/backup.zip')) {
        throw new \RuntimeException('Could not publish the verified download in private staging.');
    }
}

function read_snapshot_manifest(string $file): array {
    $limit = SNAPSHOT_MAX_MANIFEST_BYTES;
    $bytes = @file_get_contents($file, false, null, 0, $limit + 1);
    $data = $bytes !== false && strlen($bytes) <= $limit ? json_decode($bytes, true) : null;
    if (!is_array($data)) {
        throw new \RuntimeException('Could not read a private snapshot record.');
    }
    return $data;
}

function validate_snapshot_token(string $token): void {
    if ($token === '' || preg_match('/[\x00-\x20\x7f]/', $token)) {
        throw new \InvalidArgumentException('Configure the Dropbox token in the private machine environment.');
    }
}

function snapshot_dropbox_request(string $endpoint, array $arg, string $body, string $token, bool $uncertain_commit = false) {
    $response = wp_remote_post('https://content.dropboxapi.com/2/files/' . $endpoint, [
        'headers' => ['Authorization' => 'Bearer ' . $token, 'Dropbox-API-Arg' => wp_json_encode($arg), 'Content-Type' => 'application/octet-stream'],
        'body' => $body, 'timeout' => 60, 'redirection' => 0, 'sslverify' => true, 'limit_response_size' => 65536,
    ]);
    if (is_wp_error($response) && !$uncertain_commit) {
        throw new \RuntimeException('Dropbox transfer was interrupted. Preserve the upload record.');
    }
    return $response;
}
