<?php
namespace PEBKAC404\Backup;

require_once __DIR__ . '/snapshot-archive.php';

/** Select a precise scope from a fully inspected full snapshot, never a live destination. */
function selective_snapshot_members(array $manifest, string $kind, string $value = ''): array {
    if (isset($manifest['component']) || isset($manifest['delta']) || !is_array($manifest['files'] ?? null)) {
        throw new \RuntimeException('Choose a verified full snapshot for selective recovery.');
    }
    if ($kind === 'database' && $value === '') {
        $prefix = 'database.sql';
    } elseif ($kind === 'plugin' && preg_match('/^[a-zA-Z0-9][a-zA-Z0-9_.-]*$/D', $value) && !in_array($value, ['.', '..'], true)) {
        $prefix = 'wordpress/wp-content/plugins/' . $value . '/';
    } elseif ($kind === 'folder' && $value !== '' && substr($value, -1) !== '/'
        && valid_snapshot_member_name('wordpress/' . $value . '/placeholder.txt', null)
        && strpos($value, '\\') === false) {
        $prefix = 'wordpress/' . $value . '/';
    } else {
        throw new \RuntimeException('Choose the database, one plugin folder, or one folder within WordPress.');
    }
    $selected = [];
    foreach ($manifest['files'] as $name => $pin) {
        if (($kind === 'database' && $name === $prefix) || ($kind !== 'database' && strpos($name, $prefix) === 0)) {
            $selected[$name] = $pin;
        }
    }
    if ($selected === []) { throw new \RuntimeException('The selected scope is not present in this backup.'); }
    return $selected;
}

/** Verify the whole archive first; stage only the chosen scope into a fresh private directory. */
function stage_selective_snapshot(string $archive, array $manifest, string $destination, string $kind, string $value = '', ?float $deadline = null): array {
    if (inspect_snapshot($archive, $deadline) !== $manifest) {
        throw new \RuntimeException('Downloaded snapshot does not match the trusted capture manifest.');
    }
    $selected = selective_snapshot_members($manifest, $kind, $value);
    $parent = realpath(dirname($destination));
    if ($parent === false || !preg_match('/^[a-zA-Z0-9][a-zA-Z0-9_.-]*$/D', basename($destination))) {
        throw new \RuntimeException('Choose a new directory within an existing private restore folder.');
    }
    for ($path = dirname($destination); ; $path = dirname($path)) {
        if (is_link($path)) { throw new \RuntimeException('The selective restore path contains a link.'); }
        if (dirname($path) === $path || $path === '.') { break; }
    }
    require_snapshot_restore_space($destination, array_sum(array_column($selected, 'size')));
    if (!@mkdir($destination, 0700)) { throw new \RuntimeException('Choose a new isolated selective restore directory.'); }
    $zip = new \ZipArchive();
    if ($zip->open($archive, \ZipArchive::RDONLY) !== true) { throw new \RuntimeException('Could not reopen the verified snapshot.'); }
    try {
        foreach ($selected as $name => $pin) { extract_verified_backup_member($zip, $name, $pin, $destination, $deadline); }
    } finally { $zip->close(); }
    return ['kind'=>'selective_staging','scope'=>$kind,'value'=>$value,'archive_sha256'=>$manifest['archive_sha256'],
        'files'=>count($selected),'bytes'=>array_sum(array_column($selected, 'size'))];
}

if (PHP_SAPI === 'cli' && realpath($_SERVER['SCRIPT_FILENAME'] ?? '') === __FILE__) {
    try {
        if (!in_array($argc, [6,7], true) || !preg_match('/^[a-f0-9]{64}$/D', $argv[3])) {
            throw new \RuntimeException('Usage: php selective-recovery.php BACKUP.zip MANIFEST.json MANIFEST_SHA256 NEW_DIRECTORY database|plugin|folder [SELECTION]');
        }
        if (is_link($argv[2]) || !is_file($argv[2]) || filesize($argv[2]) > SNAPSHOT_MAX_MANIFEST_BYTES) {
            throw new \RuntimeException('Choose a bounded regular recovery manifest.');
        }
        $bytes = file_get_contents($argv[2]);
        if (!hash_equals($argv[3], hash('sha256', $bytes))) { throw new \RuntimeException('The recovery manifest does not match its trusted checksum.'); }
        $manifest = json_decode($bytes, true, 512, JSON_THROW_ON_ERROR);
        echo json_encode(stage_selective_snapshot($argv[1], $manifest, $argv[4], $argv[5], $argv[6] ?? ''), JSON_THROW_ON_ERROR) . PHP_EOL;
    } catch (\Throwable $error) { fwrite(STDERR, $error->getMessage() . PHP_EOL); exit(1); }
}
