<?php

namespace PEBKAC404\Backup;

require_once __DIR__ . '/offsite-verification.php';

/** Verify a trusted local manifest with fresh Dropbox metadata. */
function verify_dropbox_manifest(array $manifest, string $access_token): array {
    if ($access_token === '' || preg_match('/[\x00-\x20\x7f]/', $access_token)) {
        throw new \InvalidArgumentException('Dropbox access token is missing or invalid.');
    }

    return verify_offsite_files($manifest, static function (string $path) use ($access_token): ?array {
        return fetch_dropbox_metadata($path, $access_token);
    });
}

function fetch_dropbox_metadata(string $path, string $access_token, int $timeout = 15): ?array {
    $body = wp_json_encode(['path' => $path]);
    if ($body === false) {
        throw new \InvalidArgumentException('Invalid Dropbox archive path.');
    }

    $response = wp_remote_post('https://api.dropboxapi.com/2/files/get_metadata', [
        'headers' => [
            'Authorization' => 'Bearer ' . $access_token,
            'Content-Type' => 'application/json',
        ],
        'body' => $body,
        'timeout' => $timeout,
        'redirection' => 0,
        'sslverify' => true,
        'limit_response_size' => 65536,
    ]);
    if (is_wp_error($response)) {
        throw new \RuntimeException('Could not reach Dropbox to verify backup files.');
    }

    $code = wp_remote_retrieve_response_code($response);
    if ($code === 401 || $code === 403) {
        throw new \RuntimeException('Dropbox authorization or permissions prevented verification.');
    }
    if ($code === 429) {
        throw new \RuntimeException('Dropbox rate limited the verification request.');
    }

    $metadata = json_decode(wp_remote_retrieve_body($response), true);
    if ($code === 409 && ($metadata['error']['.tag'] ?? null) === 'path'
        && ($metadata['error']['path']['.tag'] ?? null) === 'not_found') {
        return null;
    }
    if ($code !== 200 || !is_array($metadata) || !isset($metadata['.tag'])) {
        throw new \RuntimeException('Dropbox returned an unexpected metadata response.');
    }
    return $metadata;
}

function valid_dropbox_file_revision($revision): bool {
    return is_string($revision) && preg_match('/^[a-f0-9]{9,128}$/D', $revision) === 1;
}

/** Request ordinary Dropbox removal for one exact file revision; the caller handles readback. */
function request_dropbox_retention_removal(string $site, string $path, string $revision, string $access_token, int $timeout = 15): void {
    $folder = substr($path, 0, (int) strrpos($path, '/'));
    if (!valid_dropbox_file_revision($revision) || !pilot_backup_object_path($site, $path, null, $folder)) {
        throw new \RuntimeException('The retention removal target or revision is invalid.');
    }
    validate_snapshot_token($access_token);
    $body = wp_json_encode(['path' => $path, 'parent_rev' => $revision]);
    if ($body === false) {
        throw new \RuntimeException('The Dropbox removal request could not be prepared.');
    }
    $response = wp_remote_post('https://api.dropboxapi.com/2/files/delete_v2', [
        'headers' => ['Authorization' => 'Bearer ' . $access_token, 'Content-Type' => 'application/json'],
        'body' => $body, 'timeout' => $timeout, 'redirection' => 0, 'sslverify' => true, 'limit_response_size' => 65536,
    ]);
    if (is_wp_error($response) || wp_remote_retrieve_response_code($response) !== 200) {
        throw new \RuntimeException('Dropbox did not confirm the retention removal. Check the saved intent.');
    }
}
