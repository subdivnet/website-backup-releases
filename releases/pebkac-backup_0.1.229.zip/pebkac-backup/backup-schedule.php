<?php

namespace PEBKAC404\Backup;

require_once __DIR__ . '/parked-daily-backup.php';

const BACKUP_SCHEDULE_STATE_OPTION = 'pebkac_backup_schedule_state';
const SCHEDULED_BACKUP_JOB_OPTION = 'pebkac_backup_scheduled_job';
const DEFERRED_COMPONENT_CAPTURES_OPTION = 'pebkac_backup_deferred_components';

/** Find the first occurrence at or after the supplied timestamp in the site's timezone. */
function backup_schedule_occurrence($schedule, \DateTimeZone $timezone, int $from): ?int {
    if (!is_array($schedule)) {
        return null;
    }
    $frequency = $schedule['frequency'] ?? '';
    $time = $schedule['time'] ?? '';
    if (!in_array($frequency, ['daily', 'weekly'], true) || !is_string($time)
        || !preg_match('/^(?:[01][0-9]|2[0-3]):[0-5][0-9]$/D', $time)) {
        return null;
    }
    $local = (new \DateTimeImmutable('@' . $from))->setTimezone($timezone);
    $offset = 0;
    if ($frequency === 'weekly') {
        $weekday = array_search($schedule['day'] ?? '', DAYS, true);
        if ($weekday === false) {
            return null;
        }
        $offset = ($weekday + 8 - (int) $local->format('N')) % 7;
    }
    $day = $local->modify('+' . $offset . ' days');
    $candidate = new \DateTimeImmutable($day->format('Y-m-d') . ' ' . $time, $timezone);
    if ($candidate->getTimestamp() < $from) {
        $day = $day->modify($frequency === 'daily' ? '+1 day' : '+7 days');
        $candidate = new \DateTimeImmutable($day->format('Y-m-d') . ' ' . $time, $timezone);
    }
    return $candidate->getTimestamp();
}

/** Find the latest due time covered when a fresh capture was reserved. */
function latest_due_backup_occurrence(array $rules, \DateTimeZone $timezone, int $reserved_at): ?int {
    $midnight = (new \DateTimeImmutable('@' . $reserved_at))->setTimezone($timezone)->setTime(0, 0);
    $from = $midnight->modify($rules['frequency'] === 'weekly' ? '-7 days' : '-1 day')->getTimestamp();
    $previous = backup_schedule_occurrence($rules, $timezone, $from);
    if ($previous === null || $previous > $reserved_at) {
        return null;
    }
    $next = backup_schedule_occurrence($rules, $timezone, $previous + 1);
    return $next !== null && $next <= $reserved_at ? $next : $previous;
}

/** Preserve the oldest unfulfilled occurrence until that occurrence is verified off-site. */
function backup_schedule_status($schedule, \DateTimeZone $timezone, int $enabled_at, ?int $verified_due_at, int $now): array {
    $from = $verified_due_at !== null && $verified_due_at >= $enabled_at && $verified_due_at <= $now
        ? $verified_due_at + 1 : $enabled_at;
    $due = backup_schedule_occurrence($schedule, $timezone, $from);
    return [
        'next_due_at' => $due,
        'overdue_since' => $due !== null && $due < $now ? $due : null,
    ];
}

function component_schedule_rules($schedule, \DateTimeZone $timezone, int $now): ?array {
    if (backup_schedule_occurrence($schedule, $timezone, $now) === null) {
        return null;
    }
    return [
        'frequency' => $schedule['frequency'],
        'time' => $schedule['time'],
        'day' => $schedule['frequency'] === 'weekly' ? $schedule['day'] : null,
        'timezone' => $timezone->getName(),
    ];
}

/** Reconcile active schedules while holding the backup job lock. Call only when the worker is enabled. */
function sync_backup_schedule_state(array $plan, \DateTimeZone $timezone, int $now): array {
    $saved = get_option(BACKUP_SCHEDULE_STATE_OPTION, []);
    $state = [];
    foreach (COMPONENTS as $component => $label) {
        $rules = component_schedule_rules($plan['schedules'][$component] ?? null, $timezone, $now);
        if ($rules === null) {
            continue;
        }
        $previous = $saved[$component] ?? null;
        if (is_array($previous) && ($previous['rules'] ?? null) === $rules
            && is_int($previous['enabled_at'] ?? null) && $previous['enabled_at'] > 0
            && array_key_exists('verified_due_at', $previous)
            && ($previous['verified_due_at'] === null || is_int($previous['verified_due_at']))) {
            $state[$component] = $previous;
        } else {
            $state[$component] = ['rules' => $rules, 'enabled_at' => $now, 'verified_due_at' => null];
        }
    }
    if ($state !== $saved && !update_option(BACKUP_SCHEDULE_STATE_OPTION, $state, false)) {
        throw new \RuntimeException('Could not save the backup schedule state.');
    }
    return $state;
}

/** Advance an occurrence after its off-site verification, while holding the backup job lock. */
function record_backup_schedule_verification(string $component, array $claimed, int $due, int $verified_at, int $now, ?int $reserved_at = null): bool {
    $state = get_option(BACKUP_SCHEDULE_STATE_OPTION, []);
    $current = $state[$component] ?? null;
    if (!isset(COMPONENTS[$component]) || !is_array($current) || $verified_at < $due || $verified_at > $now) {
        return false;
    }
    $rules = $claimed['rules'];
    $timezone = new \DateTimeZone($rules['timezone']);
    $covered_due = $due;
    if ($reserved_at !== null) {
        if ($reserved_at < $due || $reserved_at > $verified_at) {
            return false;
        }
        $covered_due = latest_due_backup_occurrence($rules, $timezone, $reserved_at);
        if ($covered_due === null || $covered_due < $due) {
            return false;
        }
    }
    $verified = $claimed;
    $verified['verified_due_at'] = $covered_due;
    if ($current === $verified) {
        return true;
    }
    if ($current !== $claimed) {
        return false;
    }
    $expected = backup_schedule_status($rules, $timezone, $claimed['enabled_at'], $claimed['verified_due_at'], $now);
    if ($expected['next_due_at'] !== $due) {
        return false;
    }
    $state[$component] = $verified;
    if (!update_option(BACKUP_SCHEDULE_STATE_OPTION, $state, false)) {
        throw new \RuntimeException('Could not save the verified scheduled backup.');
    }
    return true;
}

/** Read the schedule without writing options or starting backup work. */
function scheduled_backup_due_times(array $state, int $now): array {
    $times = [];
    foreach ($state as $component => $record) {
        $rules = $record['rules'];
        $timezone = new \DateTimeZone($rules['timezone']);
        $times[$component] = backup_schedule_status($rules, $timezone, $record['enabled_at'], $record['verified_due_at'], $now);
    }
    return $times;
}

function pending_scheduled_backup(): array {
    $pending = get_option(SCHEDULED_BACKUP_JOB_OPTION, []);
    if ($pending !== [] && (!is_array($pending) || !is_string($pending['id'] ?? null) || !preg_match('/^[a-f0-9]{32}$/D', $pending['id'])
        || !is_string($pending['component'] ?? null) || !isset(COMPONENTS[$pending['component']]) || !is_int($pending['due_at'] ?? null)
        || !is_array($pending['schedule'] ?? null)
        || (array_key_exists('reserved_at', $pending) && (!is_int($pending['reserved_at']) || $pending['reserved_at'] < $pending['due_at'])))) {
        throw new \RuntimeException('Could not read the saved scheduled backup.');
    }
    return $pending;
}

/** Reserve one due component while holding the backup job lock, before any transfer. */
function claim_scheduled_backup(array $state, int $now): ?array {
    $pending = pending_scheduled_backup();
    if ($pending !== []) {
        return $pending;
    }
    $job = null;
    foreach (scheduled_backup_due_times($state, $now) as $component => $timing) {
        $due = $timing['next_due_at'];
        if ($due !== null && $due <= $now && ($job === null || $due < $job['due_at'])) {
            $job = ['component' => $component, 'due_at' => $due, 'schedule' => $state[$component]];
        }
    }
    if ($job === null) {
        return null;
    }
    $job['id'] = bin2hex(random_bytes(16));
    $job['reserved_at'] = $now;
    if (!update_option(SCHEDULED_BACKUP_JOB_OPTION, $job, false)) {
        throw new \RuntimeException('Could not save the scheduled backup before starting it.');
    }
    return $job;
}

function scheduled_backup_uses_current_rules(array $current, array $claim): bool {
    return ($current['rules'] ?? null) === ($claim['schedule']['rules'] ?? false)
        && ($current['enabled_at'] ?? null) === ($claim['schedule']['enabled_at'] ?? false);
}

function scheduled_component_job_matches_claim(array $job, array $claim): bool {
    return isset($job['id'], $job['component'], $job['scheduled_due_at'])
        && ($claim['id'] ?? null) === $job['id']
        && ($claim['component'] ?? null) === $job['component']
        && ($claim['due_at'] ?? null) === $job['scheduled_due_at'];
}

function local_component_capture_without_transfer(array $job): bool {
    return in_array($job['phase'] ?? '', ['database', 'exporting', 'files', 'archiving', 'replay_inventory', 'incremental_files', 'plan_transfer'], true)
        && !isset($job['folder_progress']) && !isset($job['transfer']) && !isset($job['manifest_transfer']);
}

/** A schedule edit can replace a local capture, but an existing transfer keeps its claim. */
function component_backup_worker_has_job(array $plan, array $job): bool {
    $component = $job['component'] ?? null;
    $claim = (array) get_option(SCHEDULED_BACKUP_JOB_OPTION, []);
    if (!is_string($component) || !isset(COMPONENTS[$component]) || !component_backups_enabled($plan)
        || !scheduled_component_job_matches_claim($job, $claim)) {
        return false;
    }
    if (!local_component_capture_without_transfer($job)) {
        return true;
    }
    $rules = component_schedule_rules($plan['schedules'][$component] ?? null, wp_timezone(), time());
    $state = get_option(BACKUP_SCHEDULE_STATE_OPTION, []);
    $current = $state[$component] ?? null;
    return $rules !== null && is_array($current) && ($current['rules'] ?? null) === $rules
        && scheduled_backup_uses_current_rules($current, $claim);
}

/** Settle a claimed job only after its own Dropbox objects were verified. Caller holds the backup job lock. */
function settle_scheduled_backup(array $job, string $verified_job_id, int $verified_at, int $now): bool {
    if (get_option(SCHEDULED_BACKUP_JOB_OPTION, []) !== $job || ($job['id'] ?? null) !== $verified_job_id
        || $verified_at < $job['due_at'] || $verified_at > $now) {
        return false;
    }
    $schedules = get_option(BACKUP_SCHEDULE_STATE_OPTION, []);
    $current = $schedules[$job['component']] ?? [];
    $same_schedule = scheduled_backup_uses_current_rules($current, $job);
    if ($same_schedule && !record_backup_schedule_verification($job['component'], $job['schedule'], $job['due_at'], $verified_at, $now,
        $job['reserved_at'] ?? null)) {
        return false;
    }
    if (!update_option(SCHEDULED_BACKUP_JOB_OPTION, [], false)) {
        throw new \RuntimeException('The scheduled backup verified but its saved job could not be closed.');
    }
    return true;
}

/** Close a verified component only when the saved recovery point matches both transfers. */
function settle_completed_component_backup(array $job, array $claim, int $now): void {
    $path = pilot_backup_base(home_url(), $claim['id'], $claim['component'], backup_dropbox_folder($job)) . '.zip';
    $history = get_option(COMPONENT_RECOVERY_STATE_OPTION, []);
    $record = $history['records'][$path] ?? [];
    if (($job['phase'] ?? null) !== 'verified' || ($job['id'] ?? null) !== $claim['id']
        || ($job['component'] ?? null) !== $claim['component'] || ($job['scheduled_due_at'] ?? null) !== $claim['due_at']
        || ($record['archive_sha256'] ?? null) !== ($job['transfer']['sha256'] ?? false)
        || ($record['manifest_sha256'] ?? null) !== ($job['manifest_transfer']['sha256'] ?? false)
        || !is_int($record['offsite_verified_at'] ?? null)
        || !settle_scheduled_backup($claim, $job['id'], $record['offsite_verified_at'], $now)) {
        throw new \RuntimeException('The scheduled component could not be confirmed as verified.');
    }
    if (empty($job['cleanup_pending'])) {
        queue_waiting_backup_retention_event();
    }
}

/** Apply changed component settings to a saved claim that has never started an upload. */
function discard_obsolete_local_component(string $root, array $job, array $schedules): array {
    $pending = pending_scheduled_backup();
    if ($pending === [] || scheduled_backup_uses_current_rules($schedules[$pending['component']] ?? [], $pending)) {
        return $job;
    }
    if (($job['id'] ?? null) === $pending['id']) {
        if (!scheduled_component_job_matches_claim($job, $pending) || !local_component_capture_without_transfer($job)) {
            return $job;
        }
        clear_local_backup_capture_files($root, $pending['id']);
        if (!@unlink($root . '/job.json')) {
            throw new \RuntimeException('Could not close the obsolete local component capture.');
        }
        $job = [];
    } elseif ($job !== [] && ($job['phase'] !== 'verified' || !empty($job['cleanup_pending']))) {
        return $job;
    }
    if (!update_option(SCHEDULED_BACKUP_JOB_OPTION, [], false)) {
        throw new \RuntimeException('Could not clear the obsolete component claim.');
    }
    return $job;
}

/** A disabled worker can close a local or verified capture without touching Dropbox. */
function release_disabled_component_backup(string $root, array $job, int $now): array {
    if (!isset($job['component'])) {
        return $job;
    }
    $claim = pending_scheduled_backup();
    if (($claim['id'] ?? null) !== $job['id']) {
        return $job;
    }
    if ($job['phase'] === 'verified') {
        settle_completed_component_backup($job, $claim, $now);
        return $job;
    }
    return discard_obsolete_local_component($root, $job, []);
}

/** Finish clearing a claim after its local job has already been removed. */
function finish_deferred_component_claim(array $job, array $deferred): void {
    $pending = pending_scheduled_backup();
    if ($pending === [] || ($deferred[$pending['component']]['claim'] ?? null) !== $pending
        || ($job['id'] ?? null) === $pending['id'] || ($job !== [] && $job['phase'] !== 'verified')) {
        return;
    }
    if (!update_option(SCHEDULED_BACKUP_JOB_OPTION, [], false)) {
        throw new \RuntimeException('Could not release the deferred component claim.');
    }
}

/** A component that used its local retry yields the worker until its next scheduled occurrence. */
function defer_paused_component_capture(string $root, int $now): bool {
    return with_backup_job_lock($root, static function () use ($root, $now): bool {
        $job = read_backup_job($root);
        $component = $job['component'] ?? '';
        if (!isset(COMPONENTS[$component]) || !restartable_backup_capture($job) || isset($job['folder_progress'])
            || ($job['automatic_capture_retry'] ?? false) !== true) {
            return false;
        }
        $claim = pending_scheduled_backup();
        if (($claim['id'] ?? null) !== $job['id'] || ($claim['component'] ?? null) !== $component
            || ($claim['due_at'] ?? null) !== ($job['scheduled_due_at'] ?? null)) {
            return false;
        }
        $rules = $claim['schedule']['rules'] ?? [];
        $timezone = new \DateTimeZone($rules['timezone'] ?? 'UTC');
        $retry_at = backup_schedule_occurrence($rules, $timezone, $now + 1);
        if ($retry_at === null) {
            return false;
        }
        $deferred = (array) get_option(DEFERRED_COMPONENT_CAPTURES_OPTION, []);
        if (($deferred[$component]['claim'] ?? null) !== $claim) {
            $pause = ['claim' => $claim, 'retry_at' => $retry_at];
            $problem = $job['capture_problem'] ?? null;
            if (backup_capture_problem_message($problem) !== '') {
                $pause['problem'] = $problem;
            }
            $deferred[$component] = $pause;
            if (!update_option(DEFERRED_COMPONENT_CAPTURES_OPTION, $deferred, false)) {
                throw new \RuntimeException('Could not save when the paused component can retry.');
            }
        }
        clear_interrupted_backup_capture($root, $job);
        if (!@unlink($root . '/job.json')) {
            throw new \RuntimeException('Could not release the paused local capture.');
        }
        finish_deferred_component_claim([], $deferred);
        return true;
    });
}

/** Return only retry times for unchanged rules that still have a local pause. */
function deferred_component_retry_times(array $schedules, array $deferred, int $now): array {
    $times = [];
    foreach ($schedules as $component => $current) {
        $claim = $deferred[$component]['claim'] ?? null;
        $retry_at = $deferred[$component]['retry_at'] ?? null;
        if (is_array($claim) && ($claim['component'] ?? null) === $component
            && is_int($claim['due_at'] ?? null) && ($current['verified_due_at'] ?? 0) < $claim['due_at']
            && is_int($retry_at) && $retry_at > $now && scheduled_backup_uses_current_rules($current, $claim)) {
            $times[$component] = $retry_at;
        }
    }
    return $times;
}

/** Advance a single scheduled component while sharing the full backup's private job lock. */
function run_scheduled_component_step(string $root, array $plan, \DateTimeZone $timezone, int $now, callable $advance): string {
    return with_backup_job_lock($root, static function () use ($root, $plan, $timezone, $now, $advance): string {
        clear_abandoned_backup_records($root, $now);
        $job = read_backup_job($root);
        if (($job['phase'] ?? null) === 'verified' && !empty($job['cleanup_pending'])) {
            try {
                $job = retry_verified_backup_staging($root, $job, $job['id']);
                queue_waiting_backup_retention_event();
            } catch (\RuntimeException $error) {
                return 'waiting_for_local_cleanup';
            }
        }
        if ($job !== [] && !isset($job['component']) && $job['phase'] !== 'verified') {
            return 'busy';
        }
        if (isset($job['component']) && $job['phase'] !== 'verified') {
            $pending = get_option(SCHEDULED_BACKUP_JOB_OPTION, []);
            if (($pending['id'] ?? null) !== $job['id']) {
                return 'blocked';
            }
        }
        $parked = read_parked_daily_backup($root);
        $held = parked_component_job($parked, home_url());
        if ($held !== []) {
            if (($job['id'] ?? null) === $held['id']) {
                return 'blocked';
            }
            release_parked_component_claim($root, $parked, $held);
        }
        $state = sync_backup_schedule_state($plan, $timezone, $now);
        $job = discard_obsolete_local_component($root, $job, $state);
        $deferred = (array) get_option(DEFERRED_COMPONENT_CAPTURES_OPTION, []);
        finish_deferred_component_claim($job, $deferred);
        $state = array_diff_key($state, deferred_component_retry_times($state, $deferred, $now));
        if ($held !== []) {
            unset($state[$held['component']]);
        }
        $claim = claim_scheduled_backup($state, $now);
        if ($claim === null) {
            return 'waiting';
        }
        if (isset($job['component']) && $job['id'] === $claim['id']) {
            if ($job['component'] !== $claim['component'] || ($job['scheduled_due_at'] ?? null) !== $claim['due_at']) {
                throw new \RuntimeException('The saved component job does not match its scheduled occurrence.');
            }
            if ($job['phase'] === 'verified') {
                settle_completed_component_backup($job, $claim, $now);
                return 'settled';
            }
            if (backup_job_upload_uncertain($job)) {
                return 'blocked';
            }
            if (in_array($job['phase'], ['exporting', 'archiving'], true)) {
                return retry_scheduled_backup_capture($root, $job);
            }
        } else {
            if ($job !== [] && ($job['phase'] !== 'verified' || !empty($job['cleanup_pending']))) {
                return 'busy';
            }
            preserve_completed_backup_size($job, home_url(), $now);
            $component = $claim['component'];
            $job = ['id' => $claim['id'], 'component' => $component, 'scheduled_due_at' => $claim['due_at'],
                'phase' => $component === 'database' ? 'database' : 'files'];
            $folder = backup_dropbox_folder($plan);
            if ($folder !== PILOT_DROPBOX_FOLDER) {
                $job['folder'] = $folder;
            }
            if ($component !== 'database' && ($plan['incremental_components'] ?? false) === true) {
                $history = get_option(COMPONENT_RECOVERY_STATE_OPTION, ['records' => [], 'latest' => []]);
                $chain = plan_component_inventory_replay(home_url(), $component, $history, $now);
                if ($chain !== [] && count($chain) < COMPONENT_REPLAY_MAX_MANIFESTS) {
                    $job['phase'] = 'replay_inventory';
                    $job['incremental'] = true;
                    $job['preflight_incremental_destination'] = true;
                }
            }
            write_backup_job($root, $job);
        }
        $advance($root, $job);
        return 'advanced';
    });
}

const COMPONENT_BACKUP_HOOK = 'pebkac_backup_component_step';

function component_backups_enabled(array $plan): bool {
    return ($plan['component_jobs'] ?? false) === true;
}

function component_only_backups_enabled(array $plan): bool {
    return component_backups_enabled($plan) && !daily_backup_settings($plan)['enabled']
        && array_intersect(array_column((array) ($plan['schedules'] ?? []), 'frequency'), ['daily', 'weekly']) !== [];
}

function queue_component_backup_event(int $at): void {
    if (component_backups_enabled(get_plan()) && wp_next_scheduled(COMPONENT_BACKUP_HOOK) === false) {
        wp_schedule_single_event($at, COMPONENT_BACKUP_HOOK);
    }
}

function run_component_backup_event(): void {
    $plan = get_plan();
    if (!component_backups_enabled($plan)) {
        return;
    }
    $now = time();
    $timezone = wp_timezone();
    $next = $now + 3600;
    $root = '';
    $notify_retry = false;
    try {
        if (backup_capture_supported() && dropbox_saved_refresh_token(dropbox_app_key()) !== '') {
            $root = backup_job_root(true);
            $result = run_scheduled_component_step($root, $plan, $timezone, $now, __NAMESPACE__ . '\\advance_backup_job');
            if (in_array($result, ['advanced', 'settled', 'busy'], true)) {
                $next = $now + 60;
            } elseif ($result === 'blocked') {
                notify_paused_scheduled_backup($root, $plan);
                if (defer_paused_component_capture($root, $now)) {
                    $next = $now + 60;
                }
            } elseif ($result === 'waiting') {
                $state = get_option(BACKUP_SCHEDULE_STATE_OPTION, []);
                $held = parked_component_job(read_parked_daily_backup($root), home_url());
                if ($held !== []) {
                    unset($state[$held['component']]);
                }
                $due_times = array_filter(array_map(static function (array $timing): ?int {
                    return $timing['next_due_at'];
                }, scheduled_backup_due_times($state, $now)), 'is_int');
                foreach (deferred_component_retry_times($state, (array) get_option(DEFERRED_COMPONENT_CAPTURES_OPTION, []), $now) as $component => $retry_at) {
                    $due_times[$component] = max($due_times[$component] ?? 0, $retry_at);
                }
                $next = $due_times === [] ? $now + 3600 : max($now + 60, min($due_times));
            }
        }
    } catch (\RuntimeException $error) {
        if ($root !== '') {
            try {
                [$job, $running] = read_backup_job_progress($root);
                $claim = pending_scheduled_backup();
                if ($running) {
                    $next = time() + 60;
                } elseif (scheduled_component_job_matches_claim($job, $claim)
                    && backup_job_can_retry_safely($job)) {
                    $next = time() + 900;
                    $notify_retry = true;
                }
            } catch (\RuntimeException $unavailable) {
                // Keep the normal schedule when private staging cannot be read.
            }
        }
    } finally {
        queue_component_backup_event($next);
    }
    if ($notify_retry) {
        notify_paused_scheduled_backup($root, $plan);
    }
}

function reconcile_component_backup_event(array $old, array $new): void {
    $was_enabled = component_backups_enabled($old);
    $enabled = component_backups_enabled($new);
    if ($was_enabled === $enabled && ($old['schedules'] ?? []) === ($new['schedules'] ?? [])) {
        return;
    }
    wp_clear_scheduled_hook(COMPONENT_BACKUP_HOOK);
    queue_component_backup_event(time() + 60);
    if (!$enabled && !$was_enabled) {
        return;
    }
    try {
        $root = backup_job_root(true);
        with_backup_job_lock($root, static function () use ($root): void {
            $plan = get_plan();
            $now = time();
            if (component_backups_enabled($plan)) {
                sync_backup_schedule_state($plan, wp_timezone(), $now);
                return;
            }
            release_disabled_component_backup($root, read_backup_job($root), $now);
            sync_backup_schedule_state([], wp_timezone(), $now);
        });
    } catch (\RuntimeException $error) {
        // Scheduled workers can reconcile once staging is available.
    }
}

add_action(COMPONENT_BACKUP_HOOK, __NAMESPACE__ . '\\run_component_backup_event');

/** Report enabled component schedules, including the first upcoming time before their worker runs. */
function active_component_backup_status(array $plan, $state, \DateTimeZone $timezone, int $now): array {
    if (!component_backups_enabled($plan) || !is_array($state)) {
        return [];
    }
    $current = [];
    foreach (array_keys(COMPONENTS) as $component) {
        $record = $state[$component] ?? null;
        $rules = component_schedule_rules($plan['schedules'][$component] ?? null, $timezone, $now);
        if ($rules === null) {
            continue;
        }
        if (is_array($record) && ($record['rules'] ?? null) === $rules
            && is_int($record['enabled_at'] ?? null) && $record['enabled_at'] > 0
            && $record['enabled_at'] <= $now && array_key_exists('verified_due_at', $record)
            && ($record['verified_due_at'] === null || is_int($record['verified_due_at']))) {
            $current[$component] = $record;
        } else {
            $current[$component] = ['rules' => $rules, 'enabled_at' => $now, 'verified_due_at' => null];
        }
    }
    $times = scheduled_backup_due_times($current, $now);
    $deferred = (array) get_option(DEFERRED_COMPONENT_CAPTURES_OPTION, []);
    foreach (deferred_component_retry_times($current, $deferred, $now) as $component => $retry_at) {
        $times[$component]['retry_at'] = $retry_at;
        $problem = $deferred[$component]['problem'] ?? null;
        if (backup_capture_problem_message($problem) !== '') {
            $times[$component]['capture_problem'] = $problem;
        }
    }
    return $times;
}
