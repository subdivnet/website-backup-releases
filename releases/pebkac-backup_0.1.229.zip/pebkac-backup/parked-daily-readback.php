<?php

namespace PEBKAC404\Backup;

if (!defined('ABSPATH')) {
    exit;
}

const PARKED_DAILY_CHECK_OPTION = 'pebkac_backup_parked_daily_check';

function parked_daily_dropbox_metadata(int $maximum_requests = 3): callable {
    $timeout = max(1, min(5, intdiv((int) backup_request_budget(), $maximum_requests)));
    $token = null;
    return static function (string $path) use (&$token, $timeout): ?array {
        if ($token === null) {
            $app = dropbox_app_key();
            $refresh = dropbox_saved_refresh_token($app);
            if ($refresh === '') {
                throw new \RuntimeException('The Dropbox connection is unavailable.');
            }
            $token = refresh_dropbox_access_token($app, $refresh, $timeout);
        }
        return fetch_dropbox_metadata($path, $token, $timeout);
    };
}

/** Describe a parked full backup only when both uploaded files have complete saved checksums. */
function parked_full_recovery_evidence(array $record, string $site, int $verified_at): array {
    $job = $record['parked'] ?? [];
    if (isset($job['component']) || parked_daily_backup_day($record, $site) === ''
        || ($job['phase'] ?? null) !== 'manifest'
        || !in_array($job['manifest_transfer']['phase'] ?? '', ['committing', 'verify', 'verified'], true)) {
        return [];
    }
    $pins = parked_daily_recovery_pins($record, $site);
    $archive = $job['transfer'] ?? [];
    $manifest = $job['manifest_transfer'] ?? [];
    if (count($pins) !== 2 || !is_string($archive['sha256'] ?? null) || !is_string($manifest['sha256'] ?? null)
        || ($job['manifest_sha256'] ?? null) !== $manifest['sha256']) {
        return [];
    }
    $archive_path = $archive['path'];
    $manifest_path = $manifest['path'];
    return verified_evidence([
        'kind' => 'site_snapshot', 'site' => $site, 'run_type' => 'daily',
        'archive_path' => $archive_path, 'archive_sha256' => $archive['sha256'],
        'manifest_path' => $manifest_path, 'manifest_sha256' => $manifest['sha256'],
        'offsite_verified_at' => $verified_at, 'archive_size_bytes' => $pins[$archive_path]['size'],
        'folder' => backup_dropbox_folder($job),
        'dropbox_objects' => ['archive' => $pins[$archive_path], 'manifest' => $pins[$manifest_path]],
    ], $site, $verified_at);
}

/** Derive only the stored objects for the original pilot and exact earlier backup identity. */
function parked_daily_recovery_pins(array $record, string $site): array {
    $job = $record['parked'] ?? null;
    $component = $job['component'] ?? null;
    if (($record['site'] ?? null) !== $site || !is_array($job) || !is_string($job['id'] ?? null)
        || ($component !== null && !is_string($component))) {
        throw new \RuntimeException('The earlier upload record does not belong to this site.');
    }
    $folder = backup_dropbox_folder($job);
    $base = pilot_backup_base($site, $job['id'], $component, $folder);
    $pins = [];
    $limits = [
        'transfer' => ['.zip', SNAPSHOT_MAX_BYTES + 8 * 1024 * 1024],
        'manifest_transfer' => ['.manifest.json', SNAPSHOT_MAX_MANIFEST_BYTES],
    ];
    foreach ($limits as $field => [$extension, $limit]) {
        $object = $job[$field] ?? [];
        if ($object === []) {
            continue;
        }
        $size = $object['size'] ?? null;
        $digest = $object['content_hash'] ?? null;
        if (($object['path'] ?? null) !== $base . $extension || !is_int($size) || $size < 1 || $size > $limit
            || !is_string($digest) || !preg_match('/^[a-f0-9]{64}$/D', $digest)) {
            throw new \RuntimeException('A stored object for the earlier upload has invalid verification details.');
        }
        $pins[$object['path']] = ['size' => $size, 'content_hash' => $digest];
    }
    if ($pins !== [] && !isset($pins[$base . '.zip'])) {
        throw new \RuntimeException('The earlier upload is missing its archive verification details.');
    }
    return $pins;
}

/** Free a preserved local capture after a newer full backup has verified and Dropbox confirms the old paths are absent. */
function clear_unstored_parked_backup(string $root, array $record, string $site, int $now, callable $metadata): string {
    $job = $record['parked'] ?? [];
    $active = read_backup_job($root);
    $latest = verified_evidence(get_option(EVIDENCE_OPTION, []), $site, $now);
    $followup = $record['followup'] ?? [];
    $followup_day = $followup['daily_date'] ?? '';
    if (parked_daily_backup_day($record, $site) === '' || isset($job['component']) || isset($record['recovered_full'])
        || !valid_parked_backup_day($followup_day)
        || ($active['id'] ?? null) === ($job['id'] ?? null) || empty($latest['dropbox_objects'])) {
        throw new \RuntimeException('A newer verified full backup is required before clearing the earlier local files.');
    }
    $verified_day = (new \DateTimeImmutable('@' . $latest['offsite_verified_at']))->setTimezone(wp_timezone())->format('Y-m-d');
    $pins = parked_daily_recovery_pins($record, $site);
    if ($verified_day < $followup_day || $pins === [] || isset($pins[$latest['archive_path']])) {
        throw new \RuntimeException('A newer verified full backup is required before clearing the earlier local files.');
    }
    $history = get_option(VERIFIED_BACKUP_HISTORY_OPTION, []);
    $journal = get_option(BACKUP_RETENTION_JOURNAL_OPTION, []);
    if (!is_array($history)) {
        throw new \RuntimeException('The verified backup history could not be read.');
    }
    if ($journal !== []) {
        throw new \RuntimeException('Wait for the pending Dropbox cleanup before clearing the earlier local files.');
    }
    foreach (array_keys($pins) as $path) {
        if (isset($history[$path])) {
            throw new \RuntimeException('The earlier upload is still listed in verified backup history.');
        }
    }
    $authorization = component_readback_authorization();
    if ($authorization === '') {
        throw new \RuntimeException('Connect Dropbox before checking the earlier upload.');
    }
    if (!verify_offsite_files([$latest['archive_path'] => $latest['dropbox_objects']['archive'],
        $latest['manifest_path'] => $latest['dropbox_objects']['manifest']], $metadata)['verified']) {
        throw new \RuntimeException('Dropbox could not confirm the newer recovery files. The earlier local files were kept.');
    }
    foreach (array_keys($pins) as $path) {
        if ($metadata($path) !== null) {
            throw new \RuntimeException('Dropbox still has a file at an earlier upload path. The local files were kept.');
        }
    }
    if ($authorization !== component_readback_authorization()) {
        throw new \RuntimeException('The Dropbox connection changed during the earlier backup check.');
    }
    clear_local_backup_capture_files($root, $job['id']);
    if (!@unlink($root . '/' . PARKED_DAILY_BACKUP_FILE)) {
        throw new \RuntimeException('The local files were cleared but the saved upload still needs review.');
    }
    if ((private_fleet_refresh_record()['enabled'] ?? false) === true) {
        request_private_fleet_refresh($site, $now);
    }
    return 'cleared';
}

function parked_backup_can_offer_local_cleanup(array $record, string $site, $check, int $now): bool {
    if (isset($record['parked']['component']) || isset($record['recovered_full'])
        || ($check['id'] ?? null) !== ($record['parked']['id'] ?? false) || ($check['all_missing'] ?? false) !== true) {
        return false;
    }
    $latest = verified_evidence(get_option(EVIDENCE_OPTION, []), $site, $now);
    $day = $record['followup']['daily_date'] ?? '';
    return !empty($latest['dropbox_objects']) && valid_parked_backup_day($day)
        && (new \DateTimeImmutable('@' . $latest['offsite_verified_at']))->setTimezone(wp_timezone())->format('Y-m-d') >= $day;
}

/** Return a small read-only result. The metadata callback cannot change Dropbox objects. */
function check_parked_daily_recovery(array $record, string $site, int $now, callable $metadata): array {
    $pins = parked_daily_recovery_pins($record, $site);
    if ($pins === []) {
        throw new \RuntimeException('The earlier upload has no saved Dropbox checksums.');
    }
    $missing = 0;
    try {
        $result = verify_offsite_files($pins, static function (string $path) use ($metadata, &$missing): ?array {
            $actual = $metadata($path);
            $missing += (int) ($actual === null);
            return $actual;
        });
        $matched = count($pins) - count($result['failures']);
        $state = $matched === count($pins) ? 'matched' : 'incomplete';
    } catch (\RuntimeException $error) {
        $matched = 0;
        $state = 'unavailable';
    }
    $result = ['id' => $record['parked']['id'], 'at' => $now, 'state' => $state, 'checked' => count($pins), 'matched' => $matched];
    if ($state === 'incomplete' && $missing === count($pins)) {
        $result['all_missing'] = true;
    }
    return $result;
}

function parked_daily_recovery_check_label(array $record, $result, int $now): string {
    $at = $result['at'] ?? null;
    $state = $result['state'] ?? '';
    $checked = $result['checked'] ?? null;
    $matched = $result['matched'] ?? null;
    if (!isset($record['parked']['id']) || ($result['id'] ?? null) !== $record['parked']['id']
        || !is_int($at) || $at < 1 || $at > $now || !is_string($state) || !in_array($checked, [1, 2], true)
        || !is_int($matched) || $matched < 0 || $matched > $checked) {
        return '';
    }
    $messages = [
        'matched' => $checked === 2 ? 'Dropbox confirmed the archive and its restore manifest.' : 'Dropbox confirmed the archive.',
        'incomplete' => 'Dropbox confirmed ' . $matched . ' of ' . $checked . ' recorded files.',
        'unavailable' => 'Dropbox could not complete the check.',
    ];
    return isset($messages[$state]) ? 'Checked ' . wp_date('M j, Y H:i T', $at) . '. ' . $messages[$state] : '';
}

/** Keep the independently verified pair in history before clearing staging under the shared backup lock. */
function recover_parked_full_backup(string $root, array $record, string $site, int $now, callable $metadata): string {
    $active = read_backup_job($root);
    $job = $record['parked'] ?? [];
    if (($active['id'] ?? null) === ($job['id'] ?? null) || get_option(BACKUP_RETENTION_JOURNAL_OPTION, []) !== []) {
        throw new \RuntimeException('Wait for the separate backup or cleanup before recovering the earlier upload.');
    }
    $saved = $record['recovered_full'] ?? [];
    $authorization = component_readback_authorization();
    if ($authorization === '') {
        throw new \RuntimeException('Connect Dropbox before recovering the earlier upload.');
    }
    if ($saved === [] || ($record['recovered_authorization'] ?? null) !== $authorization) {
        $previous = verified_evidence($saved, $site, $now);
        $evidence = parked_full_recovery_evidence($record, $site, $previous['offsite_verified_at'] ?? $now);
        if (!isset($evidence['manifest_path'])) {
            throw new \RuntimeException('This earlier upload does not have both recovery files recorded.');
        }
        $check = check_parked_daily_recovery($record, $site, $now, $metadata);
        if ($authorization !== component_readback_authorization()) {
            throw new \RuntimeException('The Dropbox connection changed during the earlier backup check.');
        }
        if (($check['state'] ?? null) !== 'matched' || ($check['matched'] ?? null) !== 2) {
            if (get_option(PARKED_DAILY_CHECK_OPTION, []) !== $check && !update_option(PARKED_DAILY_CHECK_OPTION, $check, false)) {
                throw new \RuntimeException('The earlier upload check could not be saved.');
            }
            return 'waiting';
        }
        $record['recovered_full'] = $evidence;
        $record['recovered_authorization'] = $authorization;
        save_parked_daily_backup($root, $record);
    } else {
        $evidence = verified_evidence($saved, $site, $now);
        if (!isset($evidence['manifest_path'])
            || $evidence !== parked_full_recovery_evidence($record, $site, $evidence['offsite_verified_at'])) {
            throw new \RuntimeException('The saved recovery does not match the earlier upload.');
        }
    }
    $current = verified_evidence(get_option(EVIDENCE_OPTION, []), $site, $now);
    $history = get_option(VERIFIED_BACKUP_HISTORY_OPTION, []);
    $existing = is_array($history) ? ($history[$evidence['archive_path']] ?? []) : [];
    if (($current['archive_path'] ?? null) === $evidence['archive_path']) {
        $existing = $current;
    }
    if ($existing !== []) {
        $known = verified_evidence($existing, $site, $now);
        if (($known['archive_sha256'] ?? null) !== $evidence['archive_sha256']
            || ($known['manifest_sha256'] ?? null) !== $evidence['manifest_sha256']
            || ($known['dropbox_objects'] ?? null) !== $evidence['dropbox_objects']) {
            throw new \RuntimeException('The earlier upload conflicts with the saved recovery history.');
        }
        $evidence = $known;
    }
    remember_verified_backups([$evidence], $site, $now);
    if (!isset($current['manifest_path']) && !update_option(EVIDENCE_OPTION, $evidence, false)) {
        throw new \RuntimeException('Could not record the recovered backup on Overview.');
    }
    if (!clear_verified_backup_staging(wordpress_capture_directory($root, $site, $job['id']))) {
        return 'cleanup_pending';
    }
    if (!@unlink($root . '/' . PARKED_DAILY_BACKUP_FILE)) {
        throw new \RuntimeException('The recovered upload is saved, but its temporary record still needs cleanup.');
    }
    if (function_exists(__NAMESPACE__ . '\request_private_fleet_refresh') && (private_fleet_refresh_record()['enabled'] ?? false) === true) {
        request_private_fleet_refresh($site, $now);
    }
    return 'recovered';
}

function parked_daily_staging_size(string $root, string $site, array $record): ?int {
    $id = $record['parked']['id'] ?? null;
    if (($record['site'] ?? null) !== $site || !is_string($id) || !preg_match('/^[a-f0-9]{32}$/D', $id)) {
        return null;
    }
    $directory = wordpress_capture_directory($root, $site, $id);
    if (!is_dir($directory) || is_link($directory)) {
        return null;
    }
    $total = 0;
    foreach (['backup.zip', 'manifest.json'] as $name) {
        $file = $directory . '/' . $name;
        clearstatcache(true, $file);
        $size = !is_link($file) && is_file($file) ? @filesize($file) : false;
        if (is_int($size) && $size > 0 && $size <= PHP_INT_MAX - $total) {
            $total += $size;
        }
    }
    return $total === 0 ? null : $total;
}

add_action('admin_post_pebkac_backup_check_parked_daily', static function (): void {
    if (($_SERVER['REQUEST_METHOD'] ?? '') !== 'POST' || !is_ssl() || !current_user_can('manage_options')) {
        wp_die('A signed-in administrator must check the earlier upload over HTTPS.', '', ['response' => 403]);
    }
    $id = $_POST['parked'] ?? '';
    if (!is_string($id) || !preg_match('/^[a-f0-9]{32}$/D', $id)) {
        wp_die('Refresh Overview before checking the earlier upload.', '', ['response' => 400]);
    }
    check_admin_referer('pebkac_backup_check_parked_daily_' . $id);
    try {
        $root = backup_job_root();
        with_backup_job_lock($root, static function () use ($root, $id): void {
            $record = read_parked_daily_backup($root);
            if (($record['parked']['id'] ?? null) !== $id) {
                throw new \RuntimeException('The earlier upload changed. Refresh Overview.');
            }
            $result = check_parked_daily_recovery($record, home_url(), time(), parked_daily_dropbox_metadata());
            if (get_option(PARKED_DAILY_CHECK_OPTION, []) !== $result && !update_option(PARKED_DAILY_CHECK_OPTION, $result, false)) {
                throw new \RuntimeException('The earlier upload check could not be saved.');
            }
        });
    } catch (\RuntimeException $error) {
        wp_die('The earlier upload could not be checked. Refresh Overview and try the check again.', '', ['response' => 409]);
    }
    wp_safe_redirect(admin_url('admin.php?page=pebkac-backup&tab=overview&parked_checked=1#pebkac-backup-parked-daily'), 303);
    exit;
});

add_action('admin_post_pebkac_backup_recover_parked_full', static function (): void {
    if (($_SERVER['REQUEST_METHOD'] ?? '') !== 'POST' || !is_ssl() || !current_user_can('manage_options')) {
        wp_die('A signed-in administrator must recover the earlier upload over HTTPS.', '', ['response' => 403]);
    }
    $id = $_POST['parked'] ?? '';
    if (!is_string($id) || !preg_match('/^[a-f0-9]{32}$/D', $id)) {
        wp_die('Refresh Overview before recovering the earlier upload.', '', ['response' => 400]);
    }
    check_admin_referer('pebkac_backup_recover_parked_full_' . $id);
    try {
        $root = backup_job_root();
        with_backup_job_lock($root, static function () use ($root, $id): void {
            $record = read_parked_daily_backup($root);
            if (($record['parked']['id'] ?? null) !== $id) {
                throw new \RuntimeException('The earlier upload changed. Refresh Overview.');
            }
            recover_parked_full_backup($root, $record, home_url(), time(), parked_daily_dropbox_metadata());
        });
    } catch (\RuntimeException $error) {
        wp_die('The earlier backup could not be recovered. Refresh Overview to check its saved result.', '', ['response' => 409]);
    }
    wp_safe_redirect(admin_url('admin.php?page=pebkac-backup&tab=overview&parked_checked=1#pebkac-backup-parked-daily'), 303);
    exit;
});

add_action('admin_post_pebkac_backup_clear_unstored', static function (): void {
    if (($_SERVER['REQUEST_METHOD'] ?? '') !== 'POST' || !is_ssl() || !current_user_can('manage_options')) {
        wp_die('A signed-in administrator must clear the earlier temporary files over HTTPS.', '', ['response' => 403]);
    }
    $id = $_POST['parked'] ?? '';
    if (!is_string($id) || !preg_match('/^[a-f0-9]{32}$/D', $id)) {
        wp_die('Refresh Overview before clearing the earlier temporary files.', '', ['response' => 400]);
    }
    check_admin_referer('pebkac_backup_clear_unstored_' . $id);
    try {
        $root = backup_job_root();
        with_backup_job_lock($root, static function () use ($root, $id): void {
            $record = read_parked_daily_backup($root);
            if (($record['parked']['id'] ?? null) !== $id) {
                throw new \RuntimeException('The earlier upload changed. Refresh Overview.');
            }
            clear_unstored_parked_backup($root, $record, home_url(), time(), parked_daily_dropbox_metadata(5));
        });
    } catch (\RuntimeException $error) {
        wp_die($error->getMessage(), '', ['response' => 409]);
    }
    wp_safe_redirect(admin_url('admin.php?page=pebkac-backup&tab=overview'), 303);
    exit;
});
