<?php
namespace PEBKAC404\Backup;

require_once __DIR__ . '/snapshot-archive.php';

/** Resolve updater-owned identifiers to the old files that a rollback must preserve. */
function pre_update_sources(string $wordpress, string $kind, string $target, ?float $deadline = null): array {
    $root = realpath($wordpress);
    if ($root === false || !is_file($root . '/wp-includes/version.php')) { throw new \RuntimeException('A WordPress tree is required before updating.'); }
    if ($kind === 'core' && $target === '') { return snapshot_wordpress_sources($root,null,$deadline); }
    if (in_array($kind,['plugin','theme'],true) && $target === '*') {
        return snapshot_wordpress_sources($root,$kind === 'plugin' ? 'plugins' : 'themes',$deadline);
    }
    if ($kind === 'plugin' && preg_match('~^[a-zA-Z0-9][a-zA-Z0-9_.-]*(?:/[a-zA-Z0-9][a-zA-Z0-9_.-]*)?\.php$~D',$target)) {
        $relative = 'wp-content/plugins/' . (strpos($target,'/') === false ? $target : dirname($target));
    } elseif ($kind === 'theme' && preg_match('/^[a-zA-Z0-9][a-zA-Z0-9_.-]*$/D',$target) && !in_array($target,['.','..'],true)) {
        $relative = 'wp-content/themes/' . $target;
    } else { throw new \RuntimeException('The update target could not be confirmed.'); }
    if (!valid_snapshot_member_name('wordpress/' . $relative,null)) { throw new \RuntimeException('Invalid update target.'); }
    $path = $root . '/' . $relative;
    for ($parent = $path; $parent !== $root; $parent = dirname($parent)) {
        if (is_link($parent)) { throw new \RuntimeException('The update source contains a symbolic link.'); }
        if (dirname($parent) === $parent) { throw new \RuntimeException('The update source escaped WordPress.'); }
    }
    if (!file_exists($path)) { throw new \RuntimeException('The old update files are unavailable for backup.'); }
    $sources = [];
    if (is_file($path)) { $sources['wordpress/' . $relative] = $path; }
    else {
        foreach (new \RecursiveIteratorIterator(new \RecursiveDirectoryIterator($path,\FilesystemIterator::SKIP_DOTS),\RecursiveIteratorIterator::SELF_FIRST) as $entry) {
            snapshot_deadline($deadline);
            if ($entry->isLink()) { throw new \RuntimeException('The update source contains a symbolic link.'); }
            if ($entry->isFile()) {
                $name = 'wordpress/' . str_replace('\\','/',substr($entry->getPathname(),strlen($root)+1));
                $sources[$name] = $entry->getPathname();
                if (count($sources) >= SNAPSHOT_MAX_FILES) { throw new \RuntimeException('The update backup has too many files.'); }
            }
        }
    }
    if ($sources === []) { throw new \RuntimeException('The old update files are unavailable for backup.'); }
    return $sources;
}

/** Seal old target files plus an already exported consistent database; never change live files. */
function capture_pre_update_copy(string $wordpress, string $database, string $archive, string $kind, string $target, float $deadline): array {
    $root = realpath($wordpress); $parent = realpath(dirname($archive));
    if ($root === false || $parent === false || strpos(str_replace('\\','/',$parent).'/',str_replace('\\','/',$root).'/') === 0
        || !is_file($database) || is_link($database) || filesize($database) < 1) { throw new \RuntimeException('Private update backup storage and a consistent database export are required.'); }
    $sources = ['database.sql'=>$database, 'wordpress/wp-includes/version.php'=>$root . '/wp-includes/version.php']
        + pre_update_sources($wordpress,$kind,$target,$deadline);
    $manifest = package_snapshot_sources($sources,$archive,$deadline);
    return ['schema'=>1,'kind'=>'update_rollback','target_type'=>$kind,'target'=>$target,'created_at'=>time(),'manifest'=>$manifest];
}
