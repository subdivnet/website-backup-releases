<?php
namespace PEBKAC404\Backup;

/** Read the Monitor report's observation time; it is not an inferred infection start. */
function monitor_report_cutoff(array $summary,int $now): ?int {
    if (($summary['evidence_status']??null)!=='COMPLETE' || !is_int($summary['finding_count']??null) || $summary['finding_count']<1
        || !is_string($summary['checked_at_utc']??null) || !preg_match('/^[0-9]{4}-[0-9]{2}-[0-9]{2} [0-9]{2}:[0-9]{2}:[0-9]{2}$/D',$summary['checked_at_utc'])) {return null;}
    $date=\DateTimeImmutable::createFromFormat('!Y-m-d H:i:s',$summary['checked_at_utc'],new \DateTimeZone('UTC'));
    if ($date===false || $date->format('Y-m-d H:i:s')!==$summary['checked_at_utc'] || $date->getTimestamp()<1 || $date->getTimestamp()>$now) {return null;}
    return $date->getTimestamp();
}

/** Add Backup's action on Monitor's existing WordPress screen, without changing its detector. */
function render_monitor_backup_action(): void {
    if (!current_user_can('manage_options') || !class_exists('WMC_Collector',false) || !defined('WMC_Collector::MENU_SLUG')
        || ($_GET['page']??null)!==\WMC_Collector::MENU_SLUG || !is_callable(['WMC_Collector','rest_security_summary'])) {return;}
    try {
        // Its public read-only summary applies Monitor's publication/privacy gates. Do not read raw scan options.
        $response=\WMC_Collector::rest_security_summary(new \WP_REST_Request('GET','/wsm/v1/security-check'));
        if (!($response instanceof \WP_REST_Response) || $response->get_status()!==200) {return;}
        $data=$response->get_data();
        if (!is_array($data) || ($data['status']??null)!=='available' || !is_array($data['summary']??null)) {return;}
        $summary=$data['summary'];
        $before=monitor_report_cutoff($summary,time());
        if ($before===null) {return;}
        $record=local_backup_before_problem($before,time());
    } catch (\Throwable $error) {return;}
    ?>
    <section class="notice notice-warning inline" id="website-backup-monitor-recovery">
        <h2>Backup before this Monitor report</h2>
        <p><?php echo esc_html($record===null?'No retained full backup is confirmed before this report.':
            'Last earlier backup: '.wp_date('M j, Y H:i T',$record['offsite_verified_at'])); ?></p>
        <?php if ($record!==null): ?>
        <form method="post" action="<?php echo esc_url(admin_url('admin-post.php')); ?>">
            <input type="hidden" name="action" value="pebkac_backup_test_restore">
            <input type="hidden" name="point" value="<?php echo esc_attr(recovery_download_id($record)); ?>">
            <?php wp_nonce_field('pebkac_backup_test_restore'); ?>
            <button type="submit" class="button button-primary">Test restore this earlier backup</button>
        </form>
        <?php endif; ?>
        <details><summary>Show details</summary><p>This uses the completed Monitor report time. The problem may have started earlier. A test restore checks that the backup recovers; it does not prove that the backup is clean.</p></details>
    </section>
    <?php
}
add_action('all_admin_notices',__NAMESPACE__.'\\render_monitor_backup_action');
