<?php

namespace PEBKAC404\Backup;

if (!defined('ABSPATH')) {
    exit;
}

const BACKUP_FLEET_REFRESH_HOOK = 'pebkac_backup_fleet_refresh';
const BACKUP_FLEET_REFRESH_OPTION = 'pebkac_backup_fleet_refresh';

function private_fleet_refresh_record(): array {
    $record = get_option(BACKUP_FLEET_REFRESH_OPTION, []);
    return is_array($record) ? $record : [];
}

function private_fleet_connection(): string {
    return private_fleet_authorization()['connection'] ?? '';
}

/** Bind the refresh token and the account check to the same saved authorization. */
function private_fleet_authorization(): array {
    if (pilot_site_slug(home_url()) === '') {
        return [];
    }
    $app = dropbox_app_key();
    $protected = get_option(DROPBOX_CREDENTIAL_OPTION, false);
    $refresh = dropbox_open_refresh_record($app, $protected);
    return $refresh === '' ? [] : ['connection' => hash('sha256', $protected), 'app' => $app, 'refresh' => $refresh];
}

function save_private_fleet_refresh(array $record): void {
    if (private_fleet_refresh_record() !== $record && !update_option(BACKUP_FLEET_REFRESH_OPTION, $record, false)) {
        throw new \RuntimeException('The private backup report progress could not be saved.');
    }
}

function queue_private_fleet_refresh(int $at): void {
    if (wp_next_scheduled(BACKUP_FLEET_REFRESH_HOOK) === false) {
        wp_schedule_single_event($at, BACKUP_FLEET_REFRESH_HOOK);
    }
}

/** Move the next idle exchange forward after a verified backup or restore. */
function refresh_private_fleet_after_evidence($previous, $current): void {
    $site = home_url();
    $now = time();
    if ((private_fleet_refresh_record()['enabled'] ?? false) !== true || pilot_site_slug($site) === '') {
        return;
    }
    $proof = verified_evidence($current, $site, $now);
    $before = verified_evidence($previous, $site, $now);
    if (!isset($proof['manifest_path']) || (($proof['manifest_path'] ?? null) === ($before['manifest_path'] ?? null)
        && ($proof['offsite_verified_at'] ?? null) === ($before['offsite_verified_at'] ?? null)
        && ($proof['restore']['verified_at'] ?? null) === ($before['restore']['verified_at'] ?? null))) {
        return;
    }
    request_private_fleet_refresh($site, $now);
}

function refresh_private_fleet_after_component_evidence($previous = []): void {
    $site = home_url();
    if ((private_fleet_refresh_record()['enabled'] ?? false) !== true || pilot_site_slug($site) === '') {
        return;
    }
    $now = time();
    $records = component_readback_records();
    $previous_warning = $records !== [] && is_array($previous)
        ? component_readback_warning_for_chains(available_component_recovery_chains($site, $previous, $now), $records) : '';
    if (component_only_backups_enabled(get_plan()) || $previous_warning !== '') {
        request_private_fleet_refresh($site, $now);
    }
}

function refresh_private_fleet_after_component_check($previous, $current): void {
    $site = home_url();
    if ((private_fleet_refresh_record()['enabled'] ?? false) !== true || pilot_site_slug($site) === '') {
        return;
    }
    $now = time();
    $history = get_option(COMPONENT_RECOVERY_STATE_OPTION, []);
    $chains = available_component_recovery_chains($site, is_array($history) ? $history : [], $now);
    if (component_readback_warning_for_chains($chains, (array) $previous) !== component_readback_warning_for_chains($chains, (array) $current)) {
        request_private_fleet_refresh($site, $now);
    }
}

function refresh_private_fleet_after_recovery_check($previous, $current): void {
    if (($previous['point'] ?? null) === ($current['point'] ?? null)
        && ($previous['state'] ?? null) === ($current['state'] ?? null)) {
        return;
    }
    $site = home_url();
    if ((private_fleet_refresh_record()['enabled'] ?? false) !== true || pilot_site_slug($site) === '') {
        return;
    }
    $now = time();
    $check = latest_full_recovery_readback($site, $now);
    if (in_array($check['state'] ?? null, ['confirmed', 'changed', 'unavailable'], true)) {
        request_private_fleet_refresh($site, $now);
    }
}

function refresh_private_fleet_after_plan($previous, $current): void {
    $site = home_url();
    if ((private_fleet_refresh_record()['enabled'] ?? false) !== true || pilot_site_slug($site) === '') {
        return;
    }
    $previous = (array) $previous;
    $current = (array) $current;
    $previous_components = component_backups_enabled($previous) ? ($previous['schedules'] ?? []) : [];
    $current_components = component_backups_enabled($current) ? ($current['schedules'] ?? []) : [];
    if (daily_backup_settings($previous) !== daily_backup_settings($current) || $previous_components !== $current_components) {
        request_private_fleet_refresh($site, time());
    }
}

function request_private_fleet_refresh(string $site, int $now): void {
    try {
        with_backup_job_lock(backup_site_report_lock_root($site), static function () use ($now): void {
            $record = private_fleet_refresh_record();
            if (($record['enabled'] ?? false) !== true) {
                return;
            }
            $record['requested_at'] = $now;
            $phase = $record['exchange']['phase'] ?? '';
            if (($phase === '' || $phase === 'complete') && ($record['last_result'] ?? '') !== 'unavailable') {
                $at = $now + 60;
                $existing = wp_next_scheduled(BACKUP_FLEET_REFRESH_HOOK);
                if ($existing === false || $existing > $at) {
                    $record['next_at'] = $at;
                    save_private_fleet_refresh($record);
                    bring_forward_backup_event(BACKUP_FLEET_REFRESH_HOOK, [], $at);
                    return;
                }
            }
            save_private_fleet_refresh($record);
        });
    } catch (\RuntimeException $error) {
        // A completed backup remains verified if its separate status refresh is busy.
    }
}

/** Keep the old intent when a changed authorization cannot verify its earlier write. */
function rebind_private_fleet_refresh(array $record, string $connection): array {
    if ($connection === '') {
        throw new \RuntimeException('Connect Dropbox before sharing backup status.');
    }
    if (($record['connection'] ?? '') === $connection) {
        return $record;
    }
    $exchange = $record['exchange'] ?? [];
    if (($exchange['publication']['phase'] ?? '') === 'verify' || ($exchange['folder']['phase'] ?? '') === 'verify') {
        throw new \RuntimeException('Confirm the pending status write on its original Dropbox connection.');
    }
    return ['enabled' => ($record['enabled'] ?? false) === true, 'connection' => $connection];
}

/** Enable for the existing Dropbox connection. Pausing preserves a pending readback. */
function set_private_fleet_refresh(bool $enabled): void {
    $site = home_url();
    with_backup_job_lock(backup_site_report_lock_root($site), static function () use ($enabled): void {
        $record = private_fleet_refresh_record();
        if ($enabled) {
            $record = rebind_private_fleet_refresh($record, private_fleet_connection());
            $record['next_at'] = time() + 5;
        }
        $record['enabled'] = $enabled;
        save_private_fleet_refresh($record);
    });
    if ($enabled) {
        queue_private_fleet_refresh(time() + 5);
    } else {
        wp_clear_scheduled_hook(BACKUP_FLEET_REFRESH_HOOK);
    }
}

/** Run one saved Dropbox exchange step without involving a site administrator. */
function run_private_fleet_refresh(): void {
    $record = private_fleet_refresh_record();
    $site = home_url();
    if (($record['enabled'] ?? false) !== true || pilot_site_slug($site) === '') {
        return;
    }
    $now = time();
    $retry_at = $now + 900;
    try {
        $next = with_backup_job_lock(backup_site_report_lock_root($site), static function () use ($site, $now, $retry_at): ?int {
            $record = private_fleet_refresh_record();
            if (($record['enabled'] ?? false) !== true) {
                return null;
            }
            $next_at = $record['next_at'] ?? 0;
            if (is_int($next_at) && $next_at > $now) {
                return $next_at;
            }
            try {
                $authorization = private_fleet_authorization();
                $connection = $authorization['connection'] ?? '';
                $record = rebind_private_fleet_refresh($record, $connection);
                $status = monitor_report()['status'] ?? [];
                $exchange = $record['exchange'] ?? [];
                if (!is_array($exchange)) {
                    throw new \RuntimeException('The saved private status exchange is invalid.');
                }
                if (($exchange['phase'] ?? '') === 'complete') {
                    $exchange = [];
                }
                $timeout = max(1, min(8, (int) floor(backup_request_budget() / 2)));
                $token = refresh_dropbox_access_token($authorization['app'], $authorization['refresh'], $timeout);
                if (!dropbox_connection_matches($connection)) {
                    throw new \RuntimeException('Dropbox authorization changed during the status check.');
                }
                $record['exchange'] = advance_wordpress_fleet_relay($site, $status, $exchange, $connection,
                    $token, $now, static function (array $step) use (&$record): void {
                        $record['exchange'] = $step;
                        save_private_fleet_refresh($record);
                    }, $timeout);
                $record['last_result'] = 'working';
                $record['next_at'] = $now + 60;
                if ($record['exchange']['phase'] === 'complete') {
                    $report = $record['exchange']['peer_report'] ?? null;
                    if (is_array($report) && ($report['observed_at'] ?? 0) > ($record['peer_report']['observed_at'] ?? 0)) {
                        $record['peer'] = $record['exchange']['peer'];
                        $record['peer_report'] = $report;
                    }
                    $record['last_result'] = $report === null ? 'waiting' : 'checked';
                    $record['checked_at'] = $now;
                    $requested_at = $record['requested_at'] ?? 0;
                    $observed_at = $record['exchange']['observed_at'] ?? 0;
                    if (is_int($requested_at) && $requested_at > 0 && $requested_at >= $observed_at) {
                        $record['next_at'] = $now + 60;
                    } else {
                        unset($record['requested_at']);
                        $record['next_at'] = $now + HOUR_IN_SECONDS;
                    }
                }
            } catch (\RuntimeException | \JsonException $error) {
                $record['last_result'] = 'unavailable';
                $record['next_at'] = $retry_at;
            }
            save_private_fleet_refresh($record);
            return $record['next_at'];
        });
    } catch (\RuntimeException $error) {
        $next = $retry_at;
    }
    if ($next !== null && (private_fleet_refresh_record()['enabled'] ?? false) === true) {
        queue_private_fleet_refresh($next);
    }
}

function private_fleet_cached_peer(array $record, int $now): array {
    $peer = $record['peer'] ?? '';
    if (($record['enabled'] ?? false) !== true || !is_string($peer) || $peer === home_url()
        || !is_string($record['connection'] ?? null) || !dropbox_connection_matches($record['connection'])) {
        return [];
    }
    $report = normalize_backup_site_report($peer, $record['peer_report'] ?? null, $now);
    return $report === null ? [] : [$peer => $report];
}

function render_private_fleet_refresh(array $record): void {
    $enabled = ($record['enabled'] ?? false) === true;
    $connection = private_fleet_connection();
    if (pilot_site_slug(home_url()) === '' || (!$enabled && $connection === '')) {
        return;
    }
    $messages = [
        'working' => 'WordPress is checking the shared backup reports.',
        'waiting' => 'Waiting for the other pilot to share its backup status.',
        'checked' => 'WordPress received the other pilot’s backup report.',
        'unavailable' => 'The latest shared status check could not finish.',
    ];
    $message = $messages[$record['last_result'] ?? ''] ?? 'The first shared status check is queued.';
    if ($enabled && ($record['connection'] ?? '') !== $connection) {
        try {
            rebind_private_fleet_refresh($record, $connection);
            $message = 'WordPress will refresh shared status using the current Dropbox connection.';
        } catch (\RuntimeException $error) {
            $message = $error->getMessage();
        }
    }
    ?>
    <section class="notice notice-info inline">
        <h2>Shared status through Dropbox</h2>
        <details><summary>Show details</summary>
            <p>Use the same Dropbox account on both pilots to share backup dates, sizes and restore results. WordPress uses the saved Dropbox connection.</p>
            <?php if ($enabled) : ?><p><?php echo esc_html($message); ?></p><?php endif; ?>
            <form action="<?php echo esc_url(admin_url('admin-post.php')); ?>" method="post">
                <input type="hidden" name="action" value="pebkac_backup_fleet_refresh">
                <?php wp_nonce_field('pebkac_backup_fleet_refresh'); ?>
                <button class="button" type="submit" name="enabled" value="<?php echo $enabled ? '0' : '1'; ?>">
                    <?php echo $enabled ? 'Pause Dropbox status sharing' : 'Share backup status through Dropbox'; ?>
                </button>
            </form>
        </details>
    </section>
    <?php
}

add_action(BACKUP_FLEET_REFRESH_HOOK, __NAMESPACE__ . '\\run_private_fleet_refresh');
add_action('update_option_' . EVIDENCE_OPTION, __NAMESPACE__ . '\\refresh_private_fleet_after_evidence', 10, 2);
add_action('add_option_' . EVIDENCE_OPTION, static function ($option, $value): void {
    refresh_private_fleet_after_evidence([], $value);
}, 10, 2);
add_action('add_option_' . COMPONENT_RECOVERY_STATE_OPTION, __NAMESPACE__ . '\\refresh_private_fleet_after_component_evidence');
add_action('update_option_' . COMPONENT_RECOVERY_STATE_OPTION, static function ($previous, $current): void {
    if (($previous['latest'] ?? []) !== ($current['latest'] ?? [])) {
        refresh_private_fleet_after_component_evidence($previous);
    }
}, 10, 2);
add_action('add_option_' . COMPONENT_RESTORE_OPTION, __NAMESPACE__ . '\\refresh_private_fleet_after_component_evidence');
add_action('update_option_' . COMPONENT_RESTORE_OPTION, __NAMESPACE__ . '\\refresh_private_fleet_after_component_evidence');
add_action('update_option_' . COMPONENT_READBACK_OPTION, __NAMESPACE__ . '\\refresh_private_fleet_after_component_check', 10, 2);
add_action('update_option_' . LATEST_FULL_RECOVERY_CHECK_OPTION, __NAMESPACE__ . '\\refresh_private_fleet_after_recovery_check', 10, 2);
add_action('add_option_' . LATEST_FULL_RECOVERY_CHECK_OPTION, static function ($option, $value): void {
    refresh_private_fleet_after_recovery_check([], $value);
}, 10, 2);
add_action('update_option_' . OPTION, __NAMESPACE__ . '\\refresh_private_fleet_after_plan', 10, 2);
add_action('add_option_' . OPTION, static function ($option, $value): void {
    refresh_private_fleet_after_plan([], $value);
}, 10, 2);
add_action('init', static function (): void {
    $record = private_fleet_refresh_record();
    if (($record['enabled'] ?? false) === true && pilot_site_slug(home_url()) !== '') {
        $next = $record['next_at'] ?? 0;
        queue_private_fleet_refresh(is_int($next) && $next > time() ? $next : time() + 5);
    }
});

add_action('admin_post_pebkac_backup_fleet_refresh', static function (): void {
    if (($_SERVER['REQUEST_METHOD'] ?? '') !== 'POST' || !is_ssl() || !current_user_can('manage_options')) {
        wp_die('An administrator must change shared backup status over HTTPS.', '', ['response' => 403]);
    }
    check_admin_referer('pebkac_backup_fleet_refresh');
    $enabled = $_POST['enabled'] ?? '';
    if (!in_array($enabled, ['0', '1'], true)) {
        wp_die('Choose whether to share backup status.', '', ['response' => 400]);
    }
    try {
        set_private_fleet_refresh($enabled === '1');
    } catch (\RuntimeException $error) {
        wp_die('The Dropbox status setting could not be saved. Check the connection in Setup.', '', ['response' => 409]);
    }
    wp_safe_redirect(admin_url('admin.php?page=pebkac-backup&tab=sites'), 303);
    exit;
});
