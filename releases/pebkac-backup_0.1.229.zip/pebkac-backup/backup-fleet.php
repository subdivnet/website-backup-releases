<?php

namespace PEBKAC404\Backup;

require_once __DIR__ . '/backup-capture-problem.php';

const BACKUP_REPORT_MAX_AGE = 86400;

function backup_report_recovery_check_time($checked_at, ?int $backup_at, int $observed_at): ?int {
    return $backup_at !== null && is_int($checked_at) && $checked_at >= $backup_at && $checked_at <= $observed_at ? $checked_at : null;
}

/** Prepare the two pilot rows from reports fetched through an existing authenticated connection. */
function backup_fleet_rows(array $reports, int $now): array {
    $rows = [];
    foreach (['https://securitylab.subdiv.net' => 'SecurityLab', 'https://pebkac404.com' => 'PEBKAC404'] as $site => $label) {
        $row = [
            'site' => $site, 'label' => $label, 'state' => 'unavailable',
            'observed_at' => null, 'last_backup_at' => null, 'last_backup_bytes' => null, 'last_backup_run_type' => null,
            'last_component_backup_at' => null, 'last_component_backup_bytes' => null, 'latest_component_restore_at' => null,
            'last_restore_at' => null, 'latest_restore_at' => null, 'overdue_since' => null, 'next_due_at' => null,
            'awaiting_report_since' => null, 'earlier_daily_upload_pending' => false, 'earlier_component_upload_pending' => false,
            'capture_problem_message' => '', 'recovery_checked_at' => null, 'dropbox_refresh_failed' => false,
            'dropbox_destination_is_file' => false, 'dropbox_destination_check_failed' => false, 'dropbox_upload_unconfirmed' => false,
        ];
        $report = $reports[$site] ?? [];
        $observed = $report['observed_at'] ?? null;
        $status = $report['status'] ?? null;
        if (!is_int($observed) || $observed < 1 || $observed > $now || !is_array($status)
            || !in_array($status['state'] ?? null, ['setup_only', 'offsite_verified', 'restore_verified'], true)) {
            $rows[] = $row;
            continue;
        }
        $row['observed_at'] = $observed;
        $fresh = $now - $observed <= BACKUP_REPORT_MAX_AGE;
        $row['dropbox_refresh_failed'] = $fresh && ($status['scheduled_dropbox_refresh_failed'] ?? false) === true;
        $row['dropbox_destination_check_failed'] = $fresh && ($status['scheduled_dropbox_destination_check_failed'] ?? false) === true;
        $row['dropbox_upload_unconfirmed'] = $fresh && ($status['scheduled_dropbox_upload_unconfirmed'] ?? false) === true;
        $row['dropbox_destination_is_file'] = $fresh && (($status['scheduled_dropbox_destination_is_file'] ?? false) === true
            || ($status['scheduled_dropbox_staged_destination_is_file'] ?? false) === true);
        $row['earlier_daily_upload_pending'] = ($status['earlier_daily_upload_pending'] ?? false) === true;
        $row['earlier_component_upload_pending'] = ($status['earlier_component_upload_pending'] ?? false) === true;
        foreach ([
            'last_backup_at' => 'last_verified_offsite_at',
            'last_restore_at' => 'last_verified_restore_at',
            'latest_restore_at' => 'latest_backup_restore_verified_at',
            'overdue_since' => 'oldest_overdue_at',
        ] as $target => $source) {
            $time = $status[$source] ?? null;
            if (is_int($time) && $time > 0 && $time <= $observed) {
                $row[$target] = $time;
            }
        }
        $component_at = $status['last_verified_component_at'] ?? null;
        if (is_int($component_at) && $component_at > 0 && $component_at <= $observed) {
            $row['last_component_backup_at'] = $component_at;
            $component_bytes = $status['last_verified_component_size_bytes'] ?? null;
            if (is_int($component_bytes) && $component_bytes > 0) {
                $row['last_component_backup_bytes'] = $component_bytes;
            }
            $component_restore = $status['latest_component_restore_checked_at'] ?? null;
            if (is_int($component_restore) && $component_restore >= $component_at && $component_restore <= $observed) {
                $row['latest_component_restore_at'] = $component_restore;
            }
        }
        $size = $status['last_verified_offsite_size_bytes'] ?? null;
        $row['recovery_checked_at'] = backup_report_recovery_check_time($status['latest_recovery_checked_at'] ?? null, $row['last_backup_at'], $observed);
        if ($row['last_backup_at'] !== null && is_int($size) && $size > 0) {
            $row['last_backup_bytes'] = $size;
        }
        $run_type = $status['last_verified_offsite_run_type'] ?? null;
        if ($row['last_backup_at'] !== null && in_array($run_type, ['daily', 'manual'], true)) {
            $row['last_backup_run_type'] = $run_type;
        }
        $next_due = $status['next_due_at'] ?? null;
        if (is_int($next_due) && $next_due >= $observed && $next_due <= $observed + 8 * BACKUP_REPORT_MAX_AGE) {
            if ($next_due < $now) {
                $row['awaiting_report_since'] = $next_due;
            } else {
                $row['next_due_at'] = $next_due;
            }
        }
        if (!array_key_exists('latest_backup_restore_verified_at', $status) && $status['state'] === 'restore_verified') {
            $row['latest_restore_at'] = $row['last_restore_at'];
        }
        if ($row['last_backup_at'] === null || ($row['latest_restore_at'] ?? 0) < $row['last_backup_at']) {
            $row['latest_restore_at'] = null;
        }
        if (!$fresh) {
            $row['state'] = 'stale';
        } elseif ($row['last_backup_at'] !== null && ($status['latest_recovery_files'] ?? null) === 'changed') {
            $row['state'] = 'recovery_files_changed';
        } elseif (($status['component_recovery_files'] ?? null) === 'changed') {
            $row['state'] = 'component_recovery_files_changed';
        } elseif ($row['last_backup_at'] !== null && ($status['latest_recovery_files'] ?? null) === 'unavailable') {
            $row['state'] = 'recovery_files_unavailable';
        } elseif (($status['component_recovery_files'] ?? null) === 'unavailable') {
            $row['state'] = 'component_recovery_files_unavailable';
        } elseif (($status['scheduled_upload_paused'] ?? false) === true || ($status['scheduled_capture_paused'] ?? false) === true) {
            $row['state'] = 'paused';
            if (($status['scheduled_capture_paused'] ?? false) === true) {
                $row['capture_problem_message'] = backup_capture_problem_message($status['scheduled_capture_problem'] ?? null);
            }
        } elseif ($row['overdue_since'] !== null) {
            $row['state'] = 'overdue';
        } elseif (($row['last_backup_at'] !== null || $row['last_component_backup_at'] !== null)
            && ($row['dropbox_refresh_failed'] || $row['dropbox_destination_check_failed'] || $row['dropbox_destination_is_file'] || $row['dropbox_upload_unconfirmed'])) {
            $row['state'] = 'dropbox_attention';
        } elseif ($row['last_backup_at'] === null && $row['last_component_backup_at'] === null) {
            $row['state'] = 'no_verified_backup';
        } elseif ($row['awaiting_report_since'] !== null) {
            $row['state'] = 'awaiting_report';
        } elseif ($row['last_backup_at'] === null) {
            $row['state'] = 'components_verified';
        } else {
            $row['state'] = $row['latest_restore_at'] === null ? 'backup_verified' : 'restore_verified';
        }
        $rows[] = $row;
    }
    return $rows;
}

/** Render an authenticated view's supplied reports without fetching or publishing anything. */
function render_backup_fleet(array $reports, int $now): void {
    $states = [
        'unavailable' => ['notice-warning', 'Status unavailable'],
        'stale' => ['notice-warning', 'Status needs a refresh'],
        'recovery_files_changed' => ['notice-error', 'Latest backup files are missing or changed'],
        'recovery_files_unavailable' => ['notice-warning', 'Dropbox could not confirm the latest backup files'],
        'component_recovery_files_changed' => ['notice-error', 'Component recovery files are missing or changed'],
        'component_recovery_files_unavailable' => ['notice-warning', 'Dropbox could not confirm component recovery files'],
        'no_verified_backup' => ['notice-error', 'No verified backup'],
        'components_verified' => ['notice-success', 'Component backups verified'],
        'dropbox_attention' => ['notice-warning', 'Dropbox needs attention'],
        'overdue' => ['notice-warning', 'Backup overdue'],
        'awaiting_report' => ['notice-warning', 'Backup due, waiting for a fresh report'],
        'paused' => ['notice-warning', 'Scheduled backup paused'],
        'backup_verified' => ['notice-warning', 'Backup verified, restore test pending'],
        'restore_verified' => ['notice-success', 'Backup and restore verified'],
    ];
    foreach (backup_fleet_rows($reports, $now) as $row) {
        [$class, $label] = $states[$row['state']];
        ?>
        <section class="notice inline <?php echo esc_attr($class); ?>">
            <h2><?php echo esc_html($row['label']); ?></h2>
            <p><strong><?php echo esc_html($label); ?></strong></p>
            <details>
                <summary>Show details</summary>
                <?php if ($row['state'] === 'stale') : ?><p>The last report is more than a day old.</p><?php endif; ?>
                <?php if ($row['capture_problem_message'] !== '') : ?><p><?php echo esc_html($row['capture_problem_message']); ?></p><?php endif; ?>
                <?php if ($row['dropbox_refresh_failed']) : ?>
                    <p>The last scheduled backup attempt could not refresh the Dropbox connection.</p>
                <?php elseif ($row['dropbox_destination_check_failed']) : ?>
                    <p>Dropbox could not confirm the selected backup folder.</p>
                <?php elseif ($row['dropbox_destination_is_file']) : ?>
                    <p>The last Dropbox check found a file at the backup destination. Open Overview on that site to see how to continue.</p>
                <?php elseif ($row['dropbox_upload_unconfirmed']) : ?>
                    <p>Dropbox has yet to confirm a matching uploaded backup file. WordPress can check the saved path again.</p>
                <?php endif; ?>
                <?php if ($row['earlier_daily_upload_pending']) : ?><p>An earlier daily upload still needs review.</p><?php endif; ?>
                <?php if ($row['earlier_component_upload_pending']) : ?><p>An earlier component upload still needs review.</p><?php endif; ?>
                <dl>
                    <dt>Last checked</dt>
                    <dd><?php echo esc_html($row['observed_at'] === null ? 'No report received' : wp_date('M j, Y H:i T', $row['observed_at'])); ?></dd>
                    <?php if ($row['last_component_backup_at'] === null || $row['last_backup_at'] !== null) : ?>
                        <dt>Last verified backup</dt>
                        <dd><?php echo esc_html($row['last_backup_at'] === null ? 'Unavailable' : wp_date('M j, Y H:i T', $row['last_backup_at'])); ?></dd>
                    <?php endif; ?>
                    <?php if ($row['last_component_backup_at'] !== null) : ?>
                        <dt>Last verified component backup</dt>
                        <dd><?php echo esc_html(wp_date('M j, Y H:i T', $row['last_component_backup_at'])); ?></dd>
                        <?php if ($row['last_component_backup_bytes'] !== null) : ?>
                            <dt>Component ZIP size</dt>
                            <dd><?php echo esc_html(size_format($row['last_component_backup_bytes'], 1)); ?></dd>
                        <?php endif; ?>
                        <dt>Latest component restore check</dt>
                        <dd><?php echo esc_html($row['latest_component_restore_at'] === null ? 'Waiting for a reported check'
                            : 'Isolated file check passed on ' . wp_date('M j, Y H:i T', $row['latest_component_restore_at'])); ?></dd>
                    <?php endif; ?>
                    <?php if ($row['last_backup_bytes'] !== null) : ?>
                        <dt>Backup ZIP size</dt>
                        <dd><?php echo esc_html(size_format($row['last_backup_bytes'], 1)); ?></dd>
                    <?php endif; ?>
                    <?php if ($row['last_backup_run_type'] !== null) : ?>
                        <dt>Backup started from</dt>
                        <dd><?php echo $row['last_backup_run_type'] === 'daily' ? 'Daily schedule' : 'Overview'; ?></dd>
                    <?php endif; ?>
                    <?php if ($row['last_restore_at'] !== null) : ?>
                        <dt>Last successful restore test</dt>
                        <dd><?php echo esc_html(wp_date('M j, Y H:i T', $row['last_restore_at'])); ?></dd>
                    <?php endif; ?>
                    <?php if ($row['recovery_checked_at'] !== null) : ?>
                        <dt>Last Dropbox file check</dt>
                        <dd><?php echo esc_html(wp_date('M j, Y H:i T', $row['recovery_checked_at'])); ?></dd>
                    <?php endif; ?>
                    <?php if ($row['overdue_since'] !== null) : ?>
                        <dt>Overdue since</dt>
                        <dd><?php echo esc_html(wp_date('M j, Y H:i T', $row['overdue_since'])); ?></dd>
                    <?php endif; ?>
                    <?php if ($row['state'] === 'awaiting_report') : ?>
                        <dt>Backup was due</dt>
                        <dd><?php echo esc_html(wp_date('M j, Y H:i T', $row['awaiting_report_since'])); ?></dd>
                    <?php endif; ?>
                    <?php if ($row['next_due_at'] !== null && $row['state'] !== 'stale') : ?>
                        <dt>Next backup due</dt>
                        <dd><?php echo esc_html(wp_date('M j, Y H:i T', $row['next_due_at'])); ?></dd>
                    <?php endif; ?>
                </dl>
                <p><a href="<?php echo esc_url($row['site'] . '/wp-admin/admin.php?page=pebkac-backup'); ?>">
                    Open <?php echo esc_html($row['label']); ?> Overview
                </a></p>
            </details>
        </section>
        <?php
    }
}

/** A privacy-limited report for a Monitor collector already running in the same WordPress process. */
function make_backup_monitor_report(string $site, array $status, int $now): ?array {
    if (!in_array($site, ['https://securitylab.subdiv.net', 'https://pebkac404.com'], true) || $now < 1
        || !in_array($status['state'] ?? null, ['setup_only', 'offsite_verified', 'restore_verified'], true)) {
        return null;
    }
    $public = ['state' => $status['state']];
    foreach (['last_verified_offsite_at', 'last_verified_restore_at', 'latest_backup_restore_verified_at', 'oldest_overdue_at'] as $field) {
        if (!array_key_exists($field, $status)) {
            continue;
        }
        $value = $status[$field];
        $public[$field] = is_int($value) && $value > 0 && $value <= $now ? $value : null;
    }
    $size = $status['last_verified_offsite_size_bytes'] ?? null;
    $component_at = $status['last_verified_component_at'] ?? null;
    if (is_int($component_at) && $component_at > 0 && $component_at <= $now) {
        $public['last_verified_component_at'] = $component_at;
        $component_bytes = $status['last_verified_component_size_bytes'] ?? null;
        if (is_int($component_bytes) && $component_bytes > 0) {
            $public['last_verified_component_size_bytes'] = $component_bytes;
        }
        $component_restore = $status['latest_component_restore_checked_at'] ?? null;
        if (is_int($component_restore) && $component_restore >= $component_at && $component_restore <= $now) {
            $public['latest_component_restore_checked_at'] = $component_restore;
        }
    }
    if (isset($public['last_verified_offsite_at']) && is_int($size) && $size > 0) {
        $public['last_verified_offsite_size_bytes'] = $size;
    }
    $run_type = $status['last_verified_offsite_run_type'] ?? null;
    if (isset($public['last_verified_offsite_at']) && in_array($run_type, ['daily', 'manual'], true)) {
        $public['last_verified_offsite_run_type'] = $run_type;
    }
    $next_due = $status['next_due_at'] ?? null;
    if (is_int($next_due) && $next_due >= $now && $next_due <= $now + 8 * BACKUP_REPORT_MAX_AGE) {
        $public['next_due_at'] = $next_due;
    }
    if (isset($public['last_verified_offsite_at']) && in_array($status['latest_recovery_files'] ?? null, ['changed', 'unavailable'], true)) {
        $public['latest_recovery_files'] = $status['latest_recovery_files'];
    }
    if (in_array($status['component_recovery_files'] ?? null, ['changed', 'unavailable'], true)) {
        $public['component_recovery_files'] = $status['component_recovery_files'];
    }
    $checked_at = backup_report_recovery_check_time($status['latest_recovery_checked_at'] ?? null, $public['last_verified_offsite_at'] ?? null, $now);
    if ($checked_at !== null) {
        $public['latest_recovery_checked_at'] = $checked_at;
    }
    foreach (['scheduled_upload_paused', 'scheduled_capture_paused', 'scheduled_dropbox_refresh_failed',
        'scheduled_dropbox_destination_check_failed', 'scheduled_dropbox_destination_is_file',
        'scheduled_dropbox_staged_destination_is_file', 'scheduled_dropbox_upload_unconfirmed',
        'earlier_daily_upload_pending', 'earlier_component_upload_pending'] as $field) {
        if (($status[$field] ?? false) === true) {
            $public[$field] = true;
        }
    }
    $problem = $status['scheduled_capture_problem'] ?? null;
    if (isset($public['scheduled_capture_paused']) && backup_capture_problem_message($problem) !== '') {
        $public['scheduled_capture_problem'] = $problem;
    }
    return ['schema' => 1, 'observed_at' => $now, 'status' => $public];
}

function monitor_report(): ?array {
    $site = home_url();
    $now = time();
    $status = status();
    $plan = get_plan();
    $component_only = component_only_backups_enabled($plan);
    $file_checks = component_readback_records();
    if ($component_only || $file_checks !== []) {
        $history = get_option(COMPONENT_RECOVERY_STATE_OPTION, []);
        $chains = available_component_recovery_chains($site, is_array($history) ? $history : [], $now);
        $checks = get_option(COMPONENT_RESTORE_OPTION, []);
        foreach ($chains as $component => $chain) {
            $record = $chain[count($chain) - 1];
            if ($component_only && $record['offsite_verified_at'] > ($status['last_verified_component_at'] ?? 0)) {
                $status['last_verified_component_at'] = $record['offsite_verified_at'];
                $status['last_verified_component_size_bytes'] = $record['dropbox_objects']['archive']['size'];
                $check = component_restore_check_result($site, $chain, $checks[$component] ?? null, $now);
                $status['latest_component_restore_checked_at'] = !empty($check['matches_latest']) ? $check['verified_at'] : null;
            }
        }
        $status['component_recovery_files'] = component_readback_warning_for_chains($chains, $file_checks);
    }
    $report = make_backup_monitor_report($site, $status, $now);
    if ($report === null) {
        return null;
    }
    $readback = latest_full_recovery_readback($site, $now);
    if (in_array($readback['state'] ?? null, ['confirmed', 'changed', 'unavailable'], true)) {
        $checked_at = backup_report_recovery_check_time($readback['checked_at'] ?? null, $report['status']['last_verified_offsite_at'] ?? null, $now);
        if ($checked_at !== null) {
            $report['status']['latest_recovery_checked_at'] = $checked_at;
        }
    }
    if (isset($report['status']['last_verified_offsite_at']) && in_array($readback['state'] ?? null, ['changed', 'unavailable'], true)) {
        $report['status']['latest_recovery_files'] = $readback['state'];
    }
    try {
        $root = backup_job_root();
        [$job, $running] = read_backup_job_progress($root);
        if (!$running && ($job['phase'] ?? '') !== 'verified'
            && (isset($job['daily_date']) || isset(COMPONENTS[$job['component'] ?? '']))) {
            if (backup_job_upload_uncertain($job)) {
                $report['status']['scheduled_upload_paused'] = true;
            } elseif (!empty($job['automatic_capture_retry']) && restartable_backup_capture($job)) {
                $report['status']['scheduled_capture_paused'] = true;
                $problem = $job['capture_problem'] ?? null;
                if (backup_capture_problem_message($problem) !== '') {
                    $report['status']['scheduled_capture_problem'] = $problem;
                }
            } elseif (($job['dropbox_refresh_failed'] ?? false) === true && backup_job_can_retry_safely($job)) {
                $report['status']['scheduled_dropbox_refresh_failed'] = true;
            } elseif (($job['dropbox_destination_check_failed'] ?? false) === true && backup_job_needs_connection_check($job)) {
                $report['status']['scheduled_dropbox_destination_check_failed'] = true;
            } elseif (($job['dropbox_destination_is_file'] ?? false) === true && backup_job_needs_connection_check($job)) {
                $report['status']['scheduled_dropbox_destination_is_file'] = true;
            } elseif (($job['dropbox_destination_is_file'] ?? false) === true && $job['phase'] === 'folder') {
                $report['status']['scheduled_dropbox_staged_destination_is_file'] = true;
            } elseif (backup_job_readback_needs_attention($job)) {
                $report['status']['scheduled_dropbox_upload_unconfirmed'] = true;
            }
        }
        $parked = read_parked_daily_backup($root);
        if (parked_daily_backup_day($parked, $site) !== '') {
            $field = isset($parked['parked']['component']) ? 'earlier_component_upload_pending' : 'earlier_daily_upload_pending';
            $report['status'][$field] = true;
        }
    } catch (\RuntimeException $error) {
        // Keep the last verified evidence available even when staging cannot be read.
    }
    return $report;
}


/** Add the local report after Website Monitor has authorized and built its private status response. */
function add_backup_to_private_monitor_response($response, array $handler, \WP_REST_Request $request) {
    if (!$response instanceof \WP_REST_Response || $response->get_status() !== 200
        || $request->get_method() !== 'GET' || $request->get_route() !== '/wsm/v1/security-status'
        || ($handler['callback'] ?? null) !== ['WMC_Collector', 'rest_security_status']
        || !current_user_can('manage_options')) {
        return $response;
    }
    $data = $response->get_data();
    if (!is_array($data) || array_key_exists('backup_status', $data)) {
        return $response;
    }
    $report = monitor_report();
    if ($report !== null) {
        $data['backup_status'] = $report;
        $response->set_data($data);
        $response->header('Cache-Control', 'private, no-store');
    }
    return $response;
}

/** Produce the optional backup view for Monitor's existing read-only route. */
function monitor_reader_backup_response() {
    if (!current_user_can('manage_options') && !current_user_can('wmc_read_monitor_status')) {
        return new \WP_Error('backup_status_forbidden', 'Website Monitor reader access is required.', ['status' => 403]);
    }
    $site = home_url();
    $report = monitor_report();
    if ($report === null) {
        return new \WP_Error('backup_status_unavailable', 'Backup status is unavailable.', ['status' => 404]);
    }
    $response = new \WP_REST_Response(['schema' => 1, 'site_url' => $site, 'backup_status' => $report], 200);
    $response->header('Cache-Control', 'private, no-store');
    return $response;
}

/** Normalize an already authenticated report to the small set of fields shown by Sites. */
function normalize_backup_site_report(string $site, $report, int $now): ?array {
    $observed = $report['observed_at'] ?? null;
    if (($report['schema'] ?? null) !== 1 || !is_int($observed) || $observed < 1 || $observed > $now
        || !is_array($report['status'] ?? null)) {
        return null;
    }
    return make_backup_monitor_report($site, $report['status'], $observed);
}

/** Read only the backup field from responses already authenticated by Website Monitor. */
function backup_site_reports_from_monitor(array $responses, int $now): array {
    $reports = [];
    foreach ($responses as $site => $response) {
        if (!is_string($site) || !is_array($response)
            || (array_key_exists('site_url', $response) && ($response['site_url'] !== $site || ($response['schema'] ?? null) !== 1))) {
            continue;
        }
        $report = normalize_backup_site_report($site, $response['backup_status'] ?? null, $now);
        if ($report !== null) {
            $reports[$site] = $report;
        }
    }
    return $reports;
}

const BACKUP_SITE_REPORTS_OPTION = 'pebkac_backup_site_reports';

/** Use a separate, site-local lock even when Dropbox onboarding is still pending. */
function backup_site_report_lock_root(string $site): string {
    $temp = backup_temp_parent();
    if ($temp === '' || pilot_site_slug($site) === '') {
        throw new \RuntimeException('Private pilot report storage is unavailable for this site.');
    }
    $id = hash_hmac('sha256', 'website-backup/reports|' . $site . '|' . ABSPATH, wp_salt('auth'));
    return private_backup_work_directory($temp, 'website-backup-reports-' . substr($id, 0, 32), true);
}

/** Keep the newest valid peer report. Only a caller that authenticated the source should call this. */
function remember_authenticated_backup_reports(array $responses, int $now): void {
    $reports = backup_site_reports_from_monitor($responses, $now);
    $site = home_url();
    unset($reports[$site]);
    if ($reports === []) {
        return;
    }
    with_backup_job_lock(backup_site_report_lock_root($site), static function () use ($reports, $now): void {
        $saved = get_option(BACKUP_SITE_REPORTS_OPTION, []);
        $next = newest_backup_site_reports($saved, $reports, $now);
        if ($next !== $saved && !update_option(BACKUP_SITE_REPORTS_OPTION, $next, false)) {
            throw new \RuntimeException('Could not save the latest pilot backup report.');
        }
    });
}

function newest_backup_site_reports($saved, $supplied, int $now): array {
    $reports = [];
    foreach ([is_array($saved) ? $saved : [], is_array($supplied) ? $supplied : []] as $source) {
        foreach ($source as $site => $report) {
            $safe = is_string($site) ? normalize_backup_site_report($site, $report, $now) : null;
            if ($safe !== null && $safe['observed_at'] > ($reports[$site]['observed_at'] ?? 0)) {
                $reports[$site] = $safe;
            }
        }
    }
    return $reports;
}

function render_backup_sites(): void {
    $site = home_url();
    // An authenticated collector may supply cached reports from the approved pilots.
    $supplied = apply_filters('pebkac_backup_site_reports', [], $site);
    $local = monitor_report();
    $now = time();
    $reports = newest_backup_site_reports(get_option(BACKUP_SITE_REPORTS_OPTION, []), $supplied, $now);
    $relay = private_fleet_refresh_record();
    $reports = newest_backup_site_reports($reports, private_fleet_cached_peer($relay, $now), $now);
    $reports[$site] = $local;
    render_backup_fleet($reports, $now);
    render_private_fleet_refresh($relay);
}
