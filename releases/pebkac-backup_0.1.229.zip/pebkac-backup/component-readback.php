<?php

namespace PEBKAC404\Backup;

if (!defined('ABSPATH')) {
    exit;
}

const COMPONENT_READBACK_OPTION = 'pebkac_backup_component_readback';
const COMPONENT_READBACK_HOOK = 'pebkac_backup_component_readback_step';
const COMPONENT_READBACK_INTERVAL = 86400;

/** Bind a check to the exact ZIP and manifest for every copy in the chain. */
function component_readback_target(array $chain): array {
    $objects = [];
    foreach ($chain as $record) {
        $pins = backup_dropbox_object_pins($record['dropbox_objects'] ?? []);
        if ($pins === []) {
            return [];
        }
        foreach ($pins as $object => $pin) {
            $objects[$record[$object . '_path']] = $pin;
        }
    }
    return $objects === [] ? [] : [
        'id' => hash('sha256', json_encode($objects, JSON_UNESCAPED_SLASHES | JSON_THROW_ON_ERROR)),
        'objects' => $objects,
    ];
}

function remember_changed_component_recovery(array $chain, string $component, int $now): void {
    $target = component_readback_target($chain);
    if ($target !== []) {
        $records = component_readback_records();
        $records[$component] = ['point' => $target['id'], 'state' => 'changed', 'checked_at' => $now,
            'baseline' => recovery_download_id($chain[0]), 'authorization' => component_readback_authorization()];
        save_component_readback_records($records);
    }
}

function component_readback_records(): array {
    $records = get_option(COMPONENT_READBACK_OPTION, []);
    return is_array($records) ? array_intersect_key($records, COMPONENTS) : [];
}

function save_component_readback_records(array $records): void {
    if (component_readback_records() !== $records && !update_option(COMPONENT_READBACK_OPTION, $records, false)) {
        throw new \RuntimeException('Could not save the component file check.');
    }
}

function component_readback_authorization(): string {
    $saved = get_option(DROPBOX_CREDENTIAL_OPTION, '');
    return is_string($saved) && $saved !== '' ? hash('sha256', $saved) : '';
}

function queue_component_readback(int $delay = 60): void {
    if (wp_next_scheduled(COMPONENT_READBACK_HOOK) !== false) {
        return;
    }
    $now = time();
    $records = component_readback_records();
    $pending = array_filter($records, static function ($record): bool { return ($record['state'] ?? null) === 'checking'; });
    if ($pending !== []) {
        $retries = array_map(static function (array $record) use ($now): int {
            return is_int($record['retry_at'] ?? null) ? $record['retry_at'] : $now;
        }, $pending);
        wp_schedule_single_event(max($now + $delay, min($retries)), COMPONENT_READBACK_HOOK);
        return;
    }
    $next = next_automatic_component_readback(home_url(), $records, $now);
    if ($next !== []) {
        wp_schedule_single_event(max($now + $delay, $next['due_at']), COMPONENT_READBACK_HOOK);
    }
}

/** Recheck pending or scheduled chains promptly after a new connection is saved. */
function queue_component_readback_after_dropbox_authorization(): void {
    $now = time();
    $records = component_readback_records();
    $next = next_automatic_component_readback(home_url(), $records, $now);
    if (in_array('checking', array_column($records, 'state'), true)
        || ($next !== [] && $next['due_at'] <= $now)) {
        bring_forward_backup_event(COMPONENT_READBACK_HOOK, [], $now + 60);
    }
}

/** Older files in a chain still need a check when a new change is uploaded. */
function next_automatic_component_readback(string $site, array $records, int $now): array {
    $plan = get_plan();
    $authorization = component_readback_authorization();
    if (!component_backups_enabled($plan) || $authorization === '' || pilot_site_slug($site) === '') {
        return [];
    }
    $history = get_option(COMPONENT_RECOVERY_STATE_OPTION, []);
    $chains = available_component_recovery_chains($site, is_array($history) ? $history : [], $now);
    $next = [];
    foreach ($chains as $component => $chain) {
        if (!component_readback_schedule_enabled($plan, $component, $now)) {
            continue;
        }
        $anchor = $chain[0]['offsite_verified_at'];
        $checked_at = $records[$component]['checked_at'] ?? null;
        if (($records[$component]['baseline'] ?? null) === recovery_download_id($chain[0])
            && ($records[$component]['authorization'] ?? $authorization) === $authorization
            && is_int($checked_at) && $checked_at >= $anchor && $checked_at <= $now) {
            $anchor = $checked_at;
        }
        $due = $anchor + COMPONENT_READBACK_INTERVAL;
        if ($next === [] || $due < $next['due_at']) {
            $next = ['component' => $component, 'chain' => $chain, 'due_at' => $due];
        }
    }
    return $next;
}

function component_readback_schedule_enabled(array $plan, string $component, int $now): bool {
    return component_backups_enabled($plan)
        && component_schedule_rules($plan['schedules'][$component] ?? null, wp_timezone(), $now) !== null;
}

function pending_component_readback(array $chain, string $point, array $previous): array {
    $record = ['point' => $point, 'state' => 'checking', 'position' => 0,
        'baseline' => recovery_download_id($chain[0]), 'authorization' => component_readback_authorization()];
    if (($previous['point'] ?? null) === $point && isset($previous['checked_at'])
        && ($previous['authorization'] ?? $record['authorization']) === $record['authorization']) {
        $record['previous'] = $previous['previous'] ?? ['state' => $previous['state'], 'checked_at' => $previous['checked_at']];
    }
    return $record;
}

/** Keep the pending cursor when the same check is submitted twice. */
function start_component_readback(string $root, string $site, string $component, string $point): void {
    with_backup_job_lock($root, static function () use ($site, $component, $point): void {
        $history = get_option(COMPONENT_RECOVERY_STATE_OPTION, []);
        $chain = isset(COMPONENTS[$component]) && is_array($history) ? component_recovery_chain($site, $component, $history, time()) : [];
        $target = component_readback_target($chain);
        if ($target === [] || !hash_equals($target['id'], $point)) {
            throw new \RuntimeException('The latest component backup changed. Open Overview for the current recovery files.');
        }
        $records = component_readback_records();
        $current = $records[$component] ?? [];
        if (($current['state'] ?? null) !== 'checking' || ($current['point'] ?? null) !== $point) {
            $records[$component] = pending_component_readback($chain, $point, $current);
            save_component_readback_records($records);
        } elseif (($current['automatic'] ?? false) === true) {
            unset($records[$component]['automatic']);
            save_component_readback_records($records);
        }
    });
    bring_forward_backup_event(COMPONENT_READBACK_HOOK, [], time() + 60);
}

/** Read one Dropbox object per callback. Discard a cursor when its verified chain changes. */
function advance_component_readback(string $root, string $site, int $now, callable $metadata): void {
    with_backup_job_lock($root, static function () use ($site, $now, $metadata): void {
        $records = component_readback_records();
        if (!in_array('checking', array_column($records, 'state'), true)) {
            $next = next_automatic_component_readback($site, $records, $now);
            if ($next !== [] && $next['due_at'] <= $now) {
                $component = $next['component'];
                $target = component_readback_target($next['chain']);
                $records[$component] = pending_component_readback($next['chain'], $target['id'], $records[$component] ?? []);
                $records[$component]['automatic'] = true;
            }
        }
        $history = get_option(COMPONENT_RECOVERY_STATE_OPTION, []);
        foreach ($records as $component => $record) {
            if (($record['state'] ?? null) !== 'checking') {
                continue;
            }
            try {
                $chain = is_array($history) ? component_recovery_chain($site, $component, $history, $now) : [];
            } catch (\RuntimeException $error) {
                $chain = [];
            }
            $target = component_readback_target($chain);
            $position = $record['position'] ?? null;
            if (($target['id'] ?? '') !== ($record['point'] ?? null) || !is_int($position) || $position < 0
                || $position >= count($target['objects'] ?? [])) {
                unset($records[$component]);
                continue;
            }
            if (($record['automatic'] ?? false) === true && !component_readback_schedule_enabled(get_plan(), $component, $now)) {
                if (isset($record['previous'])) {
                    $records[$component] = array_intersect_key($record, array_flip(['point', 'baseline', 'authorization']))
                        + $record['previous'];
                } else {
                    unset($records[$component]);
                }
                continue;
            }
            $authorization = component_readback_authorization();
            if ($authorization !== ($record['authorization'] ?? '')) {
                $record['authorization'] = $authorization;
                $record['position'] = 0;
                unset($record['retry_at'], $record['retry_count'], $record['previous']);
                $records[$component] = $record;
                break;
            }
            if (($record['retry_at'] ?? 0) > $now) {
                continue;
            }
            $object = array_slice($target['objects'], $position, 1, true);
            try {
                if (!verify_offsite_files($object, $metadata)['verified']) {
                    $record['state'] = 'changed';
                } elseif (++$record['position'] === count($target['objects'])) {
                    $record['state'] = 'confirmed';
                }
                unset($record['retry_at'], $record['retry_count']);
            } catch (\RuntimeException $error) {
                $record['retry_count'] = ($record['retry_count'] ?? 0) + 1;
                if ($record['retry_count'] >= 3) {
                    $record['state'] = 'unavailable';
                    unset($record['retry_at'], $record['retry_count']);
                } else {
                    $record['retry_at'] = $now + 900;
                }
            }
            $current_authorization = component_readback_authorization();
            if ($authorization !== $current_authorization) {
                $record['authorization'] = $current_authorization;
                $record['position'] = 0;
                $record['state'] = 'checking';
                unset($record['retry_at'], $record['retry_count'], $record['previous']);
            }
            if ($record['state'] !== 'checking') {
                $record['checked_at'] = $now;
                if ($record['state'] !== 'unavailable' || ($record['previous']['state'] ?? null) !== 'changed') {
                    unset($record['previous']);
                }
                unset($record['automatic']);
            }
            $records[$component] = $record;
            break;
        }
        save_component_readback_records($records);
    });
}

function run_component_readback(): void {
    $delay = 60;
    try {
        $timeout = max(1, min(5, intdiv((int) backup_request_budget(), 2)));
        advance_component_readback(backup_job_root(true), home_url(), time(), static function (string $path) use ($timeout): ?array {
            $app = dropbox_app_key();
            $refresh = dropbox_saved_refresh_token($app);
            if ($refresh === '') {
                throw new \RuntimeException('Dropbox authorization is unavailable.');
            }
            return fetch_dropbox_metadata($path, refresh_dropbox_access_token($app, $refresh, $timeout), $timeout);
        });
    } catch (\RuntimeException $error) {
        $delay = 900;
    } finally {
        queue_component_readback($delay);
    }
}

/** Show only a result for the current chain, even when an earlier result was successful. */
function component_readback_status(array $chain, $record): array {
    $target = component_readback_target($chain);
    if ($target === [] || ($record['point'] ?? null) !== $target['id']
        || (isset($record['authorization']) && $record['authorization'] !== component_readback_authorization())) {
        return [];
    }
    return is_array($record) ? $record : [];
}

function component_readback_warning(array $states): string {
    if (in_array('changed', $states, true)) {
        return 'changed';
    }
    return in_array('unavailable', $states, true) ? 'unavailable' : '';
}

function component_readback_warning_for_chains(array $chains, array $records): string {
    $states = [];
    foreach (array_intersect_key($chains, $records) as $component => $chain) {
        $check = component_readback_status($chain, $records[$component]);
        $states[] = $check['previous']['state'] ?? $check['state'] ?? '';
    }
    return component_readback_warning($states);
}

function render_component_readback(string $component, array $chain, array $check): void {
    $messages = [
        'checking' => 'WordPress is checking the ZIP and manifest for each backup in this recovery chain.',
        'confirmed' => 'Dropbox confirmed every file needed to restore this component.',
        'changed' => 'Dropbox reported a missing or changed file needed for this restore.',
        'unavailable' => 'Dropbox could not confirm every file needed for this restore.',
    ];
    $state = $check['state'] ?? '';
    $message = $messages[$state] ?? 'Check that Dropbox still has every file needed for this restore.';
    $checked = $check['checked_at'] ?? null;
    if (is_int($checked) && $checked > 0 && $checked <= time()) {
        $message .= ' Checked ' . wp_date('M j, Y H:i T', $checked) . '.';
    }
    $previous = $check['previous']['state'] ?? '';
    if (($state === 'checking' || $state === 'unavailable') && in_array($previous, ['changed', 'unavailable'], true)) {
        $message .= ' ' . $messages[$previous];
    }
    if ($state === 'checking') {
        $next = wp_next_scheduled(COMPONENT_READBACK_HOOK);
        if (is_int($check['retry_at'] ?? null)) {
            $message .= ' Dropbox could not complete the last check. WordPress kept its place.';
            $next = max($next ?: 0, $check['retry_at']);
        }
        if (is_int($next)) {
            $message .= ' The next check is queued for ' . wp_date('M j, Y H:i T', $next) . '.';
        }
    }
    ?>
    <p><?php echo esc_html($message); ?></p>
    <?php if ($state !== 'checking') : ?>
        <form action="<?php echo esc_url(admin_url('admin-post.php')); ?>" method="post">
            <input type="hidden" name="action" value="pebkac_backup_component_readback">
            <input type="hidden" name="component" value="<?php echo esc_attr($component); ?>">
            <input type="hidden" name="point" value="<?php echo esc_attr(component_readback_target($chain)['id']); ?>">
            <?php wp_nonce_field('pebkac_backup_component_readback'); ?>
            <button class="button" type="submit">Check Dropbox recovery files</button>
        </form>
    <?php endif; ?>
    <?php
}

add_action('init', __NAMESPACE__ . '\\queue_component_readback', 10, 0);
add_action('add_option_' . COMPONENT_RECOVERY_STATE_OPTION, __NAMESPACE__ . '\\queue_component_readback', 10, 0);
add_action('update_option_' . COMPONENT_RECOVERY_STATE_OPTION, __NAMESPACE__ . '\\queue_component_readback', 10, 0);
add_action(COMPONENT_READBACK_HOOK, __NAMESPACE__ . '\\run_component_readback');
add_action('admin_post_pebkac_backup_component_readback', static function (): void {
    if (($_SERVER['REQUEST_METHOD'] ?? '') !== 'POST' || !current_user_can('manage_options') || !is_ssl()) {
        wp_die('Website Backup administrator access is required.', '', ['response' => 403]);
    }
    check_admin_referer('pebkac_backup_component_readback');
    $component = isset($_POST['component']) && is_string($_POST['component']) ? wp_unslash($_POST['component']) : '';
    $point = isset($_POST['point']) && is_string($_POST['point']) ? wp_unslash($_POST['point']) : '';
    if (dropbox_saved_refresh_token(dropbox_app_key()) === '') {
        wp_die('Connect Dropbox before checking the latest recovery files.', '', ['response' => 409]);
    }
    try {
        start_component_readback(backup_job_root(true), home_url(), $component, $point);
    } catch (\RuntimeException $error) {
        wp_die('Open Overview again to check the current recovery files.', '', ['response' => 409]);
    }
    wp_safe_redirect(admin_url('admin.php?page=pebkac-backup&tab=overview&component_readback=1#pebkac-backup-components'), 303);
    exit;
});
