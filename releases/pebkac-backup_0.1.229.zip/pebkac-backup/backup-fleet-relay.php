<?php

namespace PEBKAC404\Backup;

require_once __DIR__ . '/backup-fleet.php';
require_once __DIR__ . '/pilot-sites.php';
require_once __DIR__ . '/dropbox-metadata.php';

const FLEET_RELAY_MAX_BYTES = 2048;
const FLEET_RELAY_FOLDER = '/Website Backup Status';

/** Use the same app-folder location on both pilots, independent of their backup folders. */
function private_fleet_report_path(string $site): string {
    $slug = \PEBKAC404\Backup\pilot_site_slug($site);
    if ($slug === '') {
        throw new \RuntimeException('Only the two approved pilots can use the private backup report relay.');
    }
    return FLEET_RELAY_FOLDER . '/' . $slug . '.json';
}

function describe_private_fleet_report(string $site, array $status, int $now): array {
    $path = private_fleet_report_path($site);
    $report = \PEBKAC404\Backup\make_backup_monitor_report($site, $status, $now);
    if ($report === null) {
        throw new \RuntimeException('There is no valid backup report for this site.');
    }
    $bytes = json_encode(['site_url' => $site, 'report' => $report], JSON_UNESCAPED_SLASHES | JSON_THROW_ON_ERROR);
    if (strlen($bytes) > FLEET_RELAY_MAX_BYTES) {
        throw new \RuntimeException('The backup report is too large.');
    }
    return ['path' => $path, 'bytes' => $bytes, 'size' => strlen($bytes),
        'content_hash' => hash('sha256', hash('sha256', $bytes, true))];
}

/** Accept only bounded bytes from the expected site and exact provider revision. */
function read_private_fleet_report(string $site, string $bytes, array $metadata, int $now): array {
    private_fleet_report_path($site);
    if (($metadata['.tag'] ?? null) !== 'file' || !\PEBKAC404\Backup\valid_dropbox_file_revision($metadata['rev'] ?? null)
        || strlen($bytes) > FLEET_RELAY_MAX_BYTES || strlen($bytes) !== ($metadata['size'] ?? null)
        || hash('sha256', hash('sha256', $bytes, true)) !== ($metadata['content_hash'] ?? null)) {
        throw new \RuntimeException('The downloaded backup report could not be confirmed.');
    }
    return decode_private_fleet_report($site, $bytes, $now, false);
}

function decode_private_fleet_report(string $site, string $bytes, int $now, bool $publishing): array {
    $envelope = json_decode($bytes, true, 6, JSON_THROW_ON_ERROR);
    if (!is_array($envelope) || ($envelope['site_url'] ?? null) !== $site || array_keys($envelope) !== ['site_url', 'report']) {
        throw new \RuntimeException('The downloaded backup report belongs to a different site.');
    }
    $report = \PEBKAC404\Backup\normalize_backup_site_report($site, $envelope['report'], $now);
    if ($report === null || ($publishing && $report !== $envelope['report'])) {
        throw new \RuntimeException('The downloaded backup report includes unsupported information.');
    }
    return $report;
}

/** Check the existing revision and persist a write intent before replacing a prior report. */
function advance_private_fleet_publication(
    string $site, array $report, array $state, int $now, callable $metadata, callable $download, callable $write, callable $save
): array {
    $path = private_fleet_report_path($site);
    $bytes = $report['bytes'] ?? null;
    if (($report['path'] ?? null) !== $path || !is_string($bytes) || strlen($bytes) > FLEET_RELAY_MAX_BYTES
        || ($report['size'] ?? null) !== strlen($bytes) || ($report['content_hash'] ?? null) !== hash('sha256', hash('sha256', $bytes, true))) {
        throw new \RuntimeException('The backup report does not match its saved publication details.');
    }
    $candidate = decode_private_fleet_report($site, $bytes, $now, true);
    $phase = $state['phase'] ?? 'inspect';
    if ($state !== [] && (($state['path'] ?? null) !== $path || ($state['content_hash'] ?? null) !== $report['content_hash']
        || !in_array($phase, ['compare', 'write', 'verify', 'verified'], true))) {
        throw new \RuntimeException('A different backup report is waiting for Dropbox confirmation.');
    }
    $intent = ['path' => $path, 'content_hash' => $report['content_hash']];
    if ($phase === 'compare') {
        $actual = $state['previous'] ?? null;
        if (!is_array($actual) || !\PEBKAC404\Backup\valid_dropbox_file_revision($actual['rev'] ?? null)) {
            throw new \RuntimeException('The saved comparison has an invalid prior report revision.');
        }
        $previous = read_private_fleet_report($site, $download($path, $actual['rev']), $actual, $now);
        if ($previous['observed_at'] >= $candidate['observed_at']) {
            throw new \RuntimeException('Dropbox already contains an equally recent or newer report for this site.');
        }
        $state = ['phase' => 'write', 'previous_revision' => $actual['rev']] + $intent;
    } elseif ($phase === 'write') {
        if (!array_key_exists('previous_revision', $state) || ($state['previous_revision'] !== null
            && !\PEBKAC404\Backup\valid_dropbox_file_revision($state['previous_revision']))) {
            throw new \RuntimeException('The saved write has an invalid prior report revision.');
        }
        $state['phase'] = 'verify';
        $save($state);
        $write($path, $bytes, $state['previous_revision']);
        return $state;
    } else {
        $actual = $metadata($path);
        if ($actual !== null && (($actual['.tag'] ?? null) !== 'file' || !\PEBKAC404\Backup\valid_dropbox_file_revision($actual['rev'] ?? null))) {
            throw new \RuntimeException('The backup report destination is occupied by a different object.');
        }
        if (($actual['size'] ?? null) === $report['size'] && ($actual['content_hash'] ?? null) === $report['content_hash']) {
            $state = ['phase' => 'verified', 'revision' => $actual['rev']] + $intent;
        } elseif ($phase !== 'inspect') {
            throw new \RuntimeException('Dropbox did not confirm the earlier report write. The write was kept on hold.');
        } elseif ($actual === null) {
            $state = ['phase' => 'write', 'previous_revision' => null] + $intent;
        } else {
            if (!is_int($actual['size'] ?? null) || $actual['size'] < 1 || $actual['size'] > FLEET_RELAY_MAX_BYTES
                || !is_string($actual['content_hash'] ?? null) || !preg_match('/^[a-f0-9]{64}$/D', $actual['content_hash'])) {
                throw new \RuntimeException('The existing Dropbox file is not a bounded backup report.');
            }
            $state = ['phase' => 'compare', 'previous' => array_intersect_key($actual, array_flip(['.tag', 'size', 'content_hash', 'rev']))] + $intent;
        }
    }
    $save($state);
    return $state;
}
