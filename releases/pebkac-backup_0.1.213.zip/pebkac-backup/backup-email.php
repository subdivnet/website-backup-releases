<?php

namespace PEBKAC404\Backup;

/** Report a due daily run that cannot even create a backup job. Reserve before mailing. */
function notify_unstarted_daily_backup(array $plan, int $now): void {
    if (($plan['result_email'] ?? false) !== true || !daily_backup_settings($plan)['enabled']) { return; }
    $timezone = wp_timezone();
    $local = (new \DateTimeImmutable('@' . $now))->setTimezone($timezone);
    $due = backup_schedule_occurrence(['frequency' => 'daily', 'time' => daily_backup_settings($plan)['time']], $timezone,
        $local->setTime(0, 0)->getTimestamp());
    $timing = get_option(DAILY_BACKUP_TIMING_OPTION, []);
    if ($due === null || $due > $now || ($timing['enabled_at'] ?? $now + 1) > $due) { return; }
    $proof = verified_evidence(get_option(EVIDENCE_OPTION, []), home_url(), $now);
    if (isset($proof['offsite_verified_at']) && (new \DateTimeImmutable('@' . $proof['offsite_verified_at']))->setTimezone($timezone)->format('Y-m-d') === $local->format('Y-m-d')) { return; }
    $recipient = get_option('admin_email', '');
    if (!is_string($recipient) || !is_email($recipient)) { return; }
    $key = 'pebkac_backup_unstarted_mail_' . $local->format('Ymd');
    if (!add_option($key, ['attempted_at' => $now], '', false)) { return; }
    $accepted = false;
    try {
        $accepted = (bool) wp_mail($recipient, 'Website Backup: daily backup needs attention — ' . home_url(),
            'Site: ' . home_url() . "\nResult: The scheduled backup could not start. Open Overview to check Dropbox and host readiness.\nSize: Not available\nDuration: 0 seconds\nVerified in Dropbox: No\n\n"
            . admin_url('admin.php?page=pebkac-backup&tab=overview'));
    } catch (\Throwable $error) {}
    update_option($key, ['attempted_at' => $now, 'accepted' => $accepted], false);
    delete_option('pebkac_backup_unstarted_mail_' . $local->modify('-7 days')->format('Ymd'));
}

/** Reserve each result before calling mail: an interrupted send must not be repeated. */
function notify_backup_result(string $root, array $job, bool $verified): array {
    if ((get_plan()['result_email'] ?? false) !== true) {
        return $job;
    }
    $result = $verified ? 'verified' : 'failed';
    if (!empty($job['result_email'][$result])) {
        return $job;
    }
    $recipient = get_option('admin_email', '');
    if (!is_string($recipient) || !is_email($recipient)) {
        return $job;
    }
    $now = time();
    $started = $job['started_at'] ?? null;
    $duration = is_int($started) && $started > 0 && $started <= $now
        ? ($now - $started) . ' seconds' : 'Not available';
    $bytes = $job['transfer']['size'] ?? null;
    if (!is_int($bytes) || $bytes < 0) {
        $evidence = verified_evidence(get_option(EVIDENCE_OPTION, []), home_url(), $now);
        $bytes = $verified ? verified_job_archive_size($job, $evidence) : null;
    }
    $size = is_int($bytes) && $bytes >= 0 ? $bytes . ' bytes' : 'Not available';
    $message = 'Site: ' . home_url() . "\n"
        . 'Result: ' . ($verified ? 'Backup completed' : 'Backup failed or paused; review Overview') . "\n"
        . 'Size: ' . $size . "\nDuration: " . $duration . "\n"
        . 'Verified in Dropbox: ' . ($verified ? 'Yes' : 'No') . "\n\n"
        . admin_url('admin.php?page=pebkac-backup&tab=overview');
    $job['result_email'][$result] = ['attempted_at' => $now, 'accepted' => null];
    write_backup_job($root, $job);
    try {
        $job['result_email'][$result]['accepted'] = (bool) wp_mail($recipient,
            'Website Backup: ' . ($verified ? 'verified backup' : 'backup needs attention') . ' — ' . home_url(), $message);
    } catch (\Throwable $error) {
        $job['result_email'][$result]['accepted'] = false;
    }
    write_backup_job($root, $job);
    return $job;
}
