<?php

namespace PEBKAC404\Backup;

if (!defined('ABSPATH')) {
    exit;
}

require_once __DIR__ . '/backup-capture-problem.php';

const BACKUP_SQL_MAX = 32 * 1024 * 1024;
const BACKUP_DATABASE_PAGE_BYTES = 2 * 1024 * 1024;
const BACKUP_DATABASE_MAX_TABLES = 250;

function backup_sql_identifier(string $name): string {
    if (!preg_match('/^[a-zA-Z0-9_]{1,64}$/D', $name)) {
        throw new \RuntimeException('A database identifier is outside the pilot export format.');
    }
    return '`' . $name . '`';
}

/** Size the next ordered page before fetching its variable-length values into PHP. */
function backup_database_page_length(array $preview, int $single_row_limit): int {
    $page_limit = min(BACKUP_DATABASE_PAGE_BYTES, $single_row_limit);
    $rows = 0;
    $bytes = 0;
    foreach ($preview as $entry) {
        $size = filter_var($entry['payload_bytes'] ?? null, FILTER_VALIDATE_INT, ['options' => ['min_range' => 0]]);
        if ($size === false) {
            throw new \RuntimeException('WordPress could not size a database row for backup.');
        }
        if ($rows === 0 && $size > $single_row_limit) {
            throw new BackupCaptureProblem('A database row exceeds the available space for the export.', BackupCaptureProblem::DATABASE_ROW_LIMIT);
        }
        if ($rows > 0 && $size > $page_limit - $bytes) {
            break;
        }
        $rows++;
        $bytes += $size;
    }
    return $rows;
}

/** Find a stable ordering key for plugin tables that use a unique index instead of a primary key. */
function backup_unique_order_key(array $indexes, array $not_null): array {
    $groups = [];
    foreach ($indexes as $row) {
        $name = $row['Key_name'] ?? null;
        if (is_string($name)) {
            $groups[$name][] = $row;
        }
    }
    ksort($groups, SORT_STRING);
    foreach ($groups as $group) {
        usort($group, static function (array $left, array $right): int {
            return (int) $left['Seq_in_index'] <=> (int) $right['Seq_in_index'];
        });
        $columns = [];
        foreach ($group as $part) {
            $field = $part['Column_name'] ?? null;
            if (!is_string($field) || !isset($not_null[$field]) || ($part['Sub_part'] ?? null) !== null) {
                continue 2;
            }
            $columns[] = $field;
        }
        return $columns;
    }
    return [];
}

/** Export a bounded, transaction-consistent single-site database using the current WordPress connection. */
function export_wordpress_database($wpdb, $stream, float $seconds = 12.0): int {
    if (!in_array($wpdb->charset, ['utf8mb4', 'utf8', 'utf8mb3'], true)) {
        throw new \RuntimeException('This pilot requires a UTF-8 WordPress database connection.');
    }
    $deadline = microtime(true) + $seconds;
    $php_memory_limit = wp_convert_hr_to_bytes((string) ini_get('memory_limit'));
    $bytes = 0;
    $write = static function (string $sql) use ($stream, &$bytes, &$deadline): void {
        if (microtime(true) >= $deadline || ($bytes += strlen($sql)) > BACKUP_SQL_MAX) {
            throw new BackupCaptureProblem('The database export exceeded the pilot time or size limit.', BackupCaptureProblem::DATABASE_LIMIT);
        }
        if (fwrite($stream, $sql) !== strlen($sql)) {
            throw new \RuntimeException('Could not write the private database export.');
        }
    };
    $previous = $wpdb->suppress_errors(true);
    $read = static function (string $query) use ($wpdb): array {
        $result = $wpdb->get_results($query, ARRAY_A);
        if ($wpdb->last_error !== '' || !is_array($result)) {
            throw new \RuntimeException('WordPress could not read a database table for backup.');
        }
        return $result;
    };
    $transaction = false;
    $locked = false;
    $session = null;
    try {
        // A session reconnect would discard the snapshot. Record and recheck its identity.
        $identity = $read('SELECT CONNECTION_ID() AS id')[0]['id'] ?? null;
        $tables = $read($wpdb->prepare(
            'SELECT TABLE_NAME AS name, ENGINE AS engine FROM information_schema.TABLES WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME LIKE %s ORDER BY TABLE_NAME',
            $wpdb->esc_like($wpdb->prefix) . '%'
        ));
        $names = array_column($tables, 'name');
        $required = array_map(static function ($name) use ($wpdb) { return $wpdb->prefix . $name; },
            ['options', 'posts', 'postmeta', 'users', 'usermeta', 'terms', 'term_taxonomy', 'term_relationships', 'comments', 'commentmeta']);
        if ($identity === null || array_diff($required, $names)) {
            throw new \RuntimeException('Could not verify the expected WordPress database tables.');
        }
        if (count($tables) > BACKUP_DATABASE_MAX_TABLES) {
            throw new BackupCaptureProblem('The database has too many site tables for the export.', BackupCaptureProblem::DATABASE_TABLE_LIMIT);
        }
        $identifiers = [];
        $mixed = false;
        foreach ($tables as $table) {
            $name = $table['name'];
            $engine = strtolower((string) $table['engine']);
            if (strpos($name, $wpdb->prefix) !== 0 || !in_array($engine, ['innodb', 'myisam', 'memory'], true)) {
                throw new \RuntimeException('A site table cannot be included in a consistent pilot export.');
            }
            $identifiers[$name] = backup_sql_identifier($name);
            $mixed = $mixed || $engine !== 'innodb';
        }
        if ($mixed) {
            $session = $read('SELECT @@SESSION.autocommit AS autocommit, @@SESSION.lock_wait_timeout AS lock_timeout, @@SESSION.innodb_table_locks AS innodb_locks, @@SESSION.innodb_lock_wait_timeout AS innodb_timeout')[0] ?? [];
            if ((int) ($session['autocommit'] ?? 0) !== 1 || (int) ($session['innodb_locks'] ?? 0) !== 1
                || $wpdb->query('SET SESSION autocommit = 0, SESSION lock_wait_timeout = 2, SESSION innodb_lock_wait_timeout = 2') === false
                || $wpdb->query('LOCK TABLES ' . implode(' READ, ', $identifiers) . ' READ') === false) {
                throw new \RuntimeException('WordPress could not obtain short read locks for this mixed database.');
            }
            $locked = true;
            $deadline = min($deadline, microtime(true) + 6);
        } else {
            if ($wpdb->query('SET TRANSACTION ISOLATION LEVEL REPEATABLE READ') === false
                || $wpdb->query('START TRANSACTION WITH CONSISTENT SNAPSHOT, READ ONLY') === false) {
                throw new \RuntimeException('WordPress could not start a consistent database export.');
            }
            $transaction = true;
        }
        $write("SET NAMES utf8mb4;\nSET FOREIGN_KEY_CHECKS=0;\n");
        foreach ($identifiers as $name => $identifier) {
            $definition = $read('SHOW CREATE TABLE ' . $identifier)[0]['Create Table'] ?? '';
            if (strpos($definition, 'CREATE TABLE ') !== 0) {
                throw new \RuntimeException('Could not read a table definition.');
            }
            $columns = [];
            $binary = [];
            $integer_fields = [];
            $not_null = [];
            $size_fields = [];
            $may_have_large_values = false;
            foreach ($read('SHOW FULL COLUMNS FROM ' . $identifier) as $column) {
                if (stripos($column['Extra'], 'GENERATED') === false) {
                    $field = backup_sql_identifier($column['Field']);
                    $columns[] = $field;
                    $is_binary = preg_match('/^(?:bit|binary|varbinary|(?:tiny|medium|long)?blob)(?:\(|$)/i', $column['Type']) === 1;
                    $binary[$column['Field']] = $is_binary;
                    $sized_field = $is_binary ? $field : "CONVERT($field USING utf8mb4)";
                    $size_fields[] = "COALESCE(OCTET_LENGTH($sized_field), 0)";
                    $may_have_large_values = $may_have_large_values
                        || preg_match('/^(?:(?:tiny|medium|long)?(?:text|blob)|json)\b/i', $column['Type']) === 1;
                    if (preg_match('/^(?:tinyint|smallint|mediumint|int|bigint)(?:\(|\s|$)/i', $column['Type'])) {
                        $integer_fields[$column['Field']] = true;
                    }
                    if (($column['Null'] ?? null) === 'NO') {
                        $not_null[$column['Field']] = true;
                    }
                }
            }
            $primary = $read('SHOW INDEX FROM ' . $identifier . " WHERE Key_name = 'PRIMARY'");
            usort($primary, static function ($left, $right) { return (int) $left['Seq_in_index'] <=> (int) $right['Seq_in_index']; });
            $keys = array_column($primary, 'Column_name');
            if ($keys === []) {
                $keys = backup_unique_order_key($read('SHOW INDEX FROM ' . $identifier . ' WHERE Non_unique = 0'), $not_null);
            }
            if ($columns === [] || $keys === []) {
                throw new BackupCaptureProblem('A site table has no stable primary or non-null unique key for the pilot export.', BackupCaptureProblem::DATABASE_KEY);
            }
            $order = implode(', ', array_map('PEBKAC404\\Backup\\backup_sql_identifier', $keys));
            $cursor_field = count($keys) === 1 && isset($integer_fields[$keys[0]]) ? $keys[0] : null;
            $cursor = null;
            $fields = implode(', ', $columns);
            $payload_bytes = implode(' + ', $size_fields);
            $where = '';
            if ($name === $wpdb->options) {
                $where = $wpdb->prepare(' WHERE `option_name` <> %s AND `option_name` NOT LIKE %s AND `option_name` NOT LIKE %s',
                    DROPBOX_CREDENTIAL_OPTION, $wpdb->esc_like('_transient_pebkac_dbx_') . '%',
                    $wpdb->esc_like('_transient_timeout_pebkac_dbx_') . '%');
            }
            $write($definition . ";\n");
            $offset = 0;
            while (true) {
                if (microtime(true) >= $deadline) {
                    throw new BackupCaptureProblem('The database export exceeded the pilot time limit.', BackupCaptureProblem::DATABASE_LIMIT);
                }
                $page_where = $where;
                if ($cursor !== null) {
                    $page_where .= ($where === '' ? ' WHERE ' : ' AND ') . "$order > $cursor";
                }
                $page_offset = $cursor_field === null ? " OFFSET $offset" : '';
                $selection = "FROM $identifier$page_where ORDER BY $order";
                $page_length = 25;
                if ($may_have_large_values) {
                    $preview = $read("SELECT ($payload_bytes) AS payload_bytes $selection LIMIT 25$page_offset");
                    // Leave room for the result buffer and hexadecimal SQL encoding of one large row.
                    $row_limit = intdiv(BACKUP_SQL_MAX, 2);
                    if ($php_memory_limit > 0) {
                        $row_limit = min($row_limit, max(0, intdiv($php_memory_limit - memory_get_usage(), 8)));
                    }
                    $page_length = backup_database_page_length($preview, $row_limit);
                    if ($page_length === 0) {
                        break;
                    }
                }
                $rows = $read("SELECT $fields $selection LIMIT $page_length$page_offset");
                if ($may_have_large_values && count($rows) !== $page_length) {
                    throw new \RuntimeException('The database page changed between sizing and capture.');
                }
                foreach ($rows as $row) {
                    $values = [];
                    foreach ($binary as $field => $is_binary) {
                        $value = $row[$field];
                        $hex = "X'" . bin2hex((string) $value) . "'";
                        $values[] = $value === null ? 'NULL' : ($is_binary ? $hex : "CONVERT($hex USING utf8mb4)");
                    }
                    $write("INSERT INTO $identifier ($fields) VALUES (" . implode(', ', $values) . ");\n");
                }
                if (count($rows) < $page_length) {
                    break;
                }
                if ($cursor_field !== null) {
                    $cursor = (string) ($rows[$page_length - 1][$cursor_field] ?? '');
                    if (!preg_match('/^-?[0-9]{1,20}$/D', $cursor)) {
                        throw new \RuntimeException('WordPress could not continue reading the integer database key.');
                    }
                }
                $offset += $page_length;
                unset($rows);
            }
        }
        if (($read('SELECT CONNECTION_ID() AS id')[0]['id'] ?? null) !== $identity) {
            throw new \RuntimeException('The database connection changed during export.');
        }
        $write("SET FOREIGN_KEY_CHECKS=1;\n");
        return $bytes;
    } finally {
        if ($transaction) {
            $wpdb->query('ROLLBACK');
        }
        if ($locked) {
            $wpdb->query('UNLOCK TABLES');
        }
        if (isset($session['autocommit'], $session['lock_timeout'], $session['innodb_timeout'])) {
            $wpdb->query('SET SESSION autocommit = ' . (int) $session['autocommit']
                . ', SESSION lock_wait_timeout = ' . (int) $session['lock_timeout']
                . ', SESSION innodb_lock_wait_timeout = ' . (int) $session['innodb_timeout']);
        }
        $wpdb->suppress_errors($previous);
    }
}
