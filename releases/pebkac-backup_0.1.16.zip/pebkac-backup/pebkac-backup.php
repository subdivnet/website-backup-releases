<?php
/**
 * Plugin Name: Website Backup
 * Description: Set up backups and see whether this WordPress site has a verified recovery point.
 * Version: 0.1.16
 * Requires at least: 6.0
 * Requires PHP: 7.4
 * Update URI: https://pebkac404.com/wordpress/pebkac-backup/
 */

namespace PEBKAC404\Backup;

if (!defined('ABSPATH')) {
    exit;
}

const VERSION = '0.1.16';
const OPTION = 'pebkac_backup_plan';
const EVIDENCE_OPTION = 'pebkac_backup_evidence';
const COMPONENTS = [
    'database' => 'Database',
    'uploads' => 'Media uploads',
    'plugins' => 'Plugins',
    'themes' => 'Themes',
    'core' => 'WordPress core',
    'configuration' => 'Site configuration',
];
const DAYS = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday'];

require_once __DIR__ . '/dropbox-connection.php';
require_once __DIR__ . '/host-check.php';
require_once __DIR__ . '/database-export.php';
require_once __DIR__ . '/backup-job.php';
require_once __DIR__ . '/backup-recovery.php';
require_once __DIR__ . '/restore-receipt.php';
require_once __DIR__ . '/backup-schedule.php';
require_once __DIR__ . '/backup-daily.php';
require_once __DIR__ . '/backup-retention.php';
require_once __DIR__ . '/backup-fleet.php';
require_once __DIR__ . '/backup-release.php';

if (is_file(__DIR__ . '/release-public-key.php')) {
    $release_key = require __DIR__ . '/release-public-key.php';
    register_backup_release_hooks(
        ['origin' => backup_release_origin_for_site(home_url()), 'public_key' => $release_key],
        VERSION,
        __NAMESPACE__ . '\\backup_update_work_directory'
    );
    add_filter('auto_update_plugin', __NAMESPACE__ . '\\enable_pilot_backup_auto_update', 10, 2);
}

add_filter('rest_request_after_callbacks', __NAMESPACE__ . '\\add_backup_to_private_monitor_response', 10, 3);

register_deactivation_hook(__FILE__, static function (): void {
    wp_clear_scheduled_hook(DAILY_BACKUP_HOOK);
    wp_clear_scheduled_hook(BACKUP_RETENTION_HOOK);
    wp_clear_scheduled_hook(COMPONENT_BACKUP_HOOK);
});

function default_plan(): array {
    return [
        'folder' => '',
        'component_jobs' => false,
        'incremental_components' => false,
        'daily' => ['enabled' => false, 'time' => '02:00', 'retention' => false],
        'schedules' => array_fill_keys(array_keys(COMPONENTS), [
            'frequency' => 'off',
            'time' => '02:00',
            'day' => 'Monday',
        ]),
    ];
}

function get_plan(): array {
    $saved = get_option(OPTION, []);
    return array_replace_recursive(default_plan(), is_array($saved) ? $saved : []);
}

function validate_plan($input) {
    $plan = default_plan();
    $folder = $input['folder'] ?? null;
    if (!is_string($folder)) {
        return new \WP_Error('invalid_folder', 'Enter a Dropbox folder path.');
    }
    $folder = trim($folder);
    if ($folder !== '' && !valid_backup_dropbox_folder($folder)) {
        return new \WP_Error('invalid_folder', 'Use a folder path such as /Website Backups/Security Lab.');
    }
    $plan['folder'] = $folder;
    $plan['component_jobs'] = in_array($input['component_jobs'] ?? false, [true, '1'], true);
    $plan['incremental_components'] = in_array($input['incremental_components'] ?? false, [true, '1'], true);

    $daily = $input['daily'] ?? $plan['daily'];
    $time = $daily['time'] ?? null;
    if (!is_string($time) || !preg_match('/^(?:[01][0-9]|2[0-3]):[0-5][0-9]$/D', $time)) {
        return new \WP_Error('invalid_daily_backup', 'Enter a valid time for the daily backup.');
    }
    $plan['daily'] = [
        'enabled' => in_array($daily['enabled'] ?? false, [true, '1'], true),
        'time' => $time,
        'retention' => in_array($daily['retention'] ?? false, [true, '1'], true),
    ];

    foreach (COMPONENTS as $key => $label) {
        $schedule = $input['schedules'][$key] ?? [];
        $frequency = $schedule['frequency'] ?? null;
        $time = $schedule['time'] ?? null;
        $day = $schedule['day'] ?? null;
        if (!in_array($frequency, ['off', 'daily', 'weekly'], true)
            || !is_string($time) || !preg_match('/^(?:[01][0-9]|2[0-3]):[0-5][0-9]$/D', $time)
            || !in_array($day, DAYS, true)) {
            return new \WP_Error('invalid_schedule', 'Review the schedule for ' . $label . '.');
        }
        $plan['schedules'][$key] = compact('frequency', 'time', 'day');
    }
    return $plan;
}

function sanitize_plan($input): array {
    $plan = validate_plan($input);
    if (is_wp_error($plan)) {
        add_settings_error(OPTION, $plan->get_error_code(), $plan->get_error_message());
        return get_plan();
    }
    return $plan;
}

add_action('admin_init', static function () {
    register_setting(OPTION, OPTION, ['sanitize_callback' => __NAMESPACE__ . '\\sanitize_plan']);
});

add_action('admin_menu', static function () {
    add_menu_page('Website Backup', 'Website Backup', 'manage_options', 'pebkac-backup', __NAMESPACE__ . '\\settings_page', 'dashicons-backup');
});

function settings_page(): void {
    if (!current_user_can('manage_options')) {
        return;
    }
    $tabs = ['overview' => 'Overview', 'setup' => 'Setup', 'sites' => 'Sites'];
    $requested = $_GET['tab'] ?? '';
    $active = is_string($requested) && isset($tabs[$requested]) ? $requested : 'overview';
    ?>
    <div class="wrap">
        <h1>Website Backup</h1>
        <nav class="nav-tab-wrapper" aria-label="Website Backup">
            <?php foreach ($tabs as $tab => $label) : ?>
                <a class="nav-tab<?php echo $tab === $active ? ' nav-tab-active' : ''; ?>"
                    <?php if ($tab === $active) : ?>aria-current="page"<?php endif; ?>
                    href="<?php echo esc_url(admin_url('admin.php?page=pebkac-backup&tab=' . $tab)); ?>"><?php echo esc_html($label); ?></a>
            <?php endforeach; ?>
        </nav>
        <?php
        switch ($active) {
            case 'setup':
                render_setup();
                break;
            case 'sites':
                render_backup_sites();
                break;
            default:
                render_overview();
                break;
        }
        ?>
    </div>
    <?php
}

function render_overview(): void {
    $status = status();
    $backup_time = $status['last_verified_offsite_at'];
    $restore_time = $status['latest_backup_restore_verified_at'];
    $historical_restore = $status['last_verified_restore_at'];
    $restore_detail = 'The latest Dropbox backup has no completed isolated WordPress restore check.';
    if ($restore_time === null && $historical_restore !== null) {
        $restore_detail .= ' An earlier backup passed an isolated restore on ' . wp_date('M j, Y H:i T', $historical_restore) . '.';
    }
    $backup_size = $status['last_verified_offsite_size_bytes'];
    $daily = daily_backup_settings(get_plan());
    $cards = [
        ['notice-success', 'Website Backup is active', 'Open Setup to review the saved backup plan.'],
        $backup_time === null
            ? ['notice-error', 'No verified Dropbox backup', 'No real site archive has been verified in Dropbox.']
            : ['notice-success', 'Dropbox backup verified', 'Verified ' . wp_date('M j, Y H:i T', $backup_time) . '. '
                . ($backup_size === null ? 'The ZIP size is unavailable.' : 'Backup ZIP size is ' . size_format($backup_size, 1) . '.')],
        $restore_time === null
            ? ['notice-warning', 'Isolated restore not verified', $restore_detail]
            : ['notice-success', 'Isolated restore verified', 'The matching Dropbox backup passed its isolated WordPress restore on ' . wp_date('M j, Y H:i T', $restore_time) . '.'],
        $daily['enabled']
            ? ['notice-info', 'Daily full backup enabled', 'The saved backup time is ' . $daily['time'] . ' in the WordPress site timezone.']
            : ['notice-warning', 'Daily full backups are off', 'Turn on the daily full backup in Setup.'],
    ];
    if ($status['daily_schedule'] !== []) {
        $timing = $status['daily_schedule'];
        $cards[3] = $timing['overdue_since'] !== null
            ? ['notice-warning', 'A daily full backup is overdue', 'The next unverified full backup was due ' . wp_date('M j, Y H:i T', $timing['overdue_since']) . '.']
            : ['notice-info', 'Daily full backup scheduled', 'The next full backup is due ' . wp_date('M j, Y H:i T', $timing['next_due_at']) . '.'];
    }
    if ($status['component_schedules'] !== []) {
        $overdue_times = array_filter(array_column($status['component_schedules'], 'overdue_since'), 'is_int');
        $overdue = $overdue_times === [] ? null : min($overdue_times);
        $due = min(array_column($status['component_schedules'], 'next_due_at'));
        $cards[] = $overdue !== null
            ? ['notice-warning', 'A component backup is overdue', 'The earliest unverified component backup was due ' . wp_date('M j, Y H:i T', $overdue) . '.']
            : ['notice-info', 'Component backups are scheduled', 'The next component backup is due ' . wp_date('M j, Y H:i T', $due) . '.'];
    }
    foreach ($cards as [$style, $heading, $detail]) : ?>
        <section class="notice inline <?php echo esc_attr($style); ?>">
            <h2><?php echo esc_html($heading); ?></h2>
            <details><summary>Show details</summary><p><?php echo esc_html($detail); ?></p></details>
        </section>
    <?php endforeach;
    render_component_recovery_points();
    render_backup_job();
    render_backup_recovery();
    render_restore_receipt();
    render_backup_retention();
    render_component_backup_retention();
    render_host_check();
}

/** Show the latest verified recovery point for each component from saved evidence only. */
function render_component_recovery_points(): void {
    $history = get_option(COMPONENT_RECOVERY_STATE_OPTION, []);
    if (!is_array($history)) {
        return;
    }
    $site = home_url();
    $now = time();
    $connected = is_ssl() && dropbox_saved_refresh_token(dropbox_app_key()) !== '';
    $restore_checks = get_option(COMPONENT_RESTORE_OPTION, []);
    $rows = [];
    foreach (COMPONENTS as $component => $label) {
        try {
            $chain = component_recovery_chain($site, $component, $history, $now);
        } catch (\RuntimeException $error) {
            continue;
        }
        if ($chain === []) {
            continue;
        }
        $record = $chain[count($chain) - 1];
        $rows[] = [
            $component, $label,
            isset($record['parent_path']) ? 'Changes since previous backup' : 'Full copy',
            wp_date('M j, Y H:i T', $record['offsite_verified_at']),
            size_format($record['dropbox_objects']['archive']['size'], 1),
            component_restore_check_label($site, $chain, $restore_checks[$component] ?? null, $now),
            $chain,
        ];
    }
    if ($rows === []) {
        return;
    }
    ?>
    <section class="notice notice-success inline">
        <h2>Verified component backups</h2>
        <details>
            <summary>Show details</summary>
            <table class="widefat striped">
                <thead><tr><th scope="col">Component</th><th scope="col">Backup type</th><th scope="col">Verified</th><th scope="col">ZIP size</th><th scope="col">Restore check</th>
                    <?php if ($connected) : ?><th scope="col">Recovery files</th><?php endif; ?></tr></thead>
                <tbody>
                    <?php foreach ($rows as [$component, $label, $type, $verified, $size, $restore_check, $chain]) : ?>
                        <tr><th scope="row"><?php echo esc_html($label); ?></th><td><?php echo esc_html($type); ?></td>
                            <td><?php echo esc_html($verified); ?></td><td><?php echo esc_html($size); ?></td>
                            <td><?php echo esc_html($restore_check); ?></td>
                            <?php if ($connected) : ?>
                                <td><details>
                                    <summary>Download files</summary>
                                    <p>Download both files for each backup in the order shown.</p>
                                    <ol>
                                        <?php foreach ($chain as $point) : ?>
                                            <li>
                                                <?php echo esc_html(wp_date('M j, Y H:i T', $point['offsite_verified_at'])); ?>
                                                <form action="<?php echo esc_url(admin_url('admin-post.php')); ?>" method="post">
                                                    <input type="hidden" name="action" value="pebkac_backup_recovery">
                                                    <input type="hidden" name="component" value="<?php echo esc_attr($component); ?>">
                                                    <input type="hidden" name="point" value="<?php echo esc_attr(component_recovery_download_id($point)); ?>">
                                                    <?php wp_nonce_field('pebkac_backup_recovery'); ?>
                                                    <button class="button" type="submit" name="object" value="archive">ZIP</button>
                                                    <button class="button" type="submit" name="object" value="manifest">Manifest</button>
                                                </form>
                                            </li>
                                        <?php endforeach; ?>
                                    </ol>
                                </details></td>
                            <?php endif; ?>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </details>
    </section>
    <?php
}

function render_setup(): void {
    $plan = get_plan();
    $timezone = wp_timezone();
    $now = time();
    $app = dropbox_app_key();
    $ready = $app !== '' && dropbox_can_encrypt() && is_ssl() && !is_multisite();
    $saved = get_option(DROPBOX_CREDENTIAL_OPTION, false) !== false;
    $connected = dropbox_saved_refresh_token($app) !== '';
    ?>
        <h2>Dropbox</h2>
        <p>Website Backup requests access to its own app folder. Your other Dropbox folders stay outside this connection.</p>
        <?php if ($connected) : ?>
            <p><strong>Dropbox authorization saved.</strong> A backup run will verify that Dropbox accepts the connection.</p>
        <?php else : ?>
            <?php if (in_array($_GET['dropbox'] ?? '', ['failed', 'unavailable'], true)) : ?>
                <p>Dropbox could not be connected. Start again after the app setup is ready.</p>
            <?php endif; ?>
            <form action="<?php echo esc_url(admin_url('admin-post.php')); ?>" method="post">
                <input type="hidden" name="action" value="pebkac_backup_dropbox_connect">
                <?php wp_nonce_field('pebkac_backup_dropbox_connect'); ?>
                <button class="button button-primary" type="submit" <?php disabled(!$ready || $saved); ?>>Connect Dropbox</button>
            </form>
            <?php if (!$ready && home_url() === 'https://pebkac404.com' && !DROPBOX_PEBKAC404_CALLBACK_REGISTERED) : ?>
                <p>Dropbox setup for PEBKAC404 is pending. The Connect Dropbox button will be available after registration.</p>
            <?php elseif (!$ready) : ?>
                <p>Dropbox needs a supported site address, HTTPS and WordPress encryption.</p>
            <?php endif; ?>
            <?php if ($saved) : ?><p>The saved connection can no longer be read.</p><?php endif; ?>
        <?php endif; ?>
        <p>Use a daily full backup or enable the separate component schedules below.</p>
        <?php settings_errors(OPTION); ?>
        <form action="options.php" method="post">
            <?php settings_fields(OPTION); ?>
            <p>
                <label><input type="checkbox" name="pebkac_backup_plan[daily][enabled]" value="1" <?php checked($plan['daily']['enabled']); ?>>
                    Run a full backup every day</label>
                <label for="pebkac-backup-daily-time">at</label>
                <input id="pebkac-backup-daily-time" name="pebkac_backup_plan[daily][time]" type="time"
                    value="<?php echo esc_attr($plan['daily']['time']); ?>" required>
            </p>
            <p><label><input type="checkbox" name="pebkac_backup_plan[daily][retention]" value="1" <?php checked($plan['daily']['retention']); ?>>
                Keep seven daily and four weekly backups. Move older verified copies to Dropbox’s deleted files after a daily backup passes.</label></p>
            <p><label for="pebkac-backup-folder">Dropbox folder for new backups</label></p>
            <input class="regular-text" id="pebkac-backup-folder" name="pebkac_backup_plan[folder]" type="text" aria-describedby="pebkac-backup-folder-help"
                value="<?php echo esc_attr($plan['folder']); ?>" placeholder="<?php echo esc_attr(PILOT_DROPBOX_FOLDER); ?>">
            <p class="description" id="pebkac-backup-folder-help">Choose a path inside Apps › PEBKAC Website Backup in Dropbox. Leave it blank to use <?php echo esc_html(PILOT_DROPBOX_FOLDER); ?>.</p>
            <p><label><input type="checkbox" name="pebkac_backup_plan[component_jobs]" value="1" <?php checked($plan['component_jobs']); ?>>
                Run the enabled component schedules</label></p>
            <p><label><input type="checkbox" name="pebkac_backup_plan[incremental_components]" value="1" <?php checked($plan['incremental_components']); ?>>
                Save only changes between full backups for file components</label></p>
            <p>Schedules use the WordPress site timezone: <?php echo esc_html(wp_timezone_string()); ?>. Day applies to weekly schedules.</p>
            <table class="widefat striped">
                <thead><tr><th scope="col">Component</th><th scope="col">Frequency</th><th scope="col">Time</th><th scope="col">Day</th><th scope="col">Next time in saved plan</th></tr></thead>
                <tbody>
                <?php foreach (COMPONENTS as $key => $label) :
                    $schedule = $plan['schedules'][$key];
                    $preview = backup_schedule_occurrence($schedule, $timezone, $now);
                    $field = 'pebkac_backup_plan[schedules][' . $key . ']';
                    ?>
                    <tr>
                        <th scope="row"><?php echo esc_html($label); ?></th>
                        <td><select aria-label="<?php echo esc_attr($label . ' frequency'); ?>" name="<?php echo esc_attr($field . '[frequency]'); ?>">
                            <?php foreach (['off' => 'Off', 'daily' => 'Daily', 'weekly' => 'Weekly'] as $value => $caption) : ?>
                                <option value="<?php echo esc_attr($value); ?>" <?php selected($schedule['frequency'], $value); ?>><?php echo esc_html($caption); ?></option>
                            <?php endforeach; ?>
                        </select></td>
                        <td><input aria-label="<?php echo esc_attr($label . ' time'); ?>" type="time" required
                            name="<?php echo esc_attr($field . '[time]'); ?>" value="<?php echo esc_attr($schedule['time']); ?>"></td>
                        <td><select aria-label="<?php echo esc_attr($label . ' day'); ?>" name="<?php echo esc_attr($field . '[day]'); ?>">
                            <?php foreach (DAYS as $day) : ?>
                                <option value="<?php echo esc_attr($day); ?>" <?php selected($schedule['day'], $day); ?>><?php echo esc_html($day); ?></option>
                            <?php endforeach; ?>
                        </select></td>
                        <td><?php echo $preview === null ? 'Off' : esc_html(wp_date('D, M j, H:i T', $preview, $timezone)); ?></td>
                    </tr>
                <?php endforeach; ?>
                </tbody>
            </table>
            <?php submit_button('Save backup plan'); ?>
        </form>
    <?php
}

/** Only real, site-bound records may light the Overview cards. */
function verified_evidence($record, string $site, int $now): array {
    if (!is_array($record) || ($record['kind'] ?? null) !== 'site_snapshot' || ($record['site'] ?? null) !== $site) {
        return [];
    }
    $hash = $record['archive_sha256'] ?? null;
    $offsite = $record['offsite_verified_at'] ?? null;
    if (!is_string($hash) || !preg_match('/^[0-9a-f]{64}$/D', $hash) || !is_int($offsite) || $offsite < 1 || $offsite > $now) {
        return [];
    }
    $result = ['kind' => 'site_snapshot', 'site' => $site, 'archive_sha256' => $hash, 'offsite_verified_at' => $offsite];
    $manifest = $record['manifest_sha256'] ?? null;
    $archive_path = $record['archive_path'] ?? null;
    $manifest_path = $record['manifest_path'] ?? null;
    $folder = $record['folder'] ?? PILOT_DROPBOX_FOLDER;
    if ($manifest !== null || $archive_path !== null || $manifest_path !== null) {
        if (!is_string($manifest) || !preg_match('/^[0-9a-f]{64}$/D', $manifest)
            || !is_string($archive_path) || !is_string($manifest_path) || !is_string($folder) || !pilot_recovery_pair($site, $archive_path, $manifest_path, null, $folder)) {
            return [];
        }
        $result += ['manifest_sha256' => $manifest, 'archive_path' => $archive_path, 'manifest_path' => $manifest_path];
        if (isset($record['folder'])) {
            $result['folder'] = $folder;
        }
        $pins = backup_dropbox_object_pins($record['dropbox_objects'] ?? []);
        if ($pins !== []) {
            $result['dropbox_objects'] = $pins;
        }
        $size = $record['archive_size_bytes'] ?? null;
        if (is_int($size) && $size > 0 && $size <= SNAPSHOT_MAX_BYTES + 8 * 1024 * 1024) {
            $result['archive_size_bytes'] = $size;
        }
    }
    $restore = $record['restore'] ?? null;
    $restored = $restore['verified_at'] ?? null;
    if (($restore['archive_sha256'] ?? null) === $hash && ($restore['method'] ?? null) === 'isolated_wordpress'
        && is_int($restored) && $restored >= $offsite && $restored <= $now) {
        $result['restore'] = ['archive_sha256' => $hash, 'method' => 'isolated_wordpress', 'verified_at' => $restored];
    }
    return $result;
}

/** Read-only in-process status for other WordPress plugins such as Website Monitor. */
function status(): array {
    $now = time();
    $plan = get_plan();
    $components = component_backups_enabled($plan)
        ? active_component_backup_status($plan, get_option(BACKUP_SCHEDULE_STATE_OPTION, []), wp_timezone(), $now)
        : [];
    $due = array_filter(array_column($components, 'next_due_at'), 'is_int');
    $overdue = array_filter(array_column($components, 'overdue_since'), 'is_int');
    $site = home_url();
    $proof = verified_evidence(get_option(EVIDENCE_OPTION, []), $site, $now);
    $offsite = $proof['offsite_verified_at'] ?? null;
    $settings = daily_backup_settings($plan);
    $daily = $settings['enabled']
        ? active_daily_backup_status($settings, get_option(DAILY_BACKUP_TIMING_OPTION, []), wp_timezone(), $now, $offsite)
        : [];
    $all_due = $daily !== [] && is_int($daily['next_due_at']) ? array_merge($due, [$daily['next_due_at']]) : $due;
    $all_overdue = $daily !== [] && is_int($daily['overdue_since']) ? array_merge($overdue, [$daily['overdue_since']]) : $overdue;
    $restore = $proof['restore']['verified_at'] ?? null;
    $last_restore = $restore;
    $history = get_option(VERIFIED_BACKUP_HISTORY_OPTION, []);
    if (is_array($history)) {
        foreach ($history as $record) {
            $historical = verified_evidence($record, $site, $now);
            $checked = $historical['restore']['verified_at'] ?? null;
            if (isset($historical['manifest_path']) && $checked !== null && ($last_restore === null || $checked > $last_restore)) {
                $last_restore = $checked;
            }
        }
    }
    $size = $proof['archive_size_bytes'] ?? null;
    if ($size === null && isset($proof['manifest_path']) && dropbox_can_encrypt() && dropbox_app_key() !== '') {
        try {
            $size = verified_job_archive_size(read_backup_job(backup_job_root()), $proof);
        } catch (\RuntimeException $error) {
            // A legacy backup still has valid off-site evidence if its private job record is unavailable.
        }
    }
    return [
        'plugin_version' => VERSION,
        'state' => $restore !== null ? 'restore_verified' : ($offsite !== null ? 'offsite_verified' : 'setup_only'),
        'next_due_at' => $all_due === [] ? null : min($all_due),
        'oldest_overdue_at' => $all_overdue === [] ? null : min($all_overdue),
        'component_schedules' => $components,
        'daily_schedule' => $daily,
        'last_verified_offsite_at' => $offsite,
        'last_verified_offsite_size_bytes' => $size,
        'last_verified_restore_at' => $last_restore,
        'latest_backup_restore_verified_at' => $restore,
    ];
}

if (defined('WP_CLI') && WP_CLI) {
    \WP_CLI::add_command('website-backup record-evidence', __NAMESPACE__ . '\\record_evidence_command', [
        'shortdesc' => 'Record verified backup and restore evidence from a private file.',
        'synopsis' => [['type' => 'positional', 'name' => 'receipt']],
    ]);
}

function record_evidence_command(array $arguments): void {
    $path = realpath($arguments[0] ?? '');
    $root = realpath(ABSPATH);
    if ($path === false || $root === false || !is_file($path)
        || stripos(str_replace('\\', '/', $path), rtrim(str_replace('\\', '/', $root), '/') . '/') === 0) {
        \WP_CLI::error('Supply a private receipt file outside the WordPress tree.');
    }
    $bytes = @file_get_contents($path, false, null, 0, 8193);
    $raw = $bytes !== false && strlen($bytes) <= 8192 ? json_decode($bytes, true) : null;
    $site = home_url();
    $now = time();
    $proof = verified_evidence($raw, $site, $now);
    if ($proof === [] || (isset($raw['restore']) && !isset($proof['restore']))) {
        \WP_CLI::error('The verification receipt is invalid for this site.');
    }
    $current = verified_evidence(get_option(EVIDENCE_OPTION, []), $site, $now);
    if ($current !== []) {
        $same_archive = $proof['archive_sha256'] === $current['archive_sha256'];
        if ((!$same_archive && $proof['offsite_verified_at'] <= $current['offsite_verified_at'])
            || ($same_archive && $proof['offsite_verified_at'] !== $current['offsite_verified_at'])
            || ($same_archive && ($proof['restore']['verified_at'] ?? 0) < ($current['restore']['verified_at'] ?? 0))) {
            \WP_CLI::error('This receipt would replace newer verification evidence.');
        }
    }
    if ($proof !== $current && !update_option(EVIDENCE_OPTION, $proof, false)) {
        \WP_CLI::error('Could not save the verification receipt.');
    }
    \WP_CLI::success('Website Backup Overview updated.');
}
