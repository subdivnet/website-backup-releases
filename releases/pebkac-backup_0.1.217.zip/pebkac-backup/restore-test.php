<?php

namespace PEBKAC404\Backup;

const RESTORE_TEST_OPTION = 'pebkac_backup_restore_test';
const RESTORE_TEST_HOOK = 'pebkac_backup_restore_test_step';
const RESTORE_TEST_FOLDER = '/Restore Tests';

function restore_test_path(array $request, string $kind): string {
    $slug = pilot_site_slug($request['site'] ?? '');
    $id = $request['id'] ?? '';
    if ($slug === '' || !is_string($id) || !preg_match('/^[a-f0-9]{32}$/D', $id)
        || !in_array($kind, ['request', 'result'], true)) {
        throw new \RuntimeException('The test restore request is invalid.');
    }
    return RESTORE_TEST_FOLDER . '/' . $slug . '-' . $id . '.' . $kind . '.json';
}

function make_restore_test_request(array $backup, string $site, int $now): array {
    if (pilot_site_slug($site) === '' || ($backup['site'] ?? null) !== $site
        || !isset($backup['archive_path'], $backup['manifest_path'], $backup['archive_sha256'], $backup['manifest_sha256'], $backup['archive_size_bytes'])) {
        throw new \RuntimeException('A verified full backup is required before restoring to a test copy.');
    }
    return ['version' => 1, 'id' => bin2hex(random_bytes(16)), 'site' => $site, 'requested_at' => $now,
        'backup' => array_intersect_key($backup, array_flip(['site', 'archive_path', 'manifest_path', 'archive_sha256',
            'manifest_sha256', 'archive_size_bytes', 'offsite_verified_at']))];
}

function restore_test_pending(array $state): bool {
    return in_array($state['phase'] ?? '', ['folder', 'publish', 'request_check', 'waiting'], true);
}

/** Download a small immutable Dropbox result and bind it to its metadata revision. */
function read_restore_test_json(string $path, string $token): ?array {
    $metadata = fetch_dropbox_metadata($path, $token, 5);
    if ($metadata === null) { return null; }
    if (($metadata['.tag'] ?? '') !== 'file' || !is_int($metadata['size'] ?? null)
        || $metadata['size'] < 1 || $metadata['size'] > 16384 || !valid_dropbox_file_revision($metadata['rev'] ?? null)) {
        throw new \RuntimeException('Dropbox did not confirm a bounded test restore report.');
    }
    $response = wp_remote_post('https://content.dropboxapi.com/2/files/download', [
        'headers' => ['Authorization' => 'Bearer ' . $token, 'Dropbox-API-Arg' => wp_json_encode(['path' => $path])],
        'timeout' => 5, 'redirection' => 0, 'sslverify' => true, 'decompress' => false, 'limit_response_size' => 16385,
    ]);
    if (is_wp_error($response) || wp_remote_retrieve_response_code($response) !== 200) {
        throw new \RuntimeException('The PC test restore report could not be read.');
    }
    $pin = json_decode((string) wp_remote_retrieve_header($response, 'dropbox-api-result'), true);
    $bytes = wp_remote_retrieve_body($response);
    if (($pin['rev'] ?? null) !== $metadata['rev'] || ($pin['path_lower'] ?? null) !== strtolower($path)
        || strlen($bytes) !== $metadata['size'] || strlen($bytes) > 16384
        || hash('sha256', hash('sha256', $bytes, true)) !== ($metadata['content_hash'] ?? null)) {
        throw new \RuntimeException('The test restore report changed while being read.');
    }
    $decoded = json_decode($bytes, true, 12);
    if (!is_array($decoded)) { throw new \RuntimeException('The test restore report is invalid.'); }
    return $decoded;
}

/** Validate the PC's result against the exact request, never a site name alone. */
function validate_restore_test_result(array $request, array $result, int $now): ?array {
    if (($result['version'] ?? null) !== 1 || ($result['id'] ?? null) !== ($request['id'] ?? null)
        || ($result['site'] ?? null) !== ($request['site'] ?? null)
        || ($result['archive_sha256'] ?? null) !== ($request['backup']['archive_sha256'] ?? null)
        || ($result['manifest_sha256'] ?? null) !== ($request['backup']['manifest_sha256'] ?? null)
        || !is_int($result['finished_at'] ?? null) || $result['finished_at'] < $request['requested_at'] || $result['finished_at'] > $now) {
        throw new \RuntimeException('The PC result does not match this test restore request.');
    }
    if (($result['outcome'] ?? null) === 'failed') { return null; }
    if (($result['outcome'] ?? null) !== 'passed' || !is_array($result['receipt'] ?? null)) {
        throw new \RuntimeException('The PC result has no completed restore proof.');
    }
    $receipt = $result['receipt'];
    if (($receipt['site'] ?? null) !== $request['site'] || ($receipt['verified_at'] ?? 0) < $request['requested_at']) {
        throw new \RuntimeException('The restore proof predates this test request.');
    }
    accept_restore_receipt($receipt, $request['backup'], $now);
    return $receipt;
}

function save_restore_test_state(array $state): void {
    if (get_option(RESTORE_TEST_OPTION, []) !== $state && !update_option(RESTORE_TEST_OPTION, $state, false)) {
        throw new \RuntimeException('WordPress could not save the test restore progress.');
    }
}

function queue_restore_test_event(): void {
    if (restore_test_pending((array) get_option(RESTORE_TEST_OPTION, [])) && wp_next_scheduled(RESTORE_TEST_HOOK) === false) {
        wp_schedule_single_event(time() + 60, RESTORE_TEST_HOOK);
    }
}

/** Each step is bounded; an unconfirmed request upload is checked rather than repeated. */
function advance_restore_test_event(): void {
    $state = get_option(RESTORE_TEST_OPTION, []);
    if (!is_array($state) || !restore_test_pending($state)) { return; }
    try {
        with_backup_job_lock(backup_job_root(true), static function (): void {
            $state = get_option(RESTORE_TEST_OPTION, []);
            if (!is_array($state) || !restore_test_pending($state)) { return; }
            $request = $state['request'];
            $path = restore_test_path($request, 'request');
            if ($request['site'] !== home_url()) { throw new \RuntimeException('Wrong test restore site.'); }
            if (time() - $request['requested_at'] > 86400) {
                $state['phase'] = 'failed';
                $state['reason'] = 'expired';
                save_restore_test_state($state);
                return;
            }
            $token = dropbox_connected_access_token();
            if ($state['phase'] === 'folder') {
                $state['folder'] = advance_backup_dropbox_folder(RESTORE_TEST_FOLDER, $state['folder'] ?? [], $token,
                    static function (array $folder) use ($state): void {
                        $state['folder'] = $folder;
                        save_restore_test_state($state);
                    }, 5);
                if (($state['folder']['phase'] ?? null) === 'verified') {
                    $state['phase'] = 'publish';
                    unset($state['folder']);
                }
                save_restore_test_state($state);
            } elseif ($state['phase'] === 'publish') {
                $bytes = wp_json_encode($request);
                if (!is_string($bytes) || strlen($bytes) > 16384) { throw new \RuntimeException('Test restore request is too large.'); }
                $state['phase'] = 'request_check';
                save_restore_test_state($state);
                // Save the intent before transmitting. All later callbacks only read this path.
                wp_remote_post('https://content.dropboxapi.com/2/files/upload', [
                    'headers' => ['Authorization' => 'Bearer ' . $token, 'Content-Type' => 'application/octet-stream',
                        'Dropbox-API-Arg' => wp_json_encode(['path' => $path, 'mode' => 'add', 'autorename' => false, 'strict_conflict' => true, 'mute' => true])],
                    'body' => $bytes, 'timeout' => 5, 'redirection' => 0, 'sslverify' => true, 'limit_response_size' => 4096,
                ]);
            } elseif ($state['phase'] === 'request_check') {
                $saved = read_restore_test_json($path, $token);
                if ($saved !== null) {
                    if ($saved !== $request) { throw new \RuntimeException('A different request occupies the test restore path.'); }
                    $state['phase'] = 'waiting';
                    save_restore_test_state($state);
                }
            } elseif ($state['phase'] === 'waiting') {
                $result = read_restore_test_json(restore_test_path($request, 'result'), $token);
                if ($result !== null) {
                    $receipt = validate_restore_test_result($request, $result, time());
                    if ($receipt !== null) { record_full_restore_receipt($receipt, home_url(), time()); }
                    $state['phase'] = $receipt === null ? 'failed' : 'passed';
                    $state['finished_at'] = $result['finished_at'];
                    unset($state['temporarily_unavailable']);
                    save_restore_test_state($state);
                } elseif (time() - ($state['helper_checked_at'] ?? 0) >= 60) {
                    $state['helper_checked_at'] = time();
                    $helper = read_restore_test_json(RESTORE_TEST_FOLDER . '/helper.json', $token);
                    if (is_array($helper) && ($helper['version'] ?? null) === 1 && ($helper['runtime'] ?? null) === 'website-backup'
                        && in_array('isolated_wordpress', $helper['capabilities'] ?? [], true)
                        && is_int($helper['updated_at'] ?? null) && $helper['updated_at'] <= time()) {
                        $state['helper_seen_at'] = $helper['updated_at'];
                    }
                    save_restore_test_state($state);
                }
            }
        });
    } catch (\Throwable $error) {
        // Preserve the phase, especially an uncertain request upload. Do not expose provider errors.
        $state = get_option(RESTORE_TEST_OPTION, []);
        if (is_array($state) && restore_test_pending($state)) {
            $state['temporarily_unavailable'] = true;
            save_restore_test_state($state);
        }
    }
    queue_restore_test_event();
}

add_action(RESTORE_TEST_HOOK, __NAMESPACE__ . '\\advance_restore_test_event');
add_action('init', __NAMESPACE__ . '\\queue_restore_test_event');

add_action('admin_post_pebkac_backup_test_restore', static function (): void {
    if (!is_ssl() || !current_user_can('manage_options') || ($_SERVER['REQUEST_METHOD'] ?? '') !== 'POST') {
        wp_die('Administrator access over HTTPS is required.', '', ['response' => 403]);
    }
    check_admin_referer('pebkac_backup_test_restore');
    try {
        with_backup_job_lock(backup_job_root(true), static function (): void {
            $state = get_option(RESTORE_TEST_OPTION, []);
            if (is_array($state) && restore_test_pending($state)) { return; }
            $backup = verified_evidence(get_option(EVIDENCE_OPTION, []), home_url(), time());
            save_restore_test_state(['phase' => 'folder', 'request' => make_restore_test_request($backup, home_url(), time())]);
        });
        queue_restore_test_event();
    } catch (\RuntimeException $error) {
        wp_die('A verified full backup and private staging are required for a test restore.', '', ['response' => 409, 'back_link' => true]);
    }
    wp_safe_redirect(admin_url('admin.php?page=pebkac-backup&tab=overview#pebkac-backup-test-restore'));
    exit;
});

function restore_test_message(array $state, bool $same, int $now): string {
    $phase = $state['phase'] ?? '';
    if (in_array($phase, ['folder', 'publish', 'request_check'], true)) { return 'Sending this test restore request to your PC through Dropbox.'; }
    if ($phase === 'waiting') {
        return $now - ($state['helper_seen_at'] ?? 0) <= 360
            ? 'Your PC helper is available. It will restore this backup into a separate disposable WordPress copy.'
            : 'Waiting for the PC restore helper. Keep the PC awake with Dropbox running.';
    }
    if ($phase === 'passed') { return $same ? 'The test copy restored and its home page passed.' : 'An earlier backup passed its test restore.'; }
    if ($phase === 'failed') { return 'The test copy did not pass. Your saved backups remain available.'; }
    return 'Restore this backup to an isolated test copy on your PC.';
}

function render_restore_test(): void {
    $backup = verified_evidence(get_option(EVIDENCE_OPTION, []), home_url(), time());
    if (!isset($backup['archive_size_bytes']) || !is_ssl()) { return; }
    $state = get_option(RESTORE_TEST_OPTION, []);
    $state = is_array($state) ? $state : [];
    $pending = restore_test_pending($state);
    $phase = $state['phase'] ?? '';
    $same = ($state['request']['backup']['archive_sha256'] ?? '') === $backup['archive_sha256'];
    $message = restore_test_message($state, $same, time());
    $style = $phase === 'passed' && $same ? 'notice-success' : ($phase === 'failed' ? 'notice-error' : 'notice-warning');
    ?>
    <section id="pebkac-backup-test-restore" class="notice <?php echo esc_attr($style); ?> inline" data-pending="<?php echo $pending ? '1' : '0'; ?>" data-nonce="<?php echo esc_attr(wp_create_nonce('pebkac_backup_test_restore_status')); ?>">
        <h2>Restore to a test copy</h2>
        <p class="pebkac-restore-test-message" aria-live="polite"><?php echo esc_html($message); ?></p>
        <form method="post" action="<?php echo esc_url(admin_url('admin-post.php')); ?>">
            <input type="hidden" name="action" value="pebkac_backup_test_restore">
            <?php wp_nonce_field('pebkac_backup_test_restore'); ?>
            <button class="button button-primary" type="submit" <?php disabled($pending); ?>><?php echo $pending ? 'Test restore queued' : 'Restore to test copy'; ?></button>
        </form>
        <details><summary>Show details</summary><p>The PC restore helper and Dropbox must be running. The helper checks the exact backup, creates a separate copy in the Linux lab, loads its plugins and home page, then removes the test files. The result appears here automatically.</p></details>
    </section>
    <?php
}

add_action('admin_enqueue_scripts', static function ($page): void {
    if ($page === 'toplevel_page_pebkac-backup') {
        wp_enqueue_script('pebkac-backup-restore-test', plugins_url('restore-test.js', __FILE__), [], VERSION, true);
    }
});
add_action('wp_ajax_pebkac_backup_test_restore_status', static function (): void {
    if (!is_ssl() || !current_user_can('manage_options') || ($_SERVER['REQUEST_METHOD'] ?? '') !== 'POST') {
        wp_send_json_error('Administrator access over HTTPS is required.', 403);
    }
    check_ajax_referer('pebkac_backup_test_restore_status');
    advance_restore_test_event();
    $state = get_option(RESTORE_TEST_OPTION, []);
    $state = is_array($state) ? $state : [];
    wp_send_json_success(['pending' => restore_test_pending($state), 'message' => restore_test_message($state, true, time())]);
});
