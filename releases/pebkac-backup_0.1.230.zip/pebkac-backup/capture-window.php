<?php
namespace PEBKAC404\Backup;

/** Request-local only. Respect a denied extension; always keep our own finite deadline. */
function with_backup_capture_window(callable $capture) {
    $previous=(int)ini_get('max_execution_time');
    $changed=false;
    if($previous>0 && $previous<90 && function_exists('set_time_limit')) {
        try{$changed=@set_time_limit(90)===true;}catch(\Throwable $error){$changed=false;}
    }
    $effective=(int)ini_get('max_execution_time');
    $seconds=$effective===0 ? 60 : max(1,min(60,$effective-5));
    $window=['normal_seconds'=>$previous,'effective_seconds'=>$effective,'capture_seconds'=>$seconds,
        'extended'=>$previous>0 && $effective>$previous];
    try{return $capture(microtime(true)+$seconds,$window);}
    finally{
        if($changed && function_exists('set_time_limit')){
            try{@set_time_limit($previous);}catch(\Throwable $error){/* Request end restores the host default. */}
        }
    }
}
