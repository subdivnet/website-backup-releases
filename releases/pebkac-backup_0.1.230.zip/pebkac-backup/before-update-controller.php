<?php
namespace PEBKAC404\Backup;

require_once __DIR__ . '/pre-update-backup.php';
require_once __DIR__ . '/backup-capture-problem.php';
require_once __DIR__ . '/capture-window.php';

const BEFORE_UPDATE_INDEX = 'before-updates.json';

/** Core uses a download path without hook_extra; inspect the upgrader class as well. */
function before_update_kind($upgrader, array $extra): ?string {
    if ($upgrader instanceof \Core_Upgrader) { return 'core'; }
    if (($extra['action'] ?? 'update') !== 'update') { return null; }
    if (($upgrader instanceof \Plugin_Upgrader || ($extra['type'] ?? '') === 'plugin') && is_string($extra['plugin'] ?? null)) { return 'plugin'; }
    if (($upgrader instanceof \Theme_Upgrader || ($extra['type'] ?? '') === 'theme') && is_string($extra['theme'] ?? null)) { return 'theme'; }
    return null;
}

function before_update_root(bool $create=true): string {
    $parent=backup_temp_parent();
    if ($parent === '') { throw new \RuntimeException('Private rollback storage is unavailable.'); }
    $name='website-backup-before-updates-' . substr(hash_hmac('sha256',home_url(),wp_salt('auth')),0,32);
    return private_backup_work_directory($parent,$name,$create);
}

/** A complete current-state copy is required before returning control to the updater. */
function make_before_update_snapshot(string $kind): array {
    global $wpdb;
    $root=before_update_root();
    return with_backup_job_lock($root,static function () use ($root,$kind,$wpdb): array {
        $path=$root . '/' . BEFORE_UPDATE_INDEX;
        if (is_link($path)) { throw new \RuntimeException('Rollback history contains a link.'); }
        $bytes=is_file($path) && !is_link($path) ? file_get_contents($path,false,null,0,65537) : '[]';
        $history=is_string($bytes) && strlen($bytes)<=65536 ? json_decode($bytes,true) : null;
        if (!is_array($history) || count($history)>7) { throw new \RuntimeException('Rollback history could not be verified.'); }
        foreach ($history as $old) {
            if (!is_array($old) || ($old['site'] ?? null)!==home_url() || !preg_match('/^[a-f0-9]{32}$/D',$old['id'] ?? '')) {
                throw new \RuntimeException('Rollback history belongs to a different site or capture.');
            }
        }
        if (!wordpress_content_uses_standard_path(ABSPATH,WP_CONTENT_DIR)) { throw new \RuntimeException('The current content layout cannot be captured for rollback.'); }
        $id=bin2hex(random_bytes(16));
        $directory=wordpress_capture_directory($root,home_url(),$id);
        $started=microtime(true); $deadline=$started+backup_request_budget();
        $export=new \wpdb(DB_USER,DB_PASSWORD,DB_NAME,DB_HOST);
        try {
            $export->set_prefix($wpdb->prefix);
            start_wordpress_capture($directory,$export,min(12,max(1,$deadline-microtime(true))));
            $copy=with_backup_capture_window(static function(float $capture_deadline,array $window)use($directory,$kind):array {
                update_option('pebkac_backup_capture_window',$window+['at'=>time()],false);
                $copy=capture_pre_update_copy(ABSPATH,$directory.'/database.sql',$directory.'/backup.zip',$kind,$kind==='core'?'':'*',$capture_deadline);
                save_wordpress_capture_manifest($directory.'/backup.zip',$copy['manifest'],$capture_deadline);
                $copy['capture_window_seconds']=$window['capture_seconds'];return $copy;
            });
            $manifest=$copy['manifest'];
            if (!unlink($directory.'/database.sql')) { throw new \RuntimeException('The raw rollback database could not be cleared.'); }
            $record=['schema'=>1,'kind'=>'update_rollback','site'=>home_url(),'id'=>$id,'target_type'=>$kind,
                'created_at'=>time(),'archive_sha256'=>$manifest['archive_sha256'],'manifest_sha256'=>hash_file('sha256',$directory.'/manifest.json'),
                'size_bytes'=>filesize($directory.'/backup.zip'),'duration_seconds'=>(int)ceil(microtime(true)-$started),
                'capture_window_seconds'=>$copy['capture_window_seconds']];
            write_private_backup_record($directory.'/rollback.json',wp_json_encode($record));
            array_unshift($history,$record);
            $retired=array_slice($history,7); $history=array_slice($history,0,7);
            write_private_backup_record($path,wp_json_encode($history));
            // Retire only our known old copy after the new one and its index are durable.
            foreach ($retired as $old) { discard_before_update_copy($root,$old); }
            return $record;
        } catch (\Throwable $error) {
            // A failed capture never becomes a ready rollback record.
            discard_before_update_copy($root,['site'=>home_url(),'id'=>$id]);
            throw $error;
        } finally { $export->close(); }
    });
}

function discard_before_update_copy(string $root, array $record): void {
    if (($record['site'] ?? null)!==home_url() || !preg_match('/^[a-f0-9]{32}$/D',$record['id'] ?? '')) { return; }
    $directory=wordpress_capture_directory($root,home_url(),$record['id']);
    if (!is_dir($directory) || is_link($directory)) { return; }
    $entries=scandir($directory);
    if ($entries===false || array_diff($entries,['.','..','database.sql','backup.zip','manifest.json','rollback.json'])!==[]) { return; }
    foreach (array_diff($entries,['.','..']) as $file) {
        if (is_link($directory.'/'.$file) || !is_file($directory.'/'.$file)) { return; }
    }
    foreach (array_diff($entries,['.','..']) as $file) { if (!@unlink($directory.'/'.$file)) { return; } }
    @rmdir($directory);
}

/** One complete pre-batch copy per update kind; never accept a stale previous-request copy. */
function guard_before_update($reply, $package, $upgrader, array $extra, ?callable $capture=null) {
    if (is_wp_error($reply)) { return $reply; }
    $kind=before_update_kind($upgrader,$extra);
    if ($kind===null) { return $reply; }
    static $captured=[];
    if (!array_key_exists($kind,$captured)) {
        try {
            $record=($capture ?? __NAMESPACE__.'\\make_before_update_snapshot')($kind);
            if (($record['kind'] ?? null)!=='update_rollback' || ($record['target_type'] ?? null)!==$kind
                || ($record['site'] ?? null)!==home_url() || !is_int($record['created_at'] ?? null)
                || $record['created_at']<time()-60 || $record['created_at']>time()
                || !preg_match('/^[a-f0-9]{64}$/D',$record['archive_sha256'] ?? '')
                || !preg_match('/^[a-f0-9]{64}$/D',$record['manifest_sha256'] ?? '')) {
                throw new \RuntimeException('The fresh rollback copy could not be confirmed.');
            }
            $captured[$kind]=true;
            update_option('pebkac_backup_before_update_status',['state'=>'ready']+$record,false);
        } catch (\Throwable $error) {
            $captured[$kind]=false;
            $problem=$error instanceof BackupCaptureProblem ? $error->getCode() : 0;
            update_option('pebkac_backup_before_update_status',['state'=>'failed','target_type'=>$kind,'at'=>time(),'capture_problem'=>$problem],false);
        }
    }
    return $captured[$kind] ? $reply : new \WP_Error('pebkac_backup_before_update_failed',
        'Website Backup could not save the pre-update rollback copy. The update has not started. Open Website Backup Overview to check private storage and host limits.');
}

// Registered only when the checked controller is explicitly loaded by the plugin.
add_filter('upgrader_pre_download',__NAMESPACE__.'\\guard_before_update',1,4);

function render_before_update_backups(): void {
    $status=get_option('pebkac_backup_before_update_status',[]);
    $recorded=is_array($status) && ($status['state']??null)==='ready' && ($status['site']??null)===home_url();
    $ready=$recorded && is_int($status['created_at']??null) && is_int($status['size_bytes']??null)
        && is_string($status['id']??null) && preg_match('/^[a-f0-9]{32}$/D',$status['id']);
    if ($ready) {
        try {
            $directory=wordpress_capture_directory(before_update_root(false),home_url(),$status['id']);
            $ready=!is_link($directory) && is_file($directory.'/backup.zip') && !is_link($directory.'/backup.zip')
                && filesize($directory.'/backup.zip')===$status['size_bytes'] && is_file($directory.'/manifest.json') && !is_link($directory.'/manifest.json');
        } catch (\RuntimeException $error) { $ready=false; }
    }
    $failed=is_array($status) && ($status['state']??null)==='failed';
    $unavailable=$recorded && !$ready;
    $label=$ready ? 'Pre-update rollback copy ready' : ($failed ? 'An update backup needs attention' : ($unavailable ? 'The last local rollback copy is unavailable' : 'Backup before updates is on'));
    ?>
    <section class="notice inline <?php echo $ready ? 'notice-success' : ($failed ? 'notice-error' : ($unavailable ? 'notice-warning' : 'notice-info')); ?>">
        <h2><?php echo esc_html($label); ?></h2>
        <p><?php echo esc_html($ready ? wp_date('M j, Y H:i T',$status['created_at']) . ' · ' . size_format($status['size_bytes'],1)
            : ($failed ? 'A fresh rollback copy could not be saved for an update attempt. Check the update result before retrying.'
            : ($unavailable ? 'Check retained Dropbox backups if the host has cleared its temporary rollback storage.'
            : 'WordPress saves a fresh rollback copy before updating plugins, themes or core.'))); ?></p>
        <details><summary>Show details</summary>
            <p>The quick copy includes the database and the affected file group. Core updates receive a full copy. One copy covers a batch of updates of the same kind.</p>
            <p>These seven recent rollback copies are stored privately on this website. Scheduled backups continue to use Dropbox.</p>
            <?php if ($failed) : ?><p><?php echo esc_html(backup_capture_problem_message($status['capture_problem']??null) ?: 'The previous version did not record a specific cause.'); ?></p><p>Check Host readiness below for private disk space and PHP limits, then retry the update.</p><?php endif; ?>
            <?php if ($ready) : ?>
            <p>Download both files to use the selective recovery tool:</p>
            <?php foreach (['archive'=>'Download rollback ZIP','manifest'=>'Download matching manifest'] as $object=>$button) : ?>
                <form method="post" action="<?php echo esc_url(admin_url('admin-post.php')); ?>">
                    <input type="hidden" name="action" value="pebkac_backup_before_update_download">
                    <input type="hidden" name="point" value="<?php echo esc_attr($status['id']); ?>">
                    <input type="hidden" name="object" value="<?php echo esc_attr($object); ?>">
                    <?php wp_nonce_field('pebkac_backup_before_update_download'); ?>
                    <button class="button" type="submit"><?php echo esc_html($button); ?></button>
                </form>
            <?php endforeach; endif; ?>
        </details>
    </section>
    <?php
}

add_action('admin_post_pebkac_backup_before_update_download',static function (): void {
    if (!is_ssl() || !current_user_can('manage_options') || ($_SERVER['REQUEST_METHOD']??'')!=='POST') {
        wp_die('Administrator access over HTTPS is required.','',['response'=>403]);
    }
    check_admin_referer('pebkac_backup_before_update_download');
    $id=$_POST['point']??''; $object=$_POST['object']??'';
    if (!is_string($id) || !preg_match('/^[a-f0-9]{32}$/D',$id) || !in_array($object,['archive','manifest'],true)) {
        wp_die('Choose a saved rollback copy.','',['response'=>400]);
    }
    try {
        $root=before_update_root();
        with_backup_job_lock($root,static function () use ($root,$id,$object): void {
            $index=$root.'/'.BEFORE_UPDATE_INDEX;
            if (is_link($index) || !is_file($index) || filesize($index)>65536) { throw new \RuntimeException('Rollback history unavailable.'); }
            $records=json_decode(file_get_contents($index),true);
            $record=null;
            foreach (is_array($records)?$records:[] as $entry) {
                if (($entry['id']??null)===$id && ($entry['site']??null)===home_url()) { $record=$entry; break; }
            }
            if ($record===null) { throw new \RuntimeException('The requested rollback copy is no longer retained.'); }
            $directory=wordpress_capture_directory($root,home_url(),$id);
            $file=$directory.($object==='archive'?'/backup.zip':'/manifest.json');
            if (is_link($directory) || is_link($file) || !is_file($file)) { throw new \RuntimeException('Rollback file unavailable.'); }
            $stream=fopen($file,'rb');
            if ($stream===false) { throw new \RuntimeException('Rollback file unavailable.'); }
            try {
                $stat=fstat($stream);
                $maximum=$object==='archive'?SNAPSHOT_MAX_BYTES+8*1024*1024:SNAPSHOT_MAX_MANIFEST_BYTES;
                if ($stat===false || $stat['size']<1 || $stat['size']>$maximum) { throw new \RuntimeException('Rollback file size unavailable.'); }
                [$size,$hash]=snapshot_hash_stream($stream,$stat['size']+1,microtime(true)+backup_request_budget());
                if ($size!==$stat['size'] || !hash_equals($record[$object.'_sha256']??'',$hash) || !rewind($stream)) { throw new \RuntimeException('The rollback file no longer matches its saved checksum.'); }
                nocache_headers(); header('X-Content-Type-Options: nosniff');
                header('Content-Type: '.($object==='archive'?'application/zip':'application/json'));
                header('Content-Length: '.$size);
                header('Content-Disposition: attachment; filename="before-update-'.$id.($object==='archive'?'.zip':'.manifest.json').'"');
                fpassthru($stream);
            } finally { fclose($stream); }
        });
    } catch (\RuntimeException $error) { wp_die('This rollback copy could not be verified for download.','',['response'=>409]); }
    exit;
});
