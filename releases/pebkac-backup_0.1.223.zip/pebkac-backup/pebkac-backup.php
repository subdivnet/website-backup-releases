<?php
/**
 * Plugin Name: Website Backup
 * Description: Set up backups and see whether this WordPress site has a verified recovery point.
 * Version: 0.1.223
 * Requires at least: 6.0
 * Requires PHP: 7.4
 * Update URI: https://pebkac404.com/wordpress/pebkac-backup/
 */

namespace PEBKAC404\Backup;

if (!defined('ABSPATH')) {
    exit;
}

const VERSION = '0.1.223';
const OPTION = 'pebkac_backup_plan';
const EVIDENCE_OPTION = 'pebkac_backup_evidence';
const COMPONENTS = [
    'database' => 'Database',
    'uploads' => 'Media uploads',
    'plugins' => 'Plugins',
    'themes' => 'Themes',
    'core' => 'WordPress core',
    'configuration' => 'Site configuration',
];
const DAYS = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday'];

require_once __DIR__ . '/dropbox-connection.php';
require_once __DIR__ . '/host-check.php';
require_once __DIR__ . '/database-export.php';
require_once __DIR__ . '/backup-job.php';
require_once __DIR__ . '/backup-email.php';
require_once __DIR__ . '/backup-mail-health.php';
require_once __DIR__ . '/backup-recovery.php';
require_once __DIR__ . '/component-readback.php';
require_once __DIR__ . '/restore-receipt.php';
require_once __DIR__ . '/restore-test.php';
require_once __DIR__ . '/backup-schedule.php';
require_once __DIR__ . '/parked-daily-readback.php';
require_once __DIR__ . '/backup-daily.php';
require_once __DIR__ . '/backup-retention.php';
require_once __DIR__ . '/overview-facts.php';
require_once __DIR__ . '/backup-fleet.php';
require_once __DIR__ . '/monitor-recovery.php';
require_once __DIR__ . '/monitor-admin-link.php';
require_once __DIR__ . '/before-update-controller.php';
require_once __DIR__ . '/backup-fleet-dropbox.php';
require_once __DIR__ . '/backup-fleet-refresh.php';
require_once __DIR__ . '/backup-release.php';

if (is_file(__DIR__ . '/release-public-key.php')) {
    $release_key = require __DIR__ . '/release-public-key.php';
    register_backup_release_hooks(
        ['origin' => backup_release_origin_for_site(home_url()), 'public_key' => $release_key],
        VERSION,
        __NAMESPACE__ . '\\backup_update_work_directory'
    );
    add_filter('auto_update_plugin', __NAMESPACE__ . '\\enable_pilot_backup_auto_update', 10, 2);
}

add_filter('rest_request_after_callbacks', __NAMESPACE__ . '\\add_backup_to_private_monitor_response', 10, 3);

register_deactivation_hook(__FILE__, static function (): void {
    wp_unschedule_hook(MANUAL_BACKUP_HOOK);
    wp_clear_scheduled_hook(DAILY_BACKUP_HOOK);
    wp_clear_scheduled_hook(BACKUP_RETENTION_HOOK);
    wp_clear_scheduled_hook(RESTORE_TEST_HOOK);
    wp_clear_scheduled_hook(COMPONENT_BACKUP_HOOK);
    wp_clear_scheduled_hook(BACKUP_FLEET_REFRESH_HOOK);
    wp_clear_scheduled_hook(FULL_RECOVERY_READBACK_HOOK);
    wp_clear_scheduled_hook(COMPONENT_READBACK_HOOK);
});

function default_plan(): array {
    return [
        'folder' => '',
        'pause_email' => false,
        'result_email' => false,
        'email_recipient' => pilot_site_slug(rtrim(home_url(), '/')) !== '' ? 'jross@subdiv.net' : '',
        'component_jobs' => false,
        'incremental_components' => false,
        'low_resource' => false,
        'daily' => ['enabled' => false, 'time' => '02:00', 'retention' => false],
        'schedules' => array_fill_keys(array_keys(COMPONENTS), [
            'frequency' => 'off',
            'time' => '02:00',
            'day' => 'Monday',
        ]),
    ];
}

function get_plan(): array {
    $saved = get_option(OPTION, []);
    return array_replace_recursive(default_plan(), is_array($saved) ? $saved : []);
}

function validate_plan($input) {
    $plan = default_plan();
    $folder = $input['folder'] ?? null;
    if (!is_string($folder)) {
        return new \WP_Error('invalid_folder', 'Enter a Dropbox folder path.');
    }
    $folder = trim($folder);
    if ($folder !== '' && !valid_backup_dropbox_folder($folder)) {
        return new \WP_Error('invalid_folder', 'Use a folder path such as /Website Backups/Security Lab.');
    }
    $plan['folder'] = $folder;
    $plan['pause_email'] = in_array($input['pause_email'] ?? false, [true, '1'], true);
    $plan['result_email'] = in_array($input['result_email'] ?? false, [true, '1'], true);
    if (isset($input['email_recipient'])) {
        $recipient = is_string($input['email_recipient']) ? trim($input['email_recipient']) : '';
        if ($recipient !== '' && !is_email($recipient)) { return new \WP_Error('invalid_backup_recipient', 'Enter one valid backup email address.'); }
        $plan['email_recipient'] = $recipient;
    }
    $plan['component_jobs'] = in_array($input['component_jobs'] ?? false, [true, '1'], true);
    $plan['incremental_components'] = in_array($input['incremental_components'] ?? false, [true, '1'], true);
    $plan['low_resource'] = in_array($input['low_resource'] ?? false, [true, '1'], true);

    $daily = $input['daily'] ?? $plan['daily'];
    $time = $daily['time'] ?? null;
    if (!is_string($time) || !preg_match('/^(?:[01][0-9]|2[0-3]):[0-5][0-9]$/D', $time)) {
        return new \WP_Error('invalid_daily_backup', 'Enter a valid time for the daily backup.');
    }
    $plan['daily'] = [
        'enabled' => in_array($daily['enabled'] ?? false, [true, '1'], true),
        'time' => $time,
        'retention' => in_array($daily['retention'] ?? false, [true, '1'], true),
    ];

    foreach (COMPONENTS as $key => $label) {
        $schedule = $input['schedules'][$key] ?? [];
        $frequency = $schedule['frequency'] ?? null;
        $time = $schedule['time'] ?? null;
        $day = $schedule['day'] ?? null;
        if (!in_array($frequency, ['off', 'daily', 'weekly'], true)
            || !is_string($time) || !preg_match('/^(?:[01][0-9]|2[0-3]):[0-5][0-9]$/D', $time)
            || !in_array($day, DAYS, true)) {
            return new \WP_Error('invalid_schedule', 'Review the schedule for ' . $label . '.');
        }
        $plan['schedules'][$key] = compact('frequency', 'time', 'day');
    }
    return $plan;
}

function sanitize_plan($input): array {
    $plan = validate_plan($input);
    if (is_wp_error($plan)) {
        add_settings_error(OPTION, $plan->get_error_code(), $plan->get_error_message());
        return get_plan();
    }
    return $plan;
}

add_action('admin_init', static function () {
    register_setting(OPTION, OPTION, ['sanitize_callback' => __NAMESPACE__ . '\\sanitize_plan']);
});

add_action('admin_menu', static function () {
    add_menu_page('Website Backup', 'Website Backup', 'manage_options', 'pebkac-backup', __NAMESPACE__ . '\\settings_page', 'dashicons-backup');
});

function settings_page(): void {
    if (!current_user_can('manage_options')) {
        return;
    }
    $tabs = ['overview' => 'Overview', 'setup' => 'Setup', 'sites' => 'Sites'];
    $requested = $_GET['tab'] ?? '';
    $active = is_string($requested) && isset($tabs[$requested]) ? $requested : 'overview';
    ?>
    <div class="wrap">
        <h1>Website Backup</h1>
        <nav class="nav-tab-wrapper" aria-label="Website Backup">
            <?php foreach ($tabs as $tab => $label) : ?>
                <a class="nav-tab<?php echo $tab === $active ? ' nav-tab-active' : ''; ?>"
                    <?php if ($tab === $active) : ?>aria-current="page"<?php endif; ?>
                    href="<?php echo esc_url(admin_url('admin.php?page=pebkac-backup&tab=' . $tab)); ?>"><?php echo esc_html($label); ?></a>
            <?php endforeach; ?>
        </nav>
        <?php
        switch ($active) {
            case 'setup':
                render_setup();
                break;
            case 'sites':
                render_backup_sites();
                break;
            default:
                render_overview();
                break;
        }
        ?>
    </div>
    <?php
}

function render_overview(): void {
    $status = status();
    $backup_time = $status['last_verified_offsite_at'];
    $restore_time = $status['latest_backup_restore_verified_at'];
    $historical_restore = $status['last_verified_restore_at'];
    $restore_detail = 'The latest Dropbox backup has no completed isolated WordPress restore check.';
    if ($restore_time === null && $historical_restore !== null) {
        $restore_detail .= ' An earlier backup passed an isolated restore on ' . wp_date('M j, Y H:i T', $historical_restore) . '.';
    }
    $backup_size = $status['last_verified_offsite_size_bytes'];
    $plan = get_plan();
    $daily = daily_backup_settings($plan);
    $cards = [
        dropbox_overview_card(),
        $backup_time === null
            ? ['notice-error', 'No verified full backup', 'WordPress needs to verify a full site ZIP in Dropbox.']
            : ['notice-success', 'Dropbox backup verified', 'Verified ' . wp_date('M j, Y H:i T', $backup_time) . '. '
                . ($backup_size === null ? 'The ZIP size is unavailable.' : 'Backup ZIP size is ' . size_format($backup_size, 1) . '.')],
        $restore_time === null
            ? ['notice-warning', 'Isolated restore not verified', $restore_detail]
            : ['notice-success', 'Isolated restore verified', 'The matching Dropbox backup passed its isolated WordPress restore on ' . wp_date('M j, Y H:i T', $restore_time) . '.'],
        $daily['enabled']
            ? ['notice-info', 'Daily full backup enabled', 'The saved backup time is ' . $daily['time'] . ' in the WordPress site timezone.']
            : ['notice-warning', 'Daily full backups are off', 'Turn on the daily full backup in Setup.'],
    ];
    $site = home_url();
    $now = time();
    $readback = latest_full_recovery_warning($site, $now);
    if ($readback !== []) {
        $readback[2] .= $backup_size === null ? '' : ' Backup ZIP size was ' . size_format($backup_size, 1) . '.';
        $cards[1] = $readback;
        if ($restore_time !== null) {
            $cards[2] = ['notice-warning', 'Restore test passed earlier', 'This backup passed its isolated WordPress restore on '
                . wp_date('M j, Y H:i T', $restore_time) . '. See the Dropbox backup card for the latest recovery file check.'];
        }
    }
    $run_notes = [
        'daily' => ' This backup ran on the daily schedule.',
        'manual' => ' This backup was started from Overview.',
    ];
    $cards[1][2] .= $run_notes[$status['last_verified_offsite_run_type'] ?? ''] ?? '';
    $latest = verified_evidence(get_option(EVIDENCE_OPTION, []), $site, $now);
    if (isset($latest['manifest_path'])) {
        $folder = str_replace('/', ' › ', ltrim(backup_dropbox_folder($latest), '/'));
        $cards[1][2] .= ' Saved in Apps › PEBKAC Website Backup › ' . $folder . ' in Dropbox.';
    }
    if ($status['daily_schedule'] !== []) {
        $timing = $status['daily_schedule'];
        $cards[3] = $timing['overdue_since'] !== null
            ? ['notice-warning', 'A daily full backup is overdue', 'The next unverified full backup was due ' . wp_date('M j, Y H:i T', $timing['overdue_since']) . '.']
            : ['notice-info', 'Daily full backup scheduled', 'The next full backup is due ' . wp_date('M j, Y H:i T', $timing['next_due_at']) . '.'];
    }
    if ($status['component_schedules'] !== []) {
        $overdue = [];
        $upcoming = [];
        foreach ($status['component_schedules'] as $component => $timing) {
            $label = COMPONENTS[$component];
            if ($timing['overdue_since'] !== null) {
                $detail = $label . ' overdue since ' . wp_date('M j, Y H:i T', $timing['overdue_since']) . '.';
                if (isset($timing['retry_at'])) {
                    $detail .= ' Its next attempt is scheduled for ' . wp_date('M j, Y H:i T', $timing['retry_at']) . '.';
                    $reason = backup_capture_problem_message($timing['capture_problem'] ?? null);
                    if ($reason !== '') {
                        $detail .= ' ' . $reason;
                    }
                }
                $overdue[] = $detail;
            } elseif ($timing['next_due_at'] !== null) {
                $upcoming[] = $label . ' due ' . wp_date('M j, Y H:i T', $timing['next_due_at']) . '.';
            }
        }
        $details = implode(' ', array_merge($overdue, $upcoming));
        $cards[] = $overdue !== []
            ? ['notice-warning', count($overdue) === 1 ? 'A component backup is overdue' : 'Component backups are overdue', $details]
            : ['notice-info', 'Component backups are scheduled', $details];
    }
    $component_chains = null;
    if (component_only_backups_enabled($plan)) {
        unset($cards[3]);
        $history = get_option(COMPONENT_RECOVERY_STATE_OPTION, []);
        $component_chains = available_component_recovery_chains($site, is_array($history) ? $history : [], $now);
        if ($backup_time === null) {
            unset($cards[1], $cards[2]);
            if ($component_chains === []) {
                $cards[1] = ['notice-warning', 'Waiting for the first component backup',
                    'WordPress will show the backup and its size after Dropbox confirms the first scheduled component.'];
            }
        }
    }
    $visible_facts = [
        1 => $backup_time === null ? 'No completed backup yet' : wp_date('M j, Y H:i T', $backup_time) . ($backup_size === null ? '' : ' · ' . size_format($backup_size, 1)),
        2 => $restore_time === null ? 'The latest backup has not passed a test restore' : wp_date('M j, Y H:i T', $restore_time),
        3 => empty($status['daily_schedule']['next_due_at']) ? ($daily['enabled'] ? 'Next run needs checking' : 'No daily backup scheduled') : wp_date('M j, Y H:i T', $status['daily_schedule']['next_due_at']),
    ];
    foreach ($cards as $card_index => [$style, $heading, $detail]) : ?>
        <section class="notice inline <?php echo esc_attr($style); ?>">
            <h2><?php echo esc_html($heading); ?></h2>
            <?php if (isset($visible_facts[$card_index])) : ?><p><?php echo esc_html($visible_facts[$card_index]); ?></p><?php endif; ?>
            <details><summary>Show details</summary><p><?php echo esc_html($detail); ?></p></details>
        </section>
    <?php endforeach;
    render_backup_storage();
    render_before_update_backups();
    render_backup_before_problem();
    render_backup_mail_health();
    render_component_recovery_points($component_chains);
    render_backup_job();
    render_backup_recovery();
    render_restore_test();
    render_restore_receipt();
    render_backup_retention();
    render_backup_update_status();
    render_component_backup_retention();
    render_host_check();
}

/** Show the latest verified recovery point for each component from saved evidence only. */
function render_component_recovery_points(?array $chains = null): void {
    $site = home_url();
    $now = time();
    if ($chains === null) {
        $history = get_option(COMPONENT_RECOVERY_STATE_OPTION, []);
        $chains = available_component_recovery_chains($site, is_array($history) ? $history : [], $now);
    }
    if ($chains === []) {
        return;
    }
    $connected = is_ssl() && dropbox_saved_refresh_token(dropbox_app_key()) !== '';
    $restore_checks = get_option(COMPONENT_RESTORE_OPTION, []);
    $earlier_checks = get_option(COMPONENT_EARLIER_RESTORE_OPTION, []);
    $file_checks = component_readback_records();
    $rows = [];
    $verified_times = [];
    $file_states = [];
    foreach ($chains as $component => $chain) {
        $label = COMPONENTS[$component];
        $record = $chain[count($chain) - 1];
        $verified_times[] = $record['offsite_verified_at'];
        $check = $restore_checks[$component] ?? null;
        $earlier_check = $earlier_checks[$component] ?? null;
        if (($check['archive_path'] ?? null) !== $record['archive_path']
            && ($earlier_check['verified_at'] ?? 0) > ($check['verified_at'] ?? 0)) {
            $check = $earlier_check;
        }
        $file_check = component_readback_status($chain, $file_checks[$component] ?? []);
        $file_states[] = $file_check['previous']['state'] ?? $file_check['state'] ?? '';
        $rows[] = [
            $component, $label,
            isset($record['parent_path']) ? 'Changes since previous backup' : 'Full copy',
            wp_date('M j, Y H:i T', $record['offsite_verified_at']),
            size_format($record['dropbox_objects']['archive']['size'], 1),
            component_restore_check_label($site, $chain, $check, $now),
            $chain,
            $file_check,
        ];
    }
    $earliest = min($verified_times);
    $latest = max($verified_times);
    $card = ['notice-success', 'Verified component backups'];
    $file_warning = component_readback_warning($file_states);
    if ($file_warning === 'changed') {
        $card = ['notice-error', 'Component recovery files are missing or changed'];
    } elseif ($file_warning === 'unavailable') {
        $card = ['notice-warning', 'Dropbox could not confirm component recovery files'];
    }
    ?>
    <section id="pebkac-backup-components" class="notice <?php echo esc_attr($card[0]); ?> inline">
        <h2><?php echo esc_html($card[1]); ?></h2>
        <details<?php if (isset($_GET['component_point']) || isset($_GET['component_readback'])) : ?> open<?php endif; ?>>
            <summary>Show details</summary>
            <?php if ($earliest < $latest) : ?>
                <p><?php echo esc_html('The latest component copies were verified at different times. The oldest was verified on '
                    . wp_date('M j, Y H:i:s T', $earliest) . ' and the newest on ' . wp_date('M j, Y H:i:s T', $latest) . '.'); ?></p>
            <?php endif; ?>
            <?php if ($connected) : ?>
                <form action="<?php echo esc_url(admin_url('admin-post.php')); ?>" method="post">
                    <input type="hidden" name="action" value="pebkac_backup_component_recovery_plan">
                    <input type="hidden" name="plan" value="<?php echo esc_attr(component_recovery_plan_id(component_recovery_plan($site, $chains))); ?>">
                    <?php wp_nonce_field('pebkac_backup_component_recovery_plan'); ?>
                    <p><button class="button" type="submit">Download recovery plan</button></p>
                </form>
            <?php endif; ?>
            <table class="widefat striped">
                <thead><tr><th scope="col">Component</th><th scope="col">Backup type</th><th scope="col">Verified</th><th scope="col">ZIP size</th><th scope="col">Restore check</th>
                    <?php if ($connected) : ?><th scope="col">Recovery files</th><?php endif; ?></tr></thead>
                <tbody>
                    <?php foreach ($rows as [$component, $label, $type, $verified, $size, $restore_check, $chain, $file_check]) : ?>
                        <tr><th scope="row"><?php echo esc_html($label); ?></th><td><?php echo esc_html($type); ?></td>
                            <td><?php echo esc_html($verified); ?></td><td><?php echo esc_html($size); ?></td>
                            <td><?php echo esc_html($restore_check); ?></td>
                            <?php if ($connected) : ?>
                                <td><details>
                                    <summary>Recovery files</summary>
                                    <?php render_component_readback($component, $chain, $file_check); ?>
                                    <p>Download both files for each backup in the order shown.</p>
                                    <?php render_component_download_files($component, $chain); ?>
                                </details></td>
                            <?php endif; ?>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
            <?php if ($connected) { render_earlier_component_recovery($site, $history, $now); } ?>
        </details>
    </section>
    <?php
}

function render_component_download_files(string $component, array $chain): void {
    ?>
    <ol>
        <?php foreach ($chain as $point) : ?>
            <li>
                <?php echo esc_html(wp_date('M j, Y H:i T', $point['offsite_verified_at'])); ?>
                <form action="<?php echo esc_url(admin_url('admin-post.php')); ?>" method="post">
                    <input type="hidden" name="action" value="pebkac_backup_recovery">
                    <input type="hidden" name="component" value="<?php echo esc_attr($component); ?>">
                    <input type="hidden" name="point" value="<?php echo esc_attr(recovery_download_id($point)); ?>">
                    <?php wp_nonce_field('pebkac_backup_recovery'); ?>
                    <button class="button" type="submit" name="object" value="archive">ZIP</button>
                    <button class="button" type="submit" name="object" value="manifest">Manifest</button>
                </form>
            </li>
        <?php endforeach; ?>
    </ol>
    <?php
}

function render_earlier_component_recovery(string $site, array $history, int $now): void {
    try {
        $kept = retained_component_recovery_records($site, $history, $now);
    } catch (\RuntimeException $error) {
        return;
    }
    $choices = [];
    foreach (array_diff_key($kept, array_flip($history['latest'])) as $record) {
        $choices[recovery_download_id($record)] = $record;
    }
    if ($choices === []) {
        return;
    }
    $asked = $_GET['component_point'] ?? '';
    $picked = is_string($asked) && isset($choices[$asked]) ? $asked : '';
    $chain = [];
    if ($picked !== '') {
        try {
            $chain = retained_component_chain_at($site, $picked, $history, $kept, $now);
        } catch (\RuntimeException $error) {
            // The selector remains available when the requested chain no longer verifies.
        }
    }
    ?>
    <h3>Earlier component backups</h3>
    <form action="<?php echo esc_url(admin_url('admin.php')); ?>" method="get">
        <input type="hidden" name="page" value="pebkac-backup">
        <label for="pebkac-backup-component-point">Recovery point</label>
        <select id="pebkac-backup-component-point" name="component_point" required>
            <option value="">Choose a backup</option>
            <?php foreach ($choices as $id => $record) : ?>
                <option value="<?php echo esc_attr($id); ?>" <?php selected($picked, $id); ?>>
                    <?php echo esc_html(COMPONENTS[$record['component']] . ' · ' . wp_date('M j, Y H:i:s T', $record['offsite_verified_at'])); ?>
                </option>
            <?php endforeach; ?>
        </select>
        <button class="button" type="submit">Show recovery files</button>
    </form>
    <?php if ($chain !== []) : ?>
        <?php
        $component = $chain[0]['component'];
        $selected_path = $chain[count($chain) - 1]['archive_path'];
        $check = null;
        foreach ([COMPONENT_RESTORE_OPTION, COMPONENT_EARLIER_RESTORE_OPTION] as $option) {
            $saved = get_option($option, []);
            $result = $saved[$component] ?? null;
            if (($result['archive_path'] ?? null) === $selected_path && ($result['verified_at'] ?? 0) > ($check['verified_at'] ?? 0)) {
                $check = $result;
            }
        }
        ?>
        <p><?php echo esc_html(component_restore_check_label($site, $chain, $check, $now)); ?></p>
        <p>Download both files for each backup in the order shown.</p>
        <form action="<?php echo esc_url(admin_url('admin-post.php')); ?>" method="post">
            <input type="hidden" name="action" value="pebkac_backup_component_recovery_plan">
            <input type="hidden" name="earlier" value="<?php echo esc_attr($picked); ?>">
            <input type="hidden" name="plan" value="<?php echo esc_attr(component_recovery_plan_id(component_recovery_plan($site, [$component => $chain]))); ?>">
            <?php wp_nonce_field('pebkac_backup_component_recovery_plan'); ?>
            <button class="button" type="submit">Download this recovery plan</button>
        </form>
        <?php render_component_download_files($component, $chain); ?>
    <?php elseif ($asked !== '') : ?>
        <p>The selected recovery point is no longer available.</p>
    <?php endif;
}

function render_setup(): void {
    $plan = get_plan();
    $timezone = wp_timezone();
    $now = time();
    $site = home_url();
    $host = parse_url($site, PHP_URL_HOST);
    $prefix = pilot_site_slug($site);
    $destination = 'Apps › PEBKAC Website Backup';
    try {
        $destination .= ' › ' . ltrim(backup_dropbox_folder($plan), '/');
    } catch (\RuntimeException $error) {
        // Keep Setup available so the saved folder can be corrected.
    }
    $app = dropbox_app_key();
    $ready = $app !== '' && dropbox_can_encrypt() && is_ssl() && !is_multisite();
    $saved = get_option(DROPBOX_CREDENTIAL_OPTION, false) !== false;
    $connected = dropbox_saved_refresh_token($app) !== '';
    ?>
        <h2>Dropbox</h2>
        <p>Website Backup saves new backups for <strong><?php echo esc_html(is_string($host) ? $host : 'this site'); ?></strong>
            in <strong><?php echo esc_html($destination); ?></strong> in Dropbox.
            <?php if ($prefix !== '') : ?>Files for this site start with <code><?php echo esc_html($prefix . '-'); ?></code>.<?php endif; ?></p>
        <?php if (in_array($_GET['dropbox'] ?? '', ['failed', 'unavailable'], true)) : ?>
            <p>Dropbox authorization could not be saved. Check the app setup and use the account that holds your backups.</p>
        <?php endif; ?>
        <?php if ($connected) : ?>
            <p><strong>Dropbox authorization saved.</strong> A backup run will verify that Dropbox accepts the connection.</p>
        <?php elseif ($saved) : ?>
            <p>The saved Dropbox authorization could not be read.</p>
        <?php endif; ?>
        <?php if (!$ready && $site === 'https://pebkac404.com' && !DROPBOX_PEBKAC404_CALLBACK_REGISTERED) : ?>
            <p>Dropbox setup for PEBKAC404 is pending. The Connect Dropbox button will be available after registration.</p>
        <?php elseif (!$ready && $site === 'https://johnrossillustration.com' && !DROPBOX_ILLUSTRATION_CALLBACK_REGISTERED) : ?>
            <p>Dropbox connection setup for John Ross Illustration needs completion before Connect Dropbox is ready.</p>
        <?php elseif (!$ready) : ?>
            <p>Dropbox needs a supported site address, HTTPS and WordPress encryption.</p>
        <?php endif; ?>
        <?php if ($saved) : ?><details><summary>Reconnect Dropbox</summary>
            <p>Use the Dropbox account that holds your verified backups.</p>
        <?php endif; ?>
        <form action="<?php echo esc_url(admin_url('admin-post.php')); ?>" method="post">
            <input type="hidden" name="action" value="pebkac_backup_dropbox_connect">
            <?php wp_nonce_field('pebkac_backup_dropbox_connect'); ?>
            <?php if ($saved) : ?><input type="hidden" name="reconnect" value="1"><?php endif; ?>
            <button class="button <?php echo $saved ? '' : 'button-primary'; ?>" type="submit" <?php disabled(!$ready); ?>>
                <?php echo $saved ? 'Reconnect Dropbox' : 'Connect Dropbox'; ?>
            </button>
        </form>
        <?php if ($saved) : ?></details><?php endif; ?>
        <p>Use a daily full backup or enable the separate component schedules below.</p>
        <?php settings_errors(OPTION); ?>
        <form action="options.php" method="post">
            <?php settings_fields(OPTION); ?>
            <p>
                <label><input type="checkbox" name="pebkac_backup_plan[daily][enabled]" value="1" <?php checked($plan['daily']['enabled']); ?>>
                    Run a full backup every day</label>
                <label for="pebkac-backup-daily-time">at</label>
                <input id="pebkac-backup-daily-time" name="pebkac_backup_plan[daily][time]" type="time"
                    value="<?php echo esc_attr($plan['daily']['time']); ?>" required>
            </p>
            <p><label><input type="checkbox" name="pebkac_backup_plan[daily][retention]" value="1" <?php checked($plan['daily']['retention']); ?>>
                Keep seven daily and four weekly backups. Move older verified copies to Dropbox’s deleted files after a daily backup passes.</label></p>
            <p><label><input type="checkbox" name="pebkac_backup_plan[result_email]" value="1" <?php checked($plan['result_email']); ?>>
                Email the backup recipient after each backup succeeds, retries automatically or needs attention.</label></p>
            <p><label for="pebkac-backup-email-recipient">Backup email recipient</label><br>
                <input type="email" class="regular-text" id="pebkac-backup-email-recipient" name="pebkac_backup_plan[email_recipient]" value="<?php echo esc_attr($plan['email_recipient']); ?>" placeholder="WordPress administrator email"></p>
            <p><label><input type="checkbox" name="pebkac_backup_plan[pause_email]" value="1" <?php checked($plan['pause_email']); ?>>
                Email the backup recipient when a scheduled backup needs review</label></p>
            <p><label for="pebkac-backup-folder">Dropbox folder for new backups</label></p>
            <input class="regular-text" id="pebkac-backup-folder" name="pebkac_backup_plan[folder]" type="text" aria-describedby="pebkac-backup-folder-help"
                value="<?php echo esc_attr($plan['folder']); ?>" placeholder="<?php echo esc_attr(PILOT_DROPBOX_FOLDER); ?>">
            <p class="description" id="pebkac-backup-folder-help">Choose a subfolder for new backups. Leave it blank to use <?php echo esc_html(PILOT_DROPBOX_FOLDER); ?>.</p>
            <p><label><input type="checkbox" name="pebkac_backup_plan[component_jobs]" value="1" <?php checked($plan['component_jobs']); ?>>
                Run the enabled component schedules</label></p>
            <p><label><input type="checkbox" name="pebkac_backup_plan[low_resource]" value="1" <?php checked($plan['low_resource']); ?>>
                Low-resource mode: add breaks between backup steps</label></p>
            <p class="description">Reduces bursts of activity during manual backups and takes longer. Scheduled steps already run apart. Coverage, memory limits and verification stay the same.</p>
            <p><label><input type="checkbox" name="pebkac_backup_plan[incremental_components]" value="1" <?php checked($plan['incremental_components']); ?>>
                Save only changes between full backups for file components</label></p>
            <p>Schedules use the WordPress site timezone: <?php echo esc_html(wp_timezone_string()); ?>. Day applies to weekly schedules.</p>
            <table class="widefat striped">
                <thead><tr><th scope="col">Component</th><th scope="col">Frequency</th><th scope="col">Time</th><th scope="col">Day</th><th scope="col">Next time in saved plan</th></tr></thead>
                <tbody>
                <?php foreach (COMPONENTS as $key => $label) :
                    $schedule = $plan['schedules'][$key];
                    $preview = backup_schedule_occurrence($schedule, $timezone, $now);
                    $field = 'pebkac_backup_plan[schedules][' . $key . ']';
                    ?>
                    <tr>
                        <th scope="row"><?php echo esc_html($label); ?></th>
                        <td><select aria-label="<?php echo esc_attr($label . ' frequency'); ?>" name="<?php echo esc_attr($field . '[frequency]'); ?>">
                            <?php foreach (['off' => 'Off', 'daily' => 'Daily', 'weekly' => 'Weekly'] as $value => $caption) : ?>
                                <option value="<?php echo esc_attr($value); ?>" <?php selected($schedule['frequency'], $value); ?>><?php echo esc_html($caption); ?></option>
                            <?php endforeach; ?>
                        </select></td>
                        <td><input aria-label="<?php echo esc_attr($label . ' time'); ?>" type="time" required
                            name="<?php echo esc_attr($field . '[time]'); ?>" value="<?php echo esc_attr($schedule['time']); ?>"></td>
                        <td><select aria-label="<?php echo esc_attr($label . ' day'); ?>" name="<?php echo esc_attr($field . '[day]'); ?>">
                            <?php foreach (DAYS as $day) : ?>
                                <option value="<?php echo esc_attr($day); ?>" <?php selected($schedule['day'], $day); ?>><?php echo esc_html($day); ?></option>
                            <?php endforeach; ?>
                        </select></td>
                        <td><?php echo $preview === null ? 'Off' : esc_html(wp_date('D, M j, H:i T', $preview, $timezone)); ?></td>
                    </tr>
                <?php endforeach; ?>
                </tbody>
            </table>
            <?php submit_button('Save backup plan'); ?>
        </form>
    <?php
}

/** Only real, site-bound records may light the Overview cards. */
function verified_evidence($record, string $site, int $now): array {
    if (!is_array($record) || ($record['kind'] ?? null) !== 'site_snapshot' || ($record['site'] ?? null) !== $site) {
        return [];
    }
    $hash = $record['archive_sha256'] ?? null;
    $offsite = $record['offsite_verified_at'] ?? null;
    if (!is_string($hash) || !preg_match('/^[0-9a-f]{64}$/D', $hash) || !is_int($offsite) || $offsite < 1 || $offsite > $now) {
        return [];
    }
    $result = ['kind' => 'site_snapshot', 'site' => $site, 'archive_sha256' => $hash, 'offsite_verified_at' => $offsite];
    $manifest = $record['manifest_sha256'] ?? null;
    $archive_path = $record['archive_path'] ?? null;
    $manifest_path = $record['manifest_path'] ?? null;
    $folder = $record['folder'] ?? PILOT_DROPBOX_FOLDER;
    if ($manifest !== null || $archive_path !== null || $manifest_path !== null) {
        if (!is_string($manifest) || !preg_match('/^[0-9a-f]{64}$/D', $manifest)
            || !is_string($archive_path) || !is_string($manifest_path) || !is_string($folder) || !pilot_recovery_pair($site, $archive_path, $manifest_path, null, $folder)) {
            return [];
        }
        $result += ['manifest_sha256' => $manifest, 'archive_path' => $archive_path, 'manifest_path' => $manifest_path];
        if (isset($record['folder'])) {
            $result['folder'] = $folder;
        }
        $pins = backup_dropbox_object_pins($record['dropbox_objects'] ?? []);
        if ($pins !== []) {
            $result['dropbox_objects'] = $pins;
        }
        $size = $record['archive_size_bytes'] ?? null;
        if (is_int($size) && $size > 0 && $size <= SNAPSHOT_MAX_BYTES + 8 * 1024 * 1024) {
            $result['archive_size_bytes'] = $size;
        }
        if (in_array($record['run_type'] ?? null, ['daily', 'manual'], true)) {
            $result['run_type'] = $record['run_type'];
        }
    }
    $restore = $record['restore'] ?? null;
    $restored = $restore['verified_at'] ?? null;
    if (($restore['archive_sha256'] ?? null) === $hash && ($restore['method'] ?? null) === 'isolated_wordpress'
        && is_int($restored) && $restored >= $offsite && $restored <= $now) {
        $result['restore'] = ['archive_sha256' => $hash, 'method' => 'isolated_wordpress', 'verified_at' => $restored];
    }
    return $result;
}

/** Read-only in-process status for other WordPress plugins such as Website Monitor. */
function status(): array {
    $now = time();
    $plan = get_plan();
    $components = component_backups_enabled($plan)
        ? active_component_backup_status($plan, get_option(BACKUP_SCHEDULE_STATE_OPTION, []), wp_timezone(), $now)
        : [];
    $due = array_filter(array_column($components, 'next_due_at'), 'is_int');
    $overdue = array_filter(array_column($components, 'overdue_since'), 'is_int');
    $site = home_url();
    $proof = verified_evidence(get_option(EVIDENCE_OPTION, []), $site, $now);
    $offsite = $proof['offsite_verified_at'] ?? null;
    $settings = daily_backup_settings($plan);
    $daily = $settings['enabled']
        ? active_daily_backup_status($settings, get_option(DAILY_BACKUP_TIMING_OPTION, []), wp_timezone(), $now, $offsite)
        : [];
    $all_due = $daily !== [] && is_int($daily['next_due_at']) ? array_merge($due, [$daily['next_due_at']]) : $due;
    $all_overdue = $daily !== [] && is_int($daily['overdue_since']) ? array_merge($overdue, [$daily['overdue_since']]) : $overdue;
    $restore = $proof['restore']['verified_at'] ?? null;
    $last_restore = $restore;
    $history = get_option(VERIFIED_BACKUP_HISTORY_OPTION, []);
    if (is_array($history)) {
        foreach ($history as $record) {
            $historical = verified_evidence($record, $site, $now);
            $checked = $historical['restore']['verified_at'] ?? null;
            if (isset($historical['manifest_path']) && $checked !== null && ($last_restore === null || $checked > $last_restore)) {
                $last_restore = $checked;
            }
        }
    }
    $size = $proof['archive_size_bytes'] ?? null;
    if ($size === null && isset($proof['manifest_path']) && dropbox_can_encrypt() && dropbox_app_key() !== '') {
        try {
            $size = verified_job_archive_size(read_backup_job(backup_job_root()), $proof);
        } catch (\RuntimeException $error) {
            // A legacy backup still has valid off-site evidence if its private job record is unavailable.
        }
    }
    return [
        'plugin_version' => VERSION,
        'state' => $restore !== null ? 'restore_verified' : ($offsite !== null ? 'offsite_verified' : 'setup_only'),
        'next_due_at' => $all_due === [] ? null : min($all_due),
        'oldest_overdue_at' => $all_overdue === [] ? null : min($all_overdue),
        'component_schedules' => $components,
        'daily_schedule' => $daily,
        'last_verified_offsite_at' => $offsite,
        'last_verified_offsite_size_bytes' => $size,
        'last_verified_offsite_run_type' => $proof['run_type'] ?? null,
        'last_verified_restore_at' => $last_restore,
        'latest_backup_restore_verified_at' => $restore,
    ];
}

if (defined('WP_CLI') && WP_CLI) {
    \WP_CLI::add_command('website-backup record-evidence', __NAMESPACE__ . '\\record_evidence_command', [
        'shortdesc' => 'Record verified backup and restore evidence from a private file.',
        'synopsis' => [['type' => 'positional', 'name' => 'receipt']],
    ]);
}

function record_evidence_command(array $arguments): void {
    $path = realpath($arguments[0] ?? '');
    $root = realpath(ABSPATH);
    if ($path === false || $root === false || !is_file($path)
        || stripos(str_replace('\\', '/', $path), rtrim(str_replace('\\', '/', $root), '/') . '/') === 0) {
        \WP_CLI::error('Supply a private receipt file outside the WordPress tree.');
    }
    $bytes = @file_get_contents($path, false, null, 0, 8193);
    $raw = $bytes !== false && strlen($bytes) <= 8192 ? json_decode($bytes, true) : null;
    $site = home_url();
    $now = time();
    $proof = verified_evidence($raw, $site, $now);
    if ($proof === [] || (isset($raw['restore']) && !isset($proof['restore']))) {
        \WP_CLI::error('The verification receipt is invalid for this site.');
    }
    $current = verified_evidence(get_option(EVIDENCE_OPTION, []), $site, $now);
    if ($current !== []) {
        $same_archive = $proof['archive_sha256'] === $current['archive_sha256'];
        if ((!$same_archive && $proof['offsite_verified_at'] <= $current['offsite_verified_at'])
            || ($same_archive && $proof['offsite_verified_at'] !== $current['offsite_verified_at'])
            || ($same_archive && ($proof['restore']['verified_at'] ?? 0) < ($current['restore']['verified_at'] ?? 0))) {
            \WP_CLI::error('This receipt would replace newer verification evidence.');
        }
    }
    if ($proof !== $current && !update_option(EVIDENCE_OPTION, $proof, false)) {
        \WP_CLI::error('Could not save the verification receipt.');
    }
    \WP_CLI::success('Website Backup Overview updated.');
}
