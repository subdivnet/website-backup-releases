<?php
namespace PEBKAC404\Backup;

/** Resolve only the selected provider. Never return credentials or connection settings. */
function backup_mail_service(): array {
    if (function_exists('fluentMailGetSettings')) {
        try {
            $settings = \fluentMailGetSettings();
            if (($settings['misc']['simulate_emails'] ?? '') === 'yes' || (defined('FLUENTMAIL_SIMULATE_EMAILS') && FLUENTMAIL_SIMULATE_EMAILS)) {
                return ['service'=>false,'provider'=>'simulation'];
            }
            $host = (string) parse_url(home_url(), PHP_URL_HOST);
            $from = apply_filters('wp_mail_from', 'wordpress@' . preg_replace('/^www\./i', '', $host));
            $key = $settings['misc']['default_connection'] ?? '';
            foreach (($settings['mappings'] ?? []) as $address=>$mapped) {
                if (is_string($from) && strcasecmp((string)$address, $from) === 0) { $key = $mapped; break; }
            }
            $connection = $settings['connections'][$key] ?? null;
            if (!is_array($connection) && !empty($settings['connections'])) { $connection = reset($settings['connections']); }
            $provider = $connection['provider_settings']['provider'] ?? 'default';
            $allowed = ['smtp','smtp2go','ses','mailgun','sendgrid','sendinblue','postmark','gmail','outlook','sparkpost','elasticmail','pepipost','cloudflare','tosend'];
            return ['service'=>in_array($provider,$allowed,true),'provider'=>in_array($provider,$allowed,true) ? $provider : 'php'];
        } catch (\Throwable $error) { return ['service'=>false,'provider'=>'unknown']; }
    }
    return ['service'=>false,'provider'=>'unconfirmed'];
}

function render_backup_mail_health(): void {
    $mail = backup_mail_service();
    $heading = $mail['service'] ? 'Email sending service configured' : ($mail['provider'] === 'php' ? 'Backup emails are using PHP mail' : 'Backup email sending service needs checking');
    $detail = $mail['service'] ? 'Configured provider: ' . strtoupper($mail['provider']) . '. This confirms configuration, not inbox arrival.'
        : 'Backup emails may be filtered as spam. In Settings → FluentSMTP, add your existing SMTP2GO connection, select it as the default and send a test. Installing FluentSMTP alone does not change PHP mail.';
    ?>
    <section class="notice inline <?php echo $mail['service'] ? 'notice-info' : 'notice-warning'; ?>">
        <h2><?php echo esc_html($heading); ?></h2>
        <p><?php echo esc_html('Backup reports go to ' . backup_mail_recipient() . '.'); ?></p>
        <details><summary>Show details</summary><p><?php echo esc_html($detail); ?></p>
            <p><a href="<?php echo esc_url(admin_url('options-general.php?page=fluent-mail')); ?>">Open FluentSMTP settings</a></p>
        </details>
    </section>
    <?php
}

add_action('rest_api_init', static function (): void {
    register_rest_route('pebkac-backup/v1', '/diagnostics', ['methods'=>'GET','permission_callback'=>static function () { return current_user_can('manage_options'); },
        'callback'=>static function () {
            $summary = ['recipient'=>backup_mail_recipient(),'mail'=>backup_mail_service(),'last_problem'=>get_option('pebkac_backup_last_problem',[])];
            try {
                $job = read_backup_job(backup_job_root());
                $summary['job'] = array_intersect_key($job,array_flip(['id','phase','started_at','daily_date','scheduled_due_at','capture_problem','automatic_capture_retry','last_problem']));
                $summary['capture_reason'] = backup_capture_problem_message($job['capture_problem'] ?? null);
                $summary['email_attempts'] = [];
                foreach (($job['result_email'] ?? []) as $kind=>$attempt) {
                    if (in_array($kind,['verified','failed'],true)) { $summary['email_attempts'][$kind] = array_intersect_key($attempt,array_flip(['attempted_at','accepted'])); }
                }
            } catch (\RuntimeException $error) { $summary['job_unavailable'] = true; }
            return rest_ensure_response($summary);
        }]);
});
