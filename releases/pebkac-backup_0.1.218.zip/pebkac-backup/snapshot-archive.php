<?php

namespace PEBKAC404\Backup;

require_once __DIR__ . '/backup-capture-problem.php';

const SNAPSHOT_MIN_STAGING_BYTES = 32 * 1024 * 1024;
const SNAPSHOT_MAX_BYTES = 1024 * 1024 * 1024;
const SNAPSHOT_MAX_FILES = 20000;
const SNAPSHOT_MAX_MANIFEST_BYTES = 16 * 1024 * 1024;
const SNAPSHOT_COMPONENT_DIRECTORIES = [
    'database' => [],
    'uploads' => ['wp-content/uploads'],
    'plugins' => ['wp-content/plugins', 'wp-content/mu-plugins'],
    'themes' => ['wp-content/themes'],
    'core' => ['wp-admin', 'wp-includes', 'wp-content/languages'],
    'configuration' => [],
];
const SNAPSHOT_CORE_FILES = ['index.php', 'wp-activate.php', 'wp-blog-header.php', 'wp-comments-post.php', 'wp-cron.php', 'wp-links-opml.php', 'wp-load.php', 'wp-login.php', 'wp-mail.php', 'wp-settings.php', 'wp-signup.php', 'wp-trackback.php', 'xmlrpc.php'];
const SNAPSHOT_CONFIGURATION_FILES = ['wp-content/advanced-cache.php', 'wp-content/db.php', 'wp-content/object-cache.php', 'wp-content/sunrise.php'];

function snapshot_staging_bytes(int $source_bytes): int {
    return 2 * $source_bytes + 16 * 1024 * 1024;
}

/** Count the input and fingerprint metadata to catch ordinary changes while ZIP reads it. */
function snapshot_source_state(array $sources, ?float $deadline): array {
    $total = 0;
    $state = hash_init('sha256');
    foreach ($sources as $path) {
        snapshot_deadline($deadline);
        clearstatcache(true, $path);
        $info = @lstat($path);
        if ($info === false || ($info['mode'] & 0170000) !== 0100000 || $info['size'] < 0) {
            throw new \RuntimeException('A source file changed or could not be read.');
        }
        if ($info['size'] > SNAPSHOT_MAX_BYTES - $total) {
            throw new BackupCaptureProblem('The pilot snapshot exceeds its size limit.', BackupCaptureProblem::FILE_LIMIT);
        }
        $total += $info['size'];
        hash_update($state, implode(':', [$info['dev'], $info['ino'], $info['size'], $info['mtime'], $info['ctime']]) . "\n");
    }
    return [$total, hash_final($state)];
}

/** Package a pre-exported SQL dump and selected WordPress files in a new private ZIP. */
function capture_snapshot(string $wordpress, string $database, string $archive, ?float $deadline = null, ?string $component = null): array {
    snapshot_deadline($deadline);
    if ($component !== null && !isset(SNAPSHOT_COMPONENT_DIRECTORIES[$component])) {
        throw new \RuntimeException('Choose a supported backup component.');
    }
    $includes_database = $component === null || $component === 'database';
    $root = realpath($wordpress);
    $parent = realpath(dirname($archive));
    if ($root === false || $parent === false || !is_file($root . '/wp-includes/version.php')
        || ($includes_database && (!is_file($database) || is_link($database) || !filesize($database)))) {
        throw new \RuntimeException('A WordPress tree and any required SQL export must be available.');
    }
    $root_prefix = rtrim(str_replace('\\', '/', $root), '/') . '/';
    $parent_prefix = rtrim(str_replace('\\', '/', $parent), '/') . '/';
    if (stripos($parent_prefix, $root_prefix) === 0) {
        throw new \RuntimeException('Store the archive outside the WordPress tree.');
    }

    $sources = ($includes_database ? ['database.sql' => $database] : []) + snapshot_wordpress_sources($root, $component, $deadline);
    if (count($sources) > SNAPSHOT_MAX_FILES) {
        throw new BackupCaptureProblem('The pilot snapshot exceeds its file count limit.', BackupCaptureProblem::FILE_LIMIT);
    }

    [$total, $source_state] = snapshot_source_state($sources, $deadline);
    if (disk_free_space($parent) < snapshot_staging_bytes($total)) {
        throw new BackupCaptureProblem('Insufficient private staging space for the pilot snapshot.', BackupCaptureProblem::TEMPORARY_SPACE);
    }

    $zip = new \ZipArchive();
    if ($deadline !== null && !method_exists($zip, 'registerCancelCallback')) {
        throw new \RuntimeException('This host cannot bound the ZIP operation safely.');
    }
    if ($zip->open($archive, \ZipArchive::CREATE | \ZipArchive::EXCL) !== true) {
        throw new \RuntimeException('Choose a new private archive path.');
    }
    if ($deadline !== null && !$zip->registerCancelCallback(static function () use ($deadline): int {
        return microtime(true) >= $deadline ? 1 : 0;
    })) {
        throw new \RuntimeException('Could not set the ZIP time limit.');
    }
    if ($component !== null && !$zip->addFromString('component.json', snapshot_component_marker($component))) {
        $zip->close();
        throw new \RuntimeException('Could not label the component archive.');
    }
    foreach ($sources as $name => $path) {
        snapshot_deadline($deadline);
        if (!$zip->addFile($path, $name)) {
            $zip->close();
            throw new \RuntimeException('Could not add a source file to the snapshot.');
        }
        if (!$zip->setCompressionName($name, \ZipArchive::CM_DEFLATE, 1)) {
            $zip->close();
            throw new \RuntimeException('Could not set bounded-cost ZIP compression.');
        }
    }
    if (!$zip->close()) {
        snapshot_deadline($deadline);
        throw new \RuntimeException('Could not finish the snapshot ZIP.');
    }
    try {
        [, $after] = snapshot_source_state($sources, $deadline);
        if (!hash_equals($source_state, $after)) {
            throw new \RuntimeException('A source file changed while WordPress created the backup.');
        }
        return inspect_snapshot($archive, $deadline, $component);
    } catch (\Throwable $error) {
        @unlink($archive);
        throw $error;
    }
}

/** Collect WordPress paths shared by full archives and component scans. */
function snapshot_wordpress_sources(string $root, ?string $component, ?float $deadline): array {
    if (is_link($root . '/wp-content')) {
        throw new \RuntimeException('A required source directory is a symbolic link.');
    }
    $sources = [];
    $directories = $component === null ? array_merge(...array_values(SNAPSHOT_COMPONENT_DIRECTORIES)) : SNAPSHOT_COMPONENT_DIRECTORIES[$component];
    foreach ($directories as $relative) {
        $directory = $root . '/' . $relative;
        if (is_link($directory)) {
            throw new \RuntimeException('A required source directory is a symbolic link.');
        }
        if (!is_dir($directory)) {
            continue;
        }
        $iterator = new \RecursiveIteratorIterator(new \RecursiveDirectoryIterator($directory, \FilesystemIterator::SKIP_DOTS), \RecursiveIteratorIterator::SELF_FIRST);
        foreach ($iterator as $entry) {
            snapshot_deadline($deadline);
            if ($entry->isLink()) {
                throw new \RuntimeException('A backup source contains a symbolic link.');
            }
            if ($entry->isFile()) {
                $path = $entry->getPathname();
                $name = str_replace('\\', '/', substr($path, strlen($root) + 1));
                $sources['wordpress/' . $name] = $path;
                if (count($sources) > SNAPSHOT_MAX_FILES) {
                    throw new BackupCaptureProblem('The pilot snapshot exceeds its file count limit.', BackupCaptureProblem::FILE_LIMIT);
                }
            }
        }
    }
    $root_files = array_merge(
        $component === null || $component === 'core' ? SNAPSHOT_CORE_FILES : [],
        $component === null || $component === 'configuration' ? SNAPSHOT_CONFIGURATION_FILES : []
    );
    foreach ($root_files as $name) {
        $path = $root . '/' . $name;
        if (is_link($path)) {
            throw new \RuntimeException('A WordPress core file is a symbolic link.');
        }
        if (is_file($path)) {
            $sources['wordpress/' . $name] = $path;
        }
    }
    return $sources;
}

function snapshot_component_marker(string $component): string {
    return json_encode(['version' => 1, 'component' => $component]);
}

function snapshot_component_member(string $name, string $component): bool {
    if ($name === 'component.json') {
        return true;
    }
    if ($component === 'database') {
        return $name === 'database.sql';
    }
    foreach (SNAPSHOT_COMPONENT_DIRECTORIES[$component] as $directory) {
        if (strpos($name, 'wordpress/' . $directory . '/') === 0) {
            return true;
        }
    }
    $root_files = $component === 'core' ? SNAPSHOT_CORE_FILES : ($component === 'configuration' ? SNAPSHOT_CONFIGURATION_FILES : []);
    return strpos($name, 'wordpress/') === 0 && in_array(substr($name, strlen('wordpress/')), $root_files, true);
}

function snapshot_deadline(?float $deadline): void {
    if ($deadline !== null && microtime(true) >= $deadline) {
        throw new BackupCaptureProblem('The file backup exceeded the pilot request time limit.', BackupCaptureProblem::FILE_TIME);
    }
}

/** Hash at most the stated bytes, checking the request budget between reads. */
function snapshot_hash_stream($stream, int $limit, ?float $deadline): array {
    $hash = hash_init('sha256');
    $bytes = 0;
    while ($bytes < $limit) {
        snapshot_deadline($deadline);
        $length = min(1024 * 1024, $limit - $bytes);
        $read = hash_update_stream($hash, $stream, $length);
        $bytes += $read;
        if ($read < $length) {
            break;
        }
    }
    snapshot_deadline($deadline);
    return [$bytes, hash_final($hash)];
}

function snapshot_archive_sha256(string $archive, ?float $deadline): string {
    $stream = !is_link($archive) ? @fopen($archive, 'rb') : false;
    if ($stream === false) {
        throw new \RuntimeException('Could not read the snapshot ZIP checksum.');
    }
    try {
        $before = fstat($stream);
        if ($before === false || $before['size'] < 1 || $before['size'] >= PHP_INT_MAX) {
            throw new \RuntimeException('Could not measure the snapshot ZIP.');
        }
        [$bytes, $digest] = snapshot_hash_stream($stream, $before['size'] + 1, $deadline);
        $after = fstat($stream);
        if ($bytes !== $before['size'] || $after === false || $after['size'] !== $before['size']
            || $after['mtime'] !== $before['mtime'] || $after['ctime'] !== $before['ctime']) {
            throw new \RuntimeException('The snapshot ZIP changed during verification.');
        }
        return $digest;
    } finally {
        fclose($stream);
    }
}

function valid_snapshot_member_name(string $name, ?string $component): bool {
    if ($component !== null && $name === 'component.json') {
        return true;
    }
    return preg_match('~^(?:database\.sql|wordpress/[^/]+(?:/[^/]+)*)$~uD', $name) === 1
        && !preg_match('~[\x00-\x1f\x7f:<>"|?*\\\\]|[. ](?:/|$)|(?:^|/)(?:con|prn|aux|nul|com[1-9]|lpt[1-9])(?:[./]|$)~i', $name)
        && strtolower($name) !== 'wordpress/wp-config.php'
        && ($component === null || snapshot_component_member($name, $component));
}

/** Read and hash the completed archive, so the inventory describes the bytes actually captured. */
function inspect_snapshot(string $archive, ?float $deadline = null, ?string $component = null): array {
    snapshot_deadline($deadline);
    if ($component !== null && !isset(SNAPSHOT_COMPONENT_DIRECTORIES[$component])) {
        throw new \RuntimeException('Choose a supported backup component.');
    }
    $zip = new \ZipArchive();
    if ($zip->open($archive, \ZipArchive::RDONLY) !== true) {
        throw new \RuntimeException('Could not open the snapshot ZIP.');
    }
    $files = [];
    $seen = [];
    $total = 0;
    try {
        if ($zip->numFiles > SNAPSHOT_MAX_FILES + 17) {
            throw new \RuntimeException('Snapshot has too many entries.');
        }
        for ($index = 0; $index < $zip->numFiles; $index++) {
            snapshot_deadline($deadline);
            $entry = $zip->statIndex($index);
            $name = $entry['name'] ?? '';
            $key = strtolower($name);
            if (!valid_snapshot_member_name($name, $component)
                || isset($seen[$key]) || ($total += $entry['size']) > SNAPSHOT_MAX_BYTES) {
                throw new \RuntimeException('Snapshot contains an invalid, repeated or oversized entry.');
            }
            $seen[$key] = true;
            $stream = $zip->getStream($name);
            if ($stream === false) {
                throw new \RuntimeException('Could not read a snapshot entry.');
            }
            try {
                [$size, $digest] = snapshot_hash_stream($stream, $entry['size'] + 1, $deadline);
            } finally {
                fclose($stream);
            }
            if ($size !== $entry['size']) {
                throw new \RuntimeException('Snapshot entry size changed during inspection.');
            }
            $files[$name] = ['size' => $size, 'sha256' => $digest];
        }
        if ($component !== null && $zip->getFromName('component.json', 256) !== snapshot_component_marker($component)) {
            throw new \RuntimeException('The archive does not identify the expected backup component.');
        }
    } finally {
        $zip->close();
    }
    if ((($component === null || $component === 'database') && empty($files['database.sql']['size']))
        || (($component === null || $component === 'core') && empty($files['wordpress/wp-includes/version.php']['size']))) {
        throw new \RuntimeException('Snapshot is missing its SQL export or WordPress version file.');
    }
    ksort($files);
    $manifest = ['archive_sha256' => snapshot_archive_sha256($archive, $deadline), 'files' => $files];
    if ($component !== null) {
        $manifest['component'] = $component;
    }
    return $manifest;
}

/** Check free space before writing a verified recovery tree. */
function require_snapshot_restore_space(string $destination, int $bytes): void {
    $parent = realpath(dirname($destination));
    $free = $parent === false ? false : @disk_free_space($parent);
    $required = $bytes + 16 * 1024 * 1024;
    if ((!is_int($free) && !is_float($free)) || !is_finite((float) $free) || $free < $required) {
        throw new \RuntimeException('The restore directory needs more free space for the verified files.');
    }
}

/** Recover a verified snapshot to a fresh private directory, without running PHP or SQL from it. */
function stage_snapshot_restore(string $archive, array $trusted_manifest, string $destination, ?string $component = null, ?float $deadline = null): void {
    if (inspect_snapshot($archive, $deadline, $component) !== $trusted_manifest) {
        throw new \RuntimeException('Downloaded snapshot does not match the trusted capture manifest.');
    }
    require_snapshot_restore_space($destination, array_sum(array_column($trusted_manifest['files'], 'size')));
    if (!@mkdir($destination, 0700)) {
        throw new \RuntimeException('Choose a new isolated restore directory.');
    }
    $zip = new \ZipArchive();
    if ($zip->open($archive, \ZipArchive::RDONLY) !== true) {
        throw new \RuntimeException('Could not reopen the verified snapshot.');
    }
    try {
        foreach ($trusted_manifest['files'] as $name => $expected) {
            extract_verified_backup_member($zip, $name, $expected, $destination, $deadline);
        }
    } finally {
        $zip->close();
    }
}

function extract_verified_backup_member(\ZipArchive $zip, string $name, array $expected, string $destination, ?float $deadline = null): void {
    snapshot_deadline($deadline);
    $target = $destination . '/' . $name;
    $parent = dirname($target);
    if (!is_dir($parent) && !mkdir($parent, 0700, true)) {
        throw new \RuntimeException('Could not make an isolated restore subdirectory.');
    }
    $input = $zip->getStream($name);
    if ($input === false) {
        throw new \RuntimeException('Could not read a snapshot entry for recovery.');
    }
    $output = @fopen($target, 'x+b');
    if ($output === false) {
        fclose($input);
        throw new \RuntimeException('Could not open a snapshot entry for recovery.');
    }
    $verified = false;
    try {
        $written = 0;
        $limit = $expected['size'] + 1;
        while ($written < $limit) {
            snapshot_deadline($deadline);
            $length = min(1024 * 1024, $limit - $written);
            $copied = stream_copy_to_stream($input, $output, $length);
            if ($copied === false) {
                throw new \RuntimeException('Could not write a snapshot entry for recovery.');
            }
            $written += $copied;
            if ($copied < $length) {
                break;
            }
        }
        if ($written !== $expected['size'] || !fflush($output) || !rewind($output)
            || snapshot_hash_stream($output, $limit, $deadline) !== [$expected['size'], $expected['sha256']]) {
            throw new \RuntimeException('Recovered snapshot file does not match its manifest.');
        }
        $verified = true;
    } finally {
        fclose($input);
        fclose($output);
        if (!$verified) {
            @unlink($target);
        }
    }
}
