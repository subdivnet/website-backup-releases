<?php

namespace PEBKAC404\Backup;

function backup_mail_recipient(?array $plan = null): string {
    $recipient = ($plan ?? get_plan())['email_recipient'] ?? '';
    if ($recipient === '') { $recipient = get_option('admin_email', ''); }
    return is_string($recipient) && is_email($recipient) ? $recipient : '';
}

/** Fixed, safe explanations; provider responses and exception text never enter mail. */
function backup_failure_reason(array $job): string {
    if (!empty($job['dropbox_refresh_failed'])) { return 'Dropbox could not refresh the connection needed to start this backup.'; }
    if (!empty($job['dropbox_destination_is_file'])) { return 'A file is occupying the selected Dropbox backup folder.'; }
    if (!empty($job['dropbox_destination_check_failed'])) { return 'Dropbox did not confirm that the selected backup folder was available.'; }
    if (function_exists(__NAMESPACE__ . '\\backup_capture_problem_message')) {
        $capture = backup_capture_problem_message($job['capture_problem'] ?? null);
        if ($capture !== '') { return $capture; }
    }
    if (function_exists(__NAMESPACE__ . '\\backup_job_upload_uncertain') && backup_job_upload_uncertain($job)) {
        return 'Dropbox did not confirm an upload request. That unconfirmed request will not be repeated automatically.';
    }
    $stages = ['database'=>'preparing the database export','exporting'=>'exporting the database','files'=>'preparing the file archive',
        'archiving'=>'capturing the files','plan_transfer'=>'checking the ZIP','folder'=>'checking the Dropbox folder',
        'transfer'=>'uploading or verifying the ZIP','plan_manifest'=>'preparing the recovery manifest','manifest'=>'uploading or verifying the recovery manifest',
        'publish'=>'saving verified backup evidence'];
    return 'The backup stopped while ' . ($stages[$job['phase'] ?? ''] ?? 'advancing its saved progress') . '.';
}

function remember_backup_failure(string $root, array $job): array {
    $retry = function_exists(__NAMESPACE__ . '\\backup_job_can_retry_safely') && backup_job_can_retry_safely($job);
    $problem = ['phase'=>$job['phase'] ?? '', 'reason'=>backup_failure_reason($job),'automatic_retry'=>$retry];
    if (array_intersect_key($job['last_problem'] ?? [], $problem) === $problem) { return $job; }
    $job['last_problem'] = ['at'=>time()] + $problem;
    write_backup_job($root, $job);
    update_option('pebkac_backup_last_problem', ['job_id'=>$job['id']] + $job['last_problem'], false);
    return $job;
}

/** Report a due daily run that cannot even create a backup job. Reserve before mailing. */
function notify_unstarted_daily_backup(array $plan, int $now, string $failure = 'private_staging'): void {
    if (($plan['result_email'] ?? false) !== true || !daily_backup_settings($plan)['enabled']) { return; }
    $timezone = wp_timezone();
    $local = (new \DateTimeImmutable('@' . $now))->setTimezone($timezone);
    $due = backup_schedule_occurrence(['frequency' => 'daily', 'time' => daily_backup_settings($plan)['time']], $timezone,
        $local->setTime(0, 0)->getTimestamp());
    $timing = get_option(DAILY_BACKUP_TIMING_OPTION, []);
    if ($due === null || $due > $now || ($timing['enabled_at'] ?? $now + 1) > $due) { return; }
    $proof = verified_evidence(get_option(EVIDENCE_OPTION, []), home_url(), $now);
    if (isset($proof['offsite_verified_at']) && (new \DateTimeImmutable('@' . $proof['offsite_verified_at']))->setTimezone($timezone)->format('Y-m-d') === $local->format('Y-m-d')) { return; }
    $recipient = backup_mail_recipient($plan);
    if (!is_string($recipient) || !is_email($recipient)) { return; }
    $key = 'pebkac_backup_unstarted_mail_' . $local->format('Ymd');
    if (!add_option($key, ['attempted_at' => $now], '', false)) { return; }
    $accepted = false;
    $reasons = ['host_limits'=>'This host does not provide the bounded ZIP capture needed for a safe backup.',
        'dropbox_not_connected'=>'Dropbox is not connected to this site.',
        'private_staging'=>'WordPress could not open private temporary storage for this backup.'];
    $reason = $reasons[$failure] ?? $reasons['private_staging'];
    try {
        $accepted = (bool) wp_mail($recipient, 'Website Backup: daily backup needs attention — ' . home_url(),
            'Site: ' . home_url() . "\nResult: The scheduled backup could not start.\nReason: " . $reason . "\nNext: Open Overview to check Dropbox and host readiness.\nSize: Not available\nDuration: 0 seconds\nVerified in Dropbox: No\n\n"
            . admin_url('admin.php?page=pebkac-backup&tab=overview'));
    } catch (\Throwable $error) {}
    update_option($key, ['attempted_at' => $now, 'accepted' => $accepted], false);
    delete_option('pebkac_backup_unstarted_mail_' . $local->modify('-7 days')->format('Ymd'));
}

/** Reserve each result before calling mail: an interrupted send must not be repeated. */
function notify_backup_result(string $root, array $job, bool $verified): array {
    if ((get_plan()['result_email'] ?? false) !== true) {
        return $job;
    }
    $result = $verified ? 'verified' : 'failed';
    if (!empty($job['result_email'][$result])) {
        return $job;
    }
    $recipient = backup_mail_recipient();
    if (!is_string($recipient) || !is_email($recipient)) {
        return $job;
    }
    $now = time();
    $started = $job['started_at'] ?? null;
    $duration = is_int($started) && $started > 0 && $started <= $now
        ? ($now - $started) . ' seconds' : 'Not available';
    $bytes = $job['transfer']['size'] ?? null;
    if (!is_int($bytes) || $bytes < 0) {
        $evidence = verified_evidence(get_option(EVIDENCE_OPTION, []), home_url(), $now);
        $bytes = $verified ? verified_job_archive_size($job, $evidence) : null;
    }
    $size = is_int($bytes) && $bytes >= 0 ? $bytes . ' bytes' : 'Not available';
    $retrying = !$verified && ($job['last_problem']['automatic_retry'] ?? false) === true;
    $reason = $job['last_problem']['reason'] ?? backup_failure_reason($job);
    $message = 'Site: ' . home_url() . "\n"
        . 'Run: ' . (isset($job['daily_date']) ? 'Scheduled daily backup' : (isset($job['scheduled_due_at']) ? 'Scheduled component backup' : 'Manual backup')) . "\n"
        . 'Result: ' . ($verified ? 'Backup completed' : ($retrying ? 'Temporary problem; automatic retry queued' : 'Backup paused; needs attention')) . "\n"
        . (!$verified ? 'Reason: ' . $reason . "\nNext: " . ($retrying ? 'WordPress will retry this saved backup automatically.' : 'Open Overview. Unconfirmed upload requests are held and will not be repeated.') . "\n" : '')
        . ($verified && isset($job['last_problem']) ? 'Recovered after: ' . $reason . "\n" : '')
        . 'Size: ' . $size . "\nDuration: " . $duration . "\n"
        . 'Verified in Dropbox: ' . ($verified ? 'Yes' : 'No') . "\n\n"
        . admin_url('admin.php?page=pebkac-backup&tab=overview');
    $job['result_email'][$result] = ['attempted_at' => $now, 'accepted' => null];
    write_backup_job($root, $job);
    try {
        $job['result_email'][$result]['accepted'] = (bool) wp_mail($recipient,
            'Website Backup: ' . ($verified ? 'verified backup' : ($retrying ? 'retrying automatically' : 'backup needs attention')) . ' — ' . home_url(), $message);
    } catch (\Throwable $error) {
        $job['result_email'][$result]['accepted'] = false;
    }
    write_backup_job($root, $job);
    return $job;
}
